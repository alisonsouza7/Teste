import React, { createContext, useContext, useEffect, useState, useCallback, useMemo } from 'react';
import { supabase } from '@/lib/customSupabaseClient';
import { useToast } from '@/components/ui/use-toast';
import { logAuditEvent } from '@/lib/audit';

const AuthContext = createContext(undefined);

const MAX_LOGIN_ATTEMPTS = 5;
const LOCKOUT_TIME_MS = 5 * 60 * 1000; // 5 minutes

export const AuthProvider = ({ children }) => {
  const { toast } = useToast();
  const [user, setUser] = useState(null);
  const [session, setSession] = useState(null);
  const [loading, setLoading] = useState(true);
  const [userRole, setUserRole] = useState(null); // 'admin', 'contador', 'cliente'
  const [isInitialLoad, setIsInitialLoad] = useState(true);

  const fetchUserRole = async (userId) => {
    try {
      const { data, error } = await supabase
        .from('users')
        .select('tipo')
        .eq('id', userId)
        .single();
      
      if (error) {
        console.error('Error fetching user role:', error);
        return 'cliente'; // Fallback
      }
      
      return data?.tipo || 'cliente';
    } catch (error) {
      console.error('Exception fetching user role:', error);
      return 'cliente';
    }
  };

  const validateCompanyStatus = async (userId, role) => {
      // If admin/contador, skip company check
      if (role === 'admin' || role === 'contador') return true;

      const { data, error } = await supabase
          .from('user_company_roles')
          .select('company_id, companies(status)')
          .eq('user_id', userId);
      
      if (error) {
          console.error("Error checking company status", error);
          return true; // Let them in, worst case empty dashboard
      }
      
      if (data && data.length > 0) {
          const pendingCompany = data.find(r => r.companies?.status === 'pending_approval');
          if (pendingCompany) {
              return false; // Found a pending company
          }
      }
      return true;
  };

  const handleSession = useCallback(async (currentSession) => {
    setLoading(true);

    setSession(currentSession);
    const currentUser = currentSession?.user ?? null;
    setUser(currentUser);
    
    if (currentUser) {
      const role = await fetchUserRole(currentUser.id);
      
      // Validate Pending Approval Status
      const isValid = await validateCompanyStatus(currentUser.id, role);
      if (!isValid) {
          await supabase.auth.signOut();
          setUser(null);
          setSession(null);
          setUserRole(null);
          toast({
              variant: "destructive",
              title: "Acesso Pendente",
              description: "Sua conta ainda está aguardando aprovação do administrador."
          });
          setLoading(false);
          return;
      }

      setUserRole(role);
      localStorage.setItem(`user-role-${currentUser.id}`, role);
    } else {
      setUserRole(null);
    }

    setLoading(false);
    if (isInitialLoad) {
      setIsInitialLoad(false);
    }
  }, [isInitialLoad, toast]);

  // Explicit session validation on mount
  useEffect(() => {
    let mounted = true;

    const validateSession = async () => {
      try {
        const { data: { session: initialSession }, error } = await supabase.auth.getSession();
        
        if (!mounted) return;

        if (error) {
          // Handle specific refresh token error
          if (error.message && (
              error.message.includes('Refresh Token Not Found') || 
              error.message.includes('Invalid Refresh Token')
          )) {
            console.warn('Refresh token invalid, clearing session.');
            // Force cleanup
            await supabase.auth.signOut();
            localStorage.removeItem('sb-ztowsmwmtowydnptuzts-auth-token'); // Clean specific project token if known, or rely on signOut
          }
          
          setUser(null);
          setSession(null);
          setUserRole(null);
          setLoading(false);
          setIsInitialLoad(false);
        } else if (!initialSession) {
          setUser(null);
          setSession(null);
          setUserRole(null);
          setLoading(false);
          setIsInitialLoad(false);
        } else {
          await handleSession(initialSession);
        }
      } catch (err) {
        console.error('Session validation error:', err);
        if (mounted) {
          setLoading(false);
          setIsInitialLoad(false);
        }
      }
    };

    validateSession();

    const { data: { subscription } } = supabase.auth.onAuthStateChange(
      async (event, session) => {
        if (event === 'SIGNED_OUT') {
          setUser(null);
          setSession(null);
          setUserRole(null);
          setLoading(false);
        } else if (event === 'SIGNED_IN' || event === 'TOKEN_REFRESHED') {
          await handleSession(session);
        } else if (event === 'USER_UPDATED') {
           await handleSession(session);
        }
      }
    );

    return () => {
      mounted = false;
      subscription.unsubscribe();
    };
  }, [handleSession]);

  // Focus listener for silent re-validation
  useEffect(() => {
    const handleFocus = async () => {
      if (session) {
        const { data: { session: currentSession }, error } = await supabase.auth.getSession();
        if (error) {
             // If error on focus (e.g. token expired while tab away), clear state
             if (error.message && (
                error.message.includes('Refresh Token Not Found') || 
                error.message.includes('Invalid Refresh Token')
            )) {
                await supabase.auth.signOut();
                setUser(null);
                setSession(null);
                setUserRole(null);
            }
        } else if (!currentSession) {
          setUser(null);
          setSession(null);
          setUserRole(null);
        } else if (currentSession.access_token !== session.access_token) {
          await handleSession(currentSession);
        }
      }
    };
    
    window.addEventListener('focus', handleFocus);
    return () => window.removeEventListener('focus', handleFocus);
  }, [session, handleSession]);

  const signUp = useCallback(async (email, password, options) => {
    setLoading(true);
    const { data, error } = await supabase.auth.signUp({
      email,
      password,
      options: {
        ...options,
        emailRedirectTo: window.location.origin,
      },
    });

    if (error) {
      toast({
        variant: 'destructive',
        title: 'Falha no Cadastro',
        description: error.message || 'Não foi possível criar sua conta.',
      });
      await logAuditEvent({ action: 'signup_fail', details: { email, error: error.message } });
    } else if (data.user) {
      await logAuditEvent({ action: 'signup_success', userId: data.user.id, details: { email } });
    }
    setLoading(false);
    return { data, error };
  }, [toast]);

  const signIn = useCallback(async (email, password) => {
    const attemptKey = `login-attempts:${email}`;
    const attemptsData = JSON.parse(localStorage.getItem(attemptKey) || '{"count":0,"timestamp":0}');

    if (Date.now() - attemptsData.timestamp < LOCKOUT_TIME_MS && attemptsData.count >= MAX_LOGIN_ATTEMPTS) {
      toast({
        variant: 'destructive',
        title: 'Acesso Bloqueado Temporariamente',
        description: 'Muitas tentativas de acesso. Tente novamente em alguns minutos.',
      });
      return { error: { message: 'Too many attempts' } };
    }

    const { data, error } = await supabase.auth.signInWithPassword({
      email,
      password,
    });

    if (error) {
      const newCount = Date.now() - attemptsData.timestamp > LOCKOUT_TIME_MS ? 1 : attemptsData.count + 1;
      localStorage.setItem(attemptKey, JSON.stringify({ count: newCount, timestamp: Date.now() }));
      
      // Customize specific errors
      let msg = 'Email ou senha inválidos.';
      if (error.message.includes('not confirmed')) msg = 'Email não confirmado. Verifique sua caixa de entrada.';
      
      toast({
        variant: 'destructive',
        title: 'Falha no Login',
        description: msg,
      });
      await logAuditEvent({ action: 'login_fail', details: { email, attempt: newCount } });
    } else if (data.user) {
      localStorage.removeItem(attemptKey);
      await logAuditEvent({ action: 'login_success', userId: data.user.id, details: { email } });
    }
    
    return { data, error };
  }, [toast]);

  const signOut = useCallback(async () => {
    setLoading(true);
    if (user) {
      await logAuditEvent({ action: 'logout', userId: user.id });
    }
    const { error } = await supabase.auth.signOut();
    if (error) {
      // Even if error, clear local state
      console.error("Error signing out:", error);
    }
    setUser(null);
    setSession(null);
    setUserRole(null);
    setLoading(false);
    return { error };
  }, [user]);

  const value = useMemo(() => ({
    user,
    session,
    loading,
    userRole,
    signUp,
    signIn,
    signOut,
  }), [user, session, loading, userRole, signUp, signIn, signOut]);

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};