import React, { useMemo, useState } from "react";
import { Helmet } from "react-helmet";
import { useCompany } from "@/contexts/CompanyContext";
import { useToast } from "@/components/ui/use-toast";

import ReportsHeader from "@/components/reports/ReportsHeader";
import KpiCards from "@/components/reports/KpiCards";
import ChartsSection from "@/components/reports/ChartsSection";
import FinancialIndexes from "@/components/reports/FinancialIndexes";
import InsightsPanel from "@/components/reports/InsightsPanel";
import DetailedTables from "@/components/reports/DetailedTables";

import { getDefaultReportFilters, buildReportViewModel } from "@/lib/reports/reportsCompute";
import { useReportsData } from "@/hooks/useReportsData";
import { exportReportsToPdfPrint } from "@/lib/reports/reportsExportPdf";

const RelatoriosPage = () => {
  const { selectedCompany } = useCompany();
  const { toast } = useToast();

  const [filters, setFilters] = useState(getDefaultReportFilters());

  const companyId = selectedCompany?.id; // ajuste se seu id for outro campo

  const { loading, error, transactions, meta, refetch } = useReportsData({
    companyId,
    filters,
  });

  const view = useMemo(() => {
    return buildReportViewModel({ transactions, filters, meta });
  }, [transactions, filters, meta]);

  if (!selectedCompany) return null;

  const handleExport = () => {
    try {
      exportReportsToPdfPrint({
        companyName: selectedCompany.nome,
        periodLabel: view.periodLabel,
        containerId: "reports-print-root",
      });
    } catch (e) {
      toast({
        title: "Falha ao exportar",
        description: String(e?.message || e),
      });
    }
  };

  return (
    <>
      <Helmet>
        <title>Relatórios - {selectedCompany.nome}</title>
      </Helmet>

      <style>{`
        @media print {
          body { -webkit-print-color-adjust: exact; print-color-adjust: exact; }
          .no-print { display: none !important; }
          .print-page { break-inside: avoid; page-break-inside: avoid; }
          .print-break { page-break-before: always; }
        }
      `}</style>

      <div className="p-4 md:p-8">
        <div id="reports-print-root" className="rounded-2xl bg-white shadow-sm border">
          <ReportsHeader
            companyName={selectedCompany.nome}
            filters={filters}
            onChangeFilters={setFilters}
            onRefresh={refetch}
            onExport={handleExport}
            loading={loading}
            periodLabel={view.periodLabel}
          />

          <div className="p-4 md:p-6 space-y-6">
            {error ? (
              <div className="rounded-lg border p-4 text-sm text-red-600">
                Erro ao carregar dados: {String(error?.message || error)}
              </div>
            ) : null}

            <div className="print-page">
              <KpiCards kpis={view.kpis} loading={loading} />
            </div>

            <div className="print-page">
              <ChartsSection
                cashflowSeries={view.cashflowSeries}
                expensesByCategory={view.expensesByCategory}
                monthlyResult={view.monthlyResult}
                loading={loading}
              />
            </div>

            <div className="print-page">
              <FinancialIndexes indexes={view.indexes} loading={loading} />
            </div>

            <div className="print-page">
              <InsightsPanel insights={view.insights} loading={loading} />
            </div>

            <div className="print-break" />

            <div className="print-page">
              <DetailedTables
                incomeRows={view.incomeRows}
                expenseRows={view.expenseRows}
                loading={loading}
              />
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default RelatoriosPage;