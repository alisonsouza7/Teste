import React, { useState, useEffect } from 'react';
import { supabase } from '@/lib/customSupabaseClient';
import { useCompany } from '@/contexts/CompanyContext';
import { useToast } from '@/components/ui/use-toast';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from "@/components/ui/button";
import { Download, Calendar as CalendarIcon, Loader2 } from 'lucide-react';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Input } from "@/components/ui/input";
import { format, startOfMonth, endOfMonth, parseISO } from 'date-fns';
import { cn } from "@/lib/utils";
import jsPDF from 'jspdf';
import 'jspdf-autotable';

const FinanceDRE = () => {
  const { selectedCompany } = useCompany();
  const { toast } = useToast();
  const [loading, setLoading] = useState(true);
  const [reportData, setReportData] = useState([]);
  const [totals, setTotals] = useState({ receitas: 0, despesas: 0, resultado: 0 });
  const [dateRange, setDateRange] = useState({
    startDate: format(startOfMonth(new Date()), 'yyyy-MM-dd'),
    endDate: format(endOfMonth(new Date()), 'yyyy-MM-dd')
  });

  const fetchDRE = async () => {
    if (!selectedCompany?.id) return;
    setLoading(true);
    try {
      const { data: transactions, error } = await supabase
        .from('finance_transactions')
        .select(`
           id, 
           valor, 
           tipo, 
           data_competencia,
           finance_chart_of_accounts(nome_conta, grupo, tipo)
        `)
        .eq('company_id', selectedCompany.id)
        .gte('data_competencia', dateRange.startDate)
        .lte('data_competencia', dateRange.endDate)
        .eq('liquidado', true) // DRE usually is by competence, but liquidado check implies 'Realizado'. If 'Competencia' view, remove this check.
                               // Usually DRE is Competencia (Accrual). Fluxo de Caixa is Realizado (Cash).
                               // Assuming Competencia view but only confirmed transactions? Or all?
                               // Standard DRE considers all accrued. Let's remove 'liquidado' check for pure Competencia DRE, 
                               // OR keep it if user wants "Realizado". Let's stick to standard Competencia.
        .is('deleted_at', null);

      if (error) throw error;

      // Process Data
      const groups = {};
      let totalReceita = 0;
      let totalDespesa = 0;

      transactions.forEach(tx => {
          const catName = tx.finance_chart_of_accounts?.nome_conta || 'Sem Categoria';
          const catTipo = tx.tipo; // receita or despesa
          const val = Number(tx.valor);

          if (!groups[catName]) {
             groups[catName] = { 
                 category: catName, 
                 receitas: 0, 
                 despesas: 0, 
                 type: catTipo 
             };
          }

          if (catTipo === 'receita') {
             groups[catName].receitas += val;
             totalReceita += val;
          } else {
             groups[catName].despesas += val; // Store as positive for display, subtract for result
             totalDespesa += val;
          }
      });

      const processedData = Object.values(groups).sort((a,b) => {
          if (a.type === b.type) return a.category.localeCompare(b.category);
          return a.type === 'receita' ? -1 : 1;
      });

      setReportData(processedData);
      setTotals({
          receitas: totalReceita,
          despesas: totalDespesa,
          resultado: totalReceita - totalDespesa
      });

    } catch (error) {
      console.error(error);
      toast({ title: "Erro", description: "Erro ao gerar DRE.", variant: "destructive" });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchDRE();
  }, [selectedCompany?.id, dateRange]);

  const handleExportPDF = () => {
     const doc = new jsPDF();
     doc.text(`Demonstrativo de Resultados - ${selectedCompany?.nome}`, 14, 15);
     doc.text(`Período: ${format(parseISO(dateRange.startDate), 'dd/MM/yyyy')} a ${format(parseISO(dateRange.endDate), 'dd/MM/yyyy')}`, 14, 22);

     const tableColumn = ["Categoria", "Receitas", "Despesas", "Resultado"];
     const tableRows = [];

     reportData.forEach(item => {
        const row = [
            item.category,
            new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(item.receitas),
            new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(item.despesas),
            new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(item.receitas - item.despesas)
        ];
        tableRows.push(row);
     });

     // Totals Row
     tableRows.push([
         "TOTAIS",
         new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(totals.receitas),
         new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(totals.despesas),
         new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(totals.resultado)
     ]);

     doc.autoTable({
        head: [tableColumn],
        body: tableRows,
        startY: 30,
     });

     doc.save(`DRE_${dateRange.startDate}.pdf`);
  };

  const formatCurrency = (val) => new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(val);

  return (
    <div className="space-y-6">
       <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div>
             <h1 className="text-2xl font-bold tracking-tight text-slate-900">Demonstrativo de Resultados (DRE)</h1>
             <p className="text-slate-500">Analise o resultado financeiro detalhado por categoria.</p>
          </div>
          <div className="flex items-center gap-2 w-full md:w-auto">
             <div className="flex items-center gap-2 bg-white border p-1 rounded-md">
                 <CalendarIcon className="h-4 w-4 text-slate-500 ml-2" />
                 <Input 
                    type="date" 
                    value={dateRange.startDate} 
                    onChange={e => setDateRange(prev => ({ ...prev, startDate: e.target.value }))}
                    className="border-0 h-8 w-32 focus-visible:ring-0"
                 />
                 <span className="text-slate-400">-</span>
                 <Input 
                    type="date" 
                    value={dateRange.endDate} 
                    onChange={e => setDateRange(prev => ({ ...prev, endDate: e.target.value }))}
                    className="border-0 h-8 w-32 focus-visible:ring-0"
                 />
             </div>
             <Button variant="outline" onClick={handleExportPDF}>
                 <Download className="mr-2 h-4 w-4" /> PDF
             </Button>
          </div>
       </div>

       {/* Cards Summary */}
       <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
           <Card>
               <CardHeader className="pb-2"><CardTitle className="text-sm font-medium text-emerald-600">Total Receitas</CardTitle></CardHeader>
               <CardContent><div className="text-2xl font-bold">{formatCurrency(totals.receitas)}</div></CardContent>
           </Card>
           <Card>
               <CardHeader className="pb-2"><CardTitle className="text-sm font-medium text-red-600">Total Despesas</CardTitle></CardHeader>
               <CardContent><div className="text-2xl font-bold">{formatCurrency(totals.despesas)}</div></CardContent>
           </Card>
           <Card className={cn("border-l-4", totals.resultado >= 0 ? "border-l-emerald-500" : "border-l-red-500")}>
               <CardHeader className="pb-2"><CardTitle className="text-sm font-medium">Resultado Líquido</CardTitle></CardHeader>
               <CardContent><div className={cn("text-2xl font-bold", totals.resultado >= 0 ? "text-emerald-700" : "text-red-700")}>{formatCurrency(totals.resultado)}</div></CardContent>
           </Card>
       </div>

       {/* Main Table */}
       <div className="bg-white rounded-lg border shadow-sm">
           <Table>
               <TableHeader className="bg-slate-50">
                   <TableRow>
                       <TableHead>Categoria</TableHead>
                       <TableHead className="text-right text-emerald-600">Receitas</TableHead>
                       <TableHead className="text-right text-red-600">Despesas</TableHead>
                       <TableHead className="text-right">Lucro/Prejuízo</TableHead>
                   </TableRow>
               </TableHeader>
               <TableBody>
                   {loading ? (
                       <TableRow><TableCell colSpan={4} className="h-24 text-center"><Loader2 className="h-6 w-6 animate-spin mx-auto text-primary" /></TableCell></TableRow>
                   ) : reportData.length === 0 ? (
                       <TableRow><TableCell colSpan={4} className="h-24 text-center text-muted-foreground">Nenhum dado encontrado para o período.</TableCell></TableRow>
                   ) : (
                       reportData.map((row, idx) => (
                           <TableRow key={idx}>
                               <TableCell className="font-medium">{row.category}</TableCell>
                               <TableCell className="text-right text-emerald-600">{row.receitas > 0 ? formatCurrency(row.receitas) : '-'}</TableCell>
                               <TableCell className="text-right text-red-600">{row.despesas > 0 ? formatCurrency(row.despesas) : '-'}</TableCell>
                               <TableCell className={cn("text-right font-bold", (row.receitas - row.despesas) >= 0 ? "text-emerald-700" : "text-red-700")}>
                                   {formatCurrency(row.receitas - row.despesas)}
                               </TableCell>
                           </TableRow>
                       ))
                   )}
               </TableBody>
           </Table>
       </div>
    </div>
  );
};

export default FinanceDRE;