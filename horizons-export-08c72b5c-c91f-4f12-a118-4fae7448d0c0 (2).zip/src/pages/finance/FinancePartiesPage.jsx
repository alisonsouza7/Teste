import React, { useState, useEffect, useMemo } from 'react';
import { useCompany } from '@/contexts/CompanyContext';
import { supabase } from '@/lib/customSupabaseClient';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useToast } from '@/components/ui/use-toast';
import { Edit2, Trash2, Plus, Search, Users, Loader2, AlertTriangle, Filter } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { Helmet } from 'react-helmet';
import { cn } from '@/lib/utils';
import ExcelActions from '@/components/finance/ExcelActions';

const FinancePartiesPage = () => {
    const { selectedCompany } = useCompany();
    const { toast } = useToast();
    const [parties, setParties] = useState([]);
    const [loading, setLoading] = useState(true);
    const [filters, setFilters] = useState({ search: '', tipo: 'todos' });

    // Modal State
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [editingParty, setEditingParty] = useState(null);
    const [deleteConfirm, setDeleteConfirm] = useState({ open: false, party: null, hasTransactions: false });

    // Form Data
    const [formData, setFormData] = useState({
        nome: '',
        tipo: 'cliente',
        documento: '',
        email: '',
        telefone: '',
        ie_rg: '',
        endereco: ''
    });
    const [isSaving, setIsSaving] = useState(false);

    const fetchParties = async () => {
        if (!selectedCompany) return;
        setLoading(true);
        try {
            // Fetch parties and count linked transactions
            const { data, error } = await supabase
                .from('finance_parties')
                .select(`
                    *,
                    transactions:finance_transactions(count)
                `)
                .eq('company_id', selectedCompany.id)
                .is('deleted_at', null)
                .order('nome');

            if (error) throw error;
            
            const formatted = data.map(p => ({
                ...p,
                transactionCount: p.transactions?.[0]?.count || 0
            }));

            setParties(formatted || []);
        } catch (err) {
            console.error(err);
            toast({ variant: 'destructive', title: 'Erro', description: 'Falha ao carregar cadastros.' });
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        fetchParties();
    }, [selectedCompany]);

    const filteredParties = parties.filter(p => {
        const matchesSearch = p.nome.toLowerCase().includes(filters.search.toLowerCase()) || 
                              p.documento.includes(filters.search);
        const matchesTipo = filters.tipo === 'todos' || p.tipo === filters.tipo || p.tipo === 'ambos';
        return matchesSearch && matchesTipo;
    });

    const handleSave = async (e) => {
        e.preventDefault();
        
        if (!formData.nome || !formData.documento) {
            toast({ variant: 'destructive', title: 'Erro', description: 'Nome e Documento são obrigatórios.' });
            return;
        }

        setIsSaving(true);
        const payload = {
            company_id: selectedCompany.id,
            ...formData
        };

        try {
            // Check for duplicates (except self)
            const { data: existing } = await supabase
                .from('finance_parties')
                .select('id')
                .eq('company_id', selectedCompany.id)
                .eq('documento', formData.documento)
                .is('deleted_at', null)
                .neq('id', editingParty?.id || '00000000-0000-0000-0000-000000000000') // Avoid matching self
                .maybeSingle();
            
            if (existing) {
                toast({ variant: 'destructive', title: 'Duplicado', description: 'Já existe um cadastro com este documento.' });
                setIsSaving(false);
                return;
            }

            if (editingParty) {
                const { error } = await supabase
                    .from('finance_parties')
                    .update(payload)
                    .eq('id', editingParty.id);
                if (error) throw error;
                toast({ title: 'Atualizado', description: 'Cadastro atualizado com sucesso.' });
            } else {
                const { error } = await supabase
                    .from('finance_parties')
                    .insert(payload);
                if (error) throw error;
                toast({ title: 'Criado', description: 'Cadastro criado com sucesso.' });
            }
            
            setIsModalOpen(false);
            resetForm();
            fetchParties();
        } catch (err) {
            console.error(err);
            toast({ variant: 'destructive', title: 'Erro', description: 'Falha ao salvar.' });
        } finally {
            setIsSaving(false);
        }
    };

    const handleDeleteCheck = (party) => {
        setDeleteConfirm({
            open: true,
            party,
            hasTransactions: party.transactionCount > 0
        });
    };

    const confirmDelete = async () => {
        if (!deleteConfirm.party) return;
        
        try {
            const { error } = await supabase
                .from('finance_parties')
                .update({ deleted_at: new Date().toISOString() })
                .eq('id', deleteConfirm.party.id);
            
            if (error) throw error;
            
            toast({ title: 'Sucesso', description: 'Cadastro removido.' });
            setDeleteConfirm({ open: false, party: null, hasTransactions: false });
            fetchParties();
        } catch (err) {
            toast({ variant: 'destructive', title: 'Erro', description: 'Falha ao remover cadastro.' });
        }
    };

    const openEdit = (party) => {
        setEditingParty(party);
        setFormData({
            nome: party.nome,
            tipo: party.tipo,
            documento: party.documento,
            email: party.email || '',
            telefone: party.telefone || '',
            ie_rg: party.ie_rg || '',
            endereco: party.endereco || ''
        });
        setIsModalOpen(true);
    };

    const resetForm = () => {
        setEditingParty(null);
        setFormData({
            nome: '',
            tipo: 'cliente',
            documento: '',
            email: '',
            telefone: '',
            ie_rg: '',
            endereco: ''
        });
    };

    // Excel Logic
    const formatExcelData = useMemo(() => {
        return parties.map(p => ({
            nome: p.nome,
            tipo: p.tipo,
            documento: p.documento,
            email: p.email,
            telefone: p.telefone,
            ie_rg: p.ie_rg,
            endereco: p.endereco
        }));
    }, [parties]);

    const handleExcelImport = async (importedData) => {
        if (!selectedCompany) return;
        const warnings = [];
        const toInsert = [];

        for (const row of importedData) {
            // 1. Basic Validation
            if (!row.nome) {
                warnings.push(`Linha sem nome ignorada.`);
                continue;
            }

            // 2. Duplicate Check (Documento)
            if (row.documento) {
                const exists = parties.some(p => p.documento === String(row.documento).trim());
                if (exists) {
                     warnings.push(`Documento "${row.documento}" já cadastrado. Registro "${row.nome}" ignorado.`);
                     continue;
                }
            } else {
                 // Duplicate Check (Nome only if document is missing, though unlikely in finance)
                 const existsName = parties.some(p => p.nome.toLowerCase() === row.nome.trim().toLowerCase());
                 if (existsName) {
                    warnings.push(`Nome "${row.nome}" já cadastrado. Ignorado.`);
                    continue;
                 }
            }

            // 3. Type Normalization
            let tipo = row.tipo?.toLowerCase().trim();
            if (tipo === 'fornecedor' || tipo === 'fornecedores') tipo = 'fornecedor';
            else if (tipo === 'cliente' || tipo === 'clientes') tipo = 'cliente';
            else tipo = 'cliente'; // Default

            toInsert.push({
                company_id: selectedCompany.id,
                nome: row.nome.trim(),
                tipo: tipo,
                documento: row.documento ? String(row.documento).trim() : 'N/I',
                email: row.email,
                telefone: row.telefone ? String(row.telefone) : '',
                ie_rg: row.ie_rg ? String(row.ie_rg) : '',
                endereco: row.endereco
            });
        }

        if (toInsert.length > 0) {
            const { error } = await supabase.from('finance_parties').insert(toInsert);
            if (error) throw error;
        }

        fetchParties();
        return { imported: toInsert.length, warnings };
    };

    return (
        <>
            <Helmet>
                <title>Clientes e Fornecedores - {selectedCompany?.nome}</title>
            </Helmet>
            
            <div className="space-y-6">
                <div className="flex flex-col gap-2">
                    <h2 className="text-3xl font-bold tracking-tight">Clientes e Fornecedores</h2>
                    <p className="text-muted-foreground">Gerencie seus contatos para vincular aos lançamentos e notas fiscais.</p>
                </div>

                <div className="flex flex-col sm:flex-row gap-4 justify-between items-start sm:items-center bg-white p-4 rounded-lg border shadow-sm">
                    <div className="flex gap-2 w-full sm:w-auto items-center">
                        <div className="relative flex-1 sm:w-64">
                            <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
                            <Input 
                                placeholder="Buscar por nome ou documento..." 
                                className="pl-8"
                                value={filters.search}
                                onChange={(e) => setFilters({ ...filters, search: e.target.value })}
                            />
                        </div>
                        <Select value={filters.tipo} onValueChange={(v) => setFilters({ ...filters, tipo: v })}>
                            <SelectTrigger className="w-[180px]">
                                <Filter className="w-4 h-4 mr-2 text-muted-foreground" />
                                <SelectValue placeholder="Filtrar Tipo" />
                            </SelectTrigger>
                            <SelectContent>
                                <SelectItem value="todos">Todos</SelectItem>
                                <SelectItem value="cliente">Clientes</SelectItem>
                                <SelectItem value="fornecedor">Fornecedores</SelectItem>
                                <SelectItem value="ambos">Ambos</SelectItem>
                            </SelectContent>
                        </Select>
                    </div>

                    <div className="flex gap-2">
                         <ExcelActions 
                            type="PARTIES" 
                            dataToExport={formatExcelData}
                            onImport={handleExcelImport}
                        />

                        <Dialog open={isModalOpen} onOpenChange={(open) => { setIsModalOpen(open); if(!open) resetForm(); }}>
                            <DialogTrigger asChild>
                                <Button><Plus className="w-4 h-4 mr-2" /> Novo Cadastro</Button>
                            </DialogTrigger>
                            <DialogContent className="max-w-lg">
                                <DialogHeader>
                                    <DialogTitle>{editingParty ? 'Editar Cadastro' : 'Novo Cliente/Fornecedor'}</DialogTitle>
                                </DialogHeader>
                                
                                <form onSubmit={handleSave} className="space-y-4 pt-4">
                                    <div className="grid grid-cols-2 gap-4">
                                        <div className="space-y-2">
                                            <Label>Tipo</Label>
                                            <Select 
                                                value={formData.tipo} 
                                                onValueChange={(v) => setFormData({ ...formData, tipo: v })}
                                            >
                                                <SelectTrigger><SelectValue /></SelectTrigger>
                                                <SelectContent>
                                                    <SelectItem value="cliente">Cliente</SelectItem>
                                                    <SelectItem value="fornecedor">Fornecedor</SelectItem>
                                                    <SelectItem value="ambos">Ambos</SelectItem>
                                                </SelectContent>
                                            </Select>
                                        </div>
                                        <div className="space-y-2">
                                            <Label>Documento (CPF/CNPJ)</Label>
                                            <Input 
                                                value={formData.documento} 
                                                onChange={(e) => setFormData({ ...formData, documento: e.target.value })} 
                                                required
                                            />
                                        </div>
                                    </div>

                                    <div className="space-y-2">
                                        <Label>Nome / Razão Social</Label>
                                        <Input 
                                            value={formData.nome} 
                                            onChange={(e) => setFormData({ ...formData, nome: e.target.value })} 
                                            required
                                        />
                                    </div>

                                    <div className="grid grid-cols-2 gap-4">
                                        <div className="space-y-2">
                                            <Label>Telefone</Label>
                                            <Input 
                                                value={formData.telefone} 
                                                onChange={(e) => setFormData({ ...formData, telefone: e.target.value })} 
                                            />
                                        </div>
                                        <div className="space-y-2">
                                            <Label>IE / RG</Label>
                                            <Input 
                                                value={formData.ie_rg} 
                                                onChange={(e) => setFormData({ ...formData, ie_rg: e.target.value })} 
                                            />
                                        </div>
                                    </div>

                                    <div className="space-y-2">
                                        <Label>E-mail</Label>
                                        <Input 
                                            type="email"
                                            value={formData.email} 
                                            onChange={(e) => setFormData({ ...formData, email: e.target.value })} 
                                        />
                                    </div>

                                    <div className="space-y-2">
                                        <Label>Endereço</Label>
                                        <Input 
                                            value={formData.endereco} 
                                            onChange={(e) => setFormData({ ...formData, endereco: e.target.value })} 
                                        />
                                    </div>

                                    {editingParty && editingParty.transactionCount > 0 && (
                                        <div className="bg-yellow-50 p-3 rounded-md border border-yellow-200 text-xs text-yellow-800 flex gap-2">
                                            <AlertTriangle className="w-4 h-4 shrink-0" />
                                            Este cadastro possui {editingParty.transactionCount} lançamentos vinculados.
                                        </div>
                                    )}

                                    <DialogFooter>
                                        <Button type="submit" disabled={isSaving}>
                                            {isSaving && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
                                            Salvar
                                        </Button>
                                    </DialogFooter>
                                </form>
                            </DialogContent>
                        </Dialog>
                    </div>
                </div>

                <Card>
                    <CardHeader className="py-4 border-b bg-muted/20">
                        <div className="grid grid-cols-12 text-sm font-medium text-muted-foreground px-2">
                            <div className="col-span-4">Nome</div>
                            <div className="col-span-2">Tipo</div>
                            <div className="col-span-2">Documento</div>
                            <div className="col-span-2">Contato</div>
                            <div className="col-span-2 text-right">Ações</div>
                        </div>
                    </CardHeader>
                    <CardContent className="p-0">
                        {loading ? (
                            <div className="p-8 flex justify-center"><Loader2 className="w-8 h-8 animate-spin text-primary" /></div>
                        ) : filteredParties.length === 0 ? (
                            <div className="p-8 text-center text-muted-foreground">Nenhum registro encontrado.</div>
                        ) : (
                            <div className="divide-y">
                                {filteredParties.map((party) => (
                                    <div 
                                        key={party.id} 
                                        className="grid grid-cols-12 items-center py-3 px-4 hover:bg-muted/50 transition-colors text-sm"
                                    >
                                        <div className="col-span-4 font-medium flex flex-col">
                                            <span>{party.nome}</span>
                                            {party.transactionCount > 0 && (
                                                <span className="text-[10px] text-muted-foreground bg-slate-100 px-1.5 py-0.5 rounded w-fit mt-0.5">
                                                    {party.transactionCount} vinc.
                                                </span>
                                            )}
                                        </div>
                                        <div className="col-span-2">
                                            <Badge variant="outline" className={cn(
                                                "capitalize font-normal",
                                                party.tipo === 'cliente' && "bg-green-50 text-green-700 border-green-200",
                                                party.tipo === 'fornecedor' && "bg-blue-50 text-blue-700 border-blue-200",
                                                party.tipo === 'ambos' && "bg-purple-50 text-purple-700 border-purple-200",
                                            )}>
                                                {party.tipo}
                                            </Badge>
                                        </div>
                                        <div className="col-span-2 text-muted-foreground font-mono text-xs">
                                            {party.documento}
                                        </div>
                                        <div className="col-span-2 text-muted-foreground text-xs flex flex-col gap-0.5">
                                            <span>{party.email || '-'}</span>
                                            <span>{party.telefone || '-'}</span>
                                        </div>
                                        <div className="col-span-2 flex justify-end gap-1">
                                            <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => openEdit(party)}>
                                                <Edit2 className="w-4 h-4 text-muted-foreground" />
                                            </Button>
                                            <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => handleDeleteCheck(party)}>
                                                <Trash2 className="w-4 h-4 text-red-400 hover:text-red-600" />
                                            </Button>
                                        </div>
                                    </div>
                                ))}
                            </div>
                        )}
                    </CardContent>
                </Card>
            </div>

            {/* Delete Confirmation Dialog */}
            <Dialog open={deleteConfirm.open} onOpenChange={(open) => setDeleteConfirm(prev => ({ ...prev, open }))}>
                <DialogContent>
                    <DialogHeader>
                        <DialogTitle>Confirmar exclusão</DialogTitle>
                    </DialogHeader>
                    
                    <div className="py-2">
                         <p>Tem certeza que deseja excluir <strong>{deleteConfirm.party?.nome}</strong>?</p>
                         {deleteConfirm.hasTransactions && (
                            <div className="bg-red-50 border border-red-200 rounded-md p-3 flex gap-3 items-start mt-4">
                                <AlertTriangle className="w-5 h-5 text-red-600 shrink-0 mt-0.5" />
                                <div className="text-sm text-red-800">
                                    <p className="font-semibold">Atenção: Cadastro em uso</p>
                                    <p>Este cadastro possui lançamentos vinculados. Excluí-lo pode afetar a integridade dos dados históricos.</p>
                                </div>
                            </div>
                        )}
                    </div>

                    <DialogFooter>
                        <Button variant="outline" onClick={() => setDeleteConfirm({ open: false, party: null, hasTransactions: false })}>
                            Cancelar
                        </Button>
                        <Button variant="destructive" onClick={confirmDelete}>
                            {deleteConfirm.hasTransactions ? 'Excluir Mesmo Assim' : 'Excluir'}
                        </Button>
                    </DialogFooter>
                </DialogContent>
            </Dialog>
        </>
    );
};

export default FinancePartiesPage;