
/* global process */
/**
 * Server-side Environment Configuration
 * 
 * BACKEND ONLY - SECRETS ALLOWED
 * This file MUST NOT be bundled in the browser.
 */

export const validateServerEnv = () => {
  if (typeof window !== 'undefined') {
    throw new Error('SECURITY VIOLATION: env.server.js cannot be used in browser environment.');
  }

  let env;
  try {
    env = process.env;
  } catch (e) {
    throw new Error('CRITICAL SERVER ERROR: Node.js process.env is not available.');
  }

  const required = [
    'SUPABASE_URL', 
    'SUPABASE_SERVICE_ROLE_KEY', 
    'CERT_ENCRYPTION_KEY'
  ];
  
  const missing = [];
  required.forEach(key => {
    if (!env[key]) {
      missing.push(key);
    }
  });

  if (missing.length > 0) {
    throw new Error(`[ServerEnv] Missing required environment variables: ${missing.join(', ')}`);
  }

  return {
    isValid: true,
    supabaseUrl: env.SUPABASE_URL,
    supabaseServiceRoleKey: env.SUPABASE_SERVICE_ROLE_KEY,
    certEncryptionKey: env.CERT_ENCRYPTION_KEY,
    
    // NFSe Config
    nfseEnv: env.NFSE_ENV || 'prodrestrita',
    nfseTpAmb: env.NFSE_TPAMB || (env.NFSE_ENV === 'prod' ? '1' : '2'),
    nfseXmlDsigAlgo: env.NFSE_XMLDSIG_ALGO || 'sha256',
    
    // DPS Defaults
    nfseDpsVersao: env.NFSE_DPS_VERSAO || '1.01',
    nfseDpsVerAplicacao: env.NFSE_DPS_VERAPLICACAO || 'CONTERJ-1.0',
    nfseDpsTpEmit: env.NFSE_DPS_TPEMIT || '1',
    nfseDpsSerie: env.NFSE_DPS_SERIE || '80000',
    
    // XSD
    nfseDpsXsdPath: env.NFSE_DPS_XSD_PATH || '/app/xsd/DPS_v1.01.xsd',
    nfseXsdDir: env.NFSE_XSD_DIR || '/app/xsd',

    // API
    nfseApiBase: env.NFSE_API_BASE || 'https://sefin.nfse.gov.br/api' // Example default
  };
};

export default { validateServerEnv };
