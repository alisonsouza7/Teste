
import React from "react";
import ReactDOM from "react-dom/client";
import App from "./App.jsx";
import "./index.css";
import { validateClientEnv } from "@/utils/env.client";

// Early validation of Client Environment
validateClientEnv();

ReactDOM.createRoot(document.getElementById("root")).render(
  <App />
);
