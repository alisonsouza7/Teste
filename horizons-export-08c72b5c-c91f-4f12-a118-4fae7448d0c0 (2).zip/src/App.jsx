import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth } from '@/contexts/SupabaseAuthContext.jsx';
import { CompanyProvider, useCompany } from '@/contexts/CompanyContext.jsx';
import { Toaster } from '@/components/ui/toaster.jsx';
import LoginPage from '@/pages/LoginPage.jsx';
import RegisterPFPage from '@/pages/RegisterPFPage.jsx';
import ClientLayout from '@/components/layout/ClientLayout.jsx';
import AdminLayout from '@/components/layout/AdminLayout.jsx';
import ClientDashboardPage from '@/pages/ClientDashboardPage.jsx';
import NotasFiscaisPage from '@/pages/NotasFiscaisPage.jsx';
import GuiasPage from '@/pages/GuiasPage.jsx';
import RelatoriosPage from '@/pages/RelatoriosPage.jsx';
import PerfilPage from '@/pages/PerfilPage.jsx';
import FalarComConterjPage from '@/pages/FalarComConterjPage.jsx';

// Finance Module
import FinanceLayout from '@/pages/finance/FinanceLayout.jsx';
import FinanceDashboard from '@/pages/finance/FinanceDashboard.jsx';
import FinanceAccounts from '@/pages/finance/FinanceAccounts.jsx';
import FinanceTransactions from '@/pages/finance/FinanceTransactions.jsx';
import FinanceDRE from '@/pages/finance/FinanceDRE.jsx';
import FinanceChartOfAccounts from '@/pages/finance/FinanceChartOfAccounts.jsx';
import FinancePartiesPage from '@/pages/finance/FinancePartiesPage.jsx';
import FinanceCreditCards from '@/pages/finance/FinanceCreditCards.jsx';
import FinanceRecurrences from '@/pages/finance/FinanceRecurrences.jsx';

// Admin Pages
import AdminDashboardPage from '@/pages/admin/AdminDashboardPage.jsx';
import AdminEmpresasPage from '@/pages/admin/AdminEmpresasPage.jsx';
import AdminUsuariosPage from '@/pages/admin/AdminUsuariosPage.jsx';
import AdminVinculosPage from '@/pages/admin/AdminVinculosPage.jsx';
import AdminNotasPage from '@/pages/admin/AdminNotasPage.jsx';
import AdminGuiasPage from '@/pages/admin/AdminGuiasPage.jsx';
import AdminConfigPage from '@/pages/admin/AdminConfigPage.jsx';

const ProtectedRoute = ({ children, allowedRoles }) => {
  const { user, loading, session, userRole } = useAuth();

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-50 to-indigo-100">
        <div className="w-12 h-12 border-4 border-blue-600 border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  const isUserAuthenticatedAndVerified = user && session && user.email_confirmed_at;
  
  if (!isUserAuthenticatedAndVerified) {
    return <Navigate to="/login" replace />;
  }

  const cachedRole = user ? localStorage.getItem(`user-role-${user.id}`) : null;
  const effectiveRole = userRole || cachedRole;

  if (!effectiveRole) {
     return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-50 to-indigo-100">
        <div className="w-12 h-12 border-4 border-blue-600 border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  if (allowedRoles && !allowedRoles.includes(effectiveRole)) {
    return <Navigate to="/cliente/dashboard" replace />;
  }
  
  return children;
};

// Component to protect Fiscal Routes (Notas, Guias) from PF clients
const FiscalRoute = ({ children }) => {
    const { selectedCompany, loading } = useCompany();
    
    if (loading) {
        return (
            <div className="min-h-screen flex items-center justify-center bg-gray-50">
               <div className="w-8 h-8 border-4 border-blue-600 border-t-transparent rounded-full animate-spin" />
           </div>
       );
    }
    
    // If PF, redirect to dashboard or finance
    if (selectedCompany?.tipo_cliente === 'pf') {
        return <Navigate to="/cliente/financeiro/painel" replace />;
    }
    
    return children;
};

const RedirectBasedOnRole = () => {
    const { user, userRole, loading } = useAuth();
    
    if (loading) {
        return (
            <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-50 to-indigo-100">
                <div className="w-12 h-12 border-4 border-blue-600 border-t-transparent rounded-full animate-spin" />
            </div>
        );
    }

    if (!user || !user.email_confirmed_at) {
         return <Navigate to="/login" replace />;
    }

    const cachedRole = localStorage.getItem(`user-role-${user.id}`);
    const effectiveRole = userRole || cachedRole;

    if (!effectiveRole) {
         return (
            <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-50 to-indigo-100">
                <div className="w-12 h-12 border-4 border-blue-600 border-t-transparent rounded-full animate-spin" />
            </div>
        );
    }

    if (effectiveRole === 'admin' || effectiveRole === 'contador') {
        return <Navigate to="/admin/dashboard" replace />;
    } else {
        return <Navigate to="/cliente/dashboard" replace />;
    }
};

const AppContent = () => {
  const { user, loading, session } = useAuth();
  
  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-50 to-indigo-100">
        <div className="w-12 h-12 border-4 border-blue-600 border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  const isUserAuthenticatedAndVerified = user && session && user.email_confirmed_at;

  return (
    <Routes>
      <Route path="/login" element={isUserAuthenticatedAndVerified ? 
        <RedirectBasedOnRole /> : <LoginPage />} 
      />

      <Route path="/cadastro" element={<RegisterPFPage />} />
      
      {/* Client Routes */}
      <Route
        path="/cliente/*"
        element={
          <ProtectedRoute allowedRoles={['cliente', 'admin', 'contador']}>
            <ClientLayout>
              <Routes>
                <Route path="dashboard" element={<ClientDashboardPage />} />
                
                {/* Protected Fiscal Routes for PF */}
                <Route path="notas-fiscais" element={
                    <FiscalRoute><NotasFiscaisPage /></FiscalRoute>
                } />
                <Route path="guias" element={
                    <FiscalRoute><GuiasPage /></FiscalRoute>
                } />
                
                {/* Financeiro Module Nested Routes */}
                <Route path="financeiro" element={<Navigate to="painel" replace />} />
                <Route path="financeiro/*" element={<FinanceLayout />}>
                    <Route path="painel" element={<FinanceDashboard />} />
                    <Route path="contas" element={<FinanceAccounts />} />
                    <Route path="lancamentos" element={<FinanceTransactions />} />
                    <Route path="cartoes" element={<FinanceCreditCards />} />
                    <Route path="dre" element={<FinanceDRE />} />
                    <Route path="plano-contas" element={<FinanceChartOfAccounts />} />
                    <Route path="clientes" element={<FinancePartiesPage />} />
                    <Route path="recorrencias" element={<FinanceRecurrences />} />
                    <Route path="*" element={<Navigate to="painel" replace />} />
                </Route>

                <Route path="relatorios" element={<RelatoriosPage />} />
                <Route path="perfil" element={<PerfilPage />} />
                <Route path="contato" element={<FalarComConterjPage />} />
                <Route path="*" element={<Navigate to="dashboard" replace />} />
              </Routes>
            </ClientLayout>
          </ProtectedRoute>
        }
      />

      {/* Admin Routes */}
      <Route
        path="/admin/*"
        element={
          <ProtectedRoute allowedRoles={['admin', 'contador']}>
            <AdminLayout>
              <Routes>
                <Route path="dashboard" element={<AdminDashboardPage />} />
                <Route path="empresas" element={<AdminEmpresasPage />} />
                <Route path="usuarios" element={<AdminUsuariosPage />} />
                <Route path="vinculos" element={<AdminVinculosPage />} />
                <Route path="notas" element={<AdminNotasPage />} />
                <Route path="guias" element={<AdminGuiasPage />} />
                <Route path="config" element={<AdminConfigPage />} />
                <Route path="*" element={<Navigate to="dashboard" replace />} />
              </Routes>
            </AdminLayout>
          </ProtectedRoute>
        }
      />
      
      <Route path="/" element={<Navigate to="/login" replace />} />
    </Routes>
  );
};

function App() {
  return (
    <Router>
      <AuthProvider>
        <CompanyProvider>
          <AppContent />
          <Toaster />
        </CompanyProvider>
      </AuthProvider>
    </Router>
  );
}

export default App;