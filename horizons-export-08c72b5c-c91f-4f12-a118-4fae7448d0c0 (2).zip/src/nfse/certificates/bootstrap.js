
import { getKey } from './cryptoVault';
import { inspectPfx } from './pfxInspector';
import { createServiceRoleClient } from '@/lib/supabaseServiceRole';
import { logger } from './logger';
import { validateServerEnv } from '@/utils/env.server';

/**
 * Bootstrap Validation
 * 
 * BACKEND ONLY - NEVER IMPORT IN FRONTEND
 * 
 * Runs at application startup (SERVER/WORKER SIDE) to verify environment integrity.
 */

export const runCertificateBootstrap = async () => {
  // Explicit Browser Guard
  if (typeof window !== 'undefined') {
    throw new Error('CRITICAL: Certificate Bootstrap attempted to run in browser. This is strictly forbidden.');
  }

  console.log('🔒 Starting Certificate Module Bootstrap (Backend)...');
  const errors = [];

  // 1. Validate Environment Variables (throws if missing)
  let env;
  try {
    env = validateServerEnv();
  } catch (e) {
    console.error(`❌ ${e.message}`);
    return false;
  }

  // 2. Validate Encryption Key Functionality
  try {
    getKey(); // Should succeed if env is valid
  } catch (e) {
    errors.push(`Encryption Key Error: ${e.message}`);
  }

  // 3. Validate Service Role Client
  const client = createServiceRoleClient();
  if (!client) {
    errors.push('Supabase Service Role Client could not be initialized.');
  }

  // 4. Validate PfxInspector
  if (typeof inspectPfx !== 'function') {
    errors.push('PfxInspector module is not correctly loaded.');
  }

  // 5. Validate Storage Bucket Access
  if (client) {
    try {
      const bucketName = env.nfseCertBucket;
      const { error } = await client.storage.getBucket(bucketName);
      
      if (error && error.message.includes('not found')) {
        errors.push(`Storage Bucket '${bucketName}' not found in Supabase.`);
      } else if (error) {
         errors.push(`Storage Bucket Access Error: ${error.message}`);
      }
    } catch (bucketError) {
      errors.push(`Unexpected error checking storage bucket: ${bucketError.message}`);
    }
  }

  if (errors.length > 0) {
    logger.error('Bootstrap Failed', { errors });
    console.error('❌ Certificate Module Bootstrap Failed:');
    errors.forEach(e => console.error(` - ${e}`));
    return false;
  }

  console.log('✅ Certificate Module Bootstrap Complete.');
  return true;
};
