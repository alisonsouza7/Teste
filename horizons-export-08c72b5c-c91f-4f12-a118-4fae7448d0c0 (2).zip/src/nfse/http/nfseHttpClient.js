
/* global process */
import https from 'https';
import axios from 'axios';
import CertificateManager from '../certificates/certificateManager';
import { validateServerEnv } from '@/utils/env.server';

if (typeof window !== 'undefined') {
  throw new Error('nfseHttpClient must run on backend only');
}

export const createNfseHttpClient = async (company_id) => {
  const env = validateServerEnv();
  
  // Get Certificate (PFX)
  const certData = await CertificateManager.getActiveCertificate(company_id);
  if (!certData) throw new Error('No certificate found');
  
  // Create HTTPS Agent
  const agent = new https.Agent({
    pfx: certData.pfxBuffer,
    passphrase: certData.password,
    rejectUnauthorized: false // Often needed for municipal/gov servers with sketchy chains, use with caution or strict config
  });

  const client = axios.create({
      baseURL: env.nfseApiBase,
      httpsAgent: agent,
      timeout: 30000, // 30s
      headers: {
          'Content-Type': 'application/xml',
          'Accept': 'application/xml'
      }
  });

  return client;
};

const wait = (ms) => new Promise(res => setTimeout(res, ms));

export const sendWithRetry = async (client, method, url, data, maxRetries = 3) => {
    let attempt = 0;
    
    while (attempt < maxRetries) {
        try {
            const response = await client.request({
                method,
                url,
                data
            });
            return response;
        } catch (error) {
            attempt++;
            
            const isTransient = 
                error.code === 'ECONNRESET' || 
                error.code === 'ETIMEDOUT' ||
                (error.response && error.response.status >= 502 && error.response.status <= 504);

            if (!isTransient || attempt >= maxRetries) {
                throw error;
            }
            
            // Exponential Backoff: 1s, 2s, 4s...
            const delay = Math.pow(2, attempt - 1) * 1000;
            console.warn(`[NfseClient] Transient error. Retrying in ${delay}ms... (Attempt ${attempt})`);
            await wait(delay);
        }
    }
};

export const sendDpsToNfse = async (company_id, signedXml) => {
    const client = await createNfseHttpClient(company_id);
    // Note: National Standard typically uses POST /nfse
    return sendWithRetry(client, 'POST', '/nfse', signedXml);
};

export const checkDpsStatus = async (company_id, dpsId) => {
    const client = await createNfseHttpClient(company_id);
    return sendWithRetry(client, 'HEAD', `/dps/${dpsId}`);
};

export default { createNfseHttpClient, sendWithRetry, sendDpsToNfse, checkDpsStatus };
