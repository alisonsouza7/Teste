
import queue from './queue';
import importer from './importer';
import logger from './logger';

/**
 * Standalone Worker Process
 * 
 * To run this: 
 * 1. Ensure environment variables are set (SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY)
 * 2. Run: node src/nfse/anexos/worker.js
 */

const WORKER_ID = `worker-${Math.random().toString(36).substr(2, 9)}`;
const POLLING_INTERVAL_MS = 2000;
let isRunning = true;

const sleep = (ms) => new Promise(resolve => setTimeout(resolve, ms));

const runWorker = async () => {
  console.log(`Worker ${WORKER_ID} started.`);
  
  // Safety check: Prevent running in browser unintentionally if imported
  // Commented out to allow execution if needed, but generally workers run in their own context
  // if (typeof window !== 'undefined') {
  //   console.error("Worker cannot run in browser environment.");
  //   return;
  // }

  while (isRunning) {
    try {
      const job = await queue.claimNextJob(WORKER_ID);

      if (job) {
        console.log(`Claimed job ${job.id}`);
        const startTime = Date.now();

        try {
          const result = await importer.importAnexos(job.payload);
          await queue.completeJob(job.id, 'completed', result);
          
          const duration = Date.now() - startTime;
          logger.logSummary(duration, result.totalFiles, 0, result.failed.length);
          
        } catch (jobError) {
          console.error(`Job ${job.id} failed:`, jobError);
          await queue.completeJob(job.id, 'failed', null, jobError.message);
        }
      } else {
        // No jobs, sleep
        await sleep(POLLING_INTERVAL_MS);
      }
    } catch (err) {
      console.error('Worker loop error:', err);
      await sleep(5000); // Backoff on infrastructure error
    }
  }
};

// Removed Node.js specific process handling (process.on, process.argv) 
// to avoid "process is not defined" errors in Vite environment.

export default runWorker;
