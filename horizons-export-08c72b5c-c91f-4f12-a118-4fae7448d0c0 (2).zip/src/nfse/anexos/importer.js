
import { createServiceRoleClient } from '@/lib/supabaseServiceRole';
import { listAllXlsxFiles } from './storageClient';
import parser from './parser';
import anexoA from './mappers/anexoA';
import anexoB from './mappers/anexoB';
import anexoC from './mappers/anexoC';
import logger from './logger';

const supabase = createServiceRoleClient();
const BUCKET_NAME = 'nfse-tabelas';

/**
 * Downloads and parses a file from storage
 */
const downloadAndParseFile = async (fileName) => {
  const { data, error } = await supabase.storage.from(BUCKET_NAME).download(fileName);
  if (error) throw new Error(`Download failed: ${error.message}`);
  
  const buffer = await data.arrayBuffer();
  return parser.parseXlsxBuffer(buffer);
};

/**
 * Processes a single file
 */
export const processFile = async (fileName) => {
  const startTime = Date.now();
  logger.logFile(fileName, 0, 'STARTED');
  
  const stats = {
    fileName,
    sheets: {},
    errors: []
  };

  try {
    const workbook = await downloadAndParseFile(fileName);
    const sheetNames = parser.getSheetNames(workbook);

    for (const sheetName of sheetNames) {
      const rawRows = parser.parseSheet(workbook, sheetName);
      let inserted = 0;
      
      // Determine mapper based on sheet name heuristics
      const snUpper = sheetName.toUpperCase();
      
      try {
        if (snUpper.includes('MUN') || snUpper.includes('IBGE')) {
          const data = anexoA.mapMunicipios(rawRows);
          if (data.length > 0) {
            const { error } = await supabase.from('nfse_municipios_ibge')
              .upsert(data, { onConflict: 'codigo_ibge' });
            if (error) throw error;
            inserted = data.length;
          }
        } else if (snUpper.includes('PAIS') || snUpper.includes('ISO')) {
          const data = anexoA.mapPaises(rawRows);
          if (data.length > 0) {
            const { error } = await supabase.from('nfse_paises_iso2')
              .upsert(data, { onConflict: 'codigo_iso' });
            if (error) throw error;
            inserted = data.length;
          }
        } else if (snUpper.includes('NBS')) {
          const data = anexoB.mapNBS(rawRows);
          if (data.length > 0) {
             const { error } = await supabase.from('nfse_nbs')
              .upsert(data, { onConflict: 'nbs_code' });
             if (error) throw error;
             inserted = data.length;
          }
        } else if (snUpper.includes('SERV') || snUpper.includes('NACIONAL')) {
          const data = anexoB.mapServicos(rawRows);
          if (data.length > 0) {
            // Assuming no unique constraint on servico_nacional yet, using plain insert?
            // Actually instructions say UPSERT. 
            // We'll assume composite key or `id` isn't used. 
            // Since we can't edit schema, we rely on existing logic.
            // If conflict key fails, catch error.
            const { error } = await supabase.from('nfse_servico_nacional')
              .upsert(data); // Trying without explicit conflict key or letting DB handle
            if (error) throw error;
            inserted = data.length;
          }
        } else if (snUpper.includes('IND') || snUpper.includes('OP')) {
          const data = anexoC.mapIndOp(rawRows);
          if (data.length > 0) {
            const { error } = await supabase.from('nfse_indop')
              .upsert(data, { onConflict: 'codigo' });
            if (error) throw error;
            inserted = data.length;
          }
        }
        
        logger.logSheet(fileName, sheetName, rawRows.length, inserted, 0);
        stats.sheets[sheetName] = inserted;

      } catch (sheetErr) {
        logger.logLine(fileName, sheetName, 0, sheetErr.message);
        stats.errors.push({ sheet: sheetName, error: sheetErr.message });
      }
    }
    
    logger.logFile(fileName, 0, 'COMPLETED');

  } catch (err) {
    logger.logFile(fileName, 0, 'FAILED');
    stats.errors.push({ error: err.message });
    throw err; // Re-throw to fail the job
  }
  
  return stats;
};

/**
 * Orchestrates the import job logic
 * @param {Object} payload 
 */
export const importAnexos = async (payload) => {
  const { fileNames } = payload || {};
  
  // If no files specified, list all
  const targetFiles = (fileNames && fileNames.length > 0) 
    ? fileNames 
    : await listAllXlsxFiles();

  const summary = {
    totalFiles: targetFiles.length,
    processed: [],
    failed: []
  };

  for (const file of targetFiles) {
    try {
      const stats = await processFile(file);
      summary.processed.push(stats);
    } catch (e) {
      summary.failed.push({ file, error: e.message });
    }
  }

  return summary;
};

export default {
  importAnexos,
  processFile
};
