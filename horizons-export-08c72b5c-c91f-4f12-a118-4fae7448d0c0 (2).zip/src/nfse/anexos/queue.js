
import { createServiceRoleClient } from '@/lib/supabaseServiceRole';

/**
 * Database-backed Job Queue for NFSe Anexos
 * Uses 'nfse_anexos_jobs' table.
 */

const supabase = createServiceRoleClient();

/**
 * Enqueues a new import job
 * @param {Object} payload - e.g. { fileNames: [] }
 * @returns {Promise<string>} job_id
 */
export const enqueueImportJob = async (payload = {}) => {
  const { data, error } = await supabase
    .from('nfse_anexos_jobs')
    .insert({
      job_type: 'import_anexos',
      status: 'pending',
      payload
    })
    .select('id')
    .single();

  if (error) {
    console.error('Error enqueuing job:', error);
    throw error;
  }
  return data.id;
};

/**
 * Retrieves a specific job
 * @param {string} jobId 
 */
export const getJob = async (jobId) => {
  const { data, error } = await supabase
    .from('nfse_anexos_jobs')
    .select('id, status, result, error_message, locked_by, locked_at, created_at, updated_at')
    .eq('id', jobId)
    .single();

  if (error) throw error;
  return data;
};

/**
 * Claims the next pending job atomically
 * @param {string} workerId 
 * @returns {Promise<Object|null>} The claimed job or null if none available
 */
export const claimNextJob = async (workerId) => {
  // Try to find a pending job and lock it
  // We use a simplified approach since standard Postgres UPDATE ... RETURNING works well for queues
  
  // 1. Find candidate
  const { data: candidates, error: findError } = await supabase
    .from('nfse_anexos_jobs')
    .select('id')
    .eq('status', 'pending')
    .order('created_at', { ascending: true })
    .limit(1);

  if (findError || !candidates || candidates.length === 0) return null;

  const candidateId = candidates[0].id;

  // 2. Attempt to lock
  const { data, error } = await supabase
    .from('nfse_anexos_jobs')
    .update({
      status: 'processing',
      locked_by: workerId,
      locked_at: new Date().toISOString(),
      updated_at: new Date().toISOString()
    })
    .eq('id', candidateId)
    .eq('status', 'pending') // Optimistic concurrency check
    .select('*')
    .single();

  if (error) {
    // Could happen if another worker grabbed it between find and update
    return null; 
  }

  return data;
};

/**
 * Updates a job with final status
 */
export const completeJob = async (jobId, status, result = null, errorMessage = null) => {
  const updatePayload = {
    status,
    result,
    error_message: errorMessage,
    processed_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
    locked_by: null // Release lock
  };

  const { error } = await supabase
    .from('nfse_anexos_jobs')
    .update(updatePayload)
    .eq('id', jobId);

  if (error) console.error(`Error completing job ${jobId}:`, error);
};

export default {
  enqueueImportJob,
  getJob,
  claimNextJob,
  completeJob
};
