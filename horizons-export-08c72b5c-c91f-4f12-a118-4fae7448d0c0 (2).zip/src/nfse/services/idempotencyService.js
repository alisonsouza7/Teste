
import { createServiceRoleClient } from '@/lib/supabaseServiceRole';

if (typeof window !== 'undefined') {
  throw new Error('idempotencyService must run on backend only');
}

const supabase = createServiceRoleClient();

/**
 * Checks if a request has already been processed.
 * If not, creates a placeholder in PROCESSING state.
 */
export const checkIdempotency = async (company_id, idempotencyKey, operation, payload) => {
    if (!idempotencyKey) {
        return { isNew: true, request: null }; // No idempotency key provided
    }

    // 1. Try to fetch existing
    const { data: existing, error: fetchError } = await supabase
        .from('nfse_requests')
        .select('*')
        .eq('company_id', company_id)
        .eq('idempotency_key', idempotencyKey)
        .single();

    if (existing) {
        return { isNew: false, request: existing };
    }

    // 2. Create new record
    const { data: newReq, error: insertError } = await supabase
        .from('nfse_requests')
        .insert({
            company_id,
            idempotency_key: idempotencyKey,
            operation,
            request_payload: payload,
            status: 'PROCESSING'
        })
        .select()
        .single();

    if (insertError) {
        // Handle race condition: Unique constraint violation
        if (insertError.code === '23505') {
             const { data: retryExisting } = await supabase
                .from('nfse_requests')
                .select('*')
                .eq('company_id', company_id)
                .eq('idempotency_key', idempotencyKey)
                .single();
             return { isNew: false, request: retryExisting };
        }
        throw new Error(`Failed to create idempotency record: ${insertError.message}`);
    }

    return { isNew: true, request: newReq };
};

/**
 * Updates the request status after processing is done.
 */
export const updateRequestStatus = async (requestId, status, responseSummary, relatedDpsId = null) => {
    const updates = {
        status,
        response_summary: responseSummary,
        updated_at: new Date()
    };
    
    if (relatedDpsId) {
        updates.related_dps_id = relatedDpsId;
    }

    const { error } = await supabase
        .from('nfse_requests')
        .update(updates)
        .eq('id', requestId);

    if (error) {
        console.error('Failed to update request status:', error);
    }
};

export default { checkIdempotency, updateRequestStatus };
