
import { createServiceRoleClient } from '@/lib/supabaseServiceRole';
import { validateServerEnv } from '@/utils/env.server';

if (typeof window !== 'undefined') {
  throw new Error('storageService must run on backend only');
}

const supabase = createServiceRoleClient();
const BUCKET = 'nfse-xml'; // Ensure this bucket exists in storage policies

const upload = async (path, content, contentType = 'application/xml') => {
    const { data, error } = await supabase
        .storage
        .from(BUCKET)
        .upload(path, content, {
            contentType,
            upsert: true
        });
        
    if (error) throw new Error(`Storage upload failed: ${error.message}`);
    return path;
};

export const saveRequestXml = async (company_id, referenceId, xmlContent) => {
    const path = `${company_id}/requests/${referenceId}.xml`;
    return upload(path, xmlContent);
};

export const saveSignedXml = async (company_id, referenceId, xmlContent) => {
    const path = `${company_id}/signed/${referenceId}.xml`;
    return upload(path, xmlContent);
};

export const saveSendResponseXml = async (company_id, referenceId, xmlContent) => {
    const path = `${company_id}/responses/${referenceId}.xml`;
    return upload(path, xmlContent);
};

export const saveNfseXml = async (company_id, nfseNumber, xmlContent) => {
    const path = `${company_id}/nfse/${nfseNumber}.xml`;
    return upload(path, xmlContent);
};

export const getXmlPreview = async (path, maxChars = 2000) => {
    if (!path) return null;
    
    const { data, error } = await supabase.storage.from(BUCKET).download(path);
    if (error) return null; // Fail silently for preview
    
    const text = await data.text();
    return text.substring(0, maxChars) + (text.length > maxChars ? '...' : '');
};

export default { saveRequestXml, saveSignedXml, saveSendResponseXml, saveNfseXml, getXmlPreview };
