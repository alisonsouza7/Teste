
import { createServiceRoleClient } from '@/lib/supabaseServiceRole';

if (typeof window !== 'undefined') {
  throw new Error('statusMachine must run on backend only');
}

const supabase = createServiceRoleClient();

const STATUS_TRANSITIONS = {
    'DRAFT': ['SIGNED', 'CANCELLED'],
    'SIGNED': ['TRANSMITTING', 'CANCELLED', 'ERROR'],
    'TRANSMITTING': ['AUTHORIZED', 'REJECTED', 'ERROR'],
    'AUTHORIZED': ['CANCELLED'], // Can initiate cancellation
    'REJECTED': ['DRAFT', 'SIGNED'], // Can retry
    'ERROR': ['SIGNED', 'DRAFT'], // Can retry
    'CANCELLED': [] // Terminal
};

export const isValidTransition = (fromStatus, toStatus) => {
    const allowed = STATUS_TRANSITIONS[fromStatus] || [];
    return allowed.includes(toStatus);
};

export const updateDpsStatus = async (dpsId, newStatus, details = {}) => {
    // 1. Fetch current status
    const { data: current, error: fetchError } = await supabase
        .from('nfse_dps')
        .select('status, attempts')
        .eq('id', dpsId)
        .single();

    if (fetchError || !current) {
        throw new Error(`DPS ${dpsId} not found`);
    }

    // 2. Validate Transition
    // Note: We might skip validation if forcing an update (e.g. system correction), 
    // but good practice to check logic.
    if (!isValidTransition(current.status, newStatus)) {
        console.warn(`Invalid transition attempted: ${current.status} -> ${newStatus} for DPS ${dpsId}`);
        // We log but might allow for recovery scenarios
    }

    // 3. Prepare Updates
    const updates = {
        status: newStatus,
        updated_at: new Date()
    };

    if (newStatus === 'ERROR' || newStatus === 'REJECTED') {
        updates.error_code = details.errorCode || null;
        updates.error_message = details.errorMessage || null;
        updates.last_attempt_at = new Date();
        updates.attempts = (current.attempts || 0) + 1;
    }

    if (newStatus === 'AUTHORIZED') {
        updates.chave_acesso = details.chaveAcesso;
        updates.numero_nfse = details.numeroNfse;
        updates.xml_nfse_path = details.xmlNfsePath;
        // Reset error fields on success
        updates.error_code = null;
        updates.error_message = null;
    }

    if (details.xmlRequestPath) updates.xml_request_path = details.xmlRequestPath;
    if (details.xmlSignedPath) updates.xml_signed_path = details.xmlSignedPath;
    if (details.xmlResponsePath) updates.xml_response_path = details.xmlResponsePath;

    // 4. Update DB
    const { error: updateError } = await supabase
        .from('nfse_dps')
        .update(updates)
        .eq('id', dpsId);

    if (updateError) {
        throw new Error(`Failed to update DPS status: ${updateError.message}`);
    }
    
    // 5. Audit Log (Async, don't block)
    supabase.from('nfse_audit_logs').insert({
        dps_id: dpsId,
        action: `STATUS_CHANGE_${newStatus}`,
        details: { from: current.status, to: newStatus, ...details }
    }).then();
};

export default { isValidTransition, updateDpsStatus };
