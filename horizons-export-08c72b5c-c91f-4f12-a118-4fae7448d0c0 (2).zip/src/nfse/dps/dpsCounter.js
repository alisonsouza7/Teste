
/* global process */
import { createServiceRoleClient } from '@/lib/supabaseServiceRole';
import { validateServerEnv } from '@/utils/env.server';

/**
 * DPS Counter (Backend)
 * Manages atomic increment of nDPS for sequential numbering via RPC.
 * BACKEND ONLY
 */
if (typeof window !== 'undefined') {
  throw new Error('dpsCounter must run on backend only');
}

export const getNextDpsNumber = async (company_id) => {
    if (!company_id) throw new Error('Company ID required');

    const supabase = createServiceRoleClient();
    const env = validateServerEnv();
    const defaultSerie = parseInt(env.nfseDpsSerie || '80000');
    
    // Call the RPC function for atomic operation
    const { data, error } = await supabase.rpc('rpc_get_next_dps', {
        p_company_id: company_id,
        p_serie: defaultSerie
    });

    if (error) {
        throw new Error(`Failed to get next DPS number: ${error.message}`);
    }

    // RPC returns an array of rows (even if single row)
    if (!data || data.length === 0) {
        throw new Error('RPC returned no data for DPS counter');
    }

    const result = data[0]; // { serie, n_dps }

    return { 
        serie: result.serie, 
        nDPS: result.n_dps 
    };
};

export default { getNextDpsNumber };
