
/* global process */
import fs from 'fs';
import path from 'path';
// Note: In a real Node environment, you would use libxmljs2. 
// In this simulated environment, we import it but usage is guarded or mocked if missing.
import libxmljs from 'libxmljs2'; 
import { validateServerEnv } from '@/utils/env.server';

if (typeof window !== 'undefined') {
  throw new Error('DpsValidator must run on backend only');
}

export const validateXmlAgainstXsd = (xml, xsdPath) => {
  const env = validateServerEnv();
  const xsdDir = env.nfseXsdDir;

  try {
    // 1. Check file existence
    if (!fs.existsSync(xsdPath)) {
      return { ok: false, errors: [{ message: `XSD not found at ${xsdPath}` }] };
    }

    // 2. Read XSD
    const xsdContent = fs.readFileSync(xsdPath, 'utf8');

    // 3. Resolve Includes (Simple string replacement for absolute paths)
    // This allows libxmljs to find the included .xsd files
    const processedXsd = xsdContent.replace(
      /schemaLocation=["']([^"']+)["']/g, 
      (match, filename) => {
        if (filename.startsWith('http')) return match;
        const absPath = path.resolve(xsdDir, filename);
        return `schemaLocation="${absPath}"`;
      }
    );

    // 4. Parse & Validate
    const xsdDoc = libxmljs.parseXml(processedXsd);
    const xmlDoc = libxmljs.parseXml(xml);

    if (!xmlDoc.validate(xsdDoc)) {
      const errors = xmlDoc.validationErrors.map(e => ({
        message: e.message,
        line: e.line,
        column: e.column
      }));
      return { ok: false, errors };
    }

    return { ok: true, errors: [] };

  } catch (error) {
    // Fallback if libxmljs fails (e.g. missing native module in dev)
    console.error('XSD Validation Error (System):', error.message);
    return { 
      ok: false, 
      errors: [{ message: `System Error during validation: ${error.message}` }] 
    };
  }
};

export default { validateXmlAgainstXsd };
