
import { sendWithRetry, createNfseHttpClient } from '@/nfse/http/nfseHttpClient';

/**
 * Adapter for National Standard (ADN)
 * Follows the SPED NFS-e standard endpoints.
 */

if (typeof window !== 'undefined') {
  throw new Error('nacionalAdnAdapter must run on backend only');
}

export default {
    async sendDps(company_id, signedXml, context) {
        // Context contains baseURL resolved from providerResolver
        const client = await createNfseHttpClient(company_id);
        client.defaults.baseURL = context.baseURL; // Override with specific muni URL
        
        return sendWithRetry(client, 'POST', '/nfse', signedXml);
    },

    async checkDps(company_id, dpsId, context) {
        const client = await createNfseHttpClient(company_id);
        client.defaults.baseURL = context.baseURL;
        
        return sendWithRetry(client, 'GET', `/dps/${dpsId}`);
    },

    async getNfse(company_id, chaveAcesso, context) {
        const client = await createNfseHttpClient(company_id);
        client.defaults.baseURL = context.baseURL;
        
        return sendWithRetry(client, 'GET', `/nfse/${chaveAcesso}`);
    }
};
