
import { createServiceRoleClient } from '@/lib/supabaseServiceRole';
import { validateServerEnv } from '@/utils/env.server';

if (typeof window !== 'undefined') {
  throw new Error('providerResolver must run on backend only');
}

const supabase = createServiceRoleClient();

export const resolveProvider = async ({ company_id, cLocEmi }) => {
    // 1. Fetch Company Settings Override
    const { data: companySettings } = await supabase
        .from('nfse_company_settings')
        .select('*')
        .eq('company_id', company_id)
        .single();
    
    // Determine target location (Override > Payload)
    const targetLoc = companySettings?.c_loc_emi || cLocEmi;
    
    if (!targetLoc) throw new Error('Location (cLocEmi) is required to resolve provider');

    // 2. Fetch Municipal Config
    const { data: config, error: configError } = await supabase
        .from('nfse_municipios_config')
        .select('*')
        .eq('codigo_ibge', targetLoc)
        .single();

    if (configError || !config) {
        throw new Error(`Municipality ${targetLoc} not supported yet.`);
    }

    // 3. Fetch Provider Capabilities
    const { data: caps } = await supabase
        .from('nfse_provider_capabilities')
        .select('*')
        .eq('provider_code', config.provider_code)
        .single();

    // 4. Determine Base URL based on environment (homolog vs prod)
    const serverEnv = validateServerEnv();
    const env = serverEnv.nfseEnv || 'homolog';

    const baseURL = (env === 'prod' || env === 'producao') 
        ? config.api_url_prod 
        : config.api_url_homolog;

    return {
        provider_code: config.provider_code,
        baseURL,
        municipioConfig: config,
        providerCaps: caps,
        companySettings
    };
};

export default { resolveProvider };
