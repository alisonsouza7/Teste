# DRE Diagnostic Report

## 1. Database Schema & Tables
Based on the provided database metadata and code analysis, here is the current schema relevant to the DRE.

### `finance_transactions`
The core table for financial entries.
*   **Columns:**
    *   `id` (uuid, PK)
    *   `company_id` (uuid, FK -> companies.id)
    *   `conta_id` (uuid, FK -> finance_accounts.id)
    *   `categoria_id` (uuid, FK -> finance_chart_of_accounts.id) **[CRITICAL FOR DRE]**
    *   `party_id` (uuid, FK -> finance_parties.id)
    *   `recurrence_id` (uuid, FK -> finance_recurrences.id)
    *   `tipo` (text) - Values: 'receita', 'despesa', 'transferencia'.
    *   `valor` (numeric) - Positive or negative values.
    *   `descricao` (text)
    *   `data_lancamento` (date)
    *   `data_competencia` (date) - Used for **Projetado/Competência**.
    *   `vencimento` (date)
    *   `liquidado` (boolean) - Determines Realizado vs Projetado status.
    *   `data_liquidacao` (date) - Used for **Realizado/Caixa**.
    *   `origem` (text)
    *   `deleted_at` (timestamp) - Soft delete check.

### `finance_chart_of_accounts`
Defines the structure for DRE grouping.
*   **Columns:**
    *   `id` (uuid, PK)
    *   `company_id` (uuid, FK)
    *   `nome_conta` (text)
    *   `tipo` (text) - 'receita', 'despesa', 'custo', 'transferencia'.
    *   `grupo` (text) - Main grouping key (e.g., 'Receita Operacional', 'Despesas Fixas', 'Impostos').
    *   `subgrupo` (text) - Optional, used in some contexts but less consistent.
    *   `parent_id` (uuid, FK -> self) - Allows hierarchy, though current DRE logic relies mostly on string-based `grupo`.
    *   `ordem` (integer) - Used for sorting in lists.
    *   `deleted_at` (timestamp)

### `finance_recurrences`
Stores rules for repeating transactions.
*   **Columns:** `id`, `company_id`, `template_transaction_id`, `recurrence_type`, `start_date`, `next_execution_date`, `is_active`.

---

## 2. Foreign Key Relationships
*   **Transactions to Categories:**
    `finance_transactions.categoria_id` references `finance_chart_of_accounts.id`.
    *   *Trace:* This is the direct link used to group values in the DRE.

*   **Transactions to Accounts (Bank):**
    `finance_transactions.conta_id` references `finance_accounts.id`.

---

## 3. Classification Columns (Chart of Accounts)
The classification relies on:
1.  `tipo`: Broad filter ('receita', 'despesa', 'custo', 'transferencia').
2.  `grupo`: Specific bucket for DRE lines.
    *   *Current Groups Observed in Code:* 'Receita Operacional', 'Outras Receitas', 'CMV/Custos', 'Despesas Fixas', 'Despesas Variáveis', 'Impostos', 'Despesas Operacionais', 'Outras Despesas', 'Deduções', 'Receitas'.

**Note:** There is no explicit `dre_line_id` or `dre_code` column. The logic currently performs string matching on the `grupo` column to map to the DRE report structure.

---

## 4. Current DRE Page Logic (`src/pages/finance/FinanceDRE.jsx`)
The DRE calculation happens client-side inside `useEffect` in `FinanceDRE.jsx`.

**Logic Flow:**
1.  **Fetch Chart of Accounts:** Selects all categories for the company.
2.  **Fetch Transactions:** Queries `finance_transactions` filtered by date range.
3.  **Aggregation:** Iterates over transactions and sums values into `totalsByCategory[categoria_id]`.
    *   Separates `real` (if `liquidado` is true) and `proj` (if `liquidado` is false).
4.  **Grouping (Mapping):** Maps `finance_chart_of_accounts.grupo` strings to hardcoded DRE section keys (e.g., 'Receita Operacional', 'Custos').
    *   *Weakness:* Relies on exact string matches (e.g., `if (grupoPlano === 'CMV/Custos') return 'Custos';`). If a user creates a custom group "Custos de Produção", it might not map correctly unless the fallback logic catches it.

---

## 5. Hooks & Services
*   **`useCompany`**: Provides `selectedCompany.id`.
*   **`supabase` (direct client)**: Used for raw queries inside `FinanceDRE.jsx`.
*   **`applyPeriodFilterToQuery` (`src/lib/periodHelpers.js`)**: Handles date range filtering (`gte`, `lte`).
*   **`generateDREPDF` / `generateDREPNG`**: Export utilities in `src/lib/dreExportHelpers.js`.

---

## 6. Calculation Logic & Utils
There is no dedicated server-side computation or complex separate service file for the DRE math. It is embedded in the component: