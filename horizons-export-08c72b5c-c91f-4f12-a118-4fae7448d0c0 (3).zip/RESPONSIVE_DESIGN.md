# Responsive Design Strategy

## 1. Breakpoint Strategy
We utilize Tailwind's default breakpoints but impose specific layout changes at key intervals.

*   **Mobile (< 768px)**: 
    *   Single column layout.
    *   Hamburger menu for navigation.
    *   "Drawer" pattern for sidebar.
    *   Tables often hidden or converted to "Card Lists".
*   **Tablet (768px - 1024px)**:
    *   Sidebar allows toggling or icon-only mode (future).
    *   Two-column grids for dashboards.
*   **Desktop (> 1024px)**:
    *   Fixed Sidebar.
    *   3-4 column grids for KPIs.
    *   Full data tables.

## 2. Layout Patterns

### Navigation (Sidebar vs Drawer)
*   **Desktop**: The sidebar is fixed on the left (`w-64`). It provides persistent context.
*   **Mobile**: The header becomes sticky. The menu opens a `Sheet` (Drawer) from the left, overlaying content. This saves screen real estate.

### Data Tables (The "Card List" Fallback)
Tables are notoriously bad on mobile.
*   **Desktop**: Standard `<table>` with columns.
*   **Mobile**: We use `hidden md:table` on the table and `block md:hidden` on a Card List view.
    *   Each row becomes a `<Card>` with `flex-col` layout.
    *   Columns become Label/Value pairs.

### Modals (Dialogs)
*   **Desktop**: Centered modal, max-width constrained.
*   **Mobile**: Full width (`w-[95vw]`), often sliding from bottom or centered with minimal margin. Scrollable content area (`max-h-[80vh]`).

## 3. Testing Checklist
1.  [ ] **iPhone SE (Small Screen)**: Verify no horizontal overflow on Dashboard.
2.  [ ] **iPad Portrait**: Check if charts resize correctly.
3.  [ ] **Desktop**: Ensure sidebar doesn't overlap content.
4.  [ ] **Touch Targets**: Buttons/Inputs must be at least 44px height on mobile.