# Implementation Plan: Recurring Transactions Module

**Date:** 2026-01-06
**Objective:** Enable users to set up recurring financial transactions (revenues/expenses) that automatically generate future ledger entries, while ensuring data integrity and preventing duplicates.

---

## 1. Database Schema Design

We will introduce a single new table `finance_recurrences` to store the rules. Instead of duplicating transaction data inside the recurrence table, we will use a "Template Transaction" pattern. The first transaction created by the user serves as the template.

### New Table: `public.finance_recurrences`

| Column Name | Type | Constraints | Description |
| :--- | :--- | :--- | :--- |
| `id` | `uuid` | PK, DEFAULT `gen_random_uuid()` | Unique identifier. |
| `company_id` | `uuid` | FK `companies(id)`, NOT NULL | Owner company. |
| `template_transaction_id` | `uuid` | FK `finance_transactions(id)`, NOT NULL | The "source" transaction used as a template for future copies. |
| `recurrence_type` | `text` | NOT NULL | Enum: `'daily'`, `'weekly'`, `'monthly'`, `'yearly'`, `'custom'`. |
| `interval_count` | `integer` | DEFAULT 1 | e.g., "Every **2** months". |
| `start_date` | `date` | NOT NULL | When the recurrence starts. |
| `end_date` | `date` | NULLABLE | If NULL, runs indefinitely. |
| `next_execution_date` | `date` | NOT NULL | The calculated date for the *next* occurrence. |
| `is_active` | `boolean` | DEFAULT `true` | Switch to pause automation without deleting. |
| `created_at` | `timestamptz` | DEFAULT `now()` | Audit. |
| `updated_at` | `timestamptz` | DEFAULT `now()` | Audit. |
| `metadata` | `jsonb` | DEFAULT `{}` | Flexible field for future use (e.g., day of week specific logic). |

### RLS Policies (Row Level Security)
1.  **Select**: Users can view recurrences where `company_id` matches their access rights (`check_user_company_role`).
2.  **Insert/Update/Delete**: Admins and Accountants can manage. Standard users (clients) can manage if role permissions allow (typically `cliente` role has write access to their own finance data).

---

## 2. Deduplication Strategy

To prevent the "double-booking" problem (e.g., if the script runs twice or if the user manually adds a transaction that the system also tries to add), we will implement a "Find or Create" logic based on a logical composite key.

**Composite Identity Key:**
*   `company_id`
*   `recurrence_id` (New field to be added to `finance_transactions`)
*   `data_competencia` (Accrual Date)

**Logic:**
When the system attempts to generate the transaction for "Rent - February 2026":
1.  It checks `finance_transactions` for a record where:
    *   `company_id` = [Current Company]
    *   `recurrence_id` = [The Recurrence Rule ID]
    *   `data_competencia` = [Target Date]
2.  **If found:** Skip generation (log as "Already exists").
3.  **If not found:** Insert the new transaction.

**Schema Update Required:**
Add `recurrence_id` (UUID, Nullable, FK to `finance_recurrences`) to the existing `finance_transactions` table.

---

## 3. Automation Strategy (Edge Function vs. Service)

Since Supabase is the backend, we will use **Supabase Edge Functions** invoked via **pg_cron** (Database Cron) or an external scheduler.

### Proposed Workflow: `generate-recurring-transactions`
1.  **Trigger:** A scheduled Postgres function running every hour (or day).
2.  **Process:**
    *   Query `finance_recurrences` where `is_active = true` AND `next_execution_date <= CURRENT_DATE`.
    *   For each recurrence:
        *   Fetch the `template_transaction` data.
        *   Calculate the new dates (`data_competencia`, `vencimento`) based on the delta between template date and target date.
        *   **Deduplication Check:** Check if a transaction for this `recurrence_id` + `data_competencia` exists.
        *   **Insert:** Create the new transaction row.
        *   **Update:** Set `finance_recurrences.next_execution_date` to the *subsequent* period.
3.  **Error Handling:** If insertion fails, log error but continue to next recurrence.

*Note: Since we cannot strictly rely on `pg_cron` being enabled on all Supabase tiers (requires Pro), a manual "Check Recurrences" button in the UI will serve as a fallback/trigger for the MVP.*

---

## 4. UI Changes Plan

We will modify `src/pages/finance/FinanceTransactions.jsx` (and potentially split the form into a component) to include a non-intrusive "Recurrence" section.

### Transaction Form Updates
*   **New Toggle Switch:** "Repetir lançamento" (Repeat transaction).
*   **Conditional Fields (visible if Toggle is ON):**
    *   **Frequency:** Select (Monthly, Weekly, Yearly).
    *   **Repeat Every:** Input Number (Default 1).
    *   **End Condition:** Radio Group (Never, After X times, On Date).

### Flow
1.  User fills out standard transaction form (Description, Value, Category, Date).
2.  User enables "Repetir".
3.  User saves.
4.  **Frontend Logic:**
    *   Save the transaction (The "Template").
    *   If "Repetir" is ON, immediately call Supabase to insert into `finance_recurrences` using the returned Transaction ID as `template_transaction_id`.

---

## 5. File Modification List

| File | Type | Purpose |
| :--- | :--- | :--- |
| **Database Migration** (SQL) | New | Create table `finance_recurrences`, add column `recurrence_id` to `finance_transactions`, add indexes and RLS. |
| `src/pages/finance/FinanceTransactions.jsx` | Edit | Add UI controls for recurrence settings in the Create/Edit modal. Update `handleSave` to write to the new table. |
| `src/services/recurrenceService.js` | New | Create utility functions to handle the logic of calculating next dates and formatting payload for the recurrence table. |
| `src/hooks/useRecurrence.js` | New | Hook to fetch recurrence details when editing a transaction that is part of a series. |
| `supabase/functions/process-recurrences/index.ts` | New | (Optional/Future) The Edge Function logic for backend automation. |

---

## 6. RLS Policies Definition