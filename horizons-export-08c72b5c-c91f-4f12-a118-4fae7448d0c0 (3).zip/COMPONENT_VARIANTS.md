# Component Variants & Specifications

## 1. Button (`src/components/ui/button.jsx`)
The core interactive element.

| Variant | Purpose | Visual Style |
| :--- | :--- | :--- |
| **Default** | Primary Action (Save, Submit) | Solid Navy background, White text. Hover: Navy-900. |
| **Secondary** | Highlights (Upgrades, Alerts) | Solid Yellow background, Navy text. High visibility. |
| **Outline** | Secondary Actions (Cancel, Export) | White bg, Gray border, Navy text on hover. |
| **Ghost** | Navigation / Low priority | Transparent bg, gray text. Navy text on hover. |
| **Destructive** | Dangerous Actions (Delete) | Red background, White text. |

## 2. Card (`src/components/ui/card.jsx`)
The container for content.

*   **Standard**: White background, 1px border (`border-border`), `shadow-sm`. Used for lists, forms.
*   **Elevated (Hover)**: `hover:shadow-elevated`. Used for clickable summaries or KPI cards.
*   **Radius**: `rounded-xl` (12px) is the new standard.

## 3. Badge (`src/components/ui/badge.jsx`)
Status indicators.

*   **Default**: Navy bg, White text.
*   **Success**: Green-100 bg, Green-800 text. Used for "Liquidado", "Receita".
*   **Warning**: Yellow-100 bg, Yellow-800 text. Used for "Pendente", "Atrasado".
*   **Destructive**: Red-100 bg, Red-800 text. Used for "Despesa", "Erro".
*   **Outline**: White bg, Border only. Used for neutral tags (Category names).

## 4. Input & Forms (`src/components/ui/input.jsx`)
*   **Default**: Gray-100 border, White bg.
*   **Focus**: Navy Ring (2px offset).
*   **Error**: Red border.
*   **Mobile Optimization**: `text-base` (16px) on mobile to prevent iOS zoom, `text-sm` (14px) on desktop.

## 5. Table (`src/components/ui/table.jsx`)
*   **Header**: `bg-slate-50`, bold gray text, sticky top (in specific views).
*   **Row**: `hover:bg-slate-50` for tracking.
*   **Zebra**: Not used by default to maintain a clean look, relying on borders (`border-b`) instead.
*   **Numbers**: Always right-aligned with monospace font features (tnum) implicitly via Inter.