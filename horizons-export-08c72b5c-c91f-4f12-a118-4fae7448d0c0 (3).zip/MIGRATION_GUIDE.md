# Chart of Accounts Database Migration Guide

This guide provides step-by-step instructions for implementing the necessary database changes for the Chart of Accounts enhancement, including data initialization and rollback procedures.

---

## 1. Database Migration SQL Script

This SQL script modifies the `finance_chart_of_accounts` table by adding new columns required for the enhanced functionality.

**File:** `src/database/migrations/20240107_chart_of_accounts_enhancement.sql` (Note: This file is a placeholder for the actual SQL migration you would run against your Supabase database).