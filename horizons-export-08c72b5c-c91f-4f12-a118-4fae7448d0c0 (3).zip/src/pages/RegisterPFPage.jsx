import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { supabase } from '@/lib/customSupabaseClient';
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { useToast } from '@/components/ui/use-toast';
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Loader2, User, Mail, Lock, FileText, ArrowLeft, Building2 } from 'lucide-react';
import { Helmet } from 'react-helmet';

const RegisterPage = () => {
    const [tipoCliente, setTipoCliente] = useState('pj'); // 'pj' or 'pf'
    const [formData, setFormData] = useState({
        nome: '', // Razão Social (PJ) or Nome Completo (PF)
        documento: '', // CNPJ (PJ) or CPF (PF)
        nome_fantasia: '', // Only for PJ
        email: '',
        password: '',
        confirmPassword: ''
    });
    const [error, setError] = useState('');
    const [isSubmitting, setIsSubmitting] = useState(false);
    
    const { signUp, signOut } = useAuth();
    const navigate = useNavigate();
    const { toast } = useToast();

    const handleChange = (e) => {
        setFormData({
            ...formData,
            [e.target.id]: e.target.value
        });
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        setError('');

        if (formData.password !== formData.confirmPassword) {
            setError('As senhas não coincidem.');
            return;
        }

        if (formData.password.length < 6) {
            setError('A senha deve ter pelo menos 6 caracteres.');
            return;
        }

        setIsSubmitting(true);

        try {
            // 1. Sign Up User (Auth)
            const { data: authData, error: authError } = await signUp(formData.email, formData.password, {
                data: {
                    nome: formData.nome,
                    role: 'cliente'
                }
            });

            if (authError) throw authError;

            if (!authData.user) {
                throw new Error("Erro ao criar usuário.");
            }
            
            // Check if session exists (required for RPC call)
            if (!authData.session) {
                // If email confirmation is required, we can't create the company yet via RPC
                toast({
                    title: "Confirmação Necessária",
                    description: "Por favor, verifique seu email para ativar sua conta antes de continuar.",
                    duration: 8000
                });
                setIsSubmitting(false);
                return; // Stop here
            }

            // 2. Prepare Company Data
            // Ensure we map fields correctly for both PJ and PF
            const companyPayload = {
                // Common fields
                nome: formData.nome, // For PF this is also the name
                cnpj_cpf: formData.documento,
                email: formData.email,
                tipo_pessoa: tipoCliente === 'pf' ? 'PF' : 'PJ',
                tipo_cliente: tipoCliente,
                status: 'pending_approval',
                
                // Specific fields logic
                nome_fantasia: tipoCliente === 'pj' ? formData.nome_fantasia : null,
                
                // PF specific mapping - Ensure these are passed for PF registration
                cpf: tipoCliente === 'pf' ? formData.documento : null,
                nome_completo: tipoCliente === 'pf' ? formData.nome : null
            };

            // 3. Create Company and Link Role (Using RPC)
            const { data: companyData, error: companyError } = await supabase
                .rpc('register_company_and_owner', { 
                    company_data: companyPayload 
                });

            if (companyError) {
                console.error("RPC Error:", companyError);
                throw new Error(`Erro ao registrar empresa: ${companyError.message}`);
            }

            // 4. Success - Sign Out to force login flow with validation
            await signOut();
            
            toast({
                title: "Cadastro Realizado!",
                description: "Sua conta foi criada com sucesso.",
                duration: 5000
            });

            // 5. Redirect to Login with message
            navigate('/login', { 
                state: { 
                    message: "Sua conta está aguardando aprovação do administrador." 
                } 
            });

        } catch (err) {
            console.error('Registration error:', err);
            setError(err.message || 'Ocorreu um erro ao realizar o cadastro.');
        } finally {
            setIsSubmitting(false);
        }
    };

    return (
        <div className="min-h-screen flex items-center justify-center bg-slate-50 p-4">
            <Helmet>
                <title>Cadastro - Portal do Cliente</title>
            </Helmet>

            <Card className="w-full max-w-lg shadow-lg">
                <CardHeader className="space-y-1 text-center">
                    <CardTitle className="text-2xl font-bold">Criar Conta</CardTitle>
                    <CardDescription>
                        Preencha os dados para solicitar seu acesso
                    </CardDescription>
                </CardHeader>
                <CardContent>
                    <form onSubmit={handleSubmit} className="space-y-4">
                        {error && (
                            <Alert variant="destructive">
                                <AlertDescription>{error}</AlertDescription>
                            </Alert>
                        )}

                        <div className="space-y-3 pb-2 border-b">
                            <Label>Tipo de Cadastro</Label>
                            <RadioGroup 
                                defaultValue="pj" 
                                value={tipoCliente} 
                                onValueChange={setTipoCliente}
                                className="flex gap-4"
                            >
                                <div className="flex items-center space-x-2">
                                    <RadioGroupItem value="pj" id="pj" />
                                    <Label htmlFor="pj" className="cursor-pointer font-normal">Pessoa Jurídica (Empresa)</Label>
                                </div>
                                <div className="flex items-center space-x-2">
                                    <RadioGroupItem value="pf" id="pf" />
                                    <Label htmlFor="pf" className="cursor-pointer font-normal">Pessoa Física</Label>
                                </div>
                            </RadioGroup>
                        </div>

                        <div className="space-y-2">
                            <Label htmlFor="nome">
                                {tipoCliente === 'pj' ? 'Razão Social' : 'Nome Completo'}
                            </Label>
                            <div className="relative">
                                {tipoCliente === 'pj' ? (
                                    <Building2 className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                                ) : (
                                    <User className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                                )}
                                <Input 
                                    id="nome" 
                                    placeholder={tipoCliente === 'pj' ? "Razão Social da Empresa" : "Seu nome completo"}
                                    className="pl-10"
                                    value={formData.nome}
                                    onChange={handleChange}
                                    required
                                />
                            </div>
                        </div>

                        {tipoCliente === 'pj' && (
                            <div className="space-y-2">
                                <Label htmlFor="nome_fantasia">Nome Fantasia (Opcional)</Label>
                                <div className="relative">
                                    <Building2 className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                                    <Input 
                                        id="nome_fantasia" 
                                        placeholder="Nome comercial da empresa"
                                        className="pl-10"
                                        value={formData.nome_fantasia}
                                        onChange={handleChange}
                                    />
                                </div>
                            </div>
                        )}

                        <div className="space-y-2">
                            <Label htmlFor="documento">
                                {tipoCliente === 'pj' ? 'CNPJ' : 'CPF'}
                            </Label>
                            <div className="relative">
                                <FileText className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                                <Input 
                                    id="documento" 
                                    placeholder={tipoCliente === 'pj' ? "00.000.000/0000-00" : "000.000.000-00"}
                                    className="pl-10"
                                    value={formData.documento}
                                    onChange={handleChange}
                                    required
                                />
                            </div>
                        </div>

                        <div className="space-y-2">
                            <Label htmlFor="email">Email de Acesso</Label>
                            <div className="relative">
                                <Mail className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                                <Input 
                                    id="email" 
                                    type="email" 
                                    placeholder="seu@email.com" 
                                    className="pl-10"
                                    value={formData.email}
                                    onChange={handleChange}
                                    required
                                />
                            </div>
                        </div>

                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                            <div className="space-y-2">
                                <Label htmlFor="password">Senha</Label>
                                <div className="relative">
                                    <Lock className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                                    <Input 
                                        id="password" 
                                        type="password" 
                                        placeholder="Min. 6 caracteres" 
                                        className="pl-10"
                                        value={formData.password}
                                        onChange={handleChange}
                                        required
                                    />
                                </div>
                            </div>
                            <div className="space-y-2">
                                <Label htmlFor="confirmPassword">Confirmar Senha</Label>
                                <div className="relative">
                                    <Lock className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                                    <Input 
                                        id="confirmPassword" 
                                        type="password" 
                                        placeholder="Confirme a senha" 
                                        className="pl-10"
                                        value={formData.confirmPassword}
                                        onChange={handleChange}
                                        required
                                    />
                                </div>
                            </div>
                        </div>

                        <Button type="submit" className="w-full mt-4" disabled={isSubmitting}>
                            {isSubmitting ? (
                                <>
                                    <Loader2 className="mr-2 h-4 w-4 animate-spin" /> Cadastrando...
                                </>
                            ) : (
                                'Criar Conta'
                            )}
                        </Button>
                    </form>
                </CardContent>
                <CardFooter className="flex flex-col space-y-2 text-center text-sm text-muted-foreground bg-gray-50 rounded-b-lg pt-4 pb-4">
                    <Link to="/login" className="flex items-center justify-center text-blue-600 hover:underline">
                        <ArrowLeft className="w-4 h-4 mr-1" /> Voltar para Login
                    </Link>
                </CardFooter>
            </Card>
        </div>
    );
};

export default RegisterPage;