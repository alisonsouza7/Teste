
import React, { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { useCompany } from '@/contexts/CompanyContext';
import { useCompanyFiscalData } from '@/hooks/useCompanyFiscalData';
import { useToast } from '@/components/ui/use-toast';
import { supabase } from '@/lib/customSupabaseClient';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Separator } from '@/components/ui/separator';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { 
  User, 
  Building2, 
  Lock, 
  Loader2, 
  Save,
  Shield,
  Edit,
  AlertTriangle,
  FileCheck
} from 'lucide-react';
import RegimeSelector from '@/components/finance/RegimeSelector';
import { useTaxRegimes } from '@/hooks/useTaxRegimes';
import { useFinanceLevel } from '@/hooks/useFinanceLevel';
import CertificateSection from '@/components/nfse/CertificateSection';
import FinancialLevelCard from '@/components/finance/FinancialLevelCard';
import FiscalRegimeCard from '@/components/finance/FiscalRegimeCard';
import LGPDMessage from '@/components/common/LGPDMessage';

const PerfilPage = () => {
    const { user } = useAuth();
    const { selectedCompany, refreshCompanies, isPF } = useCompany();
    const { fiscalData, updateRegime, loading: fiscalLoading, error: fiscalError, refreshFiscalData } = useCompanyFiscalData();
    const { getLimitByCode } = useTaxRegimes();
    const { toast } = useToast();
    
    const { level: nivelFinanceiro } = useFinanceLevel(selectedCompany?.id);

    // User data state
    const [userData, setUserData] = useState({
        nome: '',
        email: '',
        telefone: ''
    });

    // Company data state (PJ)
    const [companyData, setCompanyData] = useState({
        nome: '',
        cnpj_cpf: '',
        endereco: '',
        telefone: '',
        email: ''
    });

    // Personal data state (PF)
    const [personalData, setPersonalData] = useState({
        nome_completo: '',
        cpf: '',
        data_nascimento: '',
        telefone: '',
        endereco: ''
    });

    // Password change state
    const [passwordData, setPasswordData] = useState({
        currentPassword: '',
        newPassword: '',
        confirmPassword: ''
    });

    // Sensitive fields editing
    const [showPasswordDialog, setShowPasswordDialog] = useState(false);
    const [verificationPassword, setVerificationPassword] = useState('');
    const [verifyingPassword, setVerifyingPassword] = useState(false);
    const [newRegime, setNewRegime] = useState('');

    const [loading, setLoading] = useState(false);
    const [loadingPassword, setLoadingPassword] = useState(false);

    // Format functions
    const formatCPFCNPJ = (value) => {
        if (!value) return '';
        const numbers = value.replace(/\D/g, '');
        if (numbers.length <= 11) {
            return numbers.replace(/(\d{3})(\d{3})(\d{3})(\d{2})/, '$1.$2.$3-$4');
        }
        return numbers.replace(/(\d{2})(\d{3})(\d{3})(\d{4})(\d{2})/, '$1.$2.$3/$4-$5');
    };

    const formatPhone = (value) => {
        if (!value) return '';
        const numbers = value.replace(/\D/g, '');
        if (numbers.length <= 10) {
            return numbers.replace(/(\d{2})(\d{4})(\d{4})/, '($1) $2-$3');
        }
        return numbers.replace(/(\d{2})(\d{5})(\d{4})/, '($1) $2-$3');
    };

    const formatCurrency = (value) => {
        if (value === null || value === undefined) return 'Não definido';
        return new Intl.NumberFormat('pt-BR', {
            style: 'currency',
            currency: 'BRL'
        }).format(value);
    };

    useEffect(() => {
        if (user) {
            fetchUserData();
        }
    }, [user]);

    useEffect(() => {
        if (selectedCompany) {
            fetchBasicCompanyData();
        }
    }, [selectedCompany?.id]);

    const fetchBasicCompanyData = async () => {
        if (!selectedCompany?.id) return;

        try {
            const { data, error } = await supabase
                .from('companies')
                .select('*')
                .eq('id', selectedCompany.id)
                .single();

            if (error) throw error;

            if (data) {
                if (isPF) {
                    setPersonalData({
                        nome_completo: data.nome_completo || '',
                        cpf: data.cpf ? formatCPFCNPJ(data.cpf) : (data.cnpj_cpf ? formatCPFCNPJ(data.cnpj_cpf) : ''),
                        data_nascimento: data.data_nascimento || '',
                        telefone: data.telefone ? formatPhone(data.telefone) : '',
                        endereco: data.endereco || ''
                    });
                } else {
                    setCompanyData({
                        nome: data.nome || '',
                        cnpj_cpf: data.cnpj_cpf ? formatCPFCNPJ(data.cnpj_cpf) : '',
                        endereco: data.endereco || '',
                        telefone: data.telefone ? formatPhone(data.telefone) : '',
                        email: data.email || ''
                    });
                }
            }
        } catch (err) {
            console.error('Error fetching company data:', err);
        }
    };

    const fetchUserData = async () => {
        try {
            const { data, error } = await supabase
                .from('users')
                .select('*')
                .eq('id', user.id)
                .single();

            if (error) throw error;

            if (data) {
                setUserData({
                    nome: data.nome || '',
                    email: data.email || user.email || '',
                    telefone: data.telefone ? formatPhone(data.telefone) : ''
                });
            }
        } catch (err) {
            console.error('Error fetching user data:', err);
            setUserData(prev => ({ ...prev, email: user.email || '' }));
        }
    };

    const handleUpdateUser = async () => {
        if (!userData.nome?.trim() || !userData.telefone?.trim()) {
            toast({
                title: 'Aviso',
                description: `Por favor, preencha nome e telefone.`,
                variant: 'default'
            });
        }

        setLoading(true);
        try {
            const { error } = await supabase
                .from('users')
                .update({
                    nome: userData.nome?.trim() || null,
                    telefone: userData.telefone?.trim() || null
                })
                .eq('id', user.id);

            if (error) throw error;

            toast({ title: 'Sucesso', description: 'Dados pessoais atualizados.' });
        } catch (err) {
            console.error('Error updating user:', err);
            toast({ variant: 'destructive', title: 'Erro', description: 'Falha ao atualizar dados.' });
        } finally {
            setLoading(false);
        }
    };

    const handleUpdateCompany = async () => {
        if (!selectedCompany) return;
        setLoading(true);
        try {
            const updatePayload = isPF ? {
                nome_completo: personalData.nome_completo?.trim() || null,
                cpf: personalData.cpf?.replace(/\D/g, '') || null,
                cnpj_cpf: personalData.cpf?.replace(/\D/g, '') || null,
                data_nascimento: personalData.data_nascimento || null,
                telefone: personalData.telefone?.replace(/\D/g, '') || null,
                endereco: personalData.endereco?.trim() || null
            } : {
                nome: companyData.nome?.trim() || null,
                cnpj_cpf: companyData.cnpj_cpf?.replace(/\D/g, '') || null,
                endereco: companyData.endereco?.trim() || null,
                telefone: companyData.telefone?.replace(/\D/g, '') || null,
                email: companyData.email?.trim() || null
            };

            const { error } = await supabase
                .from('companies')
                .update(updatePayload)
                .eq('id', selectedCompany.id);

            if (error) throw error;

            await refreshCompanies();
            toast({ title: 'Sucesso', description: 'Dados atualizados.' });
        } catch (err) {
            console.error('Error updating company:', err);
            toast({ variant: 'destructive', title: 'Erro', description: err.message });
        } finally {
            setLoading(false);
        }
    };

    const handleOpenSensitiveFieldsDialog = () => {
        if (fiscalData) {
            setNewRegime(fiscalData.regime_tributario || '');
        }
        setVerificationPassword('');
        setShowPasswordDialog(true);
    };

    const handleVerifyPasswordAndRegimeUpdate = async () => {
        if (!verificationPassword) {
            toast({ variant: 'destructive', title: 'Erro', description: 'Por favor, insira sua senha.' });
            return;
        }

        if (!newRegime) {
            toast({ variant: 'destructive', title: 'Erro', description: 'Selecione um regime tributário.' });
            return;
        }

        setVerifyingPassword(true);
        try {
            const { error: signInError } = await supabase.auth.signInWithPassword({
                email: user.email,
                password: verificationPassword
            });

            if (signInError) {
                toast({ variant: 'destructive', title: 'Senha Incorreta', description: 'A senha está incorreta.' });
                return;
            }

            const success = await updateRegime(newRegime);
            
            if (success) {
                setShowPasswordDialog(false);
                setVerificationPassword('');
            }

        } catch (err) {
            console.error('Error in verification:', err);
            toast({ variant: 'destructive', title: 'Erro', description: err.message });
        } finally {
            setVerifyingPassword(false);
        }
    };

    const handleChangePassword = async () => {
        if (passwordData.newPassword !== passwordData.confirmPassword) {
            toast({ variant: 'destructive', title: 'Erro', description: 'As senhas não coincidem.' });
            return;
        }
        if (passwordData.newPassword.length < 6) {
            toast({ variant: 'destructive', title: 'Erro', description: 'Mínimo de 6 caracteres.' });
            return;
        }

        setLoadingPassword(true);
        try {
            const { error } = await supabase.auth.updateUser({ password: passwordData.newPassword });
            if (error) throw error;

            setPasswordData({ currentPassword: '', newPassword: '', confirmPassword: '' });
            toast({ title: 'Sucesso', description: 'Senha alterada.' });
        } catch (err) {
            console.error('Error changing password:', err);
            toast({ variant: 'destructive', title: 'Erro', description: err.message });
        } finally {
            setLoadingPassword(false);
        }
    };

    return (
        <>
            <Helmet>
                <title>Meu Perfil - Conterj</title>
            </Helmet>

            <div className="space-y-6 pb-12">
                <div>
                    <h1 className="text-3xl font-bold tracking-tight">Meu Perfil</h1>
                    <p className="text-muted-foreground">Gerencie suas informações pessoais e configurações de conta</p>
                </div>

                <Tabs defaultValue="user" className="space-y-6">
                    <TabsList className="grid w-full max-w-md grid-cols-3">
                        <TabsTrigger value="user" className="gap-2"><User className="h-4 w-4" /> Usuário</TabsTrigger>
                        <TabsTrigger value="company" className="gap-2"><Building2 className="h-4 w-4" /> {isPF ? 'Pessoal' : 'Empresa'}</TabsTrigger>
                        <TabsTrigger value="security" className="gap-2"><Lock className="h-4 w-4" /> Segurança</TabsTrigger>
                    </TabsList>

                    <TabsContent value="user" className="space-y-4">
                        <Card>
                            <CardHeader>
                                <CardTitle className="flex items-center gap-2"><User className="h-5 w-5" /> Informações do Usuário</CardTitle>
                                <CardDescription>Atualize seus dados de acesso</CardDescription>
                            </CardHeader>
                            <CardContent className="space-y-4">
                                <div className="space-y-2">
                                    <Label htmlFor="nome">Nome Completo</Label>
                                    <Input id="nome" value={userData.nome} onChange={(e) => setUserData({ ...userData, nome: e.target.value })} />
                                </div>
                                <div className="space-y-2">
                                    <Label htmlFor="email">Email</Label>
                                    <Input id="email" value={userData.email} disabled className="bg-muted" />
                                </div>
                                <div className="space-y-2">
                                    <Label htmlFor="telefone-user">Telefone</Label>
                                    <Input id="telefone-user" value={userData.telefone} onChange={(e) => setUserData({ ...userData, telefone: formatPhone(e.target.value) })} maxLength={15} />
                                </div>
                                <Button onClick={handleUpdateUser} disabled={loading}>
                                    {loading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Save className="mr-2 h-4 w-4" />} Salvar
                                </Button>
                            </CardContent>
                        </Card>
                    </TabsContent>

                    <TabsContent value="company" className="space-y-6">
                        {/* PJ Sections in Requested Order */}
                        {!isPF ? (
                            <>
                                {/* 1) Financial Level */}
                                <section>
                                    <FinancialLevelCard companyId={selectedCompany?.id} />
                                </section>

                                {/* 2) Company Data & Fiscal Regime */}
                                <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                                    <div className="lg:col-span-2 space-y-6">
                                        <Card>
                                            <CardHeader>
                                                <CardTitle className="flex items-center gap-2">
                                                    <Building2 className="h-5 w-5" />
                                                    Dados Cadastrais
                                                </CardTitle>
                                                <CardDescription>Gerencie os dados cadastrais da sua empresa</CardDescription>
                                            </CardHeader>
                                            <CardContent className="space-y-4">
                                                <div className="space-y-2">
                                                    <Label>Razão Social</Label>
                                                    <Input value={companyData.nome} onChange={(e) => setCompanyData({ ...companyData, nome: e.target.value })} />
                                                </div>
                                                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                                    <div className="space-y-2">
                                                        <Label>CNPJ</Label>
                                                        <Input value={companyData.cnpj_cpf} onChange={(e) => setCompanyData({ ...companyData, cnpj_cpf: formatCPFCNPJ(e.target.value) })} maxLength={18} />
                                                    </div>
                                                    <div className="space-y-2">
                                                        <Label>Telefone</Label>
                                                        <Input value={companyData.telefone} onChange={(e) => setCompanyData({ ...companyData, telefone: formatPhone(e.target.value) })} maxLength={15} />
                                                    </div>
                                                </div>
                                                <div className="space-y-2">
                                                    <Label>Email Corporativo</Label>
                                                    <Input type="email" value={companyData.email} onChange={(e) => setCompanyData({ ...companyData, email: e.target.value })} />
                                                </div>
                                                <div className="space-y-2">
                                                    <Label>Endereço</Label>
                                                    <Input value={companyData.endereco} onChange={(e) => setCompanyData({ ...companyData, endereco: e.target.value })} />
                                                </div>

                                                <Button onClick={handleUpdateCompany} disabled={loading} className="w-full sm:w-auto mt-4">
                                                    {loading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Save className="mr-2 h-4 w-4" />} Salvar Alterações
                                                </Button>
                                            </CardContent>
                                        </Card>
                                    </div>
                                    
                                    <div className="lg:col-span-1 space-y-6 h-full flex flex-col">
                                         <FiscalRegimeCard 
                                            fiscalData={fiscalData} 
                                            loading={fiscalLoading}
                                            error={fiscalError}
                                            onRetry={refreshFiscalData}
                                            className="flex-1"
                                         />
                                         <Button 
                                            onClick={handleOpenSensitiveFieldsDialog}
                                            variant="outline"
                                            className="w-full border-dashed"
                                        >
                                            <Edit className="mr-2 h-4 w-4" /> Alterar Regime/Limites
                                        </Button>
                                    </div>
                                </div>

                                {/* 3) Certificate Section */}
                                {!isPF && nivelFinanceiro === 'C' && (
                                    <section className="space-y-4">
                                        <Separator className="my-2" />
                                        <CertificateSection companyId={selectedCompany?.id} />
                                        
                                        {/* 4) LGPD Message */}
                                        <LGPDMessage />
                                    </section>
                                )}
                            </>
                        ) : (
                            // PF Layout (Original)
                             <Card>
                                <CardHeader>
                                    <CardTitle className="flex items-center gap-2">
                                        <User className="h-5 w-5" />
                                        Dados Pessoais
                                    </CardTitle>
                                    <CardDescription>Gerencie suas informações pessoais</CardDescription>
                                </CardHeader>
                                <CardContent className="space-y-4">
                                    <div className="space-y-2">
                                        <Label>Nome Completo</Label>
                                        <Input value={personalData.nome_completo} onChange={(e) => setPersonalData({ ...personalData, nome_completo: e.target.value })} />
                                    </div>
                                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                        <div className="space-y-2">
                                            <Label>CPF</Label>
                                            <Input value={personalData.cpf} onChange={(e) => setPersonalData({ ...personalData, cpf: formatCPFCNPJ(e.target.value) })} maxLength={14} />
                                        </div>
                                        <div className="space-y-2">
                                            <Label>Data de Nascimento</Label>
                                            <Input type="date" value={personalData.data_nascimento} onChange={(e) => setPersonalData({ ...personalData, data_nascimento: e.target.value })} />
                                        </div>
                                    </div>
                                    <div className="space-y-2">
                                        <Label>Telefone</Label>
                                        <Input value={personalData.telefone} onChange={(e) => setPersonalData({ ...personalData, telefone: formatPhone(e.target.value) })} maxLength={15} />
                                    </div>
                                    <div className="space-y-2">
                                        <Label>Endereço</Label>
                                        <Input value={personalData.endereco} onChange={(e) => setPersonalData({ ...personalData, endereco: e.target.value })} />
                                    </div>
                                    <Button onClick={handleUpdateCompany} disabled={loading} className="w-full sm:w-auto mt-4">
                                        {loading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Save className="mr-2 h-4 w-4" />} Salvar Alterações
                                    </Button>
                                </CardContent>
                            </Card>
                        )}
                    </TabsContent>

                    <TabsContent value="security" className="space-y-4">
                        <Card>
                            <CardHeader>
                                <CardTitle className="flex items-center gap-2"><Shield className="h-5 w-5" /> Segurança</CardTitle>
                                <CardDescription>Altere sua senha de acesso</CardDescription>
                            </CardHeader>
                            <CardContent className="space-y-4">
                                <div className="space-y-2">
                                    <Label>Nova Senha</Label>
                                    <Input type="password" value={passwordData.newPassword} onChange={(e) => setPasswordData({ ...passwordData, newPassword: e.target.value })} />
                                </div>
                                <div className="space-y-2">
                                    <Label>Confirmar Nova Senha</Label>
                                    <Input type="password" value={passwordData.confirmPassword} onChange={(e) => setPasswordData({ ...passwordData, confirmPassword: e.target.value })} />
                                </div>
                                <Button onClick={handleChangePassword} disabled={loadingPassword || !passwordData.newPassword}>
                                    {loadingPassword ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Lock className="mr-2 h-4 w-4" />} Alterar Senha
                                </Button>
                            </CardContent>
                        </Card>
                    </TabsContent>
                </Tabs>
            </div>

            <Dialog open={showPasswordDialog} onOpenChange={setShowPasswordDialog}>
                <DialogContent className="sm:max-w-md">
                    <DialogHeader>
                        <DialogTitle className="flex items-center gap-2"><Shield className="h-5 w-5 text-amber-600" /> Confirmação de Segurança</DialogTitle>
                        <DialogDescription>Confirme sua senha para alterar o regime tributário.</DialogDescription>
                    </DialogHeader>

                    <div className="space-y-4 py-4">
                         <div className="bg-amber-50 border border-amber-200 rounded-lg p-3 flex items-start gap-2">
                            <AlertTriangle className="h-4 w-4 text-amber-600 mt-0.5 shrink-0" />
                            <p className="text-sm text-amber-800">
                                Alterações no regime tributário recalcularão automaticamente o limite de faturamento anual.
                            </p>
                        </div>

                        <div className="space-y-2">
                            <Label htmlFor="regime-edit">Regime Tributário</Label>
                            <RegimeSelector 
                                value={newRegime} 
                                onChange={setNewRegime}
                                className="w-full"
                            />
                        </div>

                        {newRegime && (
                             <div className="space-y-2">
                                <Label>Novo Limite Calculado</Label>
                                <div className="flex h-10 w-full rounded-md border border-input bg-muted px-3 py-2 text-sm items-center">
                                    {formatCurrency(getLimitByCode(newRegime))}
                                </div>
                            </div>
                        )}

                        <Separator />

                        <div className="space-y-2">
                            <Label>Sua Senha</Label>
                            <Input
                                type="password"
                                value={verificationPassword}
                                onChange={(e) => setVerificationPassword(e.target.value)}
                                placeholder="Digite sua senha"
                                onKeyDown={(e) => e.key === 'Enter' && handleVerifyPasswordAndRegimeUpdate()}
                            />
                        </div>
                    </div>

                    <DialogFooter>
                        <Button variant="outline" onClick={() => setShowPasswordDialog(false)} disabled={verifyingPassword}>Cancelar</Button>
                        <Button onClick={handleVerifyPasswordAndRegimeUpdate} disabled={verifyingPassword || !verificationPassword}>
                            {verifyingPassword ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Shield className="mr-2 h-4 w-4" />} Confirmar
                        </Button>
                    </DialogFooter>
                </DialogContent>
            </Dialog>
        </>
    );
};

export default PerfilPage;
