
import React, { useState } from 'react';
import { useCompany } from '@/contexts/CompanyContext';
import { useNfseConsulta } from '@/hooks/useNfseConsulta';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Loader2, AlertCircle, CheckCircle, FileText, Search } from 'lucide-react';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';

const NfseConsulta = () => {
    const { selectedCompany } = useCompany();
    const [dpsId, setDpsId] = useState('');
    const { loading, error, result, consultar, obterStatus } = useNfseConsulta();

    const handleObterStatus = () => {
        if (!selectedCompany || !dpsId) return;
        obterStatus(dpsId, selectedCompany.id);
    };

    const handleConsultar = () => {
        if (!selectedCompany || !dpsId) return;
        consultar(dpsId, selectedCompany.id);
    };

    return (
        <div className="container mx-auto p-6 max-w-2xl">
            <h1 className="text-3xl font-bold mb-6 text-gray-800">Consulta NFS-e</h1>
            
            <Card className="mb-6 shadow-md border border-slate-200">
                <CardHeader>
                    <CardTitle className="flex items-center gap-2 text-xl">
                        <Search className="w-5 h-5" /> Consultar DPS
                    </CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                    <div className="space-y-2">
                        <Label htmlFor="dps-input">ID do DPS</Label>
                        <Input 
                            id="dps-input"
                            value={dpsId} 
                            onChange={(e) => setDpsId(e.target.value)} 
                            placeholder="Ex: DPS12345678"
                            className="bg-white"
                        />
                        <p className="text-sm text-slate-500">
                            Identificador único gerado na emissão do DPS.
                        </p>
                    </div>
                    
                    <div className="flex flex-col sm:flex-row gap-4">
                        <Button 
                            variant="outline" 
                            onClick={handleObterStatus} 
                            disabled={loading || !dpsId || !selectedCompany}
                            className="flex-1"
                        >
                            {loading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
                            Obter Status
                        </Button>
                        <Button 
                            onClick={handleConsultar} 
                            disabled={loading || !dpsId || !selectedCompany}
                            className="flex-1 bg-blue-600 hover:bg-blue-700 text-white"
                        >
                            {loading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
                            Consultar NFS-e (1-clique)
                        </Button>
                    </div>
                </CardContent>
            </Card>

            {error && (
                <Alert variant="destructive" className="mb-6 bg-red-50 border-red-200 text-red-800">
                    <AlertCircle className="h-4 w-4" />
                    <AlertTitle>Erro na Consulta</AlertTitle>
                    <AlertDescription>{error}</AlertDescription>
                </Alert>
            )}

            {result && (
                <Card className="bg-white border-slate-200 shadow-md">
                    <CardHeader className="border-b border-slate-100 bg-slate-50">
                        <CardTitle className="flex items-center gap-2 text-slate-800">
                            {result.nfseXmlPath ? (
                                <CheckCircle className="text-green-600 h-6 w-6" />
                            ) : (
                                <FileText className="text-slate-500 h-6 w-6" />
                            )}
                            Resultado da Consulta
                        </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4 pt-6">
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <div className="p-3 bg-slate-50 rounded-lg">
                                <Label className="text-xs text-slate-500 uppercase font-semibold">Status</Label>
                                <div className="font-medium text-lg text-slate-900 mt-1">{result.status || 'N/A'}</div>
                            </div>
                            
                            {result.chaveAcesso && (
                                <div className="p-3 bg-green-50 border border-green-100 rounded-lg">
                                    <Label className="text-xs text-green-600 uppercase font-semibold">Chave de Acesso</Label>
                                    <div className="font-mono text-sm text-green-900 mt-1 break-all">{result.chaveAcesso}</div>
                                </div>
                            )}
                        </div>

                        {result.nfseXmlPath && (
                             <Alert className="bg-green-50 border-green-200">
                                <CheckCircle className="h-4 w-4 text-green-600" />
                                <AlertTitle className="text-green-800">NFS-e Emitida com Sucesso!</AlertTitle>
                                <AlertDescription className="text-green-700">
                                    O arquivo XML foi salvo e vinculado ao DPS.
                                </AlertDescription>
                            </Alert>
                        )}

                        {result.preview && (
                            <div className="mt-6">
                                <Label className="text-xs text-slate-500 mb-2 block uppercase font-semibold">Prévia do XML</Label>
                                <div className="relative">
                                    <pre className="bg-slate-900 text-slate-50 p-4 rounded-md overflow-auto text-xs max-h-80 font-mono shadow-inner">
                                        {result.preview}
                                    </pre>
                                </div>
                            </div>
                        )}
                        
                        {result.message && (
                            <div className="text-sm text-slate-500 mt-2 italic">
                                "{result.message}"
                            </div>
                        )}
                    </CardContent>
                </Card>
            )}
        </div>
    );
};

export default NfseConsulta;
