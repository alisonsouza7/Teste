
import React, { useEffect, useState, useCallback } from 'react';
import { Helmet } from 'react-helmet';
import { supabase } from '@/lib/customSupabaseClient';
import { useCompany } from '@/contexts/CompanyContext';
import { useCompanyFiscalData } from '@/hooks/useCompanyFiscalData';
import { useNavigate } from 'react-router-dom';
import { applyPeriodFilterToQuery } from '@/lib/periodHelpers';

// UI Components
import PageHeader from '@/components/ui/PageHeader';
import SmartFilter from '@/components/SmartFilter';
import KpiCard from '@/components/ui/KpiCard';
import SectionCard from '@/components/ui/SectionCard';
import EmptyState from '@/components/ui/EmptyState';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';
import FiscalRegimeCard from '@/components/finance/FiscalRegimeCard';

// Icons
import {
  DollarSign,
  TrendingUp,
  FileText,
  Plus,
  Eye,
  EyeOff,
  Calendar,
  ArrowRight,
  ArrowUpRight,
  ArrowDownRight,
} from 'lucide-react';

// Charts
import {
  ResponsiveContainer,
  ComposedChart,
  Bar,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
} from 'recharts';

const formatCurrency = (value) =>
  new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(
    Number(value || 0)
  );

const ClientDashboardPage = () => {
  const { selectedCompany } = useCompany();
  const { fiscalData, loading: fiscalLoading, error: fiscalError, refetch: refetchFiscal } = useCompanyFiscalData();
  const navigate = useNavigate();
  const [showValues, setShowValues] = useState(true);
  const [dateRange, setDateRange] = useState({ startDate: '', endDate: '' });
  const [loading, setLoading] = useState(true);

  // Data States
  const [kpiData, setKpiData] = useState({ faturamento: 0, resultado: 0, guias: 0 });
  const [cashflowSeries, setCashflowSeries] = useState([]);
  const [upcomingGuides, setUpcomingGuides] = useState([]);
  const [recentTransactions, setRecentTransactions] = useState([]);

  const fetchDashboardData = useCallback(async () => {
    setLoading(true);
    try {
      const { startDate, endDate } = dateRange;

      // --- FATURAMENTO ---
      let faturamentoInvoicesQuery = supabase
        .from('invoices')
        .select('valor_total')
        .eq('company_id', selectedCompany.id);
      faturamentoInvoicesQuery = applyPeriodFilterToQuery(
        faturamentoInvoicesQuery,
        { startDate, endDate },
        'invoice'
      );

      let faturamentoServiceInvoicesQuery = supabase
        .from('service_invoices')
        .select('valor_servico')
        .eq('company_id', selectedCompany.id)
        .eq('status', 'valida')
        .is('deleted_at', null);
      faturamentoServiceInvoicesQuery = applyPeriodFilterToQuery(
        faturamentoServiceInvoicesQuery,
        { startDate, endDate },
        'invoice'
      );

      let faturamentoFinanceQuery = supabase
        .from('finance_transactions')
        .select('valor')
        .eq('company_id', selectedCompany.id)
        .eq('liquidado', true)
        .eq('tipo', 'receita')
        .is('deleted_at', null);
      faturamentoFinanceQuery = applyPeriodFilterToQuery(
        faturamentoFinanceQuery,
        { startDate, endDate },
        'finance'
      );

      // --- RESULTADO ---
      let resultadoDataQuery = supabase
        .from('finance_transactions')
        .select('valor, tipo, data_competencia')
        .eq('company_id', selectedCompany.id)
        .eq('liquidado', true)
        .is('deleted_at', null);
      resultadoDataQuery = applyPeriodFilterToQuery(
        resultadoDataQuery,
        { startDate, endDate },
        'finance'
      );

      // --- GUIAS ---
      const upcomingGuidesQuery = supabase
        .from('tax_guides')
        .select('*')
        .eq('company_id', selectedCompany.id)
        .in('status', ['pendente', 'vencido'])
        .gte('vencimento', new Date().toISOString())
        .limit(5);

      const [inv, serv, fin, res, guides] = await Promise.all([
        faturamentoInvoicesQuery,
        faturamentoServiceInvoicesQuery,
        faturamentoFinanceQuery,
        resultadoDataQuery,
        upcomingGuidesQuery
      ]);

      const fatTotal =
        (inv.data?.reduce((a, b) => a + Number(b.valor_total), 0) || 0) +
        (serv.data?.reduce((a, b) => a + Number(b.valor_servico), 0) || 0) +
        (fin.data?.reduce((a, b) => a + Number(b.valor), 0) || 0);

      const resTotal = res.data?.reduce((a, b) => a + Number(b.valor), 0) || 0;

      setKpiData({ faturamento: fatTotal, resultado: resTotal, guias: guides.data?.length || 0 });
      setUpcomingGuides(guides.data || []);

      // Mock Chart Data - In a real app, aggregate this from actual daily/weekly transaction data
      setCashflowSeries([
        { period: 'Sem 1', receitas: fatTotal * 0.2, despesas: Math.abs(resTotal * 0.3), resultado: fatTotal * 0.1 },
        { period: 'Sem 2', receitas: fatTotal * 0.3, despesas: Math.abs(resTotal * 0.2), resultado: fatTotal * 0.2 },
        { period: 'Sem 3', receitas: fatTotal * 0.2, despesas: Math.abs(resTotal * 0.4), resultado: -fatTotal * 0.1 },
        { period: 'Sem 4', receitas: fatTotal * 0.3, despesas: Math.abs(resTotal * 0.1), resultado: fatTotal * 0.3 },
      ]);

      const { data: recentTx } = await supabase
        .from('finance_transactions')
        .select(
          `
          id, descricao, valor, tipo, data_competencia, 
          finance_parties(id, nome),
          finance_accounts(id, nome_conta)
        `
        )
        .eq('company_id', selectedCompany.id)
        .is('deleted_at', null)
        .order('data_competencia', { ascending: false })
        .limit(10);

      setRecentTransactions(recentTx || []);
    } catch (error) {
      console.error(error);
    } finally {
      setLoading(false);
    }
  }, [dateRange, selectedCompany]);

  useEffect(() => {
    if (selectedCompany && dateRange.startDate) fetchDashboardData();
  }, [selectedCompany, dateRange, fetchDashboardData]);

  if (!selectedCompany)
    return (
      <EmptyState
        title="Selecione uma empresa"
        description="Utilize o menu superior para selecionar uma empresa."
      />
    );

  const maskedValue = (val) => (showValues ? formatCurrency(val) : '••••••');
  const compactCardClass = '!h-auto !min-h-0';

  return (
    <div className="space-y-6 sm:space-y-8 animate-in fade-in duration-500">
      <Helmet>
        <title>Dashboard - {selectedCompany.nome}</title>
      </Helmet>

      <PageHeader
        title="Visão Geral"
        subtitle={`Acompanhamento financeiro de ${selectedCompany.nome}`}
        actions={
          <div className="flex flex-col sm:flex-row sm:items-center gap-2 w-full sm:w-auto">
            <div className="w-full sm:w-auto">
              <SmartFilter onPeriodChange={setDateRange} />
            </div>

            <div className="flex items-center gap-2 w-full sm:w-auto">
              <Button
                variant="outline"
                size="icon"
                onClick={() => setShowValues(!showValues)}
                className="shrink-0"
              >
                {showValues ? <Eye className="h-4 w-4" /> : <EyeOff className="h-4 w-4" />}
              </Button>

              <Button
                onClick={() => navigate('/cliente/financeiro/lancamentos')}
                variant="blueGradient"
                size="sm"
                className="gap-2 rounded-lg shadow-md hover:shadow-lg transition-all duration-200 w-full sm:w-auto"
              >
                <Plus className="h-4 w-4" /> Novo Lançamento
              </Button>
            </div>
          </div>
        }
      />

      {/* KPIs */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 sm:gap-6">
        <KpiCard
          title="Faturamento"
          value={maskedValue(kpiData.faturamento)}
          icon={DollarSign}
          variant="primary"
          trend={12}
        />
        <KpiCard
          title="Resultado Líquido"
          value={maskedValue(kpiData.resultado)}
          icon={TrendingUp}
          trend={kpiData.resultado >= 0 ? 5 : -5}
        />
        <KpiCard
          title="Guias Pendentes"
          value={kpiData.guias}
          icon={FileText}
          variant="secondary"
          trend={0}
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 sm:gap-8">
        {/* Main Column */}
        <div className="lg:col-span-2 space-y-6">
          <SectionCard
            title="Fluxo de Caixa"
            description="Entradas vs Saídas no período selecionado"
            className={compactCardClass}
          >
            <div className="h-[150px] sm:h-[220px] w-full">
              {loading ? (
                <Skeleton className="w-full h-full rounded-lg" />
              ) : (
                <ResponsiveContainer width="100%" height="100%">
                  <ComposedChart data={cashflowSeries}>
                    <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e2e8f0" />
                    <XAxis
                      dataKey="period"
                      axisLine={false}
                      tickLine={false}
                      tick={{ fill: '#64748b', fontSize: 12 }}
                      dy={10}
                    />
                    <YAxis
                      hide={!showValues}
                      axisLine={false}
                      tickLine={false}
                      tick={{ fill: '#64748b', fontSize: 12 }}
                    />
                    <Tooltip
                      cursor={{ fill: '#f1f5f9' }}
                      contentStyle={{
                        borderRadius: '8px',
                        border: 'none',
                        boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)',
                      }}
                    />
                    <Bar dataKey="receitas" fill="hsl(var(--primary))" radius={[4, 4, 0, 0]} barSize={24} name="Receitas" />
                    <Bar dataKey="despesas" fill="#ef4444" radius={[4, 4, 0, 0]} barSize={24} name="Despesas" />
                    <Line type="monotone" dataKey="resultado" stroke="hsl(var(--secondary))" strokeWidth={3} dot={{ r: 3 }} name="Resultado" />
                  </ComposedChart>
                </ResponsiveContainer>
              )}
            </div>
          </SectionCard>

          <SectionCard title="Transações Recentes" className={compactCardClass}>
            {loading ? (
              <div className="space-y-2 sm:space-y-3">
                {[1, 2, 3, 4].map((i) => (
                  <Skeleton key={i} className="h-12 sm:h-14 w-full rounded-xl" />
                ))}
              </div>
            ) : recentTransactions.length === 0 ? (
              <EmptyState
                title="Sem transações recentes"
                description="Nenhuma movimentação encontrada."
                className="py-3 sm:py-6"
              />
            ) : (
              <div className="space-y-2">
                {recentTransactions.slice(0, 4).map((tx) => (
                  <div
                    key={tx.id}
                    className="p-3 rounded-xl bg-white border hover:bg-slate-50 transition-colors"
                  >
                    <div className="flex items-start justify-between gap-3">
                      <div className="flex items-start gap-3 min-w-0">
                        <div
                          className={[
                            'p-2 rounded-lg shrink-0 mt-0.5',
                            tx.tipo === 'receita'
                              ? 'bg-emerald-100 text-emerald-600'
                              : 'bg-red-100 text-red-600',
                          ].join(' ')}
                        >
                          {tx.tipo === 'receita' ? (
                            <ArrowUpRight className="w-4 h-4" />
                          ) : (
                            <ArrowDownRight className="w-4 h-4" />
                          )}
                        </div>

                        <div className="min-w-0">
                          <p className="font-medium text-sm leading-5 line-clamp-2 break-words">
                            {tx.descricao}
                          </p>

                          <div className="mt-1 flex flex-wrap items-center gap-x-2 gap-y-1 text-xs text-muted-foreground">
                            <span className="flex items-center gap-1 whitespace-nowrap">
                              <Calendar className="w-3 h-3" />
                              {new Date(tx.data_competencia).toLocaleDateString('pt-BR')}
                            </span>
                            {tx.finance_parties?.nome ? (
                              <span className="text-muted-foreground/90 line-clamp-1">
                                • {tx.finance_parties.nome}
                              </span>
                            ) : null}
                          </div>
                        </div>
                      </div>

                      <div className="text-right shrink-0">
                        <p
                          className={[
                            'font-bold text-sm whitespace-nowrap',
                            tx.tipo === 'receita' ? 'text-emerald-600' : 'text-red-600',
                          ].join(' ')}
                        >
                          {maskedValue(tx.valor)}
                        </p>
                      </div>
                    </div>
                    <div className="mt-2 text-xs text-muted-foreground">
                      <span className="font-medium text-slate-600">Conta: </span>
                      <span className="line-clamp-1 break-words">
                        {tx.finance_accounts?.nome_conta || '—'}
                      </span>
                    </div>
                  </div>
                ))}

                <Button
                  variant="link"
                  className="w-full mt-1"
                  onClick={() => navigate('/cliente/financeiro/lancamentos')}
                >
                  Ver todas as transações <ArrowRight className="w-4 h-4 ml-1" />
                </Button>
              </div>
            )}
          </SectionCard>
        </div>

        {/* Side Column */}
        <div className="space-y-6">
          
          <FiscalRegimeCard 
            fiscalData={fiscalData}
            loading={fiscalLoading}
            error={fiscalError}
            onRetry={refetchFiscal}
            className={compactCardClass}
          />

          <SectionCard title="Próximos Pagamentos" className={compactCardClass}>
            {upcomingGuides.length === 0 ? (
              <EmptyState
                title="Tudo pago!"
                description="Nenhuma guia pendente."
                icon={FileText}
                className="py-3 sm:py-6"
              />
            ) : (
              <div className="space-y-2">
                {upcomingGuides.slice(0, 3).map((guide) => (
                  <div
                    key={guide.id}
                    className="flex items-center justify-between p-2 rounded-lg bg-slate-50 border border-slate-100"
                  >
                    <div className="flex items-center gap-3 min-w-0">
                      <div className="h-10 w-10 rounded-full bg-white border flex items-center justify-center text-primary shrink-0">
                        <FileText className="h-5 w-5" />
                      </div>
                      <div className="min-w-0">
                        <p className="font-semibold text-sm truncate">{guide.tipo_guia}</p>
                        <p className="text-xs text-muted-foreground whitespace-nowrap">
                          Vence: {new Date(guide.vencimento).toLocaleDateString('pt-BR')}
                        </p>
                      </div>
                    </div>

                    <span className="font-bold text-sm whitespace-nowrap">{maskedValue(guide.valor)}</span>
                  </div>
                ))}
              </div>
            )}

            <Button variant="link" className="w-full mt-2" onClick={() => navigate('/cliente/guias')}>
              Ver todas as guias <ArrowRight className="h-4 w-4 ml-1" />
            </Button>
          </SectionCard>
        </div>
      </div>
    </div>
  );
};

export default ClientDashboardPage;
