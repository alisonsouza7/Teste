import React from 'react';
import { Helmet } from 'react-helmet';
import { useToast } from '@/components/ui/use-toast';

const FalarComConterjPage = () => {
    const { toast } = useToast();

    const handleClick = () => {
        toast({
            title: "Funcionalidade em desenvolvimento",
            description: "🚧 This feature isn't implemented yet—but don't worry! You can request it in your next prompt! 🚀",
        });
    };
    
    return (
        <>
            <Helmet>
                <title>Falar com a Conterj</title>
            </Helmet>
            <div className="p-8 bg-white rounded-lg shadow">
                <h1 className="text-2xl font-bold mb-4">Falar com a Conterj</h1>
                <p className="text-gray-600 mb-6">Esta página ainda está em construção.</p>
                <button onClick={handleClick} className="bg-blue-600 text-white px-4 py-2 rounded-lg">Testar Notificação</button>
            </div>
        </>
    );
};

export default FalarComConterjPage;