import React from 'react';
import { Helmet } from 'react-helmet';
import { useCompany } from '@/contexts/CompanyContext';
import { useToast } from '@/components/ui/use-toast';

const FinanceiroPage = () => {
    const { selectedCompany } = useCompany();
    const { toast } = useToast();

    // Early return if no company is selected. The layout already handles this,
    // but it's good practice for component-level integrity.
    if (!selectedCompany) {
        return null;
    }
    
    const handleClick = () => {
        toast({
            title: "Funcionalidade em desenvolvimento",
            description: "🚧 This feature isn't implemented yet—but don't worry! You can request it in your next prompt! 🚀",
        });
    };

    return (
        <>
            <Helmet>
                <title>Financeiro - {selectedCompany.nome}</title>
            </Helmet>
            <div className="p-8 bg-white rounded-lg shadow">
                <h1 className="text-2xl font-bold mb-4">Financeiro</h1>
                <p className="text-gray-600 mb-6">Página de gestão financeira para {selectedCompany.nome}. Funcionalidade em construção.</p>
                <button onClick={handleClick} className="bg-blue-600 text-white px-4 py-2 rounded-lg">Testar Notificação</button>
            </div>
        </>
    );
};

export default FinanceiroPage;