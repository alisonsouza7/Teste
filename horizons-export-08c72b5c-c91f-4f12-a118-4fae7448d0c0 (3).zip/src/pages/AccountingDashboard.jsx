
import React, { useState } from 'react';
import { useAccountingClients } from '@/hooks/useAccountingClients';
import { useAccountingMetrics } from '@/hooks/useAccountingMetrics';
import { useAccountingTasks } from '@/hooks/useAccountingTasks';
import { useAccountingTemplates } from '@/hooks/useAccountingTemplates';
import ClientModal from '@/components/accounting/ClientModal';
import TemplateModal from '@/components/accounting/TemplateModal';
import TaskModal from '@/components/accounting/TaskModal';
import AccountingKanban from '@/components/accounting/AccountingKanban';
import AccountingAgenda from '@/components/accounting/AccountingAgenda';
import AccountingMetrics from '@/components/accounting/AccountingMetrics';
import TodayPanel from '@/components/accounting/TodayPanel';

import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Plus, Users, LayoutDashboard, Calendar as CalendarIcon, PieChart, FileCode, Edit, Archive, Loader2 } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { useCompany } from '@/contexts/CompanyContext';
import { useToast } from '@/components/ui/use-toast';

const AccountingDashboard = () => {
  const { selectedCompany } = useCompany();
  const { clients, loading: clientsLoading, createClient, updateClient, deleteClient } = useAccountingClients();
  const { tasks, loading: tasksLoading, createTask, updateTask, completeTask } = useAccountingTasks();
  const { createTemplate } = useAccountingTemplates();
  const { metrics, loading: metricsLoading } = useAccountingMetrics();
  const { toast } = useToast();

  // Modal States
  const [isClientModalOpen, setIsClientModalOpen] = useState(false);
  const [isTemplateModalOpen, setIsTemplateModalOpen] = useState(false);
  const [isTaskModalOpen, setIsTaskModalOpen] = useState(false);
  
  // Selection States
  const [editingClient, setEditingClient] = useState(null);
  const [editingTask, setEditingTask] = useState(null);
  const [selectedClientId, setSelectedClientId] = useState('all');

  // Filter tasks based on selected client
  const filteredTasks = selectedClientId === 'all' 
      ? tasks 
      : tasks.filter(t => t.client_id === selectedClientId);

  // Handlers
  const handleClientSave = async (data, id) => {
    try {
        if (id) await updateClient(id, data);
        else await createClient(data);
    } catch (e) {
        // Error handling already in hook
        console.error("Failed to save client:", e);
    }
  };

  const handleTemplateSave = async (data) => {
      await createTemplate(data);
  };

  const handleTaskSave = async (data, id) => {
      try {
          if (id) await updateTask(id, data);
          else {
              // Ensure we have a client ID if creating new without context
              if (!data.client_id && selectedClientId !== 'all') {
                  data.client_id = selectedClientId;
              }
              if (!data.client_id) {
                  toast({title: "Selecione um cliente para criar a tarefa", variant: "destructive"});
                  return;
              }
              data.owner_company_id = selectedCompany.id;
              await createTask(data);
          }
      } catch (e) {
          // handled in hook
      }
  };
  
  const handleTaskMove = async (result) => {
      const { destination, draggableId } = result;
      if (!destination) return;
      
      const newStatus = destination.droppableId;
      // Optimistic update handled by hook re-fetch or could be implemented locally
      await updateTask(draggableId, { status: newStatus });
  };

  const openTaskModal = (task = null) => {
      setEditingTask(task);
      setIsTaskModalOpen(true);
  };

  if (!selectedCompany) {
    return <div className="p-8 text-center text-gray-500">Selecione uma empresa para acessar a Máquina Contábil.</div>;
  }

  return (
    <div className="p-6 space-y-6 bg-slate-50 min-h-screen">
      
      {/* Header */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight text-slate-900">Máquina Contábil</h1>
          <p className="text-slate-500">Gestão inteligente para {selectedCompany.nome}</p>
        </div>
        
        <div className="flex gap-2">
            <Select value={selectedClientId} onValueChange={setSelectedClientId}>
                <SelectTrigger className="w-[200px] bg-white">
                    <SelectValue placeholder="Filtrar Cliente" />
                </SelectTrigger>
                <SelectContent>
                    <SelectItem value="all">Todos os Clientes</SelectItem>
                    {clients.map(c => <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>)}
                </SelectContent>
            </Select>
            
            <Button onClick={() => setIsTemplateModalOpen(true)} variant="outline" className="hidden md:flex">
                <FileCode className="mr-2 h-4 w-4" /> Template
            </Button>
            
            <Button onClick={() => { setEditingClient(null); setIsClientModalOpen(true); }} className="bg-blue-600 hover:bg-blue-700 text-white">
                <Plus className="mr-2 h-4 w-4" /> Cliente
            </Button>
        </div>
      </div>

      <Tabs defaultValue="today" className="space-y-4">
          <TabsList className="bg-white p-1 rounded-lg border shadow-sm">
              <TabsTrigger value="today"><LayoutDashboard className="w-4 h-4 mr-2" /> Hoje</TabsTrigger>
              <TabsTrigger value="kanban"><LayoutDashboard className="w-4 h-4 mr-2" /> Kanban</TabsTrigger>
              <TabsTrigger value="agenda"><CalendarIcon className="w-4 h-4 mr-2" /> Agenda</TabsTrigger>
              <TabsTrigger value="metrics"><PieChart className="w-4 h-4 mr-2" /> Métricas</TabsTrigger>
              <TabsTrigger value="clients"><Users className="w-4 h-4 mr-2" /> Clientes</TabsTrigger>
          </TabsList>

          <TabsContent value="today">
              {tasksLoading ? <div className="p-8 flex justify-center"><Loader2 className="animate-spin" /></div> : 
               <TodayPanel tasks={filteredTasks} onTaskComplete={(t) => completeTask(t.id)} />
              }
          </TabsContent>

          <TabsContent value="kanban" className="h-[calc(100vh-250px)]">
              {tasksLoading ? <div className="p-8 flex justify-center"><Loader2 className="animate-spin" /></div> :
               <AccountingKanban 
                  tasks={filteredTasks} 
                  onTaskMove={handleTaskMove} 
                  onTaskClick={openTaskModal} 
               />
              }
          </TabsContent>

          <TabsContent value="agenda" className="h-[calc(100vh-250px)]">
             <div className="bg-white rounded-xl shadow p-4 h-full">
                 {tasksLoading ? <div className="p-8 flex justify-center"><Loader2 className="animate-spin" /></div> :
                  <AccountingAgenda tasks={filteredTasks} />
                 }
             </div>
          </TabsContent>

          <TabsContent value="metrics">
              {metricsLoading ? <div className="p-8 flex justify-center"><Loader2 className="animate-spin" /></div> :
               <AccountingMetrics metrics={metrics} />
              }
          </TabsContent>

          <TabsContent value="clients">
               {/* Clients Grid Reused */}
                <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
                    {clientsLoading ? [1,2,3].map(i => <Skeleton key={i} className="h-40 w-full" />) :
                     clients.map((client) => (
                    <Card key={client.id} className="hover:shadow-md transition-shadow">
                        <CardHeader className="pb-2">
                            <div className="flex justify-between items-start">
                                <CardTitle className="text-base font-bold truncate pr-2">{client.name}</CardTitle>
                                <Badge variant="outline" className={client.regime_tributario === 'Simples Nacional' ? 'bg-green-50 text-green-700' : 'bg-blue-50 text-blue-700'}>
                                    {client.regime_tributario}
                                </Badge>
                            </div>
                            <p className="text-xs text-slate-500">{client.cnpj}</p>
                        </CardHeader>
                        <CardContent className="space-y-4">
                            <div className="space-y-1 text-sm text-slate-600">
                                <p><span className="font-medium">Contato:</span> {client.contact_person || '-'}</p>
                                <p><span className="font-medium">Tel:</span> {client.phone || '-'}</p>
                            </div>
                            <div className="pt-2 flex justify-end gap-2 border-t">
                                <Button variant="ghost" size="sm" onClick={() => { setEditingClient(client); setIsClientModalOpen(true); }}>
                                    <Edit className="h-4 w-4 text-slate-500" />
                                </Button>
                                <Button variant="ghost" size="sm" onClick={() => deleteClient(client.id)}>
                                    <Archive className="h-4 w-4 text-red-400" />
                                </Button>
                            </div>
                        </CardContent>
                    </Card>
                    ))}
                    {clients.length === 0 && !clientsLoading && (
                      <div className="col-span-full text-center py-12 border-2 border-dashed rounded-lg bg-white/50">
                        <p className="text-slate-500 mb-4">Nenhum cliente cadastrado ainda.</p>
                        <Button variant="outline" onClick={() => { setEditingClient(null); setIsClientModalOpen(true); }}>Começar Cadastro</Button>
                      </div>
                    )}
                </div>
          </TabsContent>
      </Tabs>

      {/* Modals */}
      <ClientModal 
        open={isClientModalOpen}
        onOpenChange={setIsClientModalOpen}
        clientToEdit={editingClient}
        onSave={handleClientSave}
      />

      <TemplateModal 
        open={isTemplateModalOpen}
        onOpenChange={setIsTemplateModalOpen}
        onSave={handleTemplateSave}
      />

      <TaskModal
        open={isTaskModalOpen}
        onOpenChange={setIsTaskModalOpen}
        taskToEdit={editingTask}
        clientName={editingTask?.accounting_clients?.name}
        onSave={handleTaskSave}
      />
    </div>
  );
};

export default AccountingDashboard;
