
import React, { useEffect, useState } from 'react';
import { Helmet } from 'react-helmet';
import { supabase } from '@/lib/customSupabaseClient';
import { useCompany } from '@/contexts/CompanyContext';
import { useToast } from '@/components/ui/use-toast';
import ServiceInvoiceUpload from '@/components/ServiceInvoiceUpload';
import BatchNfseUpload from '@/components/BatchNfseUpload';
import NfseConsultaModal from '@/components/nfse/NfseConsultaModal';
import NfseEmissaoModal from '@/components/NfseEmissaoModal';
import AccountSelectorDialog from '@/components/finance/AccountSelectorDialog';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from '@/components/ui/dialog';
import {
    DropdownMenu,
    DropdownMenuContent,
    DropdownMenuItem,
    DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { FileText, Download, Eye, Trash2, Search, ArrowUpDown, Loader2, AlertTriangle, Link2, Info, Upload, ChevronDown, Plus } from 'lucide-react';
import { Link } from 'react-router-dom';
import { useCompanyFiscalData } from '@/hooks/useCompanyFiscalData';

const NotasFiscaisPage = () => {
    const { selectedCompany } = useCompany();
    const { fiscalData, loading: fiscalLoading, error: fiscalError, refetch: refetchFiscal } = useCompanyFiscalData();
    const { toast } = useToast();
    const [invoices, setInvoices] = useState([]);
    const [loading, setLoading] = useState(true);

    // Filters
    const [dateStart, setDateStart] = useState('');
    const [dateEnd, setDateEnd] = useState('');
    const [searchTerm, setSearchTerm] = useState('');
    const [statusFilter, setStatusFilter] = useState('all');

    // Sorting
    const [sortConfig, setSortConfig] = useState({ key: 'data_emissao', direction: 'desc' });

    // Modals
    const [viewInvoice, setViewInvoice] = useState(null);
    const [deleteInvoice, setDeleteInvoice] = useState(null);
    const [isDeleting, setIsDeleting] = useState(false);

    // Import Modals State
    const [isSingleUploadOpen, setIsSingleUploadOpen] = useState(false);
    const [isBatchUploadOpen, setIsBatchUploadOpen] = useState(false);
    const [isNfseModalOpen, setIsNfseModalOpen] = useState(false);
    const [isEmissaoModalOpen, setIsEmissaoModalOpen] = useState(false);

    // Account selection for generating transactions
    const [pendingInvoiceForTransaction, setPendingInvoiceForTransaction] = useState(null);
    const [showAccountSelector, setShowAccountSelector] = useState(false);

    const fetchInvoices = async () => {
        if (!selectedCompany) return;
        setLoading(true);
        try {
            let query = supabase
                .from('service_invoices')
                .select(`
                    *,
                    finance_transactions(id, liquidado, tipo)
                `)
                .eq('company_id', selectedCompany.id)
                .is('deleted_at', null);

            const { data, error } = await query;

            if (error) throw error;
            setInvoices(data);
        } catch (error) {
            console.error('Error fetching invoices:', error);
            toast({ variant: "destructive", title: "Erro", description: "Não foi possível carregar as notas fiscais." });
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        fetchInvoices();
    }, [selectedCompany]);

    const handleDownload = async (path) => {
        if (!path) return;
        try {
            const { data, error } = await supabase.storage.from('service-invoices').createSignedUrl(path, 60);
            if (error) throw error;
            window.open(data.signedUrl, '_blank');
        } catch (error) {
             toast({ variant: "destructive", title: "Erro no download", description: "Arquivo não disponível." });
        }
    };

    const handleDelete = async () => {
        if (!deleteInvoice) return;
        setIsDeleting(true);
        try {
            const { error } = await supabase
                .from('service_invoices')
                .update({ deleted_at: new Date().toISOString() })
                .eq('id', deleteInvoice.id);

            if (error) throw error;

            toast({ title: "Sucesso", description: "NFS-e excluída do sistema." });
            setInvoices(prev => prev.filter(inv => inv.id !== deleteInvoice.id));
            setDeleteInvoice(null);
            
            // Refresh fiscal data since total changed
            refetchFiscal();
        } catch (error) {
            console.error('Error deleting invoice:', error);
            toast({ variant: "destructive", title: "Erro", description: "Não foi possível excluir a nota." });
        } finally {
            setIsDeleting(false);
        }
    };

    const ensurePartyForInvoice = async (invoice, selectedCompany, toast) => {
        try {
            if (invoice.party_id) return invoice.party_id;

            const documento = invoice.tomador_documento || invoice.emitente_documento || null;
            const nome = invoice.tomador_nome || invoice.emitente_nome || (documento ? `Cliente ${documento}` : null);

            if (!documento && !nome) return null;

            const { data: existing } = await supabase
                .from('finance_parties')
                .select('id')
                .eq('company_id', selectedCompany.id)
                .eq('documento', documento)
                .is('deleted_at', null)
                .maybeSingle();

            let partyId = existing?.id ?? null;

            if (!partyId) {
                const { data: created, error: insertError } = await supabase
                    .from('finance_parties')
                    .insert({
                        company_id: selectedCompany.id,
                        tipo: 'cliente',
                        nome,
                        documento,
                    })
                    .select('id')
                    .single();

                if (insertError) {
                    toast({
                        variant: 'destructive',
                        title: 'Erro',
                        description: 'Não foi possível cadastrar o cliente/fornecedor desta nota.',
                    });
                    return null;
                }
                partyId = created.id;
            }

            if (partyId && !invoice.party_id) {
                await supabase
                    .from('service_invoices')
                    .update({ party_id: partyId })
                    .eq('id', invoice.id);
            }

            return partyId;
        } catch (err) {
            console.error('Erro em ensurePartyForInvoice:', err);
            return null;
        }
    };

    const generateTransaction = async (invoice, selectedAccount = null) => {
        try {
            if (!selectedAccount) {
                const { data: accounts, error } = await supabase
                    .from('finance_accounts')
                    .select('id, nome_conta')
                    .eq('company_id', selectedCompany.id)
                    .is('deleted_at', null);

                if (error) throw error;

                if (accounts && accounts.length === 1) {
                    selectedAccount = accounts[0];
                } else if (accounts && accounts.length > 1) {
                    setPendingInvoiceForTransaction(invoice);
                    setShowAccountSelector(true);
                    return;
                }
            }

            const partyId = await ensurePartyForInvoice(invoice, selectedCompany, toast);

            const { data: categoryData } = await supabase
                .from('finance_chart_of_accounts')
                .select('id')
                .eq('company_id', selectedCompany.id)
                .eq('tipo', 'receita')
                .ilike('nome_conta', '%Prestação de Serviços%')
                .is('deleted_at', null)
                .limit(1)
                .maybeSingle();

            let categoryId = categoryData?.id;

            if (!categoryId) {
                const { data: fallbackCat } = await supabase
                    .from('finance_chart_of_accounts')
                    .select('id')
                    .eq('company_id', selectedCompany.id)
                    .eq('tipo', 'receita')
                    .is('deleted_at', null)
                    .limit(1)
                    .maybeSingle();

                categoryId = fallbackCat?.id;
            }

            if (!categoryId) {
                toast({
                    variant: 'destructive',
                    title: 'Erro',
                    description: 'Nenhuma categoria de receita encontrada para vincular o lançamento.',
                });
                return;
            }

            const transactionPayload = {
                company_id: selectedCompany.id,
                service_invoice_id: invoice.id,
                tipo: 'receita',
                valor: invoice.valor_servico,
                data_competencia: invoice.data_emissao,
                data_lancamento: invoice.data_emissao,
                categoria_id: categoryId,
                party_id: partyId,
                liquidado: false,
                origem: 'nfse',
                descricao: `NFS-e ${invoice.numero_nota} - ${
                    invoice.descricao_servico ? invoice.descricao_servico.substring(0, 50) : 'Serviços'
                }`,
            };

            if (selectedAccount?.id) {
                transactionPayload.conta_id = selectedAccount.id;
            }

            const { error } = await supabase.from('finance_transactions').insert(transactionPayload);

            if (error) throw error;

            toast({ title: 'Sucesso', description: 'Lançamento financeiro gerado.' });
            fetchInvoices();
        } catch (err) {
            console.error(err);
            toast({ variant: 'destructive', title: 'Erro', description: 'Falha ao gerar lançamento financeiro.' });
        }
    };

    const requestSort = (key) => {
        let direction = 'asc';
        if (sortConfig.key === key && sortConfig.direction === 'asc') {
            direction = 'desc';
        }
        setSortConfig({ key, direction });
    };

    const formatCurrency = (val) => new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(val);

    const sortedAndFilteredInvoices = React.useMemo(() => {
        let filtered = [...invoices];
        if (dateStart) filtered = filtered.filter(inv => inv.data_emissao >= dateStart);
        if (dateEnd) filtered = filtered.filter(inv => inv.data_emissao <= dateEnd);
        if (searchTerm) filtered = filtered.filter(inv => inv.numero_nota.toLowerCase().includes(searchTerm.toLowerCase()));
        if (statusFilter !== 'all') filtered = filtered.filter(inv => inv.status === statusFilter);

        filtered.sort((a, b) => {
            if (a[sortConfig.key] < b[sortConfig.key]) return sortConfig.direction === 'asc' ? -1 : 1;
            if (a[sortConfig.key] > b[sortConfig.key]) return sortConfig.direction === 'asc' ? 1 : -1;
            return 0;
        });

        return filtered;
    }, [invoices, dateStart, dateEnd, searchTerm, statusFilter, sortConfig]);

    if (!selectedCompany) return null;

    return (
        <>
            <Helmet>
                <title>Notas Fiscais - {selectedCompany.nome}</title>
            </Helmet>
            
            <div className="w-full max-w-6xl mx-auto px-4 py-6 space-y-6">
                <div className="flex justify-between items-center flex-wrap gap-4">
                    <div>
                        <h1 className="text-3xl font-bold tracking-tight">Notas Fiscais de Serviço</h1>
                        <p className="text-muted-foreground">Gerencie as NFS-e emitidas pela sua empresa.</p>
                    </div>
                    <div className="flex gap-2">
                        <Button
                            className="bg-purple-600 hover:bg-purple-700 gap-2"
                            onClick={() => setIsEmissaoModalOpen(true)}
                        >
                            <Plus className="w-4 h-4" /> Emitir NFS-e
                        </Button>
                        
                        <Button 
                            variant="outline" 
                            className="gap-2"
                            onClick={() => setIsNfseModalOpen(true)}
                        >
                            <Search className="w-4 h-4" /> Buscar NFS-e
                        </Button>

                        <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                                <Button className="gap-2 bg-green-600 hover:bg-green-700">
                                    <Upload className="w-4 h-4" /> Importar
                                    <ChevronDown className="w-4 h-4 ml-1 opacity-70" />
                                </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end">
                                <DropdownMenuItem onClick={() => setIsSingleUploadOpen(true)}>
                                    Importação Única (XML)
                                </DropdownMenuItem>
                                <DropdownMenuItem onClick={() => setIsBatchUploadOpen(true)}>
                                    Importação em Lote (XML)
                                </DropdownMenuItem>
                            </DropdownMenuContent>
                        </DropdownMenu>
                    </div>
                </div>

                <div className="w-full">
                     <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 flex gap-3">
                         <Info className="text-blue-600 w-5 h-5 shrink-0 mt-0.5" />
                         <div>
                             <h4 className="font-medium text-blue-900">Monitoramento de Limite</h4>
                             <p className="text-sm text-blue-700 mt-1">
                                 O sistema verifica automaticamente o limite de faturamento do seu regime tributário ({fiscalData?.regime_label || 'Verificando...'}) 
                                 ao importar novas notas fiscais. Mantenha seu cadastro atualizado.
                             </p>
                         </div>
                     </div>
                </div>

                {/* Filters */}
                <div className="grid grid-cols-1 md:grid-cols-5 gap-4 bg-white p-4 rounded-lg border shadow-sm">
                    <div className="space-y-1">
                        <Label className="text-xs">Data Inicial</Label>
                        <Input type="date" value={dateStart} onChange={e => setDateStart(e.target.value)} className="h-9" />
                    </div>
                    <div className="space-y-1">
                        <Label className="text-xs">Data Final</Label>
                        <Input type="date" value={dateEnd} onChange={e => setDateEnd(e.target.value)} className="h-9" />
                    </div>
                    <div className="space-y-1">
                        <Label className="text-xs">Número da Nota</Label>
                        <div className="relative">
                            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-gray-400" />
                            <Input 
                                type="text" 
                                placeholder="Buscar..." 
                                value={searchTerm} 
                                onChange={e => setSearchTerm(e.target.value)} 
                                className="h-9 pl-8" 
                            />
                        </div>
                    </div>
                    <div className="space-y-1">
                        <Label className="text-xs">Status</Label>
                        <select 
                            className="flex h-9 w-full rounded-md border border-input bg-background px-3 py-1 text-sm shadow-sm transition-colors focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring"
                            value={statusFilter}
                            onChange={e => setStatusFilter(e.target.value)}
                        >
                            <option value="all">Todos</option>
                            <option value="processado">Valida (Processado)</option>
                        </select>
                    </div>
                    <div className="flex items-end">
                        <Button variant="ghost" onClick={() => {
                            setDateStart('');
                            setDateEnd('');
                            setSearchTerm('');
                            setStatusFilter('all');
                        }} className="h-9 w-full">Limpar Filtros</Button>
                    </div>
                </div>

                <Card>
                    <CardHeader>
                        <CardTitle>Histórico de NFS-e</CardTitle>
                    </CardHeader>
                    <CardContent className="p-0">
                        {loading ? (
                            <div className="p-6 space-y-2">
                                <div className="h-10 w-full bg-gray-100 rounded animate-pulse" />
                                <div className="h-10 w-full bg-gray-100 rounded animate-pulse" />
                                <div className="h-10 w-full bg-gray-100 rounded animate-pulse" />
                            </div>
                        ) : sortedAndFilteredInvoices.length === 0 ? (
                            <div className="text-center py-10 text-gray-500">
                                <FileText className="w-12 h-12 mx-auto mb-3 opacity-20" />
                                <p>Nenhuma NFS-e encontrada com os filtros atuais.</p>
                            </div>
                        ) : (
                            <div className="relative w-full overflow-auto max-h-[600px]">
                                <Table>
                                    <TableHeader className="sticky top-0 bg-white z-10 shadow-sm">
                                        <TableRow>
                                            <TableHead 
                                                className="cursor-pointer hover:bg-gray-50"
                                                onClick={() => requestSort('data_emissao')}
                                            >
                                                <div className="flex items-center gap-1">
                                                    Data Emissão
                                                    <ArrowUpDown className="w-3 h-3" />
                                                </div>
                                            </TableHead>
                                            <TableHead 
                                                className="cursor-pointer hover:bg-gray-50"
                                                onClick={() => requestSort('numero_nota')}
                                            >
                                                <div className="flex items-center gap-1">
                                                    Número
                                                    <ArrowUpDown className="w-3 h-3" />
                                                </div>
                                            </TableHead>
                                            <TableHead>Série</TableHead>
                                            <TableHead>Tomador</TableHead>
                                            <TableHead 
                                                className="cursor-pointer hover:bg-gray-50"
                                                onClick={() => requestSort('valor_servico')}
                                            >
                                                <div className="flex items-center gap-1">
                                                    Valor (R$)
                                                    <ArrowUpDown className="w-3 h-3" />
                                                </div>
                                            </TableHead>
                                            <TableHead>Status Fin.</TableHead>
                                            <TableHead className="text-right">Ações</TableHead>
                                        </TableRow>
                                    </TableHeader>
                                    <TableBody>
                                        {sortedAndFilteredInvoices.map((invoice) => {
                                            const hasTransaction = invoice.finance_transactions && invoice.finance_transactions.length > 0;
                                            
                                            return (
                                            <TableRow key={invoice.id}>
                                                <TableCell>{new Date(invoice.data_emissao).toLocaleDateString('pt-BR')}</TableCell>
                                                <TableCell className="font-medium">{invoice.numero_nota}</TableCell>
                                                <TableCell>{invoice.serie || '-'}</TableCell>
                                                    <TableCell
                                                        className="max-w-[200px] truncate"
                                                        title={
                                                            invoice.tomador_nome ||
                                                            invoice.tomador_documento ||
                                                            invoice.emitente_nome ||
                                                            invoice.emitente_documento ||
                                                            '-'
                                                        }
                                                    >
                                                        {invoice.tomador_nome ||
                                                            invoice.tomador_documento ||
                                                            invoice.emitente_nome ||
                                                            invoice.emitente_documento ||
                                                            '-'}
                                                    </TableCell>
                                                <TableCell>{formatCurrency(invoice.valor_servico)}</TableCell>
                                                <TableCell>
                                                    {hasTransaction ? (
                                                        <Link to={`/cliente/financeiro/lancamentos?search=${encodeURIComponent(invoice.numero_nota)}`} className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800 hover:bg-blue-200">
                                                            Lançado <Link2 className="ml-1 w-3 h-3" />
                                                        </Link>
                                                    ) : (
                                                        <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-gray-100 text-gray-600">
                                                            Pendente
                                                        </span>
                                                    )}
                                                </TableCell>
                                                <TableCell className="text-right">
                                                    <div className="flex justify-end gap-2">
                                                        {!hasTransaction && (
                                                            <Button
                                                                variant="outline"
                                                                size="sm"
                                                                className="h-8 text-xs"
                                                                onClick={() => generateTransaction(invoice)}
                                                            >
                                                                Gerar Lançamento
                                                            </Button>
                                                        )}
                                                        <Button 
                                                            variant="ghost" 
                                                            size="icon" 
                                                            onClick={() => setViewInvoice(invoice)}
                                                            title="Ver Detalhes"
                                                        >
                                                            <Eye className="h-4 w-4 text-gray-500" />
                                                        </Button>
                                                        <Button 
                                                            variant="ghost" 
                                                            size="icon" 
                                                            className="text-red-500 hover:text-red-700 hover:bg-red-50"
                                                            onClick={() => setDeleteInvoice(invoice)}
                                                            title="Excluir"
                                                        >
                                                            <Trash2 className="h-4 w-4" />
                                                        </Button>
                                                    </div>
                                                </TableCell>
                                            </TableRow>
                                        )})}
                                    </TableBody>
                                </Table>
                            </div>
                        )}
                    </CardContent>
                </Card>

                {/* Detail Modal */}
                <Dialog open={!!viewInvoice} onOpenChange={(open) => !open && setViewInvoice(null)}>
                    <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
                        <DialogHeader>
                            <DialogTitle>Detalhes da NFS-e</DialogTitle>
                        </DialogHeader>
                        {viewInvoice && (
                            <div className="grid gap-4 py-4">
                                <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                                    <div className="space-y-1">
                                        <Label className="text-xs text-muted-foreground">Número</Label>
                                        <div className="font-medium">{viewInvoice.numero_nota}</div>
                                    </div>
                                    <div className="space-y-1">
                                        <Label className="text-xs text-muted-foreground">Série</Label>
                                        <div className="font-medium">{viewInvoice.serie || '-'}</div>
                                    </div>
                                    <div className="space-y-1">
                                        <Label className="text-xs text-muted-foreground">Data Emissão</Label>
                                        <div className="font-medium">{new Date(viewInvoice.data_emissao).toLocaleDateString('pt-BR')}</div>
                                    </div>
                                    <div className="space-y-1">
                                        <Label className="text-xs text-muted-foreground">Valor do Serviço</Label>
                                        <div className="font-medium text-green-700">{formatCurrency(viewInvoice.valor_servico)}</div>
                                    </div>
                                    <div className="space-y-1">
                                        <Label className="text-xs text-muted-foreground">Status</Label>
                                        <div className="capitalize">{viewInvoice.status}</div>
                                    </div>
                                    <div className="space-y-1">
                                        <Label className="text-xs text-muted-foreground">Cadastrado em</Label>
                                        <div className="text-sm">{new Date(viewInvoice.created_at).toLocaleString('pt-BR')}</div>
                                    </div>
                                </div>

                                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 border-t pt-4">
                                    <div className="space-y-1">
                                        <Label className="text-xs text-muted-foreground">Emitente (CNPJ)</Label>
                                        <div className="font-medium">{viewInvoice.emitente_documento}</div>
                                    </div>
                                    <div className="space-y-1">
                                        <Label className="text-xs text-muted-foreground">Tomador (CNPJ)</Label>
                                        <div className="font-medium">{viewInvoice.tomador_documento || 'Não informado'}</div>
                                    </div>
                                </div>

                                <div className="space-y-1 border-t pt-4">
                                    <Label className="text-xs text-muted-foreground">Descrição do Serviço</Label>
                                    <div className="bg-gray-50 p-3 rounded-md text-sm whitespace-pre-wrap">
                                        {viewInvoice.descricao_servico || 'Sem descrição'}
                                    </div>
                                </div>

                                {viewInvoice.arquivo_url && (
                                    <div className="flex justify-end pt-2">
                                        <Button variant="outline" className="gap-2" onClick={() => handleDownload(viewInvoice.arquivo_url)}>
                                            <Download className="w-4 h-4" /> Baixar XML Original
                                        </Button>
                                    </div>
                                )}
                            </div>
                        )}
                    </DialogContent>
                </Dialog>

                {/* Delete Confirmation Modal */}
                <Dialog open={!!deleteInvoice} onOpenChange={(open) => !isDeleting && !open && setDeleteInvoice(null)}>
                    <DialogContent>
                        <DialogHeader>
                            <DialogTitle className="flex items-center gap-2 text-red-600">
                                <AlertTriangle className="w-5 h-5" /> Confirmar Exclusão
                            </DialogTitle>
                            <DialogDescription className="pt-2">
                                Tem certeza que deseja excluir esta NFS-e (Nota {deleteInvoice?.numero_nota}) do sistema?
                                <br /><br />
                                <strong>Ela deixará de compor o faturamento e o cálculo do limite anual.</strong>
                            </DialogDescription>
                        </DialogHeader>
                        <DialogFooter className="gap-2 mt-4">
                            <Button variant="outline" onClick={() => setDeleteInvoice(null)} disabled={isDeleting}>Cancelar</Button>
                            <Button variant="destructive" onClick={handleDelete} disabled={isDeleting}>
                                {isDeleting && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                                Excluir Nota Fiscal
                            </Button>
                        </DialogFooter>
                    </DialogContent>
                </Dialog>

                {/* Import Modals Controlled by State */}
                <ServiceInvoiceUpload 
                    open={isSingleUploadOpen}
                    onOpenChange={setIsSingleUploadOpen}
                    onUploadSuccess={() => { 
                        fetchInvoices(); 
                        refetchFiscal(); 
                    }} 
                />
                <BatchNfseUpload 
                    open={isBatchUploadOpen}
                    onOpenChange={setIsBatchUploadOpen}
                    onUploadSuccess={() => { 
                        fetchInvoices(); 
                        refetchFiscal(); 
                    }} 
                />
                
                {/* NFSe Consulta Modal */}
                <NfseConsultaModal
                    open={isNfseModalOpen}
                    onOpenChange={setIsNfseModalOpen}
                    companyId={selectedCompany.id}
                    onSuccess={(data) => {
                        toast({ title: 'Sucesso', description: 'Consulta realizada com sucesso!' });
                        // Optionally reload list if data was imported
                        if (data.nfseXmlPath) {
                            fetchInvoices();
                            refetchFiscal();
                        }
                    }}
                />

                {/* NFSe Emissão Modal */}
                <NfseEmissaoModal
                    open={isEmissaoModalOpen}
                    onOpenChange={setIsEmissaoModalOpen}
                    companyId={selectedCompany.id}
                    onSuccess={(data) => {
                        console.log('DPS emitida:', data);
                        // We could trigger a refresh or check status here if needed
                    }}
                />
            </div>

            <AccountSelectorDialog
                isOpen={showAccountSelector}
                onClose={() => {
                    setShowAccountSelector(false);
                    setPendingInvoiceForTransaction(null);
                }}
                onSelectAccount={(account) => {
                    setShowAccountSelector(false);
                    if (pendingInvoiceForTransaction) {
                        generateTransaction(pendingInvoiceForTransaction, account);
                        setPendingInvoiceForTransaction(null);
                    }
                }}
                companyId={selectedCompany?.id}
                title="Selecionar Conta para Lançamento"
                description="Escolha a conta bancária onde o lançamento da nota fiscal será vinculado."
            />
        </>
    );
};

export default NotasFiscaisPage;
