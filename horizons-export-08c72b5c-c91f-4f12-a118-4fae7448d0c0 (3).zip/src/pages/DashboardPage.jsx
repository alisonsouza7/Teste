import React, { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { supabase } from '@/lib/customSupabaseClient';
import { Button } from '@/components/ui/button';
import { LogOut, Building2, ChevronDown } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';

const DashboardPage = () => {
  const { user, signOut } = useAuth();
  const { toast } = useToast();
  const [userData, setUserData] = useState(null);
  const [companies, setCompanies] = useState([]);
  const [selectedCompany, setSelectedCompany] = useState(null);
  const [loading, setLoading] = useState(true);
  const [showCompanyDropdown, setShowCompanyDropdown] = useState(false);

  useEffect(() => {
    if (user) {
      fetchUserData();
      fetchCompanies();
    }
  }, [user]);

  const fetchUserData = async () => {
    try {
      const { data, error } = await supabase
        .from('users')
        .select('*')
        .eq('id', user.id)
        .single();

      if (error) throw error;
      setUserData(data);
    } catch (error) {
      console.error('Error fetching user data:', error);
      toast({
        variant: "destructive",
        title: "Erro",
        description: "Não foi possível carregar seus dados"
      });
    }
  };

  const fetchCompanies = async () => {
    try {
      const { data, error } = await supabase
        .from('user_company_roles')
        .select(`
          papel,
          companies (
            id,
            nome,
            tipo_pessoa,
            cnpj_cpf
          )
        `)
        .eq('user_id', user.id);

      if (error) throw error;
      
      const companiesData = data.map(item => ({
        ...item.companies,
        papel: item.papel
      }));
      
      setCompanies(companiesData);
      if (companiesData.length > 0) {
        setSelectedCompany(companiesData[0]);
      }
    } catch (error) {
      console.error('Error fetching companies:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleSignOut = async () => {
    await signOut();
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-50 to-indigo-100">
        <motion.div
          animate={{ rotate: 360 }}
          transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
          className="w-12 h-12 border-4 border-blue-600 border-t-transparent rounded-full"
        />
      </div>
    );
  }

  return (
    <>
      <Helmet>
        <title>Dashboard - Sistema Financeiro</title>
        <meta name="description" content="Painel de controle do sistema financeiro" />
      </Helmet>

      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
        <nav className="bg-white shadow-md">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex justify-between items-center h-16">
              <div className="flex items-center gap-3">
                <Building2 className="w-8 h-8 text-blue-600" />
                <span className="text-xl font-bold text-gray-900">Sistema Financeiro</span>
              </div>
              
              <Button
                onClick={handleSignOut}
                variant="outline"
                className="flex items-center gap-2 hover:bg-red-50 hover:text-red-600 hover:border-red-300 transition-all"
              >
                <LogOut className="w-4 h-4" />
                Sair
              </Button>
            </div>
          </div>
        </nav>

        <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            <div className="bg-white rounded-2xl shadow-xl p-8 mb-6">
              <h1 className="text-3xl font-bold text-gray-900 mb-2">
                Bem-vindo, {userData?.nome || 'Usuário'}! 👋
              </h1>
              <p className="text-gray-600">
                {userData?.tipo && `Tipo: ${userData.tipo.charAt(0).toUpperCase() + userData.tipo.slice(1)}`}
              </p>
            </div>

            {companies.length > 0 && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: 0.1 }}
                className="bg-white rounded-2xl shadow-xl p-8"
              >
                <h2 className="text-2xl font-bold text-gray-900 mb-6">Suas Empresas</h2>
                
                <div className="relative">
                  <button
                    onClick={() => setShowCompanyDropdown(!showCompanyDropdown)}
                    className="w-full flex items-center justify-between p-4 bg-blue-50 border-2 border-blue-200 rounded-lg hover:bg-blue-100 transition-all"
                  >
                    <div className="flex items-center gap-3">
                      <Building2 className="w-6 h-6 text-blue-600" />
                      <div className="text-left">
                        <p className="font-semibold text-gray-900">
                          {selectedCompany?.nome || 'Selecione uma empresa'}
                        </p>
                        {selectedCompany && (
                          <p className="text-sm text-gray-600">
                            {selectedCompany.cnpj_cpf} • {selectedCompany.papel}
                          </p>
                        )}
                      </div>
                    </div>
                    <ChevronDown className={`w-5 h-5 text-gray-600 transition-transform ${showCompanyDropdown ? 'rotate-180' : ''}`} />
                  </button>

                  {showCompanyDropdown && companies.length > 1 && (
                    <motion.div
                      initial={{ opacity: 0, y: -10 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="absolute z-10 w-full mt-2 bg-white border border-gray-200 rounded-lg shadow-lg"
                    >
                      {companies.map((company) => (
                        <button
                          key={company.id}
                          onClick={() => {
                            setSelectedCompany(company);
                            setShowCompanyDropdown(false);
                          }}
                          className="w-full flex items-center gap-3 p-4 hover:bg-gray-50 transition-all border-b border-gray-100 last:border-b-0"
                        >
                          <Building2 className="w-5 h-5 text-blue-600" />
                          <div className="text-left">
                            <p className="font-semibold text-gray-900">{company.nome}</p>
                            <p className="text-sm text-gray-600">
                              {company.cnpj_cpf} • {company.papel}
                            </p>
                          </div>
                        </button>
                      ))}
                    </motion.div>
                  )}
                </div>

                <div className="mt-6 grid grid-cols-1 md:grid-cols-3 gap-4">
                  {selectedCompany && (
                    <>
                      <div className="p-4 bg-gradient-to-br from-blue-50 to-blue-100 rounded-lg">
                        <p className="text-sm text-gray-600 mb-1">Tipo</p>
                        <p className="text-lg font-semibold text-gray-900">
                          {selectedCompany.tipo_pessoa === 'fisica' ? 'Pessoa Física' : 'Pessoa Jurídica'}
                        </p>
                      </div>
                      
                      <div className="p-4 bg-gradient-to-br from-green-50 to-green-100 rounded-lg">
                        <p className="text-sm text-gray-600 mb-1">Documento</p>
                        <p className="text-lg font-semibold text-gray-900">{selectedCompany.cnpj_cpf}</p>
                      </div>
                      
                      <div className="p-4 bg-gradient-to-br from-purple-50 to-purple-100 rounded-lg">
                        <p className="text-sm text-gray-600 mb-1">Seu Papel</p>
                        <p className="text-lg font-semibold text-gray-900 capitalize">{selectedCompany.papel}</p>
                      </div>
                    </>
                  )}
                </div>
              </motion.div>
            )}

            {companies.length === 0 && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: 0.1 }}
                className="bg-white rounded-2xl shadow-xl p-8 text-center"
              >
                <Building2 className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                <h2 className="text-xl font-semibold text-gray-900 mb-2">
                  Nenhuma empresa cadastrada
                </h2>
                <p className="text-gray-600">
                  Você ainda não está vinculado a nenhuma empresa.
                </p>
              </motion.div>
            )}
          </motion.div>
        </main>
      </div>
    </>
  );
};

export default DashboardPage;