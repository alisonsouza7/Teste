
import React, { useState, useEffect, useMemo } from 'react';
import { useCompany } from '@/contexts/CompanyContext';
import { useFinanceTransactions } from '@/hooks/useFinanceTransactions';
import { supabase } from '@/lib/customSupabaseClient';
import { Card, CardHeader, CardTitle, CardContent, CardDescription } from '@/components/ui/card';
import { 
  AlertTriangle, 
  TrendingUp, 
  TrendingDown, 
  BarChart2, 
  ArrowRight,
  Wallet,
  ArrowUpRight,
  ArrowDownRight,
  CreditCard,
  Landmark,
  PieChart as PieChartIcon,
  Calendar
} from 'lucide-react';
import { 
  ResponsiveContainer, 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  Tooltip, 
  Legend,
  AreaChart,
  Area,
  CartesianGrid,
  PieChart,
  Pie,
  Cell
} from 'recharts';
import { Button } from '@/components/ui/button';
import { Link } from 'react-router-dom';
import SmartFilter from '@/components/SmartFilter';
import { applyPeriodFilterToQuery } from '@/lib/periodHelpers';
import { cn, formatTransactionValue } from '@/lib/utils';
import { Skeleton } from '@/components/ui/skeleton';
import UpcomingPaymentsCard from '@/components/finance/UpcomingPaymentsCard';
import { format, parseISO } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import EmptyState from '@/components/ui/EmptyState';

const COLORS = ['#10B981', '#3B82F6', '#F59E0B', '#EF4444', '#8B5CF6', '#EC4899', '#6366F1'];

// --- Components ---

const KPICard = ({ title, value, icon: Icon, trend, type = 'neutral', loading }) => {
  const isPositive = type === 'positive';
  const isNegative = type === 'negative';
  
  return (
    <Card className="relative overflow-hidden border-border/60 shadow-sm hover:shadow-md transition-shadow">
      <CardContent className="p-6">
        {loading ? (
           <div className="space-y-2">
             <Skeleton className="h-4 w-24" />
             <Skeleton className="h-8 w-32" />
           </div>
        ) : (
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-muted-foreground mb-1">{title}</p>
              <h3 className={cn("text-2xl font-bold tracking-tight", 
                  isPositive && "text-emerald-600",
                  isNegative && "text-red-600"
              )}>
                {formatTransactionValue(value)}
              </h3>
            </div>
            <div className={cn("h-12 w-12 rounded-full flex items-center justify-center bg-muted/50",
                isPositive && "bg-emerald-100 text-emerald-600",
                isNegative && "bg-red-100 text-red-600",
                type === 'neutral' && "bg-blue-100 text-blue-600"
            )}>
              <Icon className="h-6 w-6" />
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

const RecentTransactionsList = ({ transactions, loading }) => {
    if (loading) {
        return (
            <div className="space-y-3">
                {[1,2,3,4].map(i => <Skeleton key={i} className="h-14 w-full rounded-xl" />)}
            </div>
        );
    }

    if (!transactions || transactions.length === 0) {
        return <EmptyState title="Sem transações recentes" description="Nenhuma movimentação encontrada." className="py-8" />;
    }

    return (
        <div className="space-y-3">
            {transactions.slice(0, 5).map(tx => (
                <div key={tx.id} className="flex items-center justify-between p-3 rounded-xl bg-white border hover:bg-slate-50 transition-colors">
                    <div className="flex items-center gap-3 min-w-0">
                        <div className={cn("p-2 rounded-lg shrink-0", 
                            tx.tipo === 'receita' ? "bg-emerald-100 text-emerald-600" : "bg-red-100 text-red-600"
                        )}>
                            {tx.tipo === 'receita' ? <ArrowUpRight className="w-4 h-4"/> : <ArrowDownRight className="w-4 h-4"/>}
                        </div>
                        <div className="min-w-0">
                            <p className="font-medium text-sm truncate">{tx.descricao}</p>
                            <div className="flex items-center gap-2 text-xs text-muted-foreground">
                                <span className="flex items-center gap-1">
                                    <Calendar className="w-3 h-3"/>
                                    {format(parseISO(tx.data_competencia), 'dd/MM/yyyy')}
                                </span>
                                {tx.finance_parties && (
                                    <span className="truncate hidden sm:inline">• {tx.finance_parties.nome}</span>
                                )}
                            </div>
                        </div>
                    </div>
                    <div className="text-right shrink-0">
                        <p className={cn("font-bold text-sm", 
                            tx.tipo === 'receita' ? "text-emerald-600" : "text-red-600"
                        )}>
                            {formatTransactionValue(tx.valor)}
                        </p>
                        <p className="text-xs text-muted-foreground">
                            {tx.finance_accounts?.nome_conta}
                        </p>
                    </div>
                </div>
            ))}
            <div className="pt-2">
                 <Button variant="ghost" className="w-full text-xs text-muted-foreground" asChild>
                     <Link to="/cliente/financeiro/lancamentos">Ver todas as transações <ArrowRight className="w-3 h-3 ml-1"/></Link>
                 </Button>
            </div>
        </div>
    );
}

const FinanceDashboard = () => {
  const { selectedCompany } = useCompany();
  const [loading, setLoading] = useState(true);
  const [dateRange, setDateRange] = useState({ startDate: '', endDate: '' });

  // Data States
  const [kpis, setKpis] = useState({
    saldoTotal: 0,
    entradasMes: 0,
    saidasMes: 0,
    resultadoMes: 0
  });

  const [expensesByCategory, setExpensesByCategory] = useState([]);
  const [revenueByCategory, setRevenueByCategory] = useState([]);
  const [accounts, setAccounts] = useState([]);
  const [recentTransactions, setRecentTransactions] = useState([]);

  useEffect(() => {
    if (!selectedCompany || !dateRange.startDate || !dateRange.endDate) return;

    const fetchData = async () => {
      setLoading(true);

      try {
        // 1. Fetch Accounts & Balances
        const { data: accountsData } = await supabase
          .from('finance_accounts')
          .select('*')
          .eq('company_id', selectedCompany.id)
          .is('deleted_at', null);

        setAccounts(accountsData || []);

        // 2. Fetch Transactions for Period (for Charts & KPIs)
        let query = supabase
          .from('finance_transactions')
          .select('tipo, valor, liquidado, data_competencia, vencimento, categoria_id, finance_chart_of_accounts(nome_conta)')
          .eq('company_id', selectedCompany.id)
          .is('deleted_at', null)
          .eq('liquidado', true);

        query = applyPeriodFilterToQuery(query, dateRange);

        const { data: periodTransactions } = await query;

        // 3. Fetch Recent Transactions (Limit 10)
        const { data: recentTx } = await supabase
            .from('finance_transactions')
            .select(`
                id, descricao, valor, tipo, data_competencia, liquidado, 
                finance_parties(nome),
                finance_accounts(nome_conta)
            `)
            .eq('company_id', selectedCompany.id)
            .is('deleted_at', null)
            .order('data_competencia', { ascending: false })
            .limit(10);
            
        setRecentTransactions(recentTx || []);

        // Process Data for KPIs & Charts
        let saldoTotalPeriodo = 0;
        let entradas = 0;
        let saidas = 0;
        let resultadoMes = 0;

        const expMap = {};
        const revMap = {};

        periodTransactions?.forEach((t) => {
          const val = Number(t.valor || 0);
          const cat = t.finance_chart_of_accounts?.nome_conta || 'Outros';

          if (t.tipo === 'receita') {
              entradas += val;
              revMap[cat] = (revMap[cat] || 0) + val;
              resultadoMes += val;
          } else if (t.tipo === 'despesa') {
              saidas += val;
              expMap[cat] = (expMap[cat] || 0) + val;
              resultadoMes -= val;
          }
        });

        // Convert Maps to Arrays
        setKpis({
          saldoTotal: entradas - saidas, // Net for period
          entradasMes: entradas,
          saidasMes: saidas,
          resultadoMes
        });

        setExpensesByCategory(
          Object.entries(expMap)
            .map(([name, value]) => ({ name, value }))
            .sort((a, b) => b.value - a.value)
        );
        setRevenueByCategory(
          Object.entries(revMap)
            .map(([name, value]) => ({ name, value }))
            .sort((a, b) => b.value - a.value)
        );

      } catch (e) {
        console.error(e);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, [selectedCompany, dateRange]);

  const topExpenses = useMemo(() => expensesByCategory.slice(0, 5), [expensesByCategory]);
  const totalBalance = useMemo(() => accounts.reduce((acc, curr) => acc + Number(curr.saldo_atual || 0), 0), [accounts]);

  return (
    <div className="space-y-6 animate-in fade-in duration-500">
      {/* Header & Filters */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 sticky top-0 z-10 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 py-4 -mx-4 px-4 md:static md:p-0 md:bg-transparent border-b md:border-none">
        <div>
           <h2 className="text-2xl font-bold tracking-tight">Visão Geral</h2>
           <p className="text-muted-foreground text-sm">Acompanhe a saúde financeira da sua empresa.</p>
        </div>
        <div className="w-full md:w-auto bg-card border rounded-lg p-1 shadow-sm">
           <SmartFilter onPeriodChange={setDateRange} className="w-full" />
        </div>
      </div>

      {/* KPI Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <KPICard 
            title="Entradas" 
            value={kpis.entradasMes} 
            icon={ArrowUpRight} 
            type="positive" 
            loading={loading}
        />
        <KPICard 
            title="Saídas" 
            value={kpis.saidasMes} 
            icon={ArrowDownRight} 
            type="negative" 
            loading={loading}
        />
        <KPICard 
            title="Resultado do Período" 
            value={kpis.resultadoMes} 
            icon={kpis.resultadoMes >= 0 ? TrendingUp : TrendingDown} 
            type={kpis.resultadoMes >= 0 ? "positive" : "negative"} 
            loading={loading}
        />
        <KPICard 
            title="Saldo Geral em Contas" 
            value={totalBalance} 
            icon={Wallet} 
            type="neutral" 
            loading={loading}
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          
          {/* Recent Transactions & Upcoming */}
          <div className="lg:col-span-2 space-y-6">
              {/* Upcoming Payments */}
              <UpcomingPaymentsCard />

               {/* Recent Transactions */}
               <Card className="shadow-sm border-border/60">
                  <CardHeader>
                      <CardTitle className="text-lg flex items-center gap-2">
                          <BarChart2 className="w-5 h-5 text-primary"/> Transações Recentes
                      </CardTitle>
                  </CardHeader>
                  <CardContent>
                      <RecentTransactionsList transactions={recentTransactions} loading={loading} />
                  </CardContent>
              </Card>
          </div>

          {/* Side Panel: Accounts & Charts */}
          <div className="space-y-6">
              <Card className="shadow-sm border-border/60">
                  <CardHeader>
                      <CardTitle className="text-lg flex items-center gap-2">
                          <Wallet className="w-5 h-5 text-primary"/> Contas
                      </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                       {loading ? (
                           <div className="space-y-3">
                               <Skeleton className="h-12 w-full rounded-lg" />
                               <Skeleton className="h-12 w-full rounded-lg" />
                           </div>
                       ) : accounts.length > 0 ? (
                           <div className="space-y-3">
                               {accounts.map(acc => (
                                   <div key={acc.id} className="flex items-center justify-between p-3 rounded-xl bg-muted/30 border">
                                       <div>
                                           <p className="font-medium text-sm">{acc.nome_conta}</p>
                                           <p className="text-xs text-muted-foreground capitalize">{acc.banco || acc.tipo}</p>
                                       </div>
                                       <div className="text-right">
                                           <p className={cn("font-bold text-sm", acc.saldo_atual < 0 ? "text-red-600" : "text-foreground")}>
                                               {formatTransactionValue(acc.saldo_atual)}
                                           </p>
                                       </div>
                                   </div>
                               ))}
                           </div>
                       ) : (
                           <div className="text-center py-4 text-muted-foreground text-sm">Nenhuma conta cadastrada</div>
                       )}
                       <Button variant="outline" className="w-full text-xs" asChild>
                           <Link to="/cliente/financeiro/contas">Gerenciar Contas</Link>
                       </Button>
                  </CardContent>
              </Card>

              {/* Top Expenses Chart (Simplified) */}
              <Card className="shadow-sm border-border/60">
                  <CardHeader>
                      <CardTitle className="text-lg flex items-center gap-2">
                          <PieChartIcon className="w-5 h-5 text-red-500"/> Top Despesas
                      </CardTitle>
                  </CardHeader>
                  <CardContent className="h-[250px]">
                      {topExpenses.length > 0 ? (
                           <ResponsiveContainer width="100%" height="100%">
                               <PieChart>
                                   <Pie
                                       data={topExpenses}
                                       cx="50%"
                                       cy="50%"
                                       innerRadius={50}
                                       outerRadius={70}
                                       paddingAngle={5}
                                       dataKey="value"
                                   >
                                       {topExpenses.map((entry, index) => (
                                           <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                                       ))}
                                   </Pie>
                                   <Tooltip formatter={(value) => formatTransactionValue(value)} />
                                   <Legend verticalAlign="bottom" height={36} iconType="circle" />
                               </PieChart>
                           </ResponsiveContainer>
                      ) : (
                          <div className="h-full flex items-center justify-center text-muted-foreground text-sm">Sem dados</div>
                      )}
                  </CardContent>
              </Card>
          </div>
      </div>
    </div>
  );
};

export default FinanceDashboard;
