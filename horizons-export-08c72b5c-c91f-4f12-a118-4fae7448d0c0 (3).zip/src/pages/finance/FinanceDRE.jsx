
import React, { useMemo, useState } from 'react';
import { useCompany } from '@/contexts/CompanyContext';
import { useToast } from '@/components/ui/use-toast';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Download, Loader2, ChevronDown, ChevronRight } from 'lucide-react';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { format, startOfMonth, endOfMonth, parseISO } from 'date-fns';
import { cn } from '@/lib/utils';
import jsPDF from 'jspdf';
import 'jspdf-autotable';
import DateFilterCapsule from '@/components/finance/DateFilterCapsule.jsx';

import { useDREData } from '@/hooks/useDREData';

// util
const fmtBRL = (v) => new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(v ?? 0);
const fmtPct = (v) => `${(v ?? 0).toFixed(2)}%`;

const FinanceDRE = () => {
  const { selectedCompany } = useCompany();
  const { toast } = useToast();

  const [dateRange, setDateRange] = useState({
    startDate: format(startOfMonth(new Date()), 'yyyy-MM-dd'),
    endDate: format(endOfMonth(new Date()), 'yyyy-MM-dd'),
  });

  // "competencia" ou "realizado" – deixa preparado, mesmo que seu compute trate isso
  const [viewType, setViewType] = useState('competencia');

  // estados de expansão
  const [openBlocks, setOpenBlocks] = useState(() => ({
    receita_bruta: true,
    deducoes: true,
    cpv_csp: true,
    despesas_oper: true,
    resultado_fin: false,
  }));

  const companyId = selectedCompany?.id;

  const { loading, error, dreData } = useDREData(companyId, dateRange, viewType);

  // segurança: se seu dreCompute retornar null/undefined
  const safe = useMemo(() => {
    if (!dreData) return null;

    // Esperado do dreCompute (estrutura mínima)
    // dreData = {
    //   base: { receita_bruta },
    //   blocks: [
    //     { key, label, total, percentOfGross, lines: [{ id, label, total, percentOfGross }] }
    //   ],
    //   totals: { receita_bruta, deducoes, receita_liquida, cpv_csp, lucro_bruto, despesas_oper, ebitda, resultado_fin, resultado_liquido }
    // }
    return dreData;
  }, [dreData]);

  const receitaBruta = safe?.totals?.receita_bruta ?? 0;

  const toggleBlock = (key) => {
    setOpenBlocks((prev) => ({ ...prev, [key]: !prev[key] }));
  };

  const handleExportPDF = () => {
    if (!safe) return;

    try {
      const doc = new jsPDF();
      doc.text(`DRE Gerencial - ${selectedCompany?.nome ?? ''}`, 14, 15);
      doc.text(
        `Período: ${format(parseISO(dateRange.startDate), 'dd/MM/yyyy')} a ${format(parseISO(dateRange.endDate), 'dd/MM/yyyy')}`,
        14,
        22
      );

      const rows = [];

      // blocos + detalhamento
      safe.blocks.forEach((b) => {
        rows.push([b.label, fmtBRL(b.total), fmtPct(b.percentOfGross)]);
        (b.lines || []).forEach((l) => {
          rows.push([`   ${l.label}`, fmtBRL(l.total), fmtPct(l.percentOfGross)]);
        });
        rows.push(['', '', '']);
      });

      // totais principais
      rows.push(['Receita Líquida', fmtBRL(safe.totals.receita_liquida), fmtPct((safe.totals.receita_liquida / (receitaBruta || 1)) * 100)]);
      rows.push(['Lucro Bruto', fmtBRL(safe.totals.lucro_bruto), fmtPct((safe.totals.lucro_bruto / (receitaBruta || 1)) * 100)]);
      rows.push(['EBITDA', fmtBRL(safe.totals.ebitda), fmtPct((safe.totals.ebitda / (receitaBruta || 1)) * 100)]);
      rows.push(['Resultado Líquido', fmtBRL(safe.totals.resultado_liquido), fmtPct((safe.totals.resultado_liquido / (receitaBruta || 1)) * 100)]);

      doc.autoTable({
        head: [['Linha', 'Valor', '% s/ Receita Bruta']],
        body: rows,
        startY: 30,
      });

      doc.save(`DRE_${dateRange.startDate}_${dateRange.endDate}.pdf`);
    } catch (e) {
      console.error(e);
      toast({ title: 'Erro', description: 'Falha ao exportar PDF.', variant: 'destructive' });
    }
  };

  if (error) {
    return (
      <div className="space-y-4">
        <h1 className="text-2xl font-bold tracking-tight text-slate-900">DRE</h1>
        <div className="p-4 border rounded-md bg-white">
          <p className="text-red-600 font-medium">Erro ao carregar dados da DRE.</p>
          <p className="text-slate-600 text-sm mt-1">{String(error?.message ?? error)}</p>
        </div>
      </div>
    );
  }

  const cards = safe?.totals
    ? [
      { label: 'Receita Bruta', value: safe.totals.receita_bruta, pct: 100, tone: 'text-emerald-700' },
      { label: 'Receita Líquida', value: safe.totals.receita_liquida, pct: (safe.totals.receita_liquida / (receitaBruta || 1)) * 100, tone: 'text-slate-900' },
      { label: 'Lucro Bruto', value: safe.totals.lucro_bruto, pct: (safe.totals.lucro_bruto / (receitaBruta || 1)) * 100, tone: safe.totals.lucro_bruto >= 0 ? 'text-emerald-700' : 'text-red-700' },
      { label: 'EBITDA', value: safe.totals.ebitda, pct: (safe.totals.ebitda / (receitaBruta || 1)) * 100, tone: safe.totals.ebitda >= 0 ? 'text-emerald-700' : 'text-red-700' },
      { label: 'Resultado Líquido', value: safe.totals.resultado_liquido, pct: (safe.totals.resultado_liquido / (receitaBruta || 1)) * 100, tone: safe.totals.resultado_liquido >= 0 ? 'text-emerald-700' : 'text-red-700' },
    ]
    : [];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col xl:flex-row justify-between items-start xl:items-center gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-slate-900">DRE Gerencial</h1>
          <p className="text-slate-500">Estrutura gerencial com percentuais sobre Receita Bruta e blocos expansíveis.</p>
        </div>

        <div className="flex flex-wrap items-center gap-3 w-full xl:w-auto">
          
          <DateFilterCapsule 
            dateRange={dateRange} 
            onDateRangeChange={setDateRange} 
          />

          <div className="h-6 w-px bg-slate-200 hidden sm:block mx-1"></div>

          <div className="flex bg-slate-100 p-1 rounded-lg">
            <Button 
                variant={viewType === 'competencia' ? 'white' : 'ghost'} 
                size="sm"
                onClick={() => setViewType('competencia')}
                className={cn("h-7 px-3 text-xs", viewType === 'competencia' && "bg-white shadow-sm font-medium")}
            >
              Competência
            </Button>
            <Button 
                variant={viewType === 'realizado' ? 'white' : 'ghost'} 
                size="sm"
                onClick={() => setViewType('realizado')}
                className={cn("h-7 px-3 text-xs", viewType === 'realizado' && "bg-white shadow-sm font-medium")}
            >
              Realizado
            </Button>
          </div>

          <Button variant="outline" size="sm" onClick={handleExportPDF} disabled={!safe || loading} className="h-8">
            <Download className="mr-2 h-3.5 w-3.5" /> PDF
          </Button>
        </div>
      </div>

      {/* Cards */}
      <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
        {loading ? (
          <Card><CardContent className="h-20 flex items-center justify-center"><Loader2 className="h-6 w-6 animate-spin" /></CardContent></Card>
        ) : (
          cards.map((c) => (
            <Card key={c.label}>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-slate-600">{c.label}</CardTitle>
              </CardHeader>
              <CardContent>
                <div className={cn("text-2xl font-bold", c.tone)}>{fmtBRL(c.value)}</div>
                <div className="text-xs text-slate-500 mt-1">{fmtPct(c.pct)} s/ Receita Bruta</div>
              </CardContent>
            </Card>
          ))
        )}
      </div>

      {/* Tabela */}
      <div className="bg-white rounded-lg border shadow-sm">
        <Table>
          <TableHeader className="bg-slate-50">
            <TableRow>
              <TableHead>Linha</TableHead>
              <TableHead className="text-right">Valor</TableHead>
              <TableHead className="text-right">% s/ Receita Bruta</TableHead>
            </TableRow>
          </TableHeader>

          <TableBody>
            {loading ? (
              <TableRow>
                <TableCell colSpan={3} className="h-24 text-center">
                  <Loader2 className="h-6 w-6 animate-spin mx-auto text-primary" />
                </TableCell>
              </TableRow>
            ) : !safe ? (
              <TableRow>
                <TableCell colSpan={3} className="h-24 text-center text-muted-foreground">
                  Nenhum dado encontrado para o período.
                </TableCell>
              </TableRow>
            ) : (
              <>
                {safe.blocks.map((b) => {
                  const isOpen = !!openBlocks[b.key];
                  const isTotalRow = b.isTotal;

                  return (
                    <React.Fragment key={b.key}>
                      <TableRow className={cn("font-semibold", isTotalRow && "bg-slate-50")}>
                        <TableCell className="flex items-center gap-2">
                          {(b.lines?.length ?? 0) > 0 ? (
                            <button
                              type="button"
                              onClick={() => toggleBlock(b.key)}
                              className="p-1 rounded hover:bg-slate-100"
                              aria-label="Toggle"
                            >
                              {isOpen ? <ChevronDown className="h-4 w-4" /> : <ChevronRight className="h-4 w-4" />}
                            </button>
                          ) : (
                            <span className="w-6" />
                          )}
                          <span>{b.label}</span>
                        </TableCell>

                        <TableCell
                          className={cn(
                            "text-right",
                            b.total >= 0 ? "text-emerald-700" : "text-red-700"
                          )}
                        >
                          {fmtBRL(b.total)}
                        </TableCell>

                        <TableCell className="text-right text-slate-600">{fmtPct(b.percentOfGross)}</TableCell>
                      </TableRow>

                      {isOpen &&
                        (b.lines || []).map((l) => (
                          <TableRow key={l.id} className="text-sm">
                            <TableCell className="pl-10 text-slate-700">{l.label}</TableCell>
                            <TableCell className={cn("text-right", l.total >= 0 ? "text-emerald-700" : "text-red-700")}>
                              {fmtBRL(l.total)}
                            </TableCell>
                            <TableCell className="text-right text-slate-500">{fmtPct(l.percentOfGross)}</TableCell>
                          </TableRow>
                        ))}
                    </React.Fragment>
                  );
                })}

                {/* Linhas finais (resumo) */}
                <TableRow className="bg-slate-50 font-bold">
                  <TableCell>EBITDA</TableCell>
                  <TableCell className={cn("text-right", safe.totals.ebitda >= 0 ? "text-emerald-700" : "text-red-700")}>
                    {fmtBRL(safe.totals.ebitda)}
                  </TableCell>
                  <TableCell className="text-right">{fmtPct((safe.totals.ebitda / (receitaBruta || 1)) * 100)}</TableCell>
                </TableRow>

                <TableRow className="bg-slate-50 font-bold">
                  <TableCell>Resultado Líquido</TableCell>
                  <TableCell className={cn("text-right", safe.totals.resultado_liquido >= 0 ? "text-emerald-700" : "text-red-700")}>
                    {fmtBRL(safe.totals.resultado_liquido)}
                  </TableCell>
                  <TableCell className="text-right">{fmtPct((safe.totals.resultado_liquido / (receitaBruta || 1)) * 100)}</TableCell>
                </TableRow>
              </>
            )}
          </TableBody>
        </Table>
      </div>
    </div>
  );
};

export default FinanceDRE;
