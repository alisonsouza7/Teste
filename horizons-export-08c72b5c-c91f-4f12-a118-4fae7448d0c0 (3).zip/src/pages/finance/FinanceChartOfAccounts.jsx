import React, { useState, useMemo, useCallback } from 'react';
import { useCompany } from '@/contexts/CompanyContext';
import { useToast } from '@/components/ui/use-toast';
import { Button } from "@/components/ui/button";
import { Plus, AlertCircle } from 'lucide-react';
import EmptyState from '@/components/ui/EmptyState';
import SectionCard from '@/components/ui/SectionCard';
import ReorderableList from '@/components/finance/ChartOfAccounts/ReorderableList';
import AccountEditModal from '@/components/finance/ChartOfAccounts/AccountEditModal';
import { useChartOfAccounts } from '@/hooks/useChartOfAccounts';

const SECTION_META = {
  receita: { label: 'Receitas' },
  despesa: { label: 'Despesas' },
  custo: { label: 'Custos' },
  investimento: { label: 'Investimentos' },
  ajustes: { label: 'Ajustes e Transferências' },
};

const FinanceChartOfAccounts = () => {
  const { selectedCompany } = useCompany();
  const { toast } = useToast();

  const {
    accounts,
    loading,
    createAccount,
    updateAccount,
    deleteAccount,
    reorderAccounts,
    assignMissingNumbers
  } = useChartOfAccounts(selectedCompany?.id);

  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingAccount, setEditingAccount] = useState(null);
  const [activeSection, setActiveSection] = useState('receita');

  const grouped = useMemo(() => {
    const byTipo = {
      receita: [],
      despesa: [],
      custo: [],
      investimento: [],
      ajustes: [],
    };

    (accounts || []).forEach((a) => {
      const key = String(a?.tipo || '').toLowerCase().trim();

      if (byTipo[key]) {
        byTipo[key].push(a);
        return;
      }

      if (['ajuste', 'transferencia', 'transferência', 'outros', 'other'].includes(key)) {
        byTipo.ajustes.push(a);
        return;
      }

      byTipo.ajustes.push(a);
    });

    // ordena dentro de cada tipo por display_order e depois por nome
    Object.keys(byTipo).forEach((k) => {
      byTipo[k].sort((x, y) => {
        const dx = Number(x?.display_order ?? 999999);
        const dy = Number(y?.display_order ?? 999999);
        if (dx !== dy) return dx - dy;
        return String(x?.nome_conta ?? '').localeCompare(String(y?.nome_conta ?? ''), 'pt-BR');
      });
    });

    return byTipo;
  }, [accounts]);

  const handleOpenCreate = (section) => {
    setActiveSection(section);
    setEditingAccount(null);
    setIsModalOpen(true);
  };

  const handleOpenEdit = (account) => {
    setEditingAccount(account);
    setIsModalOpen(true);
  };

  const handleSave = async (data) => {
    // não deixa virar inativo por null/undefined
    const payload = {
      ...data,
      tipo: data?.tipo ?? activeSection,
      is_active: data?.is_active ?? true,
    };

    if (payload.id) {
      await updateAccount(payload.id, payload);
    } else {
      await createAccount(payload);
    }

    setIsModalOpen(false);
  };

  const handleDelete = async (id) => {
    await deleteAccount(id);
  };

  const reorderWithinSection = useCallback(async (sectionKey, list) => {
    const updates = list.map((item, idx) => ({
      id: item.id,
      display_order: idx + 1,
    }));

    // IMPORTANTE: seu hook precisa aceitar (sectionKey, updates)
    await reorderAccounts(sectionKey, updates);
  }, [reorderAccounts]);

  const renderSection = (sectionKey) => {
    const items = grouped[sectionKey] || [];
    const label = SECTION_META[sectionKey]?.label || sectionKey;

    return (
      <SectionCard
        key={sectionKey}
        title={label}
        action={
          <Button size="sm" variant="ghost" onClick={() => handleOpenCreate(sectionKey)}>
            <Plus className="h-4 w-4" />
          </Button>
        }
        className="w-full min-h-[280px]"
        contentClassName="px-4 py-2"
      >
        {loading ? (
          <EmptyState title="Carregando..." description="Aguarde" icon={AlertCircle} className="py-8" />
        ) : items.length > 0 ? (
          <ReorderableList
            items={items}
            sectionKey={sectionKey}
            onReorder={(list) => reorderWithinSection(sectionKey, list)}
            onEdit={handleOpenEdit}
            onDelete={handleDelete}
            showAccountNumber
          />
        ) : (
          <EmptyState
            title="Sem categorias"
            description="Adicione categorias para este grupo."
            className="py-8"
            icon={Plus}
            actionLabel="Adicionar"
            onAction={() => handleOpenCreate(sectionKey)}
          />
        )}
      </SectionCard>
    );
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-slate-900">Plano de Contas</h1>
          <p className="text-slate-500">Gerencie as categorias de receitas e despesas.</p>
        </div>
        <div className="flex gap-2">
          <Button onClick={assignMissingNumbers} variant="outline">
            Gerar códigos faltantes
          </Button>
          <Button onClick={() => handleOpenCreate('despesa')}>
            <Plus className="mr-2 h-4 w-4" /> Nova Categoria
          </Button>
        </div>
      </div>

      {/* Lista vertical: cards com mesmo tamanho, um abaixo do outro */}
      <div className="space-y-6">
        {renderSection('receita')}
        {renderSection('despesa')}
        {renderSection('custo')}
        {renderSection('investimento')}
        {renderSection('ajustes')}
      </div>

      <AccountEditModal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        onSave={handleSave}
        account={editingAccount}
        defaultTipo={activeSection}
      />
    </div>
  );
};

export default FinanceChartOfAccounts;