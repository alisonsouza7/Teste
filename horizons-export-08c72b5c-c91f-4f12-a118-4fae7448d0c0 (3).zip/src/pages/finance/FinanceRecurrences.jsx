
import React, { useState, useEffect } from 'react';
import { supabase } from '@/lib/customSupabaseClient';
import { useCompany } from '@/contexts/CompanyContext';
import { useToast } from '@/components/ui/use-toast';
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from '@/components/ui/table';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { format, parseISO } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { Plus, Trash2, Pencil, Calendar, AlertCircle } from 'lucide-react';
import EmptyState from '@/components/ui/EmptyState';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";

const FinanceRecurrences = () => {
  const { selectedCompany } = useCompany();
  const { toast } = useToast();
  const [loading, setLoading] = useState(true);
  const [recurrences, setRecurrences] = useState([]);
  
  // Basic Delete State
  const [deleteId, setDeleteId] = useState(null);

  const fetchRecurrences = async () => {
    if (!selectedCompany?.id) return;
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('finance_recurrences')
        .select(`
          id,
          recurrence_type,
          start_date,
          end_date,
          next_execution_date,
          is_active,
          metadata,
          template_transaction:finance_transactions!template_transaction_id (
            descricao,
            valor,
            tipo
          )
        `)
        .eq('company_id', selectedCompany.id);

      if (error) throw error;
      setRecurrences(data || []);
    } catch (error) {
      console.error("Error fetching recurrences:", error);
      toast({ variant: 'destructive', title: 'Erro', description: 'Falha ao buscar recorrências.' });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchRecurrences();
  }, [selectedCompany?.id]);

  const handleDelete = async () => {
    if (!deleteId) return;
    try {
        const { error } = await supabase.from('finance_recurrences').delete().eq('id', deleteId);
        if (error) throw error;
        toast({ title: 'Sucesso', description: 'Recorrência removida.' });
        fetchRecurrences();
    } catch (error) {
        console.error(error);
        toast({ variant: 'destructive', title: 'Erro', description: 'Falha ao remover.' });
    } finally {
        setDeleteId(null);
    }
  };
  
  const getFrequencyLabel = (type) => {
      const map = {
          'monthly': 'Mensal',
          'bimonthly': 'Bimestral',
          'quarterly': 'Trimestral',
          'semiannual': 'Semestral',
          'yearly': 'Anual',
          'weekly': 'Semanal'
      };
      return map[type] || type;
  };

  const formatCurrency = (val) => new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(val);

  return (
    <div className="space-y-6">
       <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
         <div>
            <h1 className="text-2xl font-bold tracking-tight text-slate-900">Recorrências</h1>
            <p className="text-slate-500">Gerencie seus lançamentos automáticos e assinaturas.</p>
         </div>
         {/* Creation is handled via Transaction Form usually, but placeholder button here */}
         <Button variant="outline" disabled title="Crie recorrências ao adicionar um novo lançamento">
             <Plus className="mr-2 h-4 w-4" /> Nova Recorrência
         </Button>
       </div>

       <div className="bg-white rounded-lg border shadow-sm overflow-hidden">
          <div className="overflow-x-auto">
              <Table>
                  <TableHeader className="bg-slate-50">
                      <TableRow>
                          <TableHead>Descrição</TableHead>
                          <TableHead>Frequência</TableHead>
                          <TableHead>Valor</TableHead>
                          <TableHead>Próxima Execução</TableHead>
                          <TableHead>Status</TableHead>
                          <TableHead className="text-right">Ações</TableHead>
                      </TableRow>
                  </TableHeader>
                  <TableBody>
                      {loading ? (
                          [1,2,3].map(i => (
                              <TableRow key={i}>
                                  <TableCell><Skeleton className="h-5 w-40" /></TableCell>
                                  <TableCell><Skeleton className="h-5 w-20" /></TableCell>
                                  <TableCell><Skeleton className="h-5 w-20" /></TableCell>
                                  <TableCell><Skeleton className="h-5 w-24" /></TableCell>
                                  <TableCell><Skeleton className="h-5 w-16" /></TableCell>
                                  <TableCell><Skeleton className="h-8 w-8 ml-auto" /></TableCell>
                              </TableRow>
                          ))
                      ) : recurrences.length === 0 ? (
                          <TableRow>
                              <TableCell colSpan={6}>
                                  <EmptyState 
                                    title="Nenhuma recorrência encontrada" 
                                    description="Crie lançamentos recorrentes através do formulário de Nova Transação."
                                    icon={Calendar}
                                  />
                              </TableCell>
                          </TableRow>
                      ) : (
                          recurrences.map((rec) => (
                              <TableRow key={rec.id} className="group hover:bg-slate-50/50">
                                  <TableCell className="font-medium">
                                      {rec.template_transaction?.descricao || 'Sem descrição'}
                                  </TableCell>
                                  <TableCell>
                                      <Badge variant="outline">{getFrequencyLabel(rec.recurrence_type)}</Badge>
                                  </TableCell>
                                  <TableCell>
                                      <span className={rec.template_transaction?.tipo === 'receita' ? "text-emerald-600 font-medium" : "text-red-600 font-medium"}>
                                          {formatCurrency(rec.template_transaction?.valor)}
                                      </span>
                                  </TableCell>
                                  <TableCell>
                                      {rec.next_execution_date ? format(parseISO(rec.next_execution_date), 'dd/MM/yyyy') : '-'}
                                  </TableCell>
                                  <TableCell>
                                      <Badge className={rec.is_active ? "bg-emerald-100 text-emerald-700 hover:bg-emerald-100 border-emerald-200" : "bg-slate-100 text-slate-700 border-slate-200"}>
                                          {rec.is_active ? 'Ativo' : 'Inativo'}
                                      </Badge>
                                  </TableCell>
                                  <TableCell className="text-right">
                                      <Button variant="ghost" size="icon" onClick={() => setDeleteId(rec.id)} className="text-red-500 hover:text-red-700 hover:bg-red-50">
                                          <Trash2 className="h-4 w-4" />
                                      </Button>
                                  </TableCell>
                              </TableRow>
                          ))
                      )}
                  </TableBody>
              </Table>
          </div>
       </div>

       <Dialog open={!!deleteId} onOpenChange={(open) => !open && setDeleteId(null)}>
           <DialogContent>
               <DialogHeader>
                   <DialogTitle>Excluir Recorrência</DialogTitle>
                   <DialogDescription>
                       Tem certeza? Isso impedirá a criação automática de futuros lançamentos para este item. Lançamentos passados não serão afetados.
                   </DialogDescription>
               </DialogHeader>
               <DialogFooter>
                   <Button variant="outline" onClick={() => setDeleteId(null)}>Cancelar</Button>
                   <Button variant="destructive" onClick={handleDelete}>Excluir</Button>
               </DialogFooter>
           </DialogContent>
       </Dialog>
    </div>
  );
};

export default FinanceRecurrences;
