import React, { useState, useRef, useEffect } from 'react';
import { useFinanceTransactions } from '@/hooks/useFinanceTransactions';
import TransactionTable from '@/components/finance/FinanceTransactions/TransactionTable';
import TransactionFilters from '@/components/finance/FinanceTransactions/TransactionFilters';
import TransactionEditModal from '@/components/finance/FinanceTransactions/TransactionEditModal';
import ImportValidationDialog from '@/components/finance/ImportValidationDialog';

import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { useToast } from '@/components/ui/use-toast';
import { useCompany } from '@/contexts/CompanyContext';

import {
  Plus,
  Download,
  Upload,
  FileDown,
  Loader2,
  SlidersHorizontal,
  X,
} from 'lucide-react';

import {
  exportTransactionsToExcel,
  importTransactionsFromExcel,
  downloadTransactionTemplate
} from '@/lib/excelUtils';

/**
 * Opcional: se você tiver um menu/hambúrguer próprio da sua UI, passe aqui.
 * Exemplo: const MobilePageMenu = () => <YourMenuButton />
 * Se não tiver, deixe null.
 */
const MobilePageMenu = null;

/** Drawer simples sem depender de Radix/Sheet (para não te travar com import). */
function MobileFiltersDrawer({ open, onClose, children, title = "Filtros" }) {
  useEffect(() => {
    if (!open) return;
    const onKeyDown = (e) => e.key === 'Escape' && onClose?.();
    document.addEventListener('keydown', onKeyDown);
    document.body.style.overflow = 'hidden';
    return () => {
      document.removeEventListener('keydown', onKeyDown);
      document.body.style.overflow = '';
    };
  }, [open, onClose]);

  if (!open) return null;

  return (
    <div className="fixed inset-0 z-50">
      {/* backdrop */}
      <button
        aria-label="Fechar filtros"
        className="absolute inset-0 bg-black/35"
        onClick={onClose}
      />

      {/* panel */}
      <div className="absolute right-0 top-0 h-full w-full max-w-[420px] bg-white shadow-xl">
        <div className="flex items-center justify-between px-4 py-3 border-b">
          <div className="flex items-center gap-2">
            <SlidersHorizontal className="h-4 w-4 text-slate-700" />
            <span className="text-sm font-semibold text-slate-900">{title}</span>
          </div>
          <Button variant="ghost" size="icon" onClick={onClose} aria-label="Fechar">
            <X className="h-4 w-4" />
          </Button>
        </div>

        <div className="p-4 overflow-y-auto h-[calc(100%-52px)]">
          {children}
        </div>
      </div>
    </div>
  );
}

const FinanceTransactions = () => {
  const {
    transactions,
    categories,
    accounts,
    parties,
    loading,
    error,
    filters,
    sort,
    handlers
  } = useFinanceTransactions();

  const { selectedCompany } = useCompany();
  const { toast } = useToast();
  const fileInputRef = useRef(null);

  const [isImporting, setIsImporting] = useState(false);
  const [importData, setImportData] = useState([]);
  const [isImportDialogOpen, setIsImportDialogOpen] = useState(false);

  const [isModalOpen, setIsModalOpen] = useState(false);
  const [selectedTransaction, setSelectedTransaction] = useState(null);

  const [isFiltersOpen, setIsFiltersOpen] = useState(false);

  const handleCreateClick = () => {
    setSelectedTransaction(null);
    setIsModalOpen(true);
  };

  const handleEditClick = (transaction) => {
    setSelectedTransaction(transaction);
    setIsModalOpen(true);
  };

  const handleCloseModal = () => {
    setIsModalOpen(false);
    setSelectedTransaction(null);
  };

  const handleSaveTransaction = async (id, data) => {
    try {
      await handlers.onUpdate(id, data);
      handleCloseModal();
    } catch (error) {
      console.error("Failed to update transaction:", error);
    }
  };

  const handleCreateTransaction = async (data) => {
    try {
      await handlers.onCreate(data);
      handleCloseModal();
    } catch (error) {
      console.error("Failed to create transaction:", error);
    }
  };

  const handleExport = () => {
    if (!transactions.length) {
      toast({ title: "Sem dados", description: "Não há transações para exportar.", variant: "warning" });
      return;
    }
    exportTransactionsToExcel(transactions, `transacoes_${new Date().toISOString().split('T')[0]}.xlsx`);
    toast({ title: "Exportação concluída", description: "O arquivo foi baixado com sucesso." });
  };

  const handleImportClick = () => fileInputRef.current?.click();

  const handleFileChange = async (event) => {
    const file = event.target.files?.[0];
    if (!file) return;

    setIsImporting(true);
    try {
      const parsedData = await importTransactionsFromExcel(file);

      if (parsedData.length === 0) {
        throw new Error("O arquivo está vazio ou não contém dados válidos.");
      }

      const preparedData = parsedData.map(row => ({
        data_competencia: row.data_competencia || new Date().toISOString().split('T')[0],
        descricao: row.descricao || '',
        party_nome: row.party_nome || row['Cliente/Fornecedor'] || '',
        categoria_nome: row.categoria_nome || row['Categoria'] || '',
        conta_nome: row.conta_nome || row['Conta'] || '',
        valor: row.valor || '',
        tipo: row.tipo ? row.tipo.toLowerCase() : (Number(row.valor) < 0 ? 'despesa' : 'receita'),
        status: row.status ? row.status.toLowerCase() : 'aberto',
        liquidado: (row.status || '').toLowerCase() === 'liquidado'
      }));

      setImportData(preparedData);
      setIsImportDialogOpen(true);
    } catch (error) {
      console.error("Import parsing error:", error);
      toast({
        title: "Erro ao ler arquivo",
        description: error.message || "Verifique se o formato está correto.",
        variant: "destructive"
      });
    } finally {
      setIsImporting(false);
      if (fileInputRef.current) fileInputRef.current.value = '';
    }
  };

  const handleImportConfirm = async (validatedRows) => {
    const result = await handlers.importTransactions(validatedRows);

    if (result.successCount > 0) {
      toast({
        title: "Importação realizada",
        description: `${result.successCount} transações importadas com sucesso.`,
        variant: "default"
      });
    }
    if (result.failedCount > 0) {
      toast({
        title: "Atenção",
        description: `${result.failedCount} itens não foram importados. Verifique erros.`,
        variant: "warning"
      });
    }
    if (result.errors && result.errors.length > 0) console.error("Import db errors:", result.errors);

    setIsImportDialogOpen(false);
  };

  const companyName = selectedCompany?.nome || selectedCompany?.name || 'Empresa';

  return (
    <div className="space-y-4 sm:space-y-6">
      {/* Header: Mobile compacto / Desktop normal */}
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          {/* empresa minimalista */}
          <div className="flex items-center gap-2">
            {MobilePageMenu ? (
              <div className="sm:hidden">{/* menu dentro da página, responsivo */}
                <MobilePageMenu />
              </div>
            ) : null}

            <span className="text-[11px] sm:text-xs text-slate-500 truncate max-w-[70vw] sm:max-w-none">
              {companyName}
            </span>
          </div>

          <h1 className="text-lg sm:text-2xl font-bold tracking-tight text-slate-900">
            Lançamentos
          </h1>

          <p className="text-xs sm:text-sm text-slate-500 leading-tight sm:leading-normal">
            Receitas, despesas e transferências.
          </p>
        </div>

        {/* Ações: no mobile vira ícones compactos */}
        <div className="hidden sm:flex flex-wrap gap-2">
          <Button variant="outline" onClick={handleExport}>
            <Download className="mr-2 h-4 w-4" /> Exportar
          </Button>

          <Button variant="outline" onClick={downloadTransactionTemplate} title="Baixar Modelo">
            <FileDown className="mr-2 h-4 w-4" /> Modelo
          </Button>

          <div>
            <input
              type="file"
              accept=".xlsx, .xls"
              ref={fileInputRef}
              onChange={handleFileChange}
              className="hidden"
            />
            <Button variant="outline" onClick={handleImportClick} disabled={isImporting}>
              {isImporting ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Upload className="mr-2 h-4 w-4" />}
              Importar
            </Button>
          </div>

          <Button onClick={handleCreateClick}>
            <Plus className="mr-2 h-4 w-4" /> Novo Lançamento
          </Button>
        </div>

        {/* Mobile icon actions */}
        <div className="flex sm:hidden items-center gap-1">
          <Button
            variant="ghost"
            size="icon"
            onClick={handleExport}
            aria-label="Exportar"
            title="Exportar"
          >
            <Download className="h-4 w-4" />
          </Button>

          <Button
            variant="ghost"
            size="icon"
            onClick={downloadTransactionTemplate}
            aria-label="Baixar modelo"
            title="Modelo"
          >
            <FileDown className="h-4 w-4" />
          </Button>

          <input
            type="file"
            accept=".xlsx, .xls"
            ref={fileInputRef}
            onChange={handleFileChange}
            className="hidden"
          />
          <Button
            variant="ghost"
            size="icon"
            onClick={handleImportClick}
            disabled={isImporting}
            aria-label="Importar"
            title="Importar"
          >
            {isImporting ? <Loader2 className="h-4 w-4 animate-spin" /> : <Upload className="h-4 w-4" />}
          </Button>

          <Button
            variant="ghost"
            size="icon"
            onClick={() => setIsFiltersOpen(true)}
            aria-label="Filtros"
            title="Filtros"
          >
            <SlidersHorizontal className="h-4 w-4" />
          </Button>
        </div>
      </div>

      {/* Desktop filtros em card / Mobile: Drawer */}
      <div className="hidden sm:block bg-white p-4 rounded-lg border shadow-sm">
        <TransactionFilters
          filters={filters}
          categories={categories}
          accounts={accounts}
          onFilterChange={handlers.onFilterChange}
          onReset={handlers.onResetFilters}
        />
      </div>

      <MobileFiltersDrawer open={isFiltersOpen} onClose={() => setIsFiltersOpen(false)} title="Filtros">
        <div className="space-y-3">
          <TransactionFilters
            filters={filters}
            categories={categories}
            accounts={accounts}
            onFilterChange={handlers.onFilterChange}
            onReset={() => {
              handlers.onResetFilters();
              setIsFiltersOpen(false);
            }}
          />
          <div className="sticky bottom-0 pt-3 bg-white">
            <Button className="w-full" onClick={() => setIsFiltersOpen(false)}>
              Aplicar filtros
            </Button>
          </div>
        </div>
      </MobileFiltersDrawer>

      {/* Conteúdo principal */}
      <div className="bg-white rounded-lg border shadow-sm overflow-hidden">
        {/* No mobile, você quer cards menores: isso precisa estar no TransactionTable.
            Aqui eu passo um flag pra ele renderizar em modo compacto/card. */}
        <TransactionTable
          transactions={transactions}
          loading={loading}
          sort={sort}
          onSort={handlers.onSortChange}
          onDelete={handlers.onDelete}
          onEdit={handleEditClick}
          accounts={accounts}
          handlers={handlers}
          ui={{
            density: 'compact',     // use isso lá dentro
            mobileMode: 'cards',    // use isso lá dentro
            cardSize: 'sm'          // use isso lá dentro
          }}
        />
      </div>

      {/* FAB: Novo lançamento (mobile) */}
      <button
        type="button"
        onClick={handleCreateClick}
        className={cn(
          "sm:hidden fixed bottom-5 right-5 z-40",
          "h-12 w-12 rounded-full shadow-lg border bg-slate-900 text-white",
          "flex items-center justify-center active:scale-95 transition"
        )}
        aria-label="Novo lançamento"
        title="Novo"
      >
        <Plus className="h-5 w-5" />
      </button>

      {isModalOpen && (
        <TransactionEditModal
          isOpen={isModalOpen}
          onClose={handleCloseModal}
          transaction={selectedTransaction}
          accounts={accounts}
          categories={categories}
          parties={parties}
          onSave={handleSaveTransaction}
          onCreate={handleCreateTransaction}
          auxHandlers={{
            createCategory: handlers.createCategory,
            createAccount: handlers.createAccount,
            createParty: handlers.createParty
          }}
          loading={loading}
        />
      )}

      {isImportDialogOpen && (
        <ImportValidationDialog
          isOpen={isImportDialogOpen}
          onClose={() => setIsImportDialogOpen(false)}
          initialData={importData}
          categories={categories}
          accounts={accounts}
          parties={parties}
          onImport={handleImportConfirm}
        />
      )}
    </div>
  );
};

export default FinanceTransactions;