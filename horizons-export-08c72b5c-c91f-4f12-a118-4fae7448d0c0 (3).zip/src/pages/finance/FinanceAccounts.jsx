import React, { useState, useEffect, useMemo } from 'react';

import { useCompany } from '@/contexts/CompanyContext';
import { useFinanceLevel } from '@/hooks/useFinanceLevel';
import { supabase } from '@/lib/customSupabaseClient';

import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useToast } from '@/components/ui/use-toast';
import { Edit2, Trash2, Plus, Wallet, Search, CreditCard } from 'lucide-react';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import ExcelActions from '@/components/finance/ExcelActions';

const formatCurrency = (value) =>
  new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(Number(value || 0));

const FinanceAccounts = () => {
  const { selectedCompany } = useCompany();
  const { level, canCreateMultipleAccounts, canImportBank, canConciliate, canUseCreditCards } =
    useFinanceLevel(selectedCompany?.id);
  const { toast } = useToast();

  const [accounts, setAccounts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [deleteConfirmId, setDeleteConfirmId] = useState(null);

  const [editingAccount, setEditingAccount] = useState(null);
  const [formData, setFormData] = useState({
    nome_conta: '',
    banco: '',
    tipo: 'corrente',
    saldo_inicial: 0,
    data_saldo_inicial: '',
    bandeira: '',
    limite: '',
    dia_fechamento: '',
    dia_vencimento: ''
  });

  const INITIAL_BALANCE_DESC = 'Saldo inicial (gerado automaticamente)';
  const OPENING_BALANCE_CATEGORY_NAME = 'Saldo inicial / Ajuste de abertura';

  const getOrCreateOpeningBalanceCategoryId = async () => {
    if (!selectedCompany) throw new Error('Empresa não selecionada');

    const { data, error } = await supabase
      .from('finance_chart_of_accounts')
      .select('id')
      .eq('company_id', selectedCompany.id)
      .eq('nome_conta', OPENING_BALANCE_CATEGORY_NAME)
      .eq('tipo', 'Ajustes')
      .is('deleted_at', null)
      .limit(1);

    if (error) throw error;

    if (data && data.length > 0) {
      return data[0].id;
    }

    const { data: inserted, error: insertError } = await supabase
      .from('finance_chart_of_accounts')
      .insert({
        company_id: selectedCompany.id,
        nome_conta: OPENING_BALANCE_CATEGORY_NAME,
        tipo: 'Ajustes',
        grupo: 'Outras Despesas',
        parent_id: null,
        ordem: 0
      })
      .select('id')
      .single();

    if (insertError) throw insertError;

    return inserted.id;
  };

  const upsertInitialBalanceTransaction = async ({
    accountId,
    saldoInicial,
    dataSaldoInicial,
    existingTransactionId
  }) => {
    if (!selectedCompany) throw new Error('Empresa não selecionada');

    const valor = Number(saldoInicial ?? 0);

    if (!existingTransactionId && !valor) {
      return null;
    }

    const categoriaId = await getOrCreateOpeningBalanceCategoryId();
    const hojeISO = new Date().toISOString().slice(0, 10);
    const data = dataSaldoInicial || hojeISO;
    const tipo = valor >= 0 ? 'receita' : 'despesa';

    if (existingTransactionId) {
      const { error: updError } = await supabase
        .from('finance_transactions')
        .update({
          company_id: selectedCompany.id,
          conta_id: accountId,
          categoria_id: categoriaId,
          tipo,
          valor: valor,
          descricao: INITIAL_BALANCE_DESC,
          data_lancamento: data,
          data_competencia: data,
          liquidado: true,
          deleted_at: null
        })
        .eq('id', existingTransactionId);

      if (updError) throw updError;
      return existingTransactionId;
    } else {
      if (!valor) return null;

      const { data: inserted, error: insError } = await supabase
        .from('finance_transactions')
        .insert({
          company_id: selectedCompany.id,
          conta_id: accountId,
          categoria_id: categoriaId,
          tipo,
          valor: valor,
          descricao: INITIAL_BALANCE_DESC,
          data_lancamento: data,
          data_competencia: data,
          liquidado: true,
          deleted_at: null
        })
        .select('id')
        .single();

      if (insError) throw insError;

      return inserted.id;
    }
  };

  const fetchAccounts = async () => {
    if (!selectedCompany) return;
    setLoading(true);

    try {
      const { data: accountsData, error: accError } = await supabase
        .from('finance_accounts')
        .select(
          'id, company_id, nome_conta, banco, tipo, saldo_inicial, data_saldo_inicial, saldo_inicial_transaction_id, bandeira, limite, dia_fechamento, dia_vencimento'
        )
        .eq('company_id', selectedCompany.id)
        .is('deleted_at', null)
        .order('nome_conta');

      if (accError) throw accError;

      // Ensure we explicitly select 'tipo' and fetch all relevant fields to calculate balance correctly
      const { data: txData, error: txError } = await supabase
        .from('finance_transactions')
        .select('conta_id, company_id, valor, liquidado, origem, tipo')
        .eq('company_id', selectedCompany.id)
        .is('deleted_at', null);

      if (txError) throw txError;

      // Create a map of account types for easier lookup
      const accountTypeMap = {};
      (accountsData || []).forEach(acc => {
          accountTypeMap[acc.id] = acc.tipo;
      });

      const saldoPorConta = {};
      const openCreditUsage = {};

      (txData || []).forEach((tx) => {
        const accountId = tx.conta_id;
        const valor = Number(tx.valor || 0);
        const accType = accountTypeMap[accountId];

        // BALANCE CALCULATION (Saldo Atual)
        // Considers ALL transaction types: Receita (+), Despesa (-), Transferência (+/-)
        // Only realized (liquidado) transactions affect the current balance.
        if (tx.liquidado) {
          if (!saldoPorConta[accountId]) saldoPorConta[accountId] = 0;
          saldoPorConta[accountId] += valor;
        }

        // CREDIT CARD USAGE (Em Aberto)
        // Tracks spending that hasn't been paid off yet.
        // Logic: If account is Credit Card AND transaction is NOT liquidated.
        // We subtract the value because expenses are negative. (e.g., -(-100) = +100 usage)
        if (accType === 'cartao_credito' && !tx.liquidado) {
          if (!openCreditUsage[accountId]) openCreditUsage[accountId] = 0;
          openCreditUsage[accountId] -= valor;
        }
      });

      const accountsWithBalance = (accountsData || []).map((acc) => {
        const isCreditCard = acc.tipo === 'cartao_credito';
        const saldoConta = saldoPorConta[acc.id] || 0;

        const limite = Number(acc.limite || 0);
        const emAberto = Number(openCreditUsage[acc.id] || 0);
        // Ensure emAberto is positive for display purposes if calculated correctly
        const emAbertoDisplay = Math.max(0, emAberto); 
        
        const disponivel = isCreditCard ? limite - emAbertoDisplay : null;

        return {
          ...acc,
          saldo_atual: isCreditCard ? disponivel : saldoConta,
          limite,
          emAberto: emAbertoDisplay,
          disponivel
        };
      });

      setAccounts(accountsWithBalance);
    } catch (err) {
      console.error(err);
      toast({
        variant: 'destructive',
        title: 'Erro',
        description: 'Falha ao carregar contas e saldos.'
      });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchAccounts();
  }, [selectedCompany]);

  const handleSave = async (e) => {
    e.preventDefault();

    if (!selectedCompany) {
      toast({
        variant: 'destructive',
        title: 'Erro',
        description: 'Nenhuma empresa selecionada.'
      });
      return;
    }

    if (!canCreateMultipleAccounts && accounts.length >= 1 && !editingAccount) {
      toast({
        variant: 'destructive',
        title: 'Limite Atingido',
        description: 'Seu plano permite apenas 1 conta bancária.'
      });
      return;
    }

    const payload = {
      company_id: selectedCompany.id,
      nome_conta: formData.nome_conta,
      banco: formData.banco,
      tipo: formData.tipo,
      saldo_inicial: Number(formData.saldo_inicial || 0),
      data_saldo_inicial: formData.data_saldo_inicial || null,
      bandeira: formData.tipo === 'cartao_credito' ? formData.bandeira : null,
      limite: formData.tipo === 'cartao_credito' ? Number(formData.limite || 0) : null,
      dia_fechamento:
        formData.tipo === 'cartao_credito' ? parseInt(formData.dia_fechamento) : null,
      dia_vencimento:
        formData.tipo === 'cartao_credito' ? parseInt(formData.dia_vencimento) : null
    };

    try {
      if (editingAccount) {
        const { error: updError } = await supabase
          .from('finance_accounts')
          .update(payload)
          .eq('id', editingAccount.id);

        if (updError) throw updError;

        const existingTxId = editingAccount.saldo_inicial_transaction_id || null;

        const txId = await upsertInitialBalanceTransaction({
          accountId: editingAccount.id,
          saldoInicial: payload.saldo_inicial,
          dataSaldoInicial: payload.data_saldo_inicial,
          existingTransactionId: existingTxId
        });

        if (!existingTxId && txId) {
          await supabase
            .from('finance_accounts')
            .update({ saldo_inicial_transaction_id: txId })
            .eq('id', editingAccount.id);
        }

        toast({ title: 'Sucesso', description: 'Conta atualizada.' });
      } else {
        const { data: inserted, error: insError } = await supabase
          .from('finance_accounts')
          .insert(payload)
          .select('id')
          .single();

        if (insError) throw insError;

        const txId = await upsertInitialBalanceTransaction({
          accountId: inserted.id,
          saldoInicial: payload.saldo_inicial,
          dataSaldoInicial: payload.data_saldo_inicial,
          existingTransactionId: null
        });

        if (txId) {
          await supabase
            .from('finance_accounts')
            .update({ saldo_inicial_transaction_id: txId })
            .eq('id', inserted.id);
        }

        toast({ title: 'Sucesso', description: 'Conta criada.' });
      }

      setIsModalOpen(false);
      setEditingAccount(null);
      setFormData({
        nome_conta: '',
        banco: '',
        tipo: 'corrente',
        saldo_inicial: 0,
        data_saldo_inicial: '',
        bandeira: '',
        limite: '',
        dia_fechamento: '',
        dia_vencimento: ''
      });
      fetchAccounts();
    } catch (err) {
      console.error(err);
      toast({
        variant: 'destructive',
        title: 'Erro',
        description: 'Falha ao salvar conta.'
      });
    }
  };

  const handleDelete = async (id) => {
    if (!selectedCompany) return;

    try {
      const { error: accError } = await supabase
        .from('finance_accounts')
        .update({ deleted_at: new Date().toISOString() })
        .eq('id', id);

      if (accError) throw accError;

      const { error: txError } = await supabase
        .from('finance_transactions')
        .delete()
        .eq('company_id', selectedCompany.id)
        .eq('conta_id', id)
        .eq('descricao', INITIAL_BALANCE_DESC);

      if (txError) throw txError;

      toast({ title: 'Excluída', description: 'Conta movida para lixeira.' });
      setDeleteConfirmId(null);
      fetchAccounts();
    } catch (err) {
      console.error(err);
      toast({
        variant: 'destructive',
        title: 'Erro',
        description: 'Falha ao excluir.'
      });
    }
  };

  const openEdit = (account) => {
    setEditingAccount(account);
    setFormData({
      nome_conta: account.nome_conta,
      banco: account.banco,
      tipo: account.tipo,
      saldo_inicial: account.saldo_inicial ?? 0,
      data_saldo_inicial: account.data_saldo_inicial || '',
      bandeira: account.bandeira || '',
      limite: account.limite || '',
      dia_fechamento: account.dia_fechamento || '',
      dia_vencimento: account.dia_vencimento || ''
    });
    setIsModalOpen(true);
  };

  // EXCEL IMPORT/EXPORT Logic
  const formatExcelData = useMemo(() => {
    return accounts.map(a => ({
        nome_conta: a.nome_conta,
        banco: a.banco,
        tipo: a.tipo,
        saldo_inicial: a.saldo_inicial,
        data_saldo_inicial: a.data_saldo_inicial
    }));
  }, [accounts]);

  const handleExcelImport = async (importedData) => {
    if (!selectedCompany) return;

    // 1. Check Limits
    if (!canCreateMultipleAccounts) {
       const currentCount = accounts.length;
       const newCount = importedData.length;
       // If attempting to exceed limit (1), throw error
       if (currentCount + newCount > 1) {
          throw new Error("Seu plano (Nível A) permite apenas 1 conta bancária. Upgrade para Nível B para importar múltiplas contas.");
       }
    }

    const warnings = [];
    const accountsToInsert = [];

    // 2. Validate and Prepare
    for (const row of importedData) {
       // Duplicate check (Client side)
       if (accounts.some(a => a.nome_conta.toLowerCase() === row.nome_conta.toString().toLowerCase())) {
          warnings.push(`Conta "${row.nome_conta}" já existe. Ignorada.`);
          continue;
       }
       
       // Basic validation
       if (!row.nome_conta) {
         warnings.push(`Linha com nome de conta vazio ignorada.`);
         continue;
       }
       
       const tipoMap = {
           'corrente': 'corrente', 'conta corrente': 'corrente',
           'poupanca': 'poupanca', 'poupança': 'poupanca',
           'investimento': 'investimento',
           'carteira digital': 'carteira_digital', 'carteira_digital': 'carteira_digital',
           'cartao credito': 'cartao_credito', 'cartão de crédito': 'cartao_credito', 'cartao_credito': 'cartao_credito'
       };
       
       const tipoClean = row.tipo ? row.tipo.toLowerCase().trim() : 'corrente';
       const finalTipo = tipoMap[tipoClean] || 'corrente';

       accountsToInsert.push({
           company_id: selectedCompany.id,
           nome_conta: row.nome_conta,
           banco: row.banco || '',
           tipo: finalTipo,
           saldo_inicial: Number(row.saldo_inicial) || 0,
           data_saldo_inicial: row.data_saldo_inicial || null,
           // Defaulting others for simplicity in import
           bandeira: null, 
           limite: null,
           dia_fechamento: null,
           dia_vencimento: null
       });
    }

    if (accountsToInsert.length === 0) {
        return { imported: 0, warnings };
    }

    // 3. Insert Accounts
    const { data: insertedAccounts, error } = await supabase
        .from('finance_accounts')
        .insert(accountsToInsert)
        .select();
    
    if (error) throw error;

    // 4. Handle Initial Balances
    for (const acc of insertedAccounts) {
        if (acc.saldo_inicial && acc.saldo_inicial !== 0) {
            try {
                const txId = await upsertInitialBalanceTransaction({
                    accountId: acc.id,
                    saldoInicial: acc.saldo_inicial,
                    dataSaldoInicial: acc.data_saldo_inicial,
                    existingTransactionId: null
                });
                
                if (txId) {
                     await supabase.from('finance_accounts').update({ saldo_inicial_transaction_id: txId }).eq('id', acc.id);
                }
            } catch (e) {
                console.error("Failed to create initial balance tx for", acc.nome_conta, e);
                warnings.push(`Conta "${acc.nome_conta}" criada, mas falha ao gerar lançamento de saldo inicial.`);
            }
        }
    }

    fetchAccounts();
    return { imported: insertedAccounts.length, warnings };
  };


  // FILTRO POR BUSCA
  const filteredAccounts = accounts.filter(
    (acc) =>
      acc.nome_conta.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (acc.banco || '').toLowerCase().includes(searchTerm.toLowerCase())
  );

  // DEFINIÇÃO DOS GRUPOS
  const groupDefinitions = [
    {
      key: 'creditCards',
      label: 'Cartões de crédito',
      predicate: (acc) => acc.tipo === 'cartao_credito'
    },
    {
      key: 'bankAccounts',
      label: 'Contas correntes e poupança',
      predicate: (acc) => acc.tipo === 'corrente' || acc.tipo === 'poupanca'
    },
    {
      key: 'investmentsWallets',
      label: 'Investimentos e carteiras digitais',
      predicate: (acc) => acc.tipo === 'investimento' || acc.tipo === 'carteira_digital'
    },
    {
      key: 'others',
      label: 'Outros tipos de conta',
      predicate: (acc) =>
        !['cartao_credito', 'corrente', 'poupanca', 'investimento', 'carteira_digital'].includes(
          acc.tipo
        )
    }
  ];

  const groupedAccounts = groupDefinitions
    .map((group) => ({
      ...group,
      accounts: filteredAccounts
        .filter(group.predicate)
        .sort((a, b) =>
          String(a.nome_conta || '').localeCompare(String(b.nome_conta || ''), 'pt-BR', {
            sensitivity: 'base'
          })
        )
    }))
    .filter((group) => group.accounts.length > 0);

  const isCreateDisabled = !canCreateMultipleAccounts && accounts.length >= 1;

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div className="relative w-full sm:w-64">
          <Search className="absolute left-2 top-2.5 h-4 w-4 text-gray-500" />
          <Input
            placeholder="Buscar contas..."
            className="pl-8"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
        <div className="flex gap-2 items-center flex-wrap sm:flex-nowrap">
          {canImportBank && <Button variant="outline">Importar OFX</Button>}
          {canConciliate && <Button variant="outline">Conciliar</Button>}

          <ExcelActions 
             type="ACCOUNTS" 
             dataToExport={formatExcelData}
             onImport={handleExcelImport}
             className="sm:ml-2"
          />

          <Dialog
            open={isModalOpen}
            onOpenChange={(open) => {
              setIsModalOpen(open);
              if (!open) {
                setEditingAccount(null);
                setFormData({
                  nome_conta: '',
                  banco: '',
                  tipo: 'corrente',
                  saldo_inicial: 0,
                  data_saldo_inicial: '',
                  bandeira: '',
                  limite: '',
                  dia_fechamento: '',
                  dia_vencimento: ''
                });
              }
            }}
          >
            <DialogTrigger asChild>
              <Button
                disabled={isCreateDisabled}
                title={isCreateDisabled ? 'Nível A permite apenas 1 conta' : 'Nova Conta'}
                className={isCreateDisabled ? 'opacity-50 cursor-not-allowed' : ''}
              >
                <Plus className="w-4 h-4 mr-2" /> Nova Conta
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>{editingAccount ? 'Editar Conta' : 'Nova Conta'}</DialogTitle>
              </DialogHeader>
              <form onSubmit={handleSave} className="space-y-4 pt-4">
                <div>
                  <Label>Nome da Conta</Label>
                  <Input
                    value={formData.nome_conta}
                    onChange={(e) =>
                      setFormData({
                        ...formData,
                        nome_conta: e.target.value
                      })
                    }
                    required
                    placeholder="Ex: Itaú Principal"
                  />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label>Banco</Label>
                    <Input
                      value={formData.banco}
                      onChange={(e) =>
                        setFormData({
                          ...formData,
                          banco: e.target.value
                        })
                      }
                      placeholder="Ex: Itaú"
                    />
                  </div>
                  <div>
                    <Label>Tipo</Label>
                    <Select
                      value={formData.tipo}
                      onValueChange={(v) =>
                        setFormData({
                          ...formData,
                          tipo: v
                        })
                      }
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Selecione o tipo" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="corrente">Conta Corrente</SelectItem>
                        <SelectItem value="poupanca">Poupança</SelectItem>
                        <SelectItem value="carteira_digital">Carteira Digital</SelectItem>
                        <SelectItem value="investimento">Investimento</SelectItem>
                        {canUseCreditCards && (
                          <SelectItem value="cartao_credito">Cartão de Crédito</SelectItem>
                        )}
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                {formData.tipo === 'cartao_credito' && (
                  <div className="bg-muted p-4 rounded-md space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <Label>Bandeira</Label>
                        <Input
                          value={formData.bandeira}
                          onChange={(e) =>
                            setFormData({ ...formData, bandeira: e.target.value })
                          }
                          placeholder="Ex: Visa"
                        />
                      </div>
                      <div>
                        <Label>Limite (R$)</Label>
                        <Input
                          type="number"
                          value={formData.limite}
                          onChange={(e) => setFormData({ ...formData, limite: e.target.value })}
                          placeholder="0.00"
                        />
                      </div>
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <Label>Dia Fechamento</Label>
                        <Input
                          type="number"
                          min="1"
                          max="31"
                          value={formData.dia_fechamento}
                          onChange={(e) =>
                            setFormData({ ...formData, dia_fechamento: e.target.value })
                          }
                          placeholder="Ex: 5"
                          required
                        />
                      </div>
                      <div>
                        <Label>Dia Vencimento</Label>
                        <Input
                          type="number"
                          min="1"
                          max="31"
                          value={formData.dia_vencimento}
                          onChange={(e) =>
                            setFormData({ ...formData, dia_vencimento: e.target.value })
                          }
                          placeholder="Ex: 15"
                          required
                        />
                      </div>
                    </div>
                  </div>
                )}

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label>Saldo Inicial</Label>
                    <Input
                      type="number"
                      step="0.01"
                      value={formData.saldo_inicial}
                      onChange={(e) =>
                        setFormData({
                          ...formData,
                          saldo_inicial: e.target.value
                        })
                      }
                      required
                    />
                  </div>
                  <div>
                    <Label>Data do Saldo Inicial</Label>
                    <Input
                      type="date"
                      value={formData.data_saldo_inicial}
                      onChange={(e) =>
                        setFormData({
                          ...formData,
                          data_saldo_inicial: e.target.value
                        })
                      }
                    />
                  </div>
                </div>

                <Button type="submit" className="w-full">
                  Salvar
                </Button>
              </form>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {isCreateDisabled && (
        <Alert className="bg-blue-50 border-blue-200">
          <AlertTitle>Plano Básico (Nível A)</AlertTitle>
          <AlertDescription>
            Seu plano atual permite gerenciar apenas uma conta bancária. Para adicionar mais contas,
            solicite um upgrade para o Nível B.
          </AlertDescription>
        </Alert>
      )}

      <Card>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Nome</TableHead>
                <TableHead>Banco</TableHead>
                <TableHead>Tipo</TableHead>
                <TableHead className="text-right">Saldo Atual / Limite</TableHead>
                <TableHead className="text-right">Ações</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {loading ? (
                <TableRow>
                  <TableCell colSpan={5} className="text-center py-8">
                    Carregando...
                  </TableCell>
                </TableRow>
              ) : filteredAccounts.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={5} className="text-center py-8 text-muted-foreground">
                    Nenhuma conta encontrada.
                  </TableCell>
                </TableRow>
              ) : (
                groupedAccounts.map((group) => (
                  <React.Fragment key={group.key}>
                    <TableRow>
                      <TableCell
                        colSpan={5}
                        className="bg-muted text-xs font-semibold uppercase tracking-wide text-gray-600"
                      >
                        {group.label}
                      </TableCell>
                    </TableRow>
                    {group.accounts.map((acc) => {
                      const isCreditCard = acc.tipo === 'cartao_credito';
                      const saldo = Number(acc.saldo_atual || 0);
                      const limite = Number(acc.limite || 0);
                      const emAberto = Number(acc.emAberto || 0);
                      const disponivel = isCreditCard ? Number(acc.disponivel || 0) : null;

                      return (
                        <TableRow key={acc.id}>
                          <TableCell className="font-medium flex items-center gap-2">
                            {isCreditCard ? (
                              <CreditCard className="w-4 h-4 text-purple-500" />
                            ) : (
                              <Wallet className="w-4 h-4 text-gray-400" />
                            )}
                            {acc.nome_conta}
                          </TableCell>
                          <TableCell>{acc.banco}</TableCell>
                          <TableCell className="capitalize">
                            {acc.tipo ? String(acc.tipo).replace('_', ' ') : ''}
                          </TableCell>
                          <TableCell className="text-right">
                            {isCreditCard ? (
                              <div className="space-y-1">
                                <div
                                  className={`font-bold ${
                                    disponivel < 0 ? 'text-red-600' : 'text-green-600'
                                  }`}
                                >
                                  Disponível: {formatCurrency(disponivel)}
                                </div>
                                <div className="text-xs text-muted-foreground">
                                  Limite: {formatCurrency(limite)} | Em aberto:{' '}
                                  {formatCurrency(emAberto)}
                                </div>
                              </div>
                            ) : (
                              <span
                                className={`font-bold ${
                                  saldo < 0 ? 'text-red-600' : 'text-green-600'
                                }`}
                              >
                                {formatCurrency(saldo)}
                              </span>
                            )}
                          </TableCell>
                          <TableCell className="text-right space-x-2">
                            <Button variant="ghost" size="sm" onClick={() => openEdit(acc)}>
                              <Edit2 className="w-4 h-4" />
                            </Button>
                            <Dialog
                              open={deleteConfirmId === acc.id}
                              onOpenChange={(open) => setDeleteConfirmId(open ? acc.id : null)}
                            >
                              <DialogTrigger asChild>
                                <Button
                                  variant="ghost"
                                  size="sm"
                                  className="text-red-500 hover:text-red-700 hover:bg-red-50"
                                >
                                  <Trash2 className="w-4 h-4" />
                                </Button>
                              </DialogTrigger>
                              <DialogContent>
                                <DialogHeader>
                                  <DialogTitle>Confirmar exclusão</DialogTitle>
                                </DialogHeader>
                                <p className="text-sm text-gray-600">
                                  Tem certeza que deseja excluir a conta{' '}
                                  <strong>{acc.nome_conta}</strong>? Esta ação não pode ser
                                  desfeita.
                                </p>
                                <div className="flex gap-2 justify-end pt-4">
                                  <Button
                                    variant="outline"
                                    onClick={() => setDeleteConfirmId(null)}
                                  >
                                    Cancelar
                                  </Button>
                                  <Button
                                    variant="destructive"
                                    onClick={() => handleDelete(acc.id)}
                                  >
                                    Excluir
                                  </Button>
                                </div>
                              </DialogContent>
                            </Dialog>
                          </TableCell>
                        </TableRow>
                      );
                    })}
                  </React.Fragment>
                ))
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
};

export default FinanceAccounts;