import React, { useMemo, useState } from 'react';
import { useLocation, Outlet, useNavigate } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import { useCompany } from '@/contexts/CompanyContext';
import { useFinanceLevel } from '@/hooks/useFinanceLevel';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuSeparator,
} from "@/components/ui/dropdown-menu";
import {
  Home,
  Receipt,
  LineChart,
  Landmark,
  Tags,
  Users,
  CreditCard,
  Repeat,
  Menu,
  ChevronRight,
  Check,
} from 'lucide-react';

const FinanceLayout = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const { selectedCompany } = useCompany();
  const { permissions } = useFinanceLevel(selectedCompany?.id);

  const [mobileOpen, setMobileOpen] = useState(false);

  const items = useMemo(() => {
    const base = [
      { key: 'dashboard', label: 'Dashboard', to: '/cliente/financeiro/painel', icon: Home },
      { key: 'lancamentos', label: 'Lançamentos', to: '/cliente/financeiro/lancamentos', icon: Receipt },
      { key: 'dre', label: 'DRE', to: '/cliente/financeiro/dre', icon: LineChart },
      { key: 'contas', label: 'Contas', to: '/cliente/financeiro/contas', icon: Landmark },
      { key: 'categorias', label: 'Plano de Contas', to: '/cliente/financeiro/plano-contas', icon: Tags },
      { key: 'clientes', label: 'Parceiros', to: '/cliente/financeiro/clientes', icon: Users },
      { key: 'recorrencias', label: 'Recorrências', to: '/cliente/financeiro/recorrencias', icon: Repeat },
    ];

    if (permissions?.canUseCreditCards) {
      // coloca Cartões perto de Contas (faz mais sentido visual)
      base.splice(4, 0, { key: 'cartoes', label: 'Cartões', to: '/cliente/financeiro/cartoes', icon: CreditCard });
    }

    return base;
  }, [permissions?.canUseCreditCards]);

  const activeItem = useMemo(() => {
    // match mais específico primeiro (evita “/contas” bater em outros paths)
    const found = items.find(i => location.pathname === i.to) ||
      items.find(i => location.pathname.startsWith(i.to));
    return found || items[0];
  }, [items, location.pathname]);

  const go = (to) => {
    navigate(to);
    setMobileOpen(false);
  };

  return (
    <>
      <Helmet>
        <title>Financeiro - {selectedCompany?.nome || 'Portal'}</title>
      </Helmet>

      <div className="flex flex-col min-h-screen bg-background pb-20 md:pb-10">
        <div className="w-full max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">

          {/* HEADER + MENU NOVO */}
          <div className="space-y-4">
            {/* Top bar */}
            <div className="flex items-start justify-between gap-4">
              <div className="min-w-0">
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <span>Financeiro</span>
                  <ChevronRight className="h-4 w-4" />
                  <span className="font-medium text-foreground truncate">
                    {activeItem?.label}
                  </span>
                </div>

                <div className="mt-1 flex flex-wrap items-center gap-2">
                  <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-foreground">
                    Gestão Financeira
                  </h1>

                  {/* “pílula” com empresa (fica bem premium e ajuda contexto) */}
                  {selectedCompany?.nome && (
                    <Badge variant="secondary" className="rounded-full px-3 py-1">
                      {selectedCompany.nome}
                    </Badge>
                  )}
                </div>
              </div>

              {/* Mobile menu trigger (mais bonito + estado) */}
              <div className="md:hidden shrink-0">
                <DropdownMenu open={mobileOpen} onOpenChange={setMobileOpen}>
                  <DropdownMenuTrigger asChild>
                    <Button
                      variant="outline"
                      size="sm"
                      className="rounded-full"
                    >
                      <Menu className="h-4 w-4 mr-2" />
                      Menu
                      <Badge
                        variant="secondary"
                        className="ml-2 rounded-full px-2 py-0.5"
                      >
                        {activeItem?.label}
                      </Badge>
                    </Button>
                  </DropdownMenuTrigger>

                  <DropdownMenuContent
                    align="end"
                    className="w-[260px] p-2"
                  >
                    <div className="px-2 py-2">
                      <div className="text-xs text-muted-foreground">Navegação</div>
                      <div className="text-sm font-semibold text-foreground truncate">
                        {selectedCompany?.nome || 'Empresa'}
                      </div>
                    </div>

                    <DropdownMenuSeparator />

                    {items.map((it) => {
                      const isActive = activeItem?.key === it.key;
                      const Icon = it.icon;

                      return (
                        <DropdownMenuItem
                          key={it.key}
                          onClick={() => go(it.to)}
                          className={[
                            "flex items-center justify-between gap-2 rounded-lg py-2",
                            isActive ? "bg-muted" : "",
                          ].join(" ")}
                        >
                          <div className="flex items-center gap-2 min-w-0">
                            <span
                              className={[
                                "grid place-items-center h-8 w-8 rounded-lg border",
                                isActive ? "bg-background" : "bg-background/50",
                              ].join(" ")}
                            >
                              <Icon className="h-4 w-4" />
                            </span>
                            <span className="truncate">{it.label}</span>
                          </div>

                          {isActive && <Check className="h-4 w-4 text-muted-foreground" />}
                        </DropdownMenuItem>
                      );
                    })}
                  </DropdownMenuContent>
                </DropdownMenu>
              </div>
            </div>

            {/* Desktop menu: “pill tabs” com ícones + underline animado simples */}
            <div className="hidden md:block">
              <div className="rounded-2xl border bg-card p-2 shadow-sm">
                <div className="flex flex-wrap gap-2">
                  {items.map((it) => {
                    const isActive = activeItem?.key === it.key;
                    const Icon = it.icon;

                    return (
                      <button
                        key={it.key}
                        type="button"
                        onClick={() => go(it.to)}
                        className={[
                          "group relative flex items-center gap-2 rounded-full px-4 py-2 text-sm font-medium transition",
                          "border",
                          isActive
                            ? "bg-foreground text-background border-foreground"
                            : "bg-background text-foreground/80 hover:bg-muted",
                        ].join(" ")}
                      >
                        <Icon
                          className={[
                            "h-4 w-4 transition",
                            isActive ? "opacity-100" : "opacity-70 group-hover:opacity-100",
                          ].join(" ")}
                        />
                        <span className="whitespace-nowrap">{it.label}</span>

                        {isActive && (
                          <span className="ml-1 rounded-full bg-background/20 px-2 py-0.5 text-[11px]">
                            ativo
                          </span>
                        )}
                      </button>
                    );
                  })}
                </div>
              </div>
            </div>
          </div>

          {/* CONTEÚDO */}
          <div className="min-h-[500px]">
            <Outlet />
          </div>
        </div>
      </div>
    </>
  );
};

export default FinanceLayout;