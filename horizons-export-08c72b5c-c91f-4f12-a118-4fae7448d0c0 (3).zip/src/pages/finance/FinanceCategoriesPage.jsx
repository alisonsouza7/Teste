import React, { useState } from 'react';
import { useCompany } from '@/contexts/CompanyContext';
import { useChartOfAccounts } from '@/hooks/useChartOfAccounts';
import { exportEnhancedExcel } from '@/lib/exportUtils';

// UI
import PageHeader from '@/components/ui/PageHeader';
import SectionCard from '@/components/ui/SectionCard';
import { Button } from '@/components/ui/button';
import { Plus, Download, Loader2 } from 'lucide-react';
import EmptyState from '@/components/ui/EmptyState';

// Enhanced Components
import ReorderableList from '@/components/finance/ChartOfAccounts/ReorderableList';
import AccountEditModal from '@/components/finance/ChartOfAccounts/AccountEditModal';

const FinanceCategoriesPage = () => {
  const { selectedCompany } = useCompany();
  const { 
    accounts, 
    loading, 
    createAccount, 
    updateAccount, 
    deleteAccount, 
    reorderAccounts 
  } = useChartOfAccounts(selectedCompany?.id);

  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingAccount, setEditingAccount] = useState(null);
  const [activeSection, setActiveSection] = useState('receita'); // For default modal type

  const handleOpenCreate = (section) => {
    setActiveSection(section);
    setEditingAccount(null);
    setIsModalOpen(true);
  };

  const handleOpenEdit = (account) => {
    setEditingAccount(account);
    setIsModalOpen(true);
  };

  const handleSave = async (data) => {
    if (data.id) {
      await updateAccount(data.id, data);
    } else {
      await createAccount(data);
    }
  };

  const handleExport = () => {
    exportEnhancedExcel(accounts, 'Plano_de_Contas', 'CATEGORIES');
  };

  // Group accounts by type
  const groupedAccounts = {
    receita: accounts.filter(a => a.tipo === 'receita'),
    despesa: accounts.filter(a => a.tipo === 'despesa'),
    custo: accounts.filter(a => a.tipo === 'custo'),
    investimento: accounts.filter(a => a.tipo === 'investimento'),
  };

  // Order of sections
  const SECTIONS = [
    { key: 'receita', label: 'Receitas', color: 'text-emerald-700 bg-emerald-50' },
    { key: 'custo', label: 'Custos (CMV/CSP)', color: 'text-amber-700 bg-amber-50' },
    { key: 'despesa', label: 'Despesas Operacionais', color: 'text-red-700 bg-red-50' },
    { key: 'investimento', label: 'Investimentos', color: 'text-blue-700 bg-blue-50' },
  ];

  if (loading) {
    return (
      <div className="flex h-[50vh] items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="space-y-6 pb-20">
      <PageHeader 
        title="Plano de Contas" 
        subtitle="Organize suas categorias com numeração hierárquica e cores."
        actions={
          <div className="flex gap-2">
            <Button variant="outline" onClick={handleExport}>
              <Download className="h-4 w-4 mr-2" /> Exportar
            </Button>
            <Button onClick={() => handleOpenCreate('receita')}>
              <Plus className="h-4 w-4 mr-2" /> Nova Categoria
            </Button>
          </div>
        }
      />

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {SECTIONS.map((section) => (
          <SectionCard 
            key={section.key}
            title={section.label}
            description={`Intervalo: ${
              section.key === 'receita' ? '1000' : 
              section.key === 'custo' ? '2000' : 
              section.key === 'despesa' ? '3000' : '4000'
            }+`}
            action={
              <Button size="sm" variant="ghost" onClick={() => handleOpenCreate(section.key)}>
                <Plus className="h-4 w-4" />
              </Button>
            }
            className="h-auto"
            contentClassName="px-4 py-2"
          >
            {groupedAccounts[section.key].length > 0 ? (
              <ReorderableList 
                items={groupedAccounts[section.key]} 
                onReorder={reorderAccounts}
                onEdit={handleOpenEdit}
                onDelete={deleteAccount}
              />
            ) : (
              <EmptyState 
                title="Sem categorias" 
                description="Adicione categorias para este grupo."
                className="py-8"
                icon={Plus}
                actionLabel="Adicionar"
                onAction={() => handleOpenCreate(section.key)}
              />
            )}
          </SectionCard>
        ))}
      </div>

      <AccountEditModal 
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        onSave={handleSave}
        account={editingAccount}
        defaultTipo={activeSection}
      />
    </div>
  );
};

export default FinanceCategoriesPage;