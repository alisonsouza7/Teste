import React, { useState, useEffect } from 'react';
import { useCompany } from '@/contexts/CompanyContext';
import { supabase } from '@/lib/customSupabaseClient';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { CreditCard, Calendar, ChevronRight } from 'lucide-react';
import { format, parseISO } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';

const formatCurrency = (value) =>
  new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(value || 0);

const FinanceCreditCards = () => {
  const { selectedCompany } = useCompany();
  const [accounts, setAccounts] = useState([]);
  const [selectedCardId, setSelectedCardId] = useState('all');
  const [invoices, setInvoices] = useState([]);
  const [loading, setLoading] = useState(true);
  const [openUsageByAccount, setOpenUsageByAccount] = useState({}); // total em aberto por cartão

  useEffect(() => {
    if (selectedCompany) {
      fetchCreditCards();
    }
  }, [selectedCompany]);

  const fetchCreditCards = async () => {
    try {
      const { data, error } = await supabase
        .from('finance_accounts')
        .select('*')
        .eq('company_id', selectedCompany.id)
        .eq('tipo', 'cartao_credito')
        .is('deleted_at', null);

      if (error) throw error;
      setAccounts(data || []);
      // Se quiser selecionar o primeiro cartão automaticamente:
      // if (data && data.length > 0) setSelectedCardId(data[0].id);
    } catch (error) {
      console.error(error);
    }
  };

  useEffect(() => {
    if (selectedCompany) {
      fetchInvoices();
    }
  }, [selectedCardId, selectedCompany]);

  const fetchInvoices = async () => {
    setLoading(true);
    try {
      let query = supabase
        .from('finance_transactions')
        .select(`
          id, valor, data_competencia, data_lancamento, descricao, liquidado, tipo, conta_id,
          finance_chart_of_accounts(nome_conta),
          finance_accounts(nome_conta)
        `)
        .eq('company_id', selectedCompany.id)
        .eq('origem', 'cartao_credito')
        .is('deleted_at', null);

      if (selectedCardId !== 'all') {
        query = query.eq('conta_id', selectedCardId);
      }

      const { data, error } = await query;
      if (error) throw error;

      const grouped = {};
      const openUsage = {}; // acumula valor em aberto por cartão

      data.forEach((tx) => {
        const monthKey = tx.data_competencia.substring(0, 7);
        const accountId = tx.conta_id;
        const uniqueKey = `${monthKey}-${accountId}`;

        if (!grouped[uniqueKey]) {
          grouped[uniqueKey] = {
            id: uniqueKey,
            month: monthKey,
            accountId: accountId,
            accountName: tx.finance_accounts?.nome_conta || 'Cartão Desconhecido',
            total: 0,
            status: 'paid',
            transactions: [],
            dueDate: tx.data_lancamento
          };
        }

        grouped[uniqueKey].transactions.push(tx);
        grouped[uniqueKey].total += Math.abs(tx.valor);

        if (!tx.liquidado) {
          grouped[uniqueKey].status = 'open';

          if (!openUsage[accountId]) {
            openUsage[accountId] = 0;
          }
          openUsage[accountId] += Math.abs(tx.valor);
        }
      });

      const invoicesArray = Object.values(grouped).sort((a, b) => {
        if (b.month !== a.month) {
          return b.month.localeCompare(a.month);
        }
        return a.accountName.localeCompare(b.accountName);
      });

      setInvoices(invoicesArray);
      setOpenUsageByAccount(openUsage);
    } catch (error) {
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  const formatMonth = (isoMonth) => {
    const [y, m] = isoMonth.split('-');
    const date = new Date(y, m - 1, 1);
    return format(date, 'MMMM yyyy', { locale: ptBR });
  };

  // INFO DE LIMITE / USO / DISPONÍVEL DO CARTÃO
  const getCardLimitInfo = (accountId) => {
    if (!accountId) return null;

    const account = accounts.find((acc) => acc.id === accountId);
    if (!account) return null;

    // Aqui é onde trocamos para limite
    const limit = Number(account.limite || 0);
    if (!limit) return null;

    const usedOpen = Number(openUsageByAccount[accountId] || 0);
    const available = limit - usedOpen;

    return {
      limit,
      usedOpen,
      available
    };
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold tracking-tight">Faturas de Cartão</h2>
        <div className="w-[200px]">
          <Select value={selectedCardId} onValueChange={setSelectedCardId}>
            <SelectTrigger>
              <SelectValue placeholder="Selecione o cartão" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Todos os Cartões</SelectItem>
              {accounts.map((acc) => (
                <SelectItem key={acc.id} value={acc.id}>
                  {acc.nome_conta}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>

      {loading ? (
        <div className="text-center py-10">Carregando faturas...</div>
      ) : invoices.length === 0 ? (
        <div className="text-center py-10 text-muted-foreground border rounded-lg bg-gray-50">
          Nenhuma fatura encontrada.
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {invoices.map((inv) => {
            const limitInfo = getCardLimitInfo(inv.accountId);

            return (
              <Card
                key={inv.id}
                className="hover:shadow-md transition-shadow flex flex-col justify-between"
              >
                <CardHeader className="p-4 pb-2">
                  <div className="flex justify-between items-start mb-2">
                    <div className="flex items-center gap-3">
                      <div className="p-2 bg-purple-100 rounded-full">
                        <CreditCard className="w-5 h-5 text-purple-600" />
                      </div>
                      <div>
                        <CardTitle className="text-lg font-bold text-gray-800 line-clamp-1">
                          {inv.accountName}
                        </CardTitle>
                        <div className="text-sm font-medium text-gray-500 capitalize">
                          {formatMonth(inv.month)}
                        </div>
                      </div>
                    </div>
                    <Badge
                      variant={inv.status === 'open' ? 'outline' : 'success'}
                      className={
                        inv.status === 'open'
                          ? 'text-orange-600 border-orange-200 bg-orange-50 whitespace-nowrap'
                          : 'bg-green-100 text-green-800 border-green-200 whitespace-nowrap'
                      }
                    >
                      {inv.status === 'open' ? 'Aberto' : 'Pago'}
                    </Badge>
                  </div>

                  <div className="mt-4">
                    <div className="text-2xl font-bold text-gray-900">
                      {formatCurrency(inv.total)}
                    </div>
                    <div className="text-xs text-muted-foreground flex items-center gap-1 mt-1">
                      <Calendar className="w-3 h-3" />
                      Vencimento aprox:{' '}
                      {inv.dueDate ? format(parseISO(inv.dueDate), 'dd/MM/yyyy') : '-'}
                    </div>

                    {limitInfo && (
                      <div className="mt-3 text-xs text-gray-700 space-y-1">
                        <div>Limite do cartão: {formatCurrency(limitInfo.limit)}</div>
                        <div>Em aberto (não liquidado): {formatCurrency(limitInfo.usedOpen)}</div>
                        <div
                          className={
                            limitInfo.available < 0
                              ? 'font-semibold text-red-600'
                              : 'font-semibold text-green-700'
                          }
                        >
                          Disponível: {formatCurrency(limitInfo.available)}
                        </div>
                      </div>
                    )}
                  </div>
                </CardHeader>

                <CardContent className="p-4 pt-0">
                  <Dialog>
                    <DialogTrigger asChild>
                      <div className="w-full text-center mt-2 p-2 border-t cursor-pointer hover:bg-gray-50 text-sm text-blue-600 flex justify-center items-center gap-1 transition-colors rounded-b-lg">
                        Ver {inv.transactions.length} lançamentos{' '}
                        <ChevronRight className="w-3 h-3" />
                      </div>
                    </DialogTrigger>
                    <DialogContent className="max-w-3xl max-h-[80vh] overflow-y-auto">
                      <DialogHeader>
                        <DialogTitle>
                          Fatura: {inv.accountName} - {formatMonth(inv.month)}
                        </DialogTitle>
                      </DialogHeader>
                      <Table>
                        <TableHeader>
                          <TableRow>
                            <TableHead className="w-[100px]">Data</TableHead>
                            <TableHead>Descrição</TableHead>
                            <TableHead>Categoria</TableHead>
                            <TableHead className="text-right">Valor</TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {inv.transactions.map((tx) => (
                            <TableRow key={tx.id}>
                              <TableCell>
                                {tx.data_lancamento
                                  ? format(parseISO(tx.data_lancamento), 'dd/MM')
                                  : '-'}
                              </TableCell>
                              <TableCell>{tx.descricao}</TableCell>
                              <TableCell>
                                {tx.finance_chart_of_accounts?.nome_conta || '-'}
                              </TableCell>
                              <TableCell className="text-right font-medium">
                                {formatCurrency(Math.abs(tx.valor))}
                              </TableCell>
                            </TableRow>
                          ))}
                        </TableBody>
                      </Table>
                    </DialogContent>
                  </Dialog>
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}
    </div>
  );
};

export default FinanceCreditCards;