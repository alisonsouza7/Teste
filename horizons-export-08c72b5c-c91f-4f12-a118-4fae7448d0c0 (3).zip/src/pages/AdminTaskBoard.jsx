
import React, { useState, useEffect } from 'react';
import { useAuth } from '@/contexts/SupabaseAuthContext.jsx';
import { useProjects } from '@/hooks/useProjects.js';
import { useTaskColumns } from '@/hooks/useTaskColumns.js';
import { useTasks } from '@/hooks/useTasks.js';
import { useSmartGoals } from '@/hooks/useSmartGoals.js';
import { useTaskAutomations } from '@/hooks/useTaskAutomations.js';
import { useTags } from '@/hooks/useTags.js';
import KanbanBoard from '@/components/tasks/KanbanBoard';
import TaskListView from '@/components/tasks/TaskListView';
import CalendarView from '@/components/tasks/CalendarView';
import MetricsView from '@/components/tasks/MetricsView';
import PomodoroWidget from '@/components/tasks/PomodoroWidget';
import WaterfallView from '@/components/tasks/WaterfallView';
import ABCDEView from '@/components/tasks/ABCDEView';
import ParetoView from '@/components/tasks/ParetoView';
import MindMapView from '@/components/tasks/MindMapView';
import AdvancedFiltersBar from '@/components/tasks/AdvancedFiltersBar';
import TaskModal from '@/components/tasks/TaskModal';
import SmartGoalsModal from '@/components/tasks/SmartGoalsModal';
import ProjectModal from '@/components/tasks/ProjectModal';
import TagModal from '@/components/tasks/TagModal';
import FloatingActionButton from '@/components/tasks/FloatingActionButton';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import { LayoutDashboard, List, Calendar as CalendarIcon, PieChart, Target, Timer, Zap, TrendingUp, Layers } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';

const AdminTaskBoard = () => {
  const [selectedProjectId, setSelectedProjectId] = useState(null);
  const [filters, setFilters] = useState({});
  
  // Modal States
  const [isTaskModalOpen, setIsTaskModalOpen] = useState(false);
  const [isGoalModalOpen, setIsGoalModalOpen] = useState(false);
  const [isProjectModalOpen, setIsProjectModalOpen] = useState(false);
  const [isTagModalOpen, setIsTagModalOpen] = useState(false);
  
  // Editing States
  const [editingTask, setEditingTask] = useState(null);
  const [editingProject, setEditingProject] = useState(null);
  const [editingTag, setEditingTag] = useState(null);
  const [targetColumnId, setTargetColumnId] = useState(null);

  const { user } = useAuth();
  const { projects, loading: projectsLoading, createProject, updateProject } = useProjects();
  const { columns, loading: columnsLoading } = useTaskColumns(selectedProjectId);
  const { tasks, loading: tasksLoading, updateTask, createTask, reorderTasks, deleteTask } = useTasks(selectedProjectId, filters);
  const { goals, createGoal, updateGoal, deleteGoal } = useSmartGoals();
  const { completeTask } = useTaskAutomations();
  const { tags, createTag } = useTags();
  const { toast } = useToast();

  useEffect(() => {
    // Select first project by default when loaded
    if (projects.length > 0 && !selectedProjectId) {
      setSelectedProjectId(projects[0].id);
    }
  }, [projects, selectedProjectId]);

  const handleDragEnd = async (result) => {
    const { destination, source, draggableId } = result;

    if (!destination) return;

    const sourceColumnId = source.droppableId;
    const destColumnId = destination.droppableId;
    
    // Create a copy of tasks to modify optimistically
    const newTasks = Array.from(tasks);
    const draggedTask = newTasks.find(t => t.id === draggableId);
    
    if (!draggedTask) return;

    // Update task column immediately in local state
    draggedTask.column_id = destColumnId;

    try {
        await reorderTasks(newTasks);
        
        // If moved to a different column, update db
        if (sourceColumnId !== destColumnId) {
             await updateTask(draggableId, { column_id: destColumnId });
        }
    } catch (e) {
        console.error("Failed to reorder", e);
        toast({ title: "Erro ao mover tarefa", variant: "destructive" });
    }
  };

  const handleSaveTask = async (taskData, id) => {
     if (id) {
         await updateTask(id, taskData);
     } else {
         await createTask(taskData);
     }
  };

  const handleSaveGoal = async (goalData, id) => {
      try {
          if (id) await updateGoal(id, goalData);
          else await createGoal(goalData);
          toast({ title: "Meta salva com sucesso!" });
      } catch (e) {
          toast({ title: "Erro ao salvar meta", variant: "destructive" });
      }
  };

  const handleSaveProject = async (data, id) => {
      if (id) {
          await updateProject(id, data);
      } else {
          const newProject = await createProject(data);
          if (newProject) {
              setSelectedProjectId(newProject.id);
          }
      }
  };

  const handleSaveTag = async (data, id) => {
      // Tags update usually not implemented in simple hook, assuming create only for now or simple structure
      // If useTags hook supports update, we would use it. For now, creating new.
      // Since useTags implementation provided only has createTag:
      await createTag(data.name, data.color);
  };

  const openNewTaskModal = (columnId = null) => {
      if (!selectedProjectId) {
          toast({
              title: "Nenhum projeto selecionado",
              description: "Crie ou selecione um projeto antes de criar tarefas.",
              variant: "destructive"
          });
          return;
      }
      setEditingTask(null);
      setTargetColumnId(columnId || (columns.length > 0 ? columns[0].id : null));
      setIsTaskModalOpen(true);
  };

  const openEditTaskModal = (task) => {
      setEditingTask(task);
      setIsTaskModalOpen(true);
  };

  const handleTaskToggle = async (task) => {
      const newStatus = task.status === 'completed' ? 'todo' : 'completed';
      const completedAt = newStatus === 'completed' ? new Date().toISOString() : null;
      
      try {
          await updateTask(task.id, { status: newStatus, completed_at: completedAt });
          toast({ title: newStatus === 'completed' ? "Tarefa concluída! 🎉" : "Tarefa reaberta" });
      } catch (e) {
          toast({ title: "Erro ao atualizar status", variant: "destructive" });
      }
  };

  return (
    <div className="p-6 min-h-screen bg-gray-50/50">
      <div className="flex flex-col space-y-6 max-w-[1600px] mx-auto h-[calc(100vh-100px)]">
        
        {/* Header & Filters */}
        <div>
          <h1 className="text-3xl font-bold tracking-tight text-gray-900 mb-6">Gestão de Tarefas</h1>
          <AdvancedFiltersBar 
            projects={projects}
            selectedProject={selectedProjectId}
            onProjectChange={setSelectedProjectId}
            filters={filters}
            onFilterChange={(key, val) => setFilters(prev => ({...prev, [key]: val}))}
            onClearFilters={() => setFilters({})}
          />
        </div>

        {/* Views Tabs */}
        <Tabs defaultValue="kanban" className="flex-1 flex flex-col overflow-hidden">
           <div className="flex justify-between items-center mb-4 overflow-x-auto pb-2 scrollbar-hide">
               <TabsList className="flex-nowrap">
                   <TabsTrigger value="kanban"><LayoutDashboard className="w-4 h-4 mr-2" /> Kanban</TabsTrigger>
                   <TabsTrigger value="list"><List className="w-4 h-4 mr-2" /> Lista</TabsTrigger>
                   <TabsTrigger value="waterfall"><Layers className="w-4 h-4 mr-2" /> Waterfall</TabsTrigger>
                   <TabsTrigger value="abcde"><Zap className="w-4 h-4 mr-2" /> ABCDE</TabsTrigger>
                   <TabsTrigger value="pareto"><TrendingUp className="w-4 h-4 mr-2" /> Pareto</TabsTrigger>
                   <TabsTrigger value="mindmap"><Target className="w-4 h-4 mr-2" /> Mind Map</TabsTrigger>
                   <TabsTrigger value="calendar"><CalendarIcon className="w-4 h-4 mr-2" /> Calendário</TabsTrigger>
                   <TabsTrigger value="metrics"><PieChart className="w-4 h-4 mr-2" /> Métricas</TabsTrigger>
                   <TabsTrigger value="goals"><Target className="w-4 h-4 mr-2" /> Metas</TabsTrigger>
                   <TabsTrigger value="pomodoro"><Timer className="w-4 h-4 mr-2" /> Foco</TabsTrigger>
               </TabsList>
           </div>

           <div className="flex-1 overflow-y-auto overflow-x-hidden rounded-xl border bg-white/50 backdrop-blur-sm p-4 shadow-sm relative">
               <TabsContent value="kanban" className="h-full m-0">
                   {selectedProjectId ? (
                       <KanbanBoard 
                          columns={columns}
                          tasks={tasks}
                          loading={columnsLoading || tasksLoading}
                          onTaskMove={handleDragEnd}
                          onTaskClick={openEditTaskModal}
                          onAddClick={openNewTaskModal}
                       />
                   ) : (
                       <div className="flex items-center justify-center h-full text-gray-400">Selecione ou crie um projeto</div>
                   )}
               </TabsContent>
               
               <TabsContent value="list" className="h-full m-0">
                    <TaskListView 
                        tasks={tasks} 
                        onTaskClick={openEditTaskModal} 
                        onToggleComplete={handleTaskToggle}
                        onDeleteTask={deleteTask}
                    />
               </TabsContent>

               <TabsContent value="waterfall" className="h-full m-0">
                    <WaterfallView tasks={tasks} onTaskClick={openEditTaskModal} />
               </TabsContent>

               <TabsContent value="abcde" className="h-full m-0">
                    <ABCDEView tasks={tasks} onTaskClick={openEditTaskModal} />
               </TabsContent>

               <TabsContent value="pareto" className="h-full m-0">
                    <ParetoView tasks={tasks} onTaskClick={openEditTaskModal} />
               </TabsContent>

               <TabsContent value="mindmap" className="h-full m-0">
                    <MindMapView tasks={tasks} onTaskClick={openEditTaskModal} />
               </TabsContent>

               <TabsContent value="calendar" className="h-full m-0">
                   <CalendarView 
                       tasks={tasks} 
                       onTaskClick={openEditTaskModal} 
                       onDateClick={() => openNewTaskModal()} 
                   />
               </TabsContent>

               <TabsContent value="metrics" className="h-full m-0">
                   <MetricsView tasks={tasks} />
               </TabsContent>

               <TabsContent value="goals" className="h-full m-0">
                    <div className="space-y-6">
                        <div className="flex justify-between items-center">
                            <h2 className="text-xl font-bold">Minhas Metas SMART</h2>
                            <Button onClick={() => setIsGoalModalOpen(true)}>Nova Meta</Button>
                        </div>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            {goals.map(goal => (
                                <Card key={goal.id} className="hover:shadow-md transition-all">
                                    <CardContent className="p-6 space-y-4">
                                        <div className="flex justify-between items-start">
                                            <h3 className="font-bold text-lg">{goal.title}</h3>
                                            <Button variant="ghost" size="sm" onClick={() => deleteGoal(goal.id)} className="text-red-500 h-6">Excluir</Button>
                                        </div>
                                        <div className="text-sm text-gray-500 line-clamp-2">{goal.specific}</div>
                                        <div className="space-y-1">
                                            <div className="flex justify-between text-xs text-gray-500">
                                                <span>Progresso</span>
                                                <span>{goal.progress || 0}%</span>
                                            </div>
                                            <Progress value={goal.progress || 0} />
                                        </div>
                                    </CardContent>
                                </Card>
                            ))}
                            {goals.length === 0 && (
                                <div className="col-span-2 text-center py-10 text-gray-400 bg-gray-50 rounded-xl border border-dashed">
                                    Nenhuma meta definida ainda. Use o método SMART para criar objetivos claros!
                                </div>
                            )}
                        </div>
                    </div>
               </TabsContent>

               <TabsContent value="pomodoro" className="h-full m-0">
                   <PomodoroWidget tasks={tasks} />
               </TabsContent>
           </div>
        </Tabs>

      </div>

      <FloatingActionButton 
         onCreateTask={() => openNewTaskModal()} 
         onCreateProject={() => {
             setEditingProject(null);
             setIsProjectModalOpen(true);
         }}
         onCreateGoal={() => setIsGoalModalOpen(true)}
         onCreateTag={() => {
             setEditingTag(null);
             setIsTagModalOpen(true);
         }}
         onCreateEvent={() => toast({ title: "Novo Evento", description: "Use a aba Calendário para adicionar eventos.", duration: 3000 })}
      />

      <TaskModal 
        open={isTaskModalOpen}
        onOpenChange={setIsTaskModalOpen}
        taskToEdit={editingTask}
        projectId={selectedProjectId}
        columnId={targetColumnId || (editingTask?.column_id)}
        onSave={handleSaveTask}
      />

      <SmartGoalsModal 
        open={isGoalModalOpen}
        onOpenChange={setIsGoalModalOpen}
        onSave={handleSaveGoal}
      />
      
      <ProjectModal 
        open={isProjectModalOpen}
        onOpenChange={setIsProjectModalOpen}
        projectToEdit={editingProject}
        onSave={handleSaveProject}
      />
      
      <TagModal
        open={isTagModalOpen}
        onOpenChange={setIsTagModalOpen}
        tagToEdit={editingTag}
        onSave={handleSaveTag}
      />
    </div>
  );
};

export default AdminTaskBoard;
