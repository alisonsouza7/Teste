
import React, { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet';
import { supabase } from '@/lib/customSupabaseClient';
import { useToast } from '@/components/ui/use-toast';
import {
    Card,
    CardContent,
    CardHeader,
    CardTitle,
    CardDescription,
} from '@/components/ui/card';
import {
    Table,
    TableBody,
    TableCell,
    TableHead,
    TableHeader,
    TableRow,
} from '@/components/ui/table';
import {
    Dialog,
    DialogContent,
    DialogHeader,
    DialogTitle,
    DialogDescription,
    DialogFooter,
} from '@/components/ui/dialog';
import {
    Select,
    SelectContent,
    SelectItem,
    SelectTrigger,
    SelectValue,
} from '@/components/ui/select';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import {
    Plus,
    Search,
    Filter,
    MoreVertical,
    Edit,
    Trash2,
    Link as LinkIcon,
    Building2,
    User,
    Loader2,
    X
} from 'lucide-react';
import {
    DropdownMenu,
    DropdownMenuContent,
    DropdownMenuItem,
    DropdownMenuLabel,
    DropdownMenuSeparator,
    DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';

const AdminVinculosPage = () => {
    const { toast } = useToast();

    // --- State Management ---
    const [vinculos, setVinculos] = useState([]);
    const [users, setUsers] = useState([]);
    const [companies, setCompanies] = useState([]);
    const [loading, setLoading] = useState(true);

    // Filters
    const [searchTerm, setSearchTerm] = useState('');
    const [filterUser, setFilterUser] = useState('all');
    const [filterCompany, setFilterCompany] = useState('all');
    const [filterRole, setFilterRole] = useState('all');
    const [filterStatus, setFilterStatus] = useState('all');

    // Modals
    const [isCreateOpen, setIsCreateOpen] = useState(false);
    const [isEditOpen, setIsEditOpen] = useState(false);
    const [isDeleteOpen, setIsDeleteOpen] = useState(false);
    
    // Form State
    const [selectedVinculo, setSelectedVinculo] = useState(null);
    const [formData, setFormData] = useState({
        user_id: '',
        company_id: '',
        papel: '',
        status: 'ativo'
    });
    const [isSubmitting, setIsSubmitting] = useState(false);

    // --- Data Fetching ---

    useEffect(() => {
        fetchData();
        const savedFilters = localStorage.getItem('admin-vinculos-filters');
        if (savedFilters) {
            const parsed = JSON.parse(savedFilters);
            setFilterUser(parsed.filterUser || 'all');
            setFilterCompany(parsed.filterCompany || 'all');
            setFilterRole(parsed.filterRole || 'all');
            setFilterStatus(parsed.filterStatus || 'all');
        }
    }, []);

    const fetchData = async () => {
        setLoading(true);
        try {
            // Fetch Vinculos with relations
            const { data: vinculosData, error: vinculosError } = await supabase
                .from('user_company_roles')
                .select(`
                    *,
                    users (id, email, nome),
                    companies (id, nome, cnpj_cpf)
                `)
                .order('created_at', { ascending: false });

            if (vinculosError) throw vinculosError;

            // Fetch Users for dropdowns
            const { data: usersData, error: usersError } = await supabase
                .from('users')
                .select('id, email, nome')
                .order('email');

            if (usersError) throw usersError;

            // Fetch Companies for dropdowns
            const { data: companiesData, error: companiesError } = await supabase
                .from('companies')
                .select('id, nome')
                .order('nome');

            if (companiesError) throw companiesError;

            setVinculos(vinculosData || []);
            setUsers(usersData || []);
            setCompanies(companiesData || []);

        } catch (error) {
            console.error('Error fetching data:', error);
            toast({
                variant: 'destructive',
                title: 'Erro ao carregar dados',
                description: 'Não foi possível carregar a lista de vínculos.'
            });
        } finally {
            setLoading(false);
        }
    };

    // --- Handlers ---

    const handleFilterChange = (key, value) => {
        const newFilters = {
            filterUser,
            filterCompany,
            filterRole,
            filterStatus,
            [key]: value
        };
        
        // Update state based on key
        if (key === 'filterUser') setFilterUser(value);
        if (key === 'filterCompany') setFilterCompany(value);
        if (key === 'filterRole') setFilterRole(value);
        if (key === 'filterStatus') setFilterStatus(value);

        localStorage.setItem('admin-vinculos-filters', JSON.stringify(newFilters));
    };

    const clearFilters = () => {
        setFilterUser('all');
        setFilterCompany('all');
        setFilterRole('all');
        setFilterStatus('all');
        setSearchTerm('');
        localStorage.removeItem('admin-vinculos-filters');
    };

    const validateForm = (isEdit = false) => {
        if (!formData.papel) {
            toast({ variant: 'destructive', title: 'Campo obrigatório', description: 'Selecione um papel.' });
            return false;
        }
        if (!formData.status) {
            toast({ variant: 'destructive', title: 'Campo obrigatório', description: 'Selecione um status.' });
            return false;
        }
        
        if (!isEdit) {
            if (!formData.user_id) {
                toast({ variant: 'destructive', title: 'Campo obrigatório', description: 'Selecione um usuário.' });
                return false;
            }
            if (!formData.company_id) {
                toast({ variant: 'destructive', title: 'Campo obrigatório', description: 'Selecione uma empresa.' });
                return false;
            }

            // Check duplicates
            const exists = vinculos.some(v => 
                v.user_id === formData.user_id && 
                v.company_id === formData.company_id
            );

            if (exists) {
                toast({ 
                    variant: 'destructive', 
                    title: 'Vínculo existente', 
                    description: 'Este usuário já está vinculado a esta empresa.' 
                });
                return false;
            }
        }
        return true;
    };

    const handleCreate = async () => {
        if (!validateForm()) return;

        setIsSubmitting(true);
        try {
            const { error } = await supabase
                .from('user_company_roles')
                .insert([{
                    user_id: formData.user_id,
                    company_id: formData.company_id,
                    papel: formData.papel,
                    status: formData.status
                }]);

            if (error) throw error;

            toast({ title: 'Sucesso', description: 'Vínculo criado com sucesso.' });
            setIsCreateOpen(false);
            setFormData({ user_id: '', company_id: '', papel: '', status: 'ativo' });
            fetchData();
        } catch (error) {
            console.error(error);
            toast({ variant: 'destructive', title: 'Erro', description: 'Falha ao criar vínculo.' });
        } finally {
            setIsSubmitting(false);
        }
    };

    const handleUpdate = async () => {
        if (!validateForm(true)) return;
        if (!selectedVinculo) return;

        setIsSubmitting(true);
        try {
            const { error } = await supabase
                .from('user_company_roles')
                .update({
                    papel: formData.papel,
                    status: formData.status
                })
                .eq('id', selectedVinculo.id);

            if (error) throw error;

            toast({ title: 'Sucesso', description: 'Vínculo atualizado com sucesso.' });
            setIsEditOpen(false);
            setSelectedVinculo(null);
            fetchData();
        } catch (error) {
            console.error(error);
            toast({ variant: 'destructive', title: 'Erro', description: 'Falha ao atualizar vínculo.' });
        } finally {
            setIsSubmitting(false);
        }
    };

    const handleDelete = async () => {
        if (!selectedVinculo) return;

        setIsSubmitting(true);
        try {
            const { error } = await supabase
                .from('user_company_roles')
                .delete()
                .eq('id', selectedVinculo.id);

            if (error) throw error;

            toast({ title: 'Sucesso', description: 'Vínculo removido com sucesso.' });
            setIsDeleteOpen(false);
            setSelectedVinculo(null);
            fetchData();
        } catch (error) {
            console.error(error);
            toast({ variant: 'destructive', title: 'Erro', description: 'Falha ao remover vínculo.' });
        } finally {
            setIsSubmitting(false);
        }
    };

    const openEditModal = (vinculo) => {
        setSelectedVinculo(vinculo);
        setFormData({
            user_id: vinculo.user_id,
            company_id: vinculo.company_id,
            papel: vinculo.papel,
            status: vinculo.status || 'ativo'
        });
        setIsEditOpen(true);
    };

    const openDeleteModal = (vinculo) => {
        setSelectedVinculo(vinculo);
        setIsDeleteOpen(true);
    };

    // --- Filtering Logic ---

    const filteredVinculos = vinculos.filter(vinculo => {
        // Search Term (User email or Company name)
        const searchLower = searchTerm.toLowerCase();
        const userName = vinculo.users?.nome?.toLowerCase() || '';
        const userEmail = vinculo.users?.email?.toLowerCase() || '';
        const companyName = vinculo.companies?.nome?.toLowerCase() || '';
        
        const matchesSearch = 
            userName.includes(searchLower) || 
            userEmail.includes(searchLower) || 
            companyName.includes(searchLower);

        // Dropdown Filters
        const matchesUser = filterUser === 'all' || vinculo.user_id === filterUser;
        const matchesCompany = filterCompany === 'all' || vinculo.company_id === filterCompany;
        const matchesRole = filterRole === 'all' || vinculo.papel === filterRole;
        const matchesStatus = filterStatus === 'all' || (vinculo.status || 'ativo') === filterStatus;

        return matchesSearch && matchesUser && matchesCompany && matchesRole && matchesStatus;
    });

    return (
        <div className="space-y-6">
            <Helmet>
                <title>Admin - Gerenciar Vínculos</title>
            </Helmet>

            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
                <div>
                    <h1 className="text-3xl font-bold text-slate-900">Gerenciamento de Vínculos</h1>
                    <p className="text-muted-foreground">Controle o acesso de usuários às empresas do sistema.</p>
                </div>
                <Button onClick={() => {
                    setFormData({ user_id: '', company_id: '', papel: '', status: 'ativo' });
                    setIsCreateOpen(true);
                }}>
                    <Plus className="w-4 h-4 mr-2" /> Novo Vínculo
                </Button>
            </div>

            {/* Filters Section */}
            <Card>
                <CardContent className="p-4 space-y-4">
                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                        {/* Search */}
                        <div className="relative">
                            <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
                            <Input 
                                placeholder="Buscar usuário ou empresa..." 
                                className="pl-8" 
                                value={searchTerm}
                                onChange={(e) => setSearchTerm(e.target.value)}
                            />
                        </div>

                        {/* Role Filter */}
                        <Select value={filterRole} onValueChange={(v) => handleFilterChange('filterRole', v)}>
                            <SelectTrigger>
                                <SelectValue placeholder="Filtrar por Papel" />
                            </SelectTrigger>
                            <SelectContent>
                                <SelectItem value="all">Todos os Papéis</SelectItem>
                                <SelectItem value="proprietario">Proprietário</SelectItem>
                                <SelectItem value="funcionario">Funcionário</SelectItem>
                                <SelectItem value="socio">Sócio</SelectItem>
                                <SelectItem value="contador">Contador</SelectItem>
                            </SelectContent>
                        </Select>

                        {/* Status Filter */}
                        <Select value={filterStatus} onValueChange={(v) => handleFilterChange('filterStatus', v)}>
                            <SelectTrigger>
                                <SelectValue placeholder="Filtrar por Status" />
                            </SelectTrigger>
                            <SelectContent>
                                <SelectItem value="all">Todos os Status</SelectItem>
                                <SelectItem value="ativo">Ativo</SelectItem>
                                <SelectItem value="inativo">Inativo</SelectItem>
                            </SelectContent>
                        </Select>
                        
                         {/* Company Filter */}
                         <Select value={filterCompany} onValueChange={(v) => handleFilterChange('filterCompany', v)}>
                            <SelectTrigger>
                                <SelectValue placeholder="Filtrar por Empresa" />
                            </SelectTrigger>
                            <SelectContent>
                                <SelectItem value="all">Todas as Empresas</SelectItem>
                                {companies.map(c => (
                                    <SelectItem key={c.id} value={c.id}>{c.nome}</SelectItem>
                                ))}
                            </SelectContent>
                        </Select>
                    </div>

                    <div className="flex justify-end gap-2">
                        <Button variant="outline" size="sm" onClick={clearFilters} className="text-muted-foreground">
                            <X className="w-3 h-3 mr-1" /> Limpar Filtros
                        </Button>
                    </div>
                </CardContent>
            </Card>

            {/* Table Section */}
            <Card>
                <CardHeader className="pb-0">
                    <CardTitle>Vínculos Existentes</CardTitle>
                    <CardDescription>
                        Total: {filteredVinculos.length} registros encontrados
                    </CardDescription>
                </CardHeader>
                <CardContent>
                    <div className="rounded-md border mt-4">
                        <Table>
                            <TableHeader>
                                <TableRow>
                                    <TableHead>Usuário</TableHead>
                                    <TableHead>Empresa</TableHead>
                                    <TableHead>Papel</TableHead>
                                    <TableHead>Status</TableHead>
                                    <TableHead className="hidden md:table-cell">Data Criação</TableHead>
                                    <TableHead className="text-right">Ações</TableHead>
                                </TableRow>
                            </TableHeader>
                            <TableBody>
                                {loading ? (
                                    <TableRow>
                                        <TableCell colSpan={6} className="text-center py-10">
                                            <Loader2 className="h-8 w-8 animate-spin mx-auto text-primary" />
                                            <span className="text-sm text-muted-foreground mt-2 block">Carregando vínculos...</span>
                                        </TableCell>
                                    </TableRow>
                                ) : filteredVinculos.length === 0 ? (
                                    <TableRow>
                                        <TableCell colSpan={6} className="text-center py-10 text-muted-foreground">
                                            Nenhum vínculo encontrado com os filtros atuais.
                                        </TableCell>
                                    </TableRow>
                                ) : (
                                    filteredVinculos.map((vinculo) => (
                                        <TableRow key={vinculo.id}>
                                            <TableCell>
                                                <div className="flex flex-col">
                                                    <span className="font-medium text-sm">{vinculo.users?.nome || 'Sem nome'}</span>
                                                    <span className="text-xs text-muted-foreground">{vinculo.users?.email}</span>
                                                </div>
                                            </TableCell>
                                            <TableCell>
                                                <div className="flex items-center gap-2">
                                                    <Building2 className="w-4 h-4 text-muted-foreground" />
                                                    <span className="text-sm">{vinculo.companies?.nome}</span>
                                                </div>
                                            </TableCell>
                                            <TableCell>
                                                <Badge variant="outline" className="capitalize">
                                                    {vinculo.papel}
                                                </Badge>
                                            </TableCell>
                                            <TableCell>
                                                 <Badge className={
                                                    (vinculo.status || 'ativo') === 'ativo' 
                                                        ? 'bg-green-100 text-green-800 hover:bg-green-100 border-green-200' 
                                                        : 'bg-red-100 text-red-800 hover:bg-red-100 border-red-200'
                                                }>
                                                    {vinculo.status || 'ativo'}
                                                </Badge>
                                            </TableCell>
                                            <TableCell className="hidden md:table-cell text-muted-foreground text-sm">
                                                {new Date(vinculo.created_at).toLocaleDateString('pt-BR')}
                                            </TableCell>
                                            <TableCell className="text-right">
                                                <DropdownMenu>
                                                    <DropdownMenuTrigger asChild>
                                                        <Button variant="ghost" className="h-8 w-8 p-0">
                                                            <span className="sr-only">Menu</span>
                                                            <MoreVertical className="h-4 w-4" />
                                                        </Button>
                                                    </DropdownMenuTrigger>
                                                    <DropdownMenuContent align="end">
                                                        <DropdownMenuLabel>Ações</DropdownMenuLabel>
                                                        <DropdownMenuItem onClick={() => openEditModal(vinculo)}>
                                                            <Edit className="mr-2 h-4 w-4" /> Editar
                                                        </DropdownMenuItem>
                                                        <DropdownMenuSeparator />
                                                        <DropdownMenuItem className="text-red-600" onClick={() => openDeleteModal(vinculo)}>
                                                            <Trash2 className="mr-2 h-4 w-4" /> Excluir
                                                        </DropdownMenuItem>
                                                    </DropdownMenuContent>
                                                </DropdownMenu>
                                            </TableCell>
                                        </TableRow>
                                    ))
                                )}
                            </TableBody>
                        </Table>
                    </div>
                </CardContent>
            </Card>

            {/* --- CREATE MODAL --- */}
            <Dialog open={isCreateOpen} onOpenChange={setIsCreateOpen}>
                <DialogContent className="sm:max-w-[500px]">
                    <DialogHeader>
                        <DialogTitle>Novo Vínculo</DialogTitle>
                        <DialogDescription>Associe um usuário a uma empresa e defina suas permissões.</DialogDescription>
                    </DialogHeader>
                    <div className="grid gap-4 py-4">
                        <div className="space-y-2">
                            <Label htmlFor="user">Usuário</Label>
                            <Select 
                                value={formData.user_id} 
                                onValueChange={(v) => setFormData({...formData, user_id: v})}
                            >
                                <SelectTrigger id="user">
                                    <SelectValue placeholder="Selecione um usuário" />
                                </SelectTrigger>
                                <SelectContent className="max-h-[200px]">
                                    {users.map(u => (
                                        <SelectItem key={u.id} value={u.id}>
                                            {u.nome} ({u.email})
                                        </SelectItem>
                                    ))}
                                </SelectContent>
                            </Select>
                        </div>
                        
                        <div className="space-y-2">
                            <Label htmlFor="company">Empresa</Label>
                            <Select 
                                value={formData.company_id} 
                                onValueChange={(v) => setFormData({...formData, company_id: v})}
                            >
                                <SelectTrigger id="company">
                                    <SelectValue placeholder="Selecione uma empresa" />
                                </SelectTrigger>
                                <SelectContent className="max-h-[200px]">
                                    {companies.map(c => (
                                        <SelectItem key={c.id} value={c.id}>{c.nome}</SelectItem>
                                    ))}
                                </SelectContent>
                            </Select>
                        </div>

                        <div className="grid grid-cols-2 gap-4">
                            <div className="space-y-2">
                                <Label htmlFor="role">Papel</Label>
                                <Select 
                                    value={formData.papel} 
                                    onValueChange={(v) => setFormData({...formData, papel: v})}
                                >
                                    <SelectTrigger id="role">
                                        <SelectValue placeholder="Selecione" />
                                    </SelectTrigger>
                                    <SelectContent>
                                        <SelectItem value="proprietario">Proprietário</SelectItem>
                                        <SelectItem value="funcionario">Funcionário</SelectItem>
                                        <SelectItem value="socio">Sócio</SelectItem>
                                        <SelectItem value="contador">Contador</SelectItem>
                                    </SelectContent>
                                </Select>
                            </div>
                            <div className="space-y-2">
                                <Label htmlFor="status">Status</Label>
                                <Select 
                                    value={formData.status} 
                                    onValueChange={(v) => setFormData({...formData, status: v})}
                                >
                                    <SelectTrigger id="status">
                                        <SelectValue placeholder="Selecione" />
                                    </SelectTrigger>
                                    <SelectContent>
                                        <SelectItem value="ativo">Ativo</SelectItem>
                                        <SelectItem value="inativo">Inativo</SelectItem>
                                    </SelectContent>
                                </Select>
                            </div>
                        </div>
                    </div>
                    <DialogFooter>
                        <Button variant="outline" onClick={() => setIsCreateOpen(false)}>Cancelar</Button>
                        <Button onClick={handleCreate} disabled={isSubmitting}>
                            {isSubmitting ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : null}
                            Criar Vínculo
                        </Button>
                    </DialogFooter>
                </DialogContent>
            </Dialog>

            {/* --- EDIT MODAL --- */}
            <Dialog open={isEditOpen} onOpenChange={setIsEditOpen}>
                <DialogContent className="sm:max-w-[500px]">
                    <DialogHeader>
                        <DialogTitle>Editar Vínculo</DialogTitle>
                        <DialogDescription>Alterar permissões ou status do vínculo.</DialogDescription>
                    </DialogHeader>
                    <div className="grid gap-4 py-4">
                        <div className="space-y-2">
                            <Label>Usuário (Leitura)</Label>
                            <Input value={selectedVinculo?.users?.email || ''} disabled className="bg-slate-50" />
                        </div>
                        <div className="space-y-2">
                            <Label>Empresa (Leitura)</Label>
                            <Input value={selectedVinculo?.companies?.nome || ''} disabled className="bg-slate-50" />
                        </div>
                        
                        <div className="grid grid-cols-2 gap-4">
                            <div className="space-y-2">
                                <Label htmlFor="edit-role">Papel</Label>
                                <Select 
                                    value={formData.papel} 
                                    onValueChange={(v) => setFormData({...formData, papel: v})}
                                >
                                    <SelectTrigger id="edit-role">
                                        <SelectValue placeholder="Selecione" />
                                    </SelectTrigger>
                                    <SelectContent>
                                        <SelectItem value="proprietario">Proprietário</SelectItem>
                                        <SelectItem value="funcionario">Funcionário</SelectItem>
                                        <SelectItem value="socio">Sócio</SelectItem>
                                        <SelectItem value="contador">Contador</SelectItem>
                                    </SelectContent>
                                </Select>
                            </div>
                            <div className="space-y-2">
                                <Label htmlFor="edit-status">Status</Label>
                                <Select 
                                    value={formData.status} 
                                    onValueChange={(v) => setFormData({...formData, status: v})}
                                >
                                    <SelectTrigger id="edit-status">
                                        <SelectValue placeholder="Selecione" />
                                    </SelectTrigger>
                                    <SelectContent>
                                        <SelectItem value="ativo">Ativo</SelectItem>
                                        <SelectItem value="inativo">Inativo</SelectItem>
                                    </SelectContent>
                                </Select>
                            </div>
                        </div>
                    </div>
                    <DialogFooter>
                        <Button variant="outline" onClick={() => setIsEditOpen(false)}>Cancelar</Button>
                        <Button onClick={handleUpdate} disabled={isSubmitting}>
                            {isSubmitting ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : null}
                            Salvar Alterações
                        </Button>
                    </DialogFooter>
                </DialogContent>
            </Dialog>

             {/* --- DELETE MODAL --- */}
             <Dialog open={isDeleteOpen} onOpenChange={setIsDeleteOpen}>
                <DialogContent>
                    <DialogHeader>
                        <DialogTitle className="text-red-600 flex items-center gap-2">
                            <Trash2 className="w-5 h-5" /> Remover Vínculo
                        </DialogTitle>
                        <DialogDescription>
                            Tem certeza que deseja remover o acesso deste usuário a esta empresa?
                        </DialogDescription>
                    </DialogHeader>
                    
                    {selectedVinculo && (
                        <div className="py-4 bg-slate-50 rounded-lg p-4 border border-slate-100">
                            <div className="flex flex-col gap-1">
                                <span className="text-sm font-medium text-slate-500">Usuário:</span>
                                <span className="text-slate-900">{selectedVinculo.users?.nome} ({selectedVinculo.users?.email})</span>
                            </div>
                            <div className="flex flex-col gap-1 mt-3">
                                <span className="text-sm font-medium text-slate-500">Empresa:</span>
                                <span className="text-slate-900">{selectedVinculo.companies?.nome}</span>
                            </div>
                        </div>
                    )}

                    <DialogFooter>
                        <Button variant="outline" onClick={() => setIsDeleteOpen(false)}>Cancelar</Button>
                        <Button variant="destructive" onClick={handleDelete} disabled={isSubmitting}>
                            {isSubmitting ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : null}
                            Remover Vínculo
                        </Button>
                    </DialogFooter>
                </DialogContent>
            </Dialog>
        </div>
    );
};

export default AdminVinculosPage;
