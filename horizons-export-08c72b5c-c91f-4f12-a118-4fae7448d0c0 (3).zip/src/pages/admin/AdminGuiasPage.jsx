import React from 'react';
import { Helmet } from 'react-helmet';
import { useToast } from '@/components/ui/use-toast';

const AdminGuiasPage = () => {
    const { toast } = useToast();

    return (
        <>
             <Helmet>
                <title>Admin - Guias</title>
            </Helmet>
            <div className="p-8 text-center">
                <h1 className="text-2xl font-bold text-gray-800 mb-4">Gerenciamento de Guias (Admin)</h1>
                <p className="text-gray-500">Funcionalidade de emissão e upload de guias em desenvolvimento.</p>
            </div>
        </>
    )
}
export default AdminGuiasPage;