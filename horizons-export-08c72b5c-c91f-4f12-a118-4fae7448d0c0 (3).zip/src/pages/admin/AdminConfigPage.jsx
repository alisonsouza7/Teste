import React from 'react';
import { Helmet } from 'react-helmet';
import { useToast } from '@/components/ui/use-toast';

const AdminConfigPage = () => {
    const { toast } = useToast();

    return (
        <>
             <Helmet>
                <title>Admin - Configurações</title>
            </Helmet>
            <div className="p-8 text-center">
                <h1 className="text-2xl font-bold text-gray-800 mb-4">Configurações do Sistema</h1>
                <p className="text-gray-500">Definições de alertas RBT12 e templates de mensagens em desenvolvimento.</p>
            </div>
        </>
    )
}
export default AdminConfigPage;