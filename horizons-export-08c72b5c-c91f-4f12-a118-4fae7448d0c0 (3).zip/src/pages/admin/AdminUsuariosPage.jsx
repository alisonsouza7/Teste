import React, { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet';
import { supabase } from '@/lib/customSupabaseClient';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from '@/components/ui/dialog';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/components/ui/use-toast';
import { 
    CheckCircle, 
    Building2, 
    Search,
    Loader2,
    Plus,
    Copy,
    AlertTriangle,
    UserPlus,
    Edit,
    Trash2,
    AlertOctagon
} from 'lucide-react';

const AdminUsuariosPage = () => {
    const { toast } = useToast();
    
    // Data State
    const [users, setUsers] = useState([]);
    const [loading, setLoading] = useState(true);
    const [searchTerm, setSearchTerm] = useState('');

    // Create Modal State
    const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
    const [createForm, setCreateForm] = useState({
        nome: '',
        email: '',
        tipo: 'cliente',
        status: 'ativo'
    });
    const [isCreating, setIsCreating] = useState(false);
    const [createdUserCreds, setCreatedUserCreds] = useState(null); // { email, password }

    // Edit Modal State
    const [isEditModalOpen, setIsEditModalOpen] = useState(false);
    const [editForm, setEditForm] = useState({
        id: '',
        nome: '',
        email: '',
        tipo: 'cliente',
        status: 'ativo'
    });
    const [isUpdating, setIsUpdating] = useState(false);

    // Delete User State
    const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
    const [userToDelete, setUserToDelete] = useState(null);
    const [isDeleting, setIsDeleting] = useState(false);

    useEffect(() => {
        fetchUsers();
    }, []);

    const fetchUsers = async () => {
        setLoading(true);
        try {
            // Fetch users and their links
            const { data, error } = await supabase
                .from('users')
                .select(`
                    *,
                    user_company_roles (
                        id,
                        papel,
                        companies (
                            id,
                            nome
                        )
                    )
                `)
                .order('created_at', { ascending: false });

            if (error) throw error;
            setUsers(data);
        } catch (error) {
            console.error(error);
            toast({ variant: "destructive", title: "Erro", description: "Falha ao carregar usuários." });
        } finally {
            setLoading(false);
        }
    };

    // --- HELPER FUNCTIONS ---
    
    const generateTemporaryPassword = () => {
        const chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*";
        let password = "";
        for (let i = 0; i < 12; i++) {
            password += chars.charAt(Math.floor(Math.random() * chars.length));
        }
        return password;
    };

    const copyToClipboard = (text) => {
        navigator.clipboard.writeText(text);
        toast({ title: "Copiado!", description: "Copiado para a área de transferência." });
    };

    const openEditModal = (user) => {
        setEditForm({
            id: user.id,
            nome: user.nome || '',
            email: user.email || '',
            tipo: user.tipo || 'cliente',
            status: user.status || 'ativo'
        });
        setIsEditModalOpen(true);
    };

    const openDeleteModal = (user) => {
        setUserToDelete(user);
        setIsDeleteModalOpen(true);
    };

    // --- UNIFIED CREATE USER FLOW ---

    const handleCreateClick = () => {
        setCreateForm({
            nome: '',
            email: '',
            tipo: 'cliente',
            status: 'ativo'
        });
        setCreatedUserCreds(null);
        setIsCreateModalOpen(true);
    };

    const handleCreateUser = async () => {
        if (!createForm.email || !createForm.nome) {
            toast({ variant: "destructive", title: "Campos obrigatórios", description: "Preencha nome e email." });
            return;
        }

        setIsCreating(true);
        try {
            // 1. Generate Password
            const tempPassword = generateTemporaryPassword();

            // 2. Call Edge Function to create user in Auth
            // This handles Identity creation and sets email_confirm=true
            const { data, error } = await supabase.functions.invoke('create-user', {
                body: JSON.stringify({
                    email: createForm.email,
                    password: tempPassword,
                    nome: createForm.nome,
                    tipo: createForm.tipo,
                    status: createForm.status
                })
            });

            if (error) throw error;
            if (data.error) throw new Error(data.error);

            // 3. Show Success with Credentials
            setCreatedUserCreds({
                email: createForm.email,
                password: tempPassword,
                nome: createForm.nome
            });
            
            toast({ title: "Sucesso", description: "Usuário criado com sucesso." });
            fetchUsers(); // Refresh list

        } catch (error) {
            console.error('Error creating user:', error);
            let msg = "Falha ao criar usuário.";
            if (error.message?.includes("already registered")) {
                msg = "Este email já está cadastrado.";
            }
            toast({ variant: "destructive", title: "Erro", description: msg });
        } finally {
            setIsCreating(false);
        }
    };

    // --- UNIFIED EDIT USER FLOW ---

    const handleUpdateUser = async () => {
        if (!editForm.nome) {
            toast({ variant: "destructive", title: "Campos obrigatórios", description: "Preencha o nome." });
            return;
        }

        setIsUpdating(true);
        try {
            // 1. Update Auth User (Metadata only, since email is read-only)
            // Using Edge Function to ensure we have permission to update user data
            const { data: authData, error: authError } = await supabase.functions.invoke('update-user', {
                body: JSON.stringify({
                    id: editForm.id,
                    user_metadata: { nome: editForm.nome },
                    app_metadata: { role: editForm.tipo, status: editForm.status }
                })
            });

            if (authError) throw authError;
            if (authData.error) throw new Error(authData.error);

            // 2. Update Public User (for immediate UI consistency)
            const { error: publicError } = await supabase
                .from('users')
                .update({
                    nome: editForm.nome,
                    tipo: editForm.tipo,
                    status: editForm.status
                })
                .eq('id', editForm.id);

            if (publicError) throw publicError;

            toast({ title: "Sucesso", description: "Dados do usuário atualizados." });
            setIsEditModalOpen(false);
            fetchUsers();

        } catch (error) {
            console.error('Error updating user:', error);
            toast({ variant: "destructive", title: "Erro", description: "Falha ao atualizar usuário: " + error.message });
        } finally {
            setIsUpdating(false);
        }
    };

    // --- DELETE USER FLOW ---

    const handleDeleteUser = async () => {
        if (!userToDelete) return;

        setIsDeleting(true);
        try {
            // Call Edge Function to delete user completely (Auth + Public + Links)
            const { data, error } = await supabase.functions.invoke('delete-user', {
                body: JSON.stringify({ id: userToDelete.id })
            });

            if (error) throw error;
            if (data.error) throw new Error(data.error);

            toast({ title: "Usuário Deletado", description: "O usuário e seus vínculos foram removidos." });
            
            setIsDeleteModalOpen(false);
            setUserToDelete(null);
            fetchUsers();

        } catch (error) {
            console.error('Error deleting user:', error);
            toast({ variant: "destructive", title: "Erro", description: "Falha ao deletar usuário: " + error.message });
        } finally {
            setIsDeleting(false);
        }
    };

    // --- FILTERS ---

    const filteredUsers = users.filter(user => 
        user.nome?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        user.email?.toLowerCase().includes(searchTerm.toLowerCase())
    );

    return (
        <>
            <Helmet>
                <title>Admin - Gerenciar Usuários</title>
            </Helmet>
            <div className="space-y-6">
                <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
                    <div>
                        <h1 className="text-3xl font-bold text-slate-900">Gerenciar Usuários</h1>
                        <p className="text-muted-foreground">Visualize e gerencie todos os usuários da plataforma.</p>
                    </div>
                    <Button onClick={handleCreateClick} className="bg-blue-600 hover:bg-blue-700">
                        <UserPlus className="w-4 h-4 mr-2" /> Novo Usuário
                    </Button>
                </div>

                <Card>
                    <CardHeader className="pb-3">
                        <div className="flex items-center justify-between">
                            <CardTitle>Usuários Cadastrados</CardTitle>
                            <div className="relative w-64">
                                <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
                                <Input 
                                    placeholder="Buscar por nome ou email..." 
                                    className="pl-8" 
                                    value={searchTerm}
                                    onChange={(e) => setSearchTerm(e.target.value)}
                                />
                            </div>
                        </div>
                    </CardHeader>
                    <CardContent className="p-0">
                        <Table>
                            <TableHeader>
                                <TableRow>
                                    <TableHead>Usuário</TableHead>
                                    <TableHead>Tipo</TableHead>
                                    <TableHead>Status</TableHead>
                                    <TableHead>Empresas Vinculadas</TableHead>
                                    <TableHead>Data Cadastro</TableHead>
                                    <TableHead className="text-right">Ações</TableHead>
                                </TableRow>
                            </TableHeader>
                            <TableBody>
                                {loading ? (
                                    <TableRow><TableCell colSpan={6} className="text-center py-8"><Loader2 className="h-6 w-6 animate-spin mx-auto" /></TableCell></TableRow>
                                ) : filteredUsers.length === 0 ? (
                                    <TableRow><TableCell colSpan={6} className="text-center py-8">Nenhum usuário encontrado.</TableCell></TableRow>
                                ) : (
                                    filteredUsers.map(user => (
                                        <TableRow key={user.id}>
                                            <TableCell>
                                                <div className="flex flex-col">
                                                    <span className="font-medium">{user.nome || 'Sem nome'}</span>
                                                    <span className="text-xs text-muted-foreground">{user.email}</span>
                                                </div>
                                            </TableCell>
                                            <TableCell>
                                                <Badge variant={user.tipo === 'admin' ? 'default' : user.tipo === 'contador' ? 'secondary' : 'outline'}>
                                                    {user.tipo}
                                                </Badge>
                                            </TableCell>
                                            <TableCell>
                                                <Badge className={
                                                    user.status === 'ativo' ? 'bg-green-100 text-green-800 hover:bg-green-100 border-green-200' : 
                                                    'bg-red-100 text-red-800 hover:bg-red-100 border-red-200'
                                                }>
                                                    {user.status}
                                                </Badge>
                                            </TableCell>
                                            <TableCell>
                                                <div className="flex flex-col gap-1">
                                                    {user.user_company_roles && user.user_company_roles.length > 0 ? (
                                                        <>
                                                            {user.user_company_roles.slice(0, 2).map(role => (
                                                                <span key={role.id} className="text-xs bg-slate-100 px-2 py-0.5 rounded flex items-center w-fit">
                                                                    <Building2 className="w-3 h-3 mr-1 text-slate-500" />
                                                                    {role.companies?.nome || 'Empresa'}
                                                                </span>
                                                            ))}
                                                            {user.user_company_roles.length > 2 && (
                                                                <span className="text-xs text-muted-foreground pl-1">+ {user.user_company_roles.length - 2} outras</span>
                                                            )}
                                                        </>
                                                    ) : (
                                                        <span className="text-xs text-muted-foreground italic">Sem vínculos</span>
                                                    )}
                                                </div>
                                            </TableCell>
                                            <TableCell className="text-muted-foreground text-sm">
                                                {new Date(user.created_at).toLocaleDateString('pt-BR')}
                                            </TableCell>
                                            <TableCell className="text-right">
                                                <div className="flex justify-end gap-2">
                                                    <Button 
                                                        variant="ghost" 
                                                        size="icon" 
                                                        className="h-8 w-8"
                                                        onClick={() => openEditModal(user)}
                                                    >
                                                        <Edit className="w-4 h-4" />
                                                    </Button>
                                                    <Button 
                                                        variant="ghost" 
                                                        size="icon" 
                                                        className="h-8 w-8 text-red-600 hover:text-red-700 hover:bg-red-50"
                                                        onClick={() => openDeleteModal(user)}
                                                    >
                                                        <Trash2 className="w-4 h-4" />
                                                    </Button>
                                                </div>
                                            </TableCell>
                                        </TableRow>
                                    ))
                                )}
                            </TableBody>
                        </Table>
                    </CardContent>
                </Card>

                {/* CREATE USER MODAL */}
                <Dialog open={isCreateModalOpen} onOpenChange={(open) => !createdUserCreds && setIsCreateModalOpen(open)}>
                    <DialogContent className="sm:max-w-[500px]">
                        <DialogHeader>
                            <DialogTitle>Novo Usuário</DialogTitle>
                            <DialogDescription>
                                {createdUserCreds 
                                    ? "Usuário criado com sucesso! Copie as credenciais abaixo."
                                    : "Preencha os dados para criar um novo usuário no sistema."
                                }
                            </DialogDescription>
                        </DialogHeader>

                        {!createdUserCreds ? (
                            <div className="space-y-4 py-4">
                                <div className="space-y-2">
                                    <Label htmlFor="new-nome">Nome Completo</Label>
                                    <Input 
                                        id="new-nome"
                                        value={createForm.nome} 
                                        onChange={(e) => setCreateForm({...createForm, nome: e.target.value})}
                                        placeholder="João da Silva"
                                    />
                                </div>
                                <div className="space-y-2">
                                    <Label htmlFor="new-email">Email</Label>
                                    <Input 
                                        id="new-email"
                                        type="email"
                                        value={createForm.email} 
                                        onChange={(e) => setCreateForm({...createForm, email: e.target.value})}
                                        placeholder="joao@exemplo.com"
                                    />
                                </div>
                                <div className="grid grid-cols-2 gap-4">
                                    <div className="space-y-2">
                                        <Label htmlFor="new-tipo">Tipo</Label>
                                        <Select 
                                            value={createForm.tipo} 
                                            onValueChange={(v) => setCreateForm({...createForm, tipo: v})}
                                        >
                                            <SelectTrigger id="new-tipo">
                                                <SelectValue />
                                            </SelectTrigger>
                                            <SelectContent>
                                                <SelectItem value="cliente">Cliente</SelectItem>
                                                <SelectItem value="contador">Contador</SelectItem>
                                                <SelectItem value="admin">Admin</SelectItem>
                                            </SelectContent>
                                        </Select>
                                    </div>
                                    <div className="space-y-2">
                                        <Label htmlFor="new-status">Status</Label>
                                        <Select 
                                            value={createForm.status} 
                                            onValueChange={(v) => setCreateForm({...createForm, status: v})}
                                        >
                                            <SelectTrigger id="new-status">
                                                <SelectValue />
                                            </SelectTrigger>
                                            <SelectContent>
                                                <SelectItem value="ativo">Ativo</SelectItem>
                                                <SelectItem value="inativo">Inativo</SelectItem>
                                            </SelectContent>
                                        </Select>
                                    </div>
                                </div>
                                <div className="bg-blue-50 p-3 rounded border border-blue-100 text-xs text-blue-800">
                                    <strong>Nota:</strong> Este usuário será criado sem vínculos. Para associá-lo a uma empresa, acesse a página de <strong>Vínculos</strong>.
                                </div>
                            </div>
                        ) : (
                            <div className="py-6 space-y-6">
                                <div className="bg-green-50 border border-green-200 rounded-lg p-4 text-center">
                                    <CheckCircle className="w-12 h-12 text-green-500 mx-auto mb-2" />
                                    <h3 className="text-lg font-medium text-green-900">Conta Criada!</h3>
                                    <p className="text-green-700">A conta foi ativada e está pronta para uso.</p>
                                </div>

                                <div className="space-y-4">
                                    <div className="space-y-2">
                                        <Label className="text-muted-foreground">Email de acesso</Label>
                                        <div className="flex gap-2">
                                            <Input value={createdUserCreds.email} readOnly className="font-mono bg-slate-50" />
                                            <Button variant="outline" size="icon" onClick={() => copyToClipboard(createdUserCreds.email)}>
                                                <Copy className="w-4 h-4" />
                                            </Button>
                                        </div>
                                    </div>
                                    <div className="space-y-2">
                                        <Label className="text-muted-foreground">Senha Temporária</Label>
                                        <div className="flex gap-2">
                                            <Input value={createdUserCreds.password} readOnly className="font-mono bg-slate-50 text-lg font-bold tracking-wide" />
                                            <Button variant="outline" size="icon" onClick={() => copyToClipboard(createdUserCreds.password)}>
                                                <Copy className="w-4 h-4" />
                                            </Button>
                                        </div>
                                        <p className="text-xs text-yellow-600 mt-2 bg-yellow-50 p-2 rounded border border-yellow-100 flex items-start gap-2">
                                            <AlertTriangle className="w-3 h-3 mt-0.5" />
                                            Copie esta senha agora! Ela não será mostrada novamente.
                                        </p>
                                    </div>
                                </div>
                            </div>
                        )}

                        <DialogFooter>
                            {!createdUserCreds ? (
                                <>
                                    <Button variant="outline" onClick={() => setIsCreateModalOpen(false)}>Cancelar</Button>
                                    <Button onClick={handleCreateUser} disabled={isCreating}>
                                        {isCreating ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : <Plus className="w-4 h-4 mr-2" />}
                                        Criar Usuário
                                    </Button>
                                </>
                            ) : (
                                <Button className="w-full" onClick={() => {
                                    setIsCreateModalOpen(false);
                                    setCreatedUserCreds(null);
                                }}>
                                    Concluir
                                </Button>
                            )}
                        </DialogFooter>
                    </DialogContent>
                </Dialog>

                 {/* EDIT USER MODAL */}
                 <Dialog open={isEditModalOpen} onOpenChange={setIsEditModalOpen}>
                    <DialogContent className="sm:max-w-[500px]">
                        <DialogHeader>
                            <DialogTitle>Editar Usuário</DialogTitle>
                            <DialogDescription>
                                Atualize os dados e permissões do usuário.
                            </DialogDescription>
                        </DialogHeader>

                        <div className="space-y-4 py-4">
                            <div className="space-y-2">
                                <Label htmlFor="edit-email">Email (Não editável)</Label>
                                <Input 
                                    id="edit-email"
                                    value={editForm.email}
                                    disabled
                                    className="bg-slate-100 text-slate-500"
                                />
                            </div>
                            <div className="space-y-2">
                                <Label htmlFor="edit-nome">Nome Completo</Label>
                                <Input 
                                    id="edit-nome"
                                    value={editForm.nome} 
                                    onChange={(e) => setEditForm({...editForm, nome: e.target.value})}
                                />
                            </div>
                            <div className="grid grid-cols-2 gap-4">
                                <div className="space-y-2">
                                    <Label htmlFor="edit-tipo">Tipo</Label>
                                    <Select 
                                        value={editForm.tipo} 
                                        onValueChange={(v) => setEditForm({...editForm, tipo: v})}
                                    >
                                        <SelectTrigger id="edit-tipo">
                                            <SelectValue />
                                        </SelectTrigger>
                                        <SelectContent>
                                            <SelectItem value="cliente">Cliente</SelectItem>
                                            <SelectItem value="contador">Contador</SelectItem>
                                            <SelectItem value="admin">Admin</SelectItem>
                                        </SelectContent>
                                    </Select>
                                </div>
                                <div className="space-y-2">
                                    <Label htmlFor="edit-status">Status</Label>
                                    <Select 
                                        value={editForm.status} 
                                        onValueChange={(v) => setEditForm({...editForm, status: v})}
                                    >
                                        <SelectTrigger id="edit-status">
                                            <SelectValue />
                                        </SelectTrigger>
                                        <SelectContent>
                                            <SelectItem value="ativo">Ativo</SelectItem>
                                            <SelectItem value="inativo">Inativo</SelectItem>
                                        </SelectContent>
                                    </Select>
                                </div>
                            </div>
                        </div>

                        <DialogFooter>
                            <Button variant="outline" onClick={() => setIsEditModalOpen(false)}>Cancelar</Button>
                            <Button onClick={handleUpdateUser} disabled={isUpdating}>
                                {isUpdating ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : null}
                                Salvar Alterações
                            </Button>
                        </DialogFooter>
                    </DialogContent>
                </Dialog>

                {/* DELETE USER MODAL */}
                <Dialog open={isDeleteModalOpen} onOpenChange={setIsDeleteModalOpen}>
                    <DialogContent className="sm:max-w-[500px]">
                        <DialogHeader>
                            <DialogTitle className="flex items-center gap-2 text-red-600">
                                <AlertOctagon className="h-6 w-6" />
                                Deletar Usuário
                            </DialogTitle>
                            <DialogDescription>
                                Esta ação é irreversível e removerá permanentemente o acesso.
                            </DialogDescription>
                        </DialogHeader>

                        <div className="py-4 space-y-4">
                            <div className="bg-red-50 border border-red-200 rounded-md p-4 text-red-900 text-sm space-y-2">
                                <p className="font-bold">Você está deletando: {userToDelete?.email}</p>
                                <ul className="list-disc pl-5 space-y-1">
                                    <li>Todos os dados pessoais serão apagados.</li>
                                    <li>Todas as identidades de login serão removidas.</li>
                                    {userToDelete?.user_company_roles?.length > 0 && (
                                        <li>
                                            O usuário será desvinculado de <strong>{userToDelete.user_company_roles.length}</strong> empresa(s).
                                        </li>
                                    )}
                                </ul>
                            </div>
                        </div>

                        <DialogFooter>
                            <Button variant="outline" onClick={() => setIsDeleteModalOpen(false)}>Cancelar</Button>
                            <Button variant="destructive" onClick={handleDeleteUser} disabled={isDeleting}>
                                {isDeleting ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : <Trash2 className="w-4 h-4 mr-2" />}
                                Confirmar Exclusão
                            </Button>
                        </DialogFooter>
                    </DialogContent>
                </Dialog>
            </div>
        </>
    );
};

export default AdminUsuariosPage;