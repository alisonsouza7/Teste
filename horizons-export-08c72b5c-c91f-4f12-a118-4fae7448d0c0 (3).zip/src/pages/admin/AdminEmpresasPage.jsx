
import React, { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet';
import { supabase } from '@/lib/customSupabaseClient';
import { useToast } from '@/components/ui/use-toast';
import { Card, CardContent } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from '@/components/ui/dialog';
import{ Badge } from '@/components/ui/badge';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import {
    Building2,
    Search,
    Plus,
    Edit,
    Loader2,
    UserPlus,
    CheckCircle,
    Trash2
} from 'lucide-react';
import RegimeSelector from '@/components/finance/RegimeSelector';

const AdminEmpresasPage = () => {
    const { toast } = useToast();
    const { user, userRole } = useAuth(); // Assuming userRole is available in context

    // Data State
    const [companies, setCompanies] = useState([]);
    const [loading, setLoading] = useState(true);
    const [searchTerm, setSearchTerm] = useState('');
    const [activeTab, setActiveTab] = useState('active');

    // Create Company State
    const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
    const [createForm, setCreateForm] = useState({
        nome: '',
        cnpj_cpf: '',
        telefone: '',
        tipo_pessoa: 'PJ',
        regime_tributario: 'simples_nacional',
        cidade: '',
        estado: '',
        nivel_financeiro: 'A'
    });
    const [isCreating, setIsCreating] = useState(false);

    // Edit Company State
    const [isEditModalOpen, setIsEditModalOpen] = useState(false);
    const [editForm, setEditForm] = useState({
        id: '',
        nome: '',
        cnpj_cpf: '',
        telefone: '',
        tipo_pessoa: 'PJ',
        regime_tributario: 'simples_nacional',
        cidade: '',
        estado: '',
        nivel_financeiro: 'A'
    });
    const [isUpdating, setIsUpdating] = useState(false);

    // Delete Company State
    const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
    const [companyToDelete, setCompanyToDelete] = useState(null);
    const [isDeleting, setIsDeleting] = useState(false);

    // Approval State
    const [isApproveModalOpen, setIsApproveModalOpen] = useState(false);
    const [companyToApprove, setCompanyToApprove] = useState(null);

    // Backfill State
    const [isBackfillModalOpen, setIsBackfillModalOpen] = useState(false);
    const [orphanCompanies, setOrphanCompanies] = useState([]);

    useEffect(() => {
        fetchCompanies();

        // Real-time synchronization for finance level changes
        const channel = supabase
            .channel('admin-companies-changes')
            .on(
                'postgres_changes',
                { event: '*', schema: 'public', table: 'finance_level_changes' },
                (payload) => {
                    console.log('Real-time update received from finance_level_changes:', payload);
                    fetchCompanies();
                }
            )
            .on(
                'postgres_changes',
                { event: '*', schema: 'public', table: 'companies' },
                (payload) => {
                     console.log('Real-time update received from companies:', payload);
                     fetchCompanies();
                }
            )
            .subscribe();

        return () => {
            supabase.removeChannel(channel);
        };
    }, []);

    const fetchCompanies = async () => {
        setLoading(true);
        try {
            // Query fetching finance_level_changes as requested
            const { data, error } = await supabase
                .from('companies')
                .select(`
                    *,
                    user_company_roles (
                        id,
                        papel,
                        users (
                            id,
                            email,
                            nome
                        )
                    ),
                    finance_config (
                        nivel_financeiro
                    ),
                    finance_level_changes (
                        nivel_novo,
                        mudado_em
                    ),
                    tax_regimes (
                        nome_exibicao
                    )
                `)
                .order('created_at', { ascending: false });

            if (error) throw error;
            
            setCompanies(data || []);

            const orphans = (data || []).filter(c => !c.user_company_roles || c.user_company_roles.length === 0);
            setOrphanCompanies(orphans);

        } catch (error) {
            console.error(error);
            toast({ variant: "destructive", title: "Erro", description: "Falha ao carregar empresas." });
        } finally {
            setLoading(false);
        }
    };

    const getFinanceLevelFromRelation = (obj) => {
        if (!obj) return 'A';

        // Priority 1: Check history (finance_level_changes) for the latest change
        if (obj.finance_level_changes && Array.isArray(obj.finance_level_changes) && obj.finance_level_changes.length > 0) {
            // Sort by changed date descending to get the latest
            const sortedChanges = [...obj.finance_level_changes].sort((a, b) => new Date(b.mudado_em) - new Date(a.mudado_em));
            const latest = sortedChanges[0];
            if (latest && latest.nivel_novo) {
                return latest.nivel_novo;
            }
        }

        // Priority 2: Fallback to finance_config (current state)
        if (Array.isArray(obj.finance_config)) {
            return obj.finance_config?.[0]?.nivel_financeiro || 'A';
        }
        if (obj.finance_config && typeof obj.finance_config === 'object') {
            return obj.finance_config.nivel_financeiro || 'A';
        }
        
        // Default
        return 'A';
    };
    
    const getRegimeName = (company) => {
        // Handle array or object return from Supabase
        const regimeInfo = Array.isArray(company.tax_regimes) ? company.tax_regimes[0] : company.tax_regimes;
        return regimeInfo?.nome_exibicao || company.regime_tributario;
    };

    const openEditModal = (company) => {
        const level = getFinanceLevelFromRelation(company);
        let normalizedTipo = company.tipo_pessoa || 'PJ';
        if (normalizedTipo.toLowerCase().includes('jur') || normalizedTipo.toLowerCase() === 'pj') normalizedTipo = 'PJ';
        else normalizedTipo = 'PF';

        setEditForm({
            id: company.id,
            nome: company.nome || '',
            cnpj_cpf: company.cnpj_cpf || '',
            telefone: company.telefone || '',
            tipo_pessoa: normalizedTipo,
            regime_tributario: company.regime_tributario || 'simples_nacional',
            cidade: company.cidade || '',
            estado: company.estado || '',
            nivel_financeiro: level
        });
        setIsEditModalOpen(true);
    };

    const openDeleteModal = (company) => {
        setCompanyToDelete(company);
        setIsDeleteModalOpen(true);
    };

    const handleCreateCompany = async () => {
        if (!createForm.nome || !createForm.cnpj_cpf) {
            toast({ variant: "destructive", title: "Campos obrigatórios", description: "Preencha Nome e CNPJ/CPF." });
            return;
        }

        setIsCreating(true);

        try {
            const tipoCliente = createForm.tipo_pessoa === 'PF' ? 'pf' : 'pj';

            const { data: companyData, error: companyError } = await supabase
                .from('companies')
                .insert([{
                    nome: createForm.nome,
                    cnpj_cpf: createForm.cnpj_cpf,
                    telefone: createForm.telefone,
                    tipo_pessoa: createForm.tipo_pessoa,
                    tipo_cliente: tipoCliente,
                    regime_tributario: createForm.regime_tributario,
                    cidade: createForm.cidade,
                    estado: createForm.estado,
                    status: 'active'
                }])
                .select()
                .single();

            if (companyError) throw companyError;

            // Setup Finance Level
            if (createForm.nivel_financeiro) {
                // 1. Set current config
                await supabase.from('finance_config').upsert(
                    { company_id: companyData.id, nivel_financeiro: createForm.nivel_financeiro },
                    { onConflict: 'company_id' }
                );

                // 2. Log initial level as a change so it appears in history
                if (user?.id) {
                    await supabase.from('finance_level_changes').insert({
                        company_id: companyData.id,
                        nivel_anterior: null,
                        nivel_novo: createForm.nivel_financeiro,
                        mudado_por: user.id,
                        mudado_em: new Date().toISOString()
                    });
                }
            }

            toast({ title: "Sucesso", description: "Empresa criada." });
            setIsCreateModalOpen(false);
            setCreateForm({
                nome: '',
                cnpj_cpf: '',
                telefone: '',
                tipo_pessoa: 'PJ',
                regime_tributario: 'simples_nacional',
                cidade: '',
                estado: '',
                nivel_financeiro: 'A'
            });
            fetchCompanies();

        } catch (error) {
            console.error(error);
            toast({ variant: "destructive", title: "Erro", description: error.message });
        } finally {
            setIsCreating(false);
        }
    };

const handleUpdateCompany = async () => {
    console.group('AdminEmpresasPage: handleUpdateCompany Debug Report');
    const timestamp = new Date().toISOString();
    console.log(`[${timestamp}] Iniciando atualização para empresa: ${editForm.id}`);
    
    setIsUpdating(true);
    
    try {
        // 1. Validação de Nível
        const validLevels = ['A', 'B', 'C'];
        if (!validLevels.includes(editForm.nivel_financeiro)) {
            throw new Error(`Nível inválido: ${editForm.nivel_financeiro}.`);
        }

        // 2. Buscar nível atual para o histórico (Audit Log)
        const { data: originalData } = await supabase
            .from('companies')
            .select('finance_config(nivel_financeiro)')
            .eq('id', editForm.id)
            .single();

        const currentLevel = originalData?.finance_config?.[0]?.nivel_financeiro 
            || originalData?.finance_config?.nivel_financeiro 
            || 'A';

        // 3. Atualização de Informações Básicas
        const tipoCliente = editForm.tipo_pessoa === 'PF' ? 'pf' : 'pj';
        const basicPayload = {
            nome: editForm.nome,
            cnpj_cpf: editForm.cnpj_cpf,
            telefone: editForm.telefone,
            tipo_pessoa: editForm.tipo_pessoa,
            tipo_cliente: tipoCliente,
            regime_tributario: editForm.regime_tributario,
            cidade: editForm.cidade,
            estado: editForm.estado
        };

        console.log(`[${timestamp}] Atualizando dados básicos...`);
        const { error: basicError } = await supabase
            .from('companies')
            .update(basicPayload)
            .eq('id', editForm.id);

        if (basicError) throw basicError;

        // 4. Atualização do Nível Financeiro (Sempre executa o Upsert para garantir)
        console.log(`[${timestamp}] Executando upsert no finance_config para nível: ${editForm.nivel_financeiro}`);
        const { error: configError } = await supabase
            .from('finance_config')
            .upsert({ 
                company_id: editForm.id, 
                nivel_financeiro: editForm.nivel_financeiro 
            }, { onConflict: 'company_id' });

        if (configError) throw configError;

        // 5. Registrar Histórico (Apenas se o nível realmente mudou)
        if (currentLevel !== editForm.nivel_financeiro && user?.id) {
            console.log(`[${timestamp}] Registrando mudança de nível no histórico...`);
            await supabase.from('finance_level_changes').insert({
                company_id: editForm.id,
                nivel_anterior: currentLevel,
                nivel_novo: editForm.nivel_financeiro,
                mudado_por: user.id,
                mudado_em: new Date().toISOString()
            });
        }

        // 6. Finalização
        toast({ title: "Sucesso", description: "Empresa e nível financeiro atualizados." });
        setIsEditModalOpen(false);
        
        // Recarregar dados
        await fetchCompanies();

    } catch (error) {
        console.error(`[${timestamp}] Erro no handleUpdateCompany:`, error);
        toast({ 
            variant: "destructive", 
            title: "Erro ao atualizar", 
            description: error.message || "Ocorreu um erro inesperado." 
        });
    } finally {
        setIsUpdating(false);
        console.groupEnd();
    }
};

    const handleDeleteCompany = async () => {
        if (!companyToDelete) return;
        setIsDeleting(true);
        try {
            const { data, error } = await supabase.functions.invoke('delete-company', {
                body: JSON.stringify({ id: companyToDelete.id })
            });
            if (error) throw error;
            if (data.error) throw new Error(data.error);

            toast({ title: "Deletada", description: "Empresa removida." });
            setIsDeleteModalOpen(false);
            setCompanyToDelete(null);
            fetchCompanies();
        } catch (error) {
            console.error(error);
            toast({ variant: "destructive", title: "Erro", description: error.message });
        } finally {
            setIsDeleting(false);
        }
    };

    const handleApprove = async () => {
        if (!companyToApprove) return;
        try {
            const { error } = await supabase
                .from('companies')
                .update({ status: 'active' })
                .eq('id', companyToApprove.id);

            if (error) throw error;

            toast({ title: "Aprovado", description: "Empresa ativada com sucesso." });
            setIsApproveModalOpen(false);
            setCompanyToApprove(null);
            fetchCompanies();
        } catch (err) {
            toast({ variant: "destructive", title: "Erro", description: err.message });
        }
    };

    // Filter Logic
    const filteredCompanies = companies.filter(c =>
        (c.nome?.toLowerCase().includes(searchTerm.toLowerCase()) || c.cnpj_cpf?.includes(searchTerm)) &&
        (activeTab === 'pending' ? c.status === 'pending_approval' : (c.status === 'active' || !c.status))
    );

    const pendingCount = companies.filter(c => c.status === 'pending_approval').length;

    return (
        <>
            <Helmet>
                <title>Admin - Gerenciar Empresas</title>
            </Helmet>
            <div className="space-y-6">
                <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
                    <div>
                        <h1 className="text-3xl font-bold text-slate-900">Gerenciar Empresas</h1>
                        <p className="text-muted-foreground">Cadastre e gerencie as empresas clientes do sistema.</p>
                    </div>
                    <div className="flex gap-2">
                        {orphanCompanies.length > 0 && (
                            <Button
                                variant="outline"
                                className="text-yellow-600 bg-yellow-50"
                                onClick={() => setIsBackfillModalOpen(true)}
                            >
                                <UserPlus className="w-4 h-4 mr-2" /> Corrigir ({orphanCompanies.length})
                            </Button>
                        )}
                        <Button
                            onClick={() => {
                                setCreateForm({
                                    nome: '',
                                    cnpj_cpf: '',
                                    telefone: '',
                                    tipo_pessoa: 'PJ',
                                    regime_tributario: 'simples_nacional',
                                    cidade: '',
                                    estado: '',
                                    nivel_financeiro: 'A'
                                });
                                setIsCreateModalOpen(true);
                            }}
                        >
                            <Plus className="w-4 h-4 mr-2" /> Nova Empresa
                        </Button>
                    </div>
                </div>

                <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
                    <TabsList className="mb-4">
                        <TabsTrigger value="active">Ativas</TabsTrigger>
                        <TabsTrigger value="pending" className="relative">
                            Pendentes
                            {pendingCount > 0 && (
                                <span className="ml-2 bg-red-500 text-white text-[10px] px-1.5 rounded-full">
                                    {pendingCount}
                                </span>
                            )}
                        </TabsTrigger>
                    </TabsList>

                    <div className="relative mb-4">
                        <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
                        <Input
                            placeholder="Buscar empresa..."
                            className="pl-8"
                            value={searchTerm}
                            onChange={(e) => setSearchTerm(e.target.value)}
                        />
                    </div>

                    <TabsContent value="active" className="mt-0">
                        <Card>
                            <CardContent className="p-0">
                                <Table>
                                    <TableHeader>
                                        <TableRow>
                                            <TableHead>Empresa</TableHead>
                                            <TableHead>CNPJ/CPF</TableHead>
                                            <TableHead>Tipo</TableHead>
                                            <TableHead>Regime</TableHead>
                                            <TableHead>Nível</TableHead>
                                            <TableHead>Proprietário</TableHead>
                                            <TableHead className="text-right">Ações</TableHead>
                                        </TableRow>
                                    </TableHeader>
                                    <TableBody>
                                        {loading ? (
                                            <TableRow>
                                                <TableCell colSpan={7} className="text-center py-8">
                                                    <Loader2 className="animate-spin h-6 w-6 mx-auto" />
                                                </TableCell>
                                            </TableRow>
                                        ) : filteredCompanies.length === 0 ? (
                                            <TableRow>
                                                <TableCell colSpan={7} className="text-center py-8">
                                                    Nenhuma encontrada.
                                                </TableCell>
                                            </TableRow>
                                        ) : (
                                            filteredCompanies.map((c) => (
                                                <TableRow key={c.id}>
                                                    <TableCell>
                                                        <div className="flex items-center gap-3">
                                                            <div className="bg-blue-100 p-2 rounded-lg">
                                                                <Building2 className="w-4 h-4 text-blue-700" />
                                                            </div>
                                                            <div>
                                                                <div className="font-medium">{c.nome}</div>
                                                                <div className="text-xs text-muted-foreground">
                                                                    {c.cidade && c.estado ? `${c.cidade} - ${c.estado}` : ''}
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </TableCell>
                                                    <TableCell>{c.cnpj_cpf}</TableCell>
                                                    <TableCell>
                                                        <Badge variant="outline">{c.tipo_pessoa || 'PJ'}</Badge>
                                                    </TableCell>
                                                    <TableCell>
                                                        <span className="text-sm text-slate-600">{getRegimeName(c)}</span>
                                                    </TableCell>
                                                    <TableCell>
                                                        <Badge variant="secondary">
                                                            Nível {getFinanceLevelFromRelation(c)}
                                                        </Badge>
                                                    </TableCell>
                                                    <TableCell>
                                                        {c.user_company_roles?.[0]?.users?.nome || '-'}
                                                    </TableCell>
                                                    <TableCell className="text-right space-x-2">
                                                        <Button
                                                            variant="ghost"
                                                            size="icon"
                                                            onClick={() => openEditModal(c)}
                                                        >
                                                            <Edit className="w-4 h-4" />
                                                        </Button>
                                                        <Button
                                                            variant="ghost"
                                                            size="icon"
                                                            className="text-red-500 hover:bg-red-50"
                                                            onClick={() => openDeleteModal(c)}
                                                        >
                                                            <Trash2 className="w-4 h-4" />
                                                        </Button>
                                                    </TableCell>
                                                </TableRow>
                                            ))
                                        )}
                                    </TableBody>
                                </Table>
                            </CardContent>
                        </Card>
                    </TabsContent>

                    <TabsContent value="pending" className="mt-0">
                        {/* Pending content omitted for brevity as it is similar structure */}
                         <Card>
                            <CardContent className="p-0">
                                <Table>
                                    <TableHeader>
                                        <TableRow>
                                            <TableHead>Empresa</TableHead>
                                            <TableHead>CNPJ/CPF</TableHead>
                                            <TableHead>Tipo</TableHead>
                                            <TableHead>Regime</TableHead>
                                            <TableHead>Nível</TableHead>
                                            <TableHead>Proprietário</TableHead>
                                            <TableHead className="text-right">Ações</TableHead>
                                        </TableRow>
                                    </TableHeader>
                                    <TableBody>
                                        {loading ? (
                                            <TableRow>
                                                <TableCell colSpan={7} className="text-center py-8">
                                                    <Loader2 className="animate-spin h-6 w-6 mx-auto" />
                                                </TableCell>
                                            </TableRow>
                                        ) : filteredCompanies.length === 0 ? (
                                            <TableRow>
                                                <TableCell colSpan={7} className="text-center py-8">
                                                    Nenhuma encontrada.
                                                </TableCell>
                                            </TableRow>
                                        ) : (
                                            filteredCompanies.map((c) => (
                                                <TableRow key={c.id}>
                                                    <TableCell>
                                                        <div className="flex items-center gap-3">
                                                            <div className="bg-blue-100 p-2 rounded-lg">
                                                                <Building2 className="w-4 h-4 text-blue-700" />
                                                            </div>
                                                            <div>
                                                                <div className="font-medium">{c.nome}</div>
                                                                <div className="text-xs text-muted-foreground">
                                                                    {c.cidade && c.estado ? `${c.cidade} - ${c.estado}` : ''}
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </TableCell>
                                                    <TableCell>{c.cnpj_cpf}</TableCell>
                                                    <TableCell>
                                                        <Badge variant="outline">{c.tipo_pessoa || 'PJ'}</Badge>
                                                    </TableCell>
                                                    <TableCell>
                                                        <span className="text-sm text-slate-600">{getRegimeName(c)}</span>
                                                    </TableCell>
                                                    <TableCell>
                                                        <Badge variant="secondary">
                                                            Nível {getFinanceLevelFromRelation(c)}
                                                        </Badge>
                                                    </TableCell>
                                                    <TableCell>
                                                        {c.user_company_roles?.[0]?.users?.nome || '-'}
                                                    </TableCell>
                                                    <TableCell className="text-right space-x-2">
                                                        <Button
                                                            size="icon"
                                                            className="bg-green-600 hover:bg-green-700 text-white"
                                                            onClick={() => {
                                                                setCompanyToApprove(c);
                                                                setIsApproveModalOpen(true);
                                                            }}
                                                        >
                                                            <CheckCircle className="w-4 h-4" />
                                                        </Button>
                                                        <Button
                                                            variant="ghost"
                                                            size="icon"
                                                            onClick={() => openEditModal(c)}
                                                        >
                                                            <Edit className="w-4 h-4" />
                                                        </Button>
                                                        <Button
                                                            variant="ghost"
                                                            size="icon"
                                                            className="text-red-500 hover:bg-red-50"
                                                            onClick={() => openDeleteModal(c)}
                                                        >
                                                            <Trash2 className="w-4 h-4" />
                                                        </Button>
                                                    </TableCell>
                                                </TableRow>
                                            ))
                                        )}
                                    </TableBody>
                                </Table>
                            </CardContent>
                        </Card>
                    </TabsContent>
                </Tabs>

                {/* Modal Criar Empresa */}
                <Dialog open={isCreateModalOpen} onOpenChange={setIsCreateModalOpen}>
                    <DialogContent className="sm:max-w-[600px]">
                        <DialogHeader>
                            <DialogTitle>Nova Empresa</DialogTitle>
                        </DialogHeader>
                        <div className="grid gap-4 py-4">
                            <div className="grid grid-cols-2 gap-4">
                                <div className="space-y-2">
                                    <Label>Nome</Label>
                                    <Input
                                        value={createForm.nome}
                                        onChange={e => setCreateForm({ ...createForm, nome: e.target.value })}
                                    />
                                </div>
                                <div className="space-y-2">
                                    <Label>CNPJ/CPF</Label>
                                    <Input
                                        value={createForm.cnpj_cpf}
                                        onChange={e => setCreateForm({ ...createForm, cnpj_cpf: e.target.value })}
                                    />
                                </div>
                            </div>
                            <div className="grid grid-cols-2 gap-4">
                                <div className="space-y-2">
                                    <Label>Telefone</Label>
                                    <Input
                                        value={createForm.telefone}
                                        onChange={e => setCreateForm({ ...createForm, telefone: e.target.value })}
                                    />
                                </div>
                                <div className="space-y-2">
                                    <Label>Tipo</Label>
                                    <Select
                                        value={createForm.tipo_pessoa}
                                        onValueChange={v => setCreateForm({ ...createForm, tipo_pessoa: v })}
                                    >
                                        <SelectTrigger>
                                            <SelectValue placeholder="Selecione" />
                                        </SelectTrigger>
                                        <SelectContent>
                                            <SelectItem value="PJ">Pessoa Jurídica</SelectItem>
                                            <SelectItem value="PF">Pessoa Física</SelectItem>
                                        </SelectContent>
                                    </Select>
                                </div>
                            </div>
                            <div className="grid grid-cols-2 gap-4">
                                <div className="space-y-2">
                                    <Label>Regime Tributário</Label>
                                    <RegimeSelector 
                                        value={createForm.regime_tributario}
                                        onChange={v => setCreateForm({ ...createForm, regime_tributario: v })}
                                    />
                                </div>
                                <div className="space-y-2">
                                    <Label>Nível Financeiro</Label>
                                    <Select
                                        value={createForm.nivel_financeiro}
                                        onValueChange={v => setCreateForm({ ...createForm, nivel_financeiro: v })}
                                    >
                                        <SelectTrigger>
                                            <SelectValue placeholder="Selecione" />
                                        </SelectTrigger>
                                        <SelectContent>
                                            <SelectItem value="A">Nível A</SelectItem>
                                            <SelectItem value="B">Nível B</SelectItem>
                                            <SelectItem value="C">Nível C</SelectItem>
                                        </SelectContent>
                                    </Select>
                                </div>
                            </div>
                            <div className="grid grid-cols-2 gap-4">
                                <div className="space-y-2">
                                    <Label>Cidade</Label>
                                    <Input
                                        value={createForm.cidade}
                                        onChange={e => setCreateForm({ ...createForm, cidade: e.target.value })}
                                    />
                                </div>
                                <div className="space-y-2">
                                    <Label>Estado</Label>
                                    <Input
                                        value={createForm.estado}
                                        onChange={e => setCreateForm({ ...createForm, estado: e.target.value })}
                                    />
                                </div>
                            </div>
                            <Button onClick={handleCreateCompany} disabled={isCreating}>
                                {isCreating ? <Loader2 className="animate-spin" /> : 'Criar'}
                            </Button>
                        </div>
                    </DialogContent>
                </Dialog>

                {/* Modal Editar Empresa */}
                <Dialog open={isEditModalOpen} onOpenChange={setIsEditModalOpen}>
                    <DialogContent className="sm:max-w-[600px]">
                        <DialogHeader>
                            <DialogTitle>Editar Empresa</DialogTitle>
                        </DialogHeader>
                        <div className="grid gap-4 py-4">
                            <div className="grid grid-cols-2 gap-4">
                                <div className="space-y-2">
                                    <Label>Nome</Label>
                                    <Input
                                        value={editForm.nome}
                                        onChange={e => setEditForm({ ...editForm, nome: e.target.value })}
                                    />
                                </div>
                                <div className="space-y-2">
                                    <Label>CNPJ/CPF</Label>
                                    <Input
                                        value={editForm.cnpj_cpf}
                                        onChange={e => setEditForm({ ...editForm, cnpj_cpf: e.target.value })}
                                    />
                                </div>
                            </div>
                            <div className="grid grid-cols-2 gap-4">
                                <div className="space-y-2">
                                    <Label>Telefone</Label>
                                    <Input
                                        value={editForm.telefone}
                                        onChange={e => setEditForm({ ...editForm, telefone: e.target.value })}
                                    />
                                </div>
                                <div className="space-y-2">
                                    <Label>Tipo</Label>
                                    <Select
                                        value={editForm.tipo_pessoa}
                                        onValueChange={v => setEditForm({ ...editForm, tipo_pessoa: v })}
                                    >
                                        <SelectTrigger>
                                            <SelectValue />
                                        </SelectTrigger>
                                        <SelectContent>
                                            <SelectItem value="PJ">Pessoa Jurídica</SelectItem>
                                            <SelectItem value="PF">Pessoa Física</SelectItem>
                                        </SelectContent>
                                    </Select>
                                </div>
                            </div>
                            <div className="grid grid-cols-2 gap-4">
                                <div className="space-y-2">
                                    <Label>Regime Tributário</Label>
                                    <RegimeSelector 
                                        value={editForm.regime_tributario}
                                        onChange={v => setEditForm({ ...editForm, regime_tributario: v })}
                                    />
                                </div>
                                <div className="space-y-2">
                                    <Label>Nível Financeiro</Label>
                                    <Select
                                        value={editForm.nivel_financeiro}
                                        onValueChange={v => setEditForm({ ...editForm, nivel_financeiro: v })}
                                    >
                                        <SelectTrigger>
                                            <SelectValue />
                                        </SelectTrigger>
                                        <SelectContent>
                                            <SelectItem value="A">Nível A</SelectItem>
                                            <SelectItem value="B">Nível B</SelectItem>
                                            <SelectItem value="C">Nível C</SelectItem>
                                        </SelectContent>
                                    </Select>
                                </div>
                            </div>
                            <div className="grid grid-cols-2 gap-4">
                                <div className="space-y-2">
                                    <Label>Cidade</Label>
                                    <Input
                                        value={editForm.cidade}
                                        onChange={e => setEditForm({ ...editForm, cidade: e.target.value })}
                                    />
                                </div>
                                <div className="space-y-2">
                                    <Label>Estado</Label>
                                    <Input
                                        value={editForm.estado}
                                        onChange={e => setEditForm({ ...editForm, estado: e.target.value })}
                                    />
                                </div>
                            </div>
                            <Button onClick={handleUpdateCompany} disabled={isUpdating}>
                                {isUpdating ? <Loader2 className="animate-spin" /> : 'Salvar'}
                            </Button>
                        </div>
                    </DialogContent>
                </Dialog>
                
                 <Dialog open={isDeleteModalOpen} onOpenChange={setIsDeleteModalOpen}>
                    <DialogContent>
                        <DialogHeader>
                            <DialogTitle>Deletar Empresa</DialogTitle>
                            <DialogDescription>
                                Tem certeza que deseja deletar a empresa {companyToDelete?.nome}? Esta ação não pode ser desfeita.
                            </DialogDescription>
                        </DialogHeader>
                        <DialogFooter>
                            <Button variant="outline" onClick={() => setIsDeleteModalOpen(false)}>Cancelar</Button>
                            <Button variant="destructive" onClick={handleDeleteCompany} disabled={isDeleting}>
                                {isDeleting ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Trash2 className="mr-2 h-4 w-4" />}
                                Deletar
                            </Button>
                        </DialogFooter>
                    </DialogContent>
                </Dialog>

                <Dialog open={isApproveModalOpen} onOpenChange={setIsApproveModalOpen}>
                    <DialogContent>
                        <DialogHeader>
                            <DialogTitle>Aprovar Empresa</DialogTitle>
                            <DialogDescription>
                                Confirma a ativação da empresa {companyToApprove?.nome}?
                            </DialogDescription>
                        </DialogHeader>
                        <DialogFooter>
                            <Button variant="outline" onClick={() => setIsApproveModalOpen(false)}>Cancelar</Button>
                            <Button onClick={handleApprove}>Aprovar</Button>
                        </DialogFooter>
                    </DialogContent>
                </Dialog>
                
                {/* Backfill modal would go here */}
            </div>
        </>
    );
};

export default AdminEmpresasPage;
