import React from 'react';
import { Helmet } from 'react-helmet';
import { useToast } from '@/components/ui/use-toast';

const AdminNotasPage = () => {
    const { toast } = useToast();

    return (
        <>
             <Helmet>
                <title>Admin - Notas Fiscais</title>
            </Helmet>
            <div className="p-8 text-center">
                <h1 className="text-2xl font-bold text-gray-800 mb-4">Gerenciamento de Notas Fiscais (Admin)</h1>
                <p className="text-gray-500">Funcionalidade de visualização global e importação em lote para admin em desenvolvimento.</p>
            </div>
        </>
    )
}
export default AdminNotasPage;