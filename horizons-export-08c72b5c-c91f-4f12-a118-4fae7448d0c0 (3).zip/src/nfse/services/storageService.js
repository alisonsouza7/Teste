
import { createServiceRoleClient } from '@/lib/supabaseServiceRole';

const BUCKET = 'nfse-xml';

const getSupabase = () => {
    const client = createServiceRoleClient();
    if (!client) throw new Error('Service Role Client unavailable for storage operations.');
    return client;
};

const upload = async (path, content, contentType = 'application/xml') => {
    const supabase = getSupabase();
    const { error } = await supabase.storage.from(BUCKET).upload(path, content, { contentType, upsert: true });
    if (error) throw new Error(`Storage upload failed: ${error.message}`);
    return path;
};

export const saveRequestXml = async (company_id, referenceId, xmlContent) => {
    const path = `${company_id}/requests/${referenceId}.xml`;
    return upload(path, xmlContent);
};

export const saveSignedXml = async (company_id, referenceId, xmlContent) => {
    const path = `${company_id}/signed/${referenceId}.xml`;
    return upload(path, xmlContent);
};

export const saveSendResponseXml = async (company_id, referenceId, xmlContent) => {
    const path = `${company_id}/responses/${referenceId}.xml`;
    return upload(path, xmlContent);
};

export const saveNfseXml = async (company_id, nfseNumber, xmlContent) => {
    const path = `${company_id}/nfse/${nfseNumber}.xml`;
    return upload(path, xmlContent);
};

export const getXmlPreview = async (path, maxChars = 2000) => {
    if (!path) return null;
    const supabase = getSupabase();
    
    const { data, error } = await supabase.storage.from(BUCKET).download(path);
    if (error) return null;
    const text = await data.text();
    return text.substring(0, maxChars) + (text.length > maxChars ? '...' : '');
};

export default { saveRequestXml, saveSignedXml, saveSendResponseXml, saveNfseXml, getXmlPreview };
