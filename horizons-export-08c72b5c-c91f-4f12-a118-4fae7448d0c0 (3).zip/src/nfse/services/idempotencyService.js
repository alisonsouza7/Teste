
import { createServiceRoleClient } from '@/lib/supabaseServiceRole';

// Helper to ensure we have a client before proceeding
const getSupabase = () => {
    const client = createServiceRoleClient();
    if (!client) throw new Error('Service Role Client unavailable. Check server configuration.');
    return client;
};

export const checkIdempotency = async (company_id, idempotencyKey, operation, payload) => {
    const supabase = getSupabase();

    if (!idempotencyKey) {
        return { isNew: true, request: null };
    }

    const { data: existing } = await supabase
        .from('nfse_requests')
        .select('*')
        .eq('company_id', company_id)
        .eq('idempotency_key', idempotencyKey)
        .single();

    if (existing) {
        return { isNew: false, request: existing };
    }

    const { data: newReq, error: insertError } = await supabase
        .from('nfse_requests')
        .insert({
            company_id,
            idempotency_key: idempotencyKey,
            operation,
            request_payload: payload,
            status: 'PROCESSING'
        })
        .select()
        .single();

    if (insertError) {
        if (insertError.code === '23505') {
             const { data: retryExisting } = await supabase
                .from('nfse_requests')
                .select('*')
                .eq('company_id', company_id)
                .eq('idempotency_key', idempotencyKey)
                .single();
             return { isNew: false, request: retryExisting };
        }
        throw new Error(`Failed to create idempotency record: ${insertError.message}`);
    }

    return { isNew: true, request: newReq };
};

export const updateRequestStatus = async (requestId, status, responseSummary, relatedDpsId = null) => {
    const supabase = getSupabase();
    
    const updates = {
        status,
        response_summary: responseSummary,
        updated_at: new Date()
    };
    
    if (relatedDpsId) {
        updates.related_dps_id = relatedDpsId;
    }

    await supabase.from('nfse_requests').update(updates).eq('id', requestId);
};

export default { checkIdempotency, updateRequestStatus };
