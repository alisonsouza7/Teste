
import { createServiceRoleClient } from '@/lib/supabaseServiceRole';

const STATUS_TRANSITIONS = {
    'DRAFT': ['SIGNED', 'CANCELLED'],
    'SIGNED': ['TRANSMITTING', 'CANCELLED', 'ERROR'],
    'TRANSMITTING': ['AUTHORIZED', 'REJECTED', 'ERROR'],
    'AUTHORIZED': ['CANCELLED'],
    'REJECTED': ['DRAFT', 'SIGNED'],
    'ERROR': ['SIGNED', 'DRAFT'],
    'CANCELLED': []
};

const getSupabase = () => {
    const client = createServiceRoleClient();
    if (!client) throw new Error('Service Role Client unavailable.');
    return client;
};

export const isValidTransition = (fromStatus, toStatus) => {
    const allowed = STATUS_TRANSITIONS[fromStatus] || [];
    return allowed.includes(toStatus);
};

export const updateDpsStatus = async (dpsId, newStatus, details = {}) => {
    const supabase = getSupabase();

    const { data: current } = await supabase
        .from('nfse_dps')
        .select('status, attempts')
        .eq('id', dpsId)
        .single();

    if (!current) throw new Error(`DPS ${dpsId} not found`);

    const updates = { status: newStatus, updated_at: new Date() };

    if (newStatus === 'ERROR' || newStatus === 'REJECTED') {
        updates.error_code = details.errorCode || null;
        updates.error_message = details.errorMessage || null;
        updates.last_attempt_at = new Date();
        updates.attempts = (current.attempts || 0) + 1;
    }

    if (newStatus === 'AUTHORIZED') {
        updates.chave_acesso = details.chaveAcesso;
        updates.numero_nfse = details.numeroNfse;
        updates.xml_nfse_path = details.xmlNfsePath;
        updates.error_code = null;
        updates.error_message = null;
    }

    if (details.xmlRequestPath) updates.xml_request_path = details.xmlRequestPath;
    if (details.xmlSignedPath) updates.xml_signed_path = details.xmlSignedPath;
    if (details.xmlResponsePath) updates.xml_response_path = details.xmlResponsePath;

    await supabase.from('nfse_dps').update(updates).eq('id', dpsId);
    
    supabase.from('nfse_audit_logs').insert({
        dps_id: dpsId,
        action: `STATUS_CHANGE_${newStatus}`,
        details: { from: current.status, to: newStatus, ...details }
    }).then();
};

export default { isValidTransition, updateDpsStatus };
