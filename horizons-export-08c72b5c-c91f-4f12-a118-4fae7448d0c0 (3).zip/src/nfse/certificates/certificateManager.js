
import { createServiceRoleClient } from '@/lib/supabaseServiceRole';
import { encrypt, decrypt } from './cryptoVault';
import { validateServerEnv } from '@/utils/env.server';

export const getActiveCertificate = async (companyId) => {
  if (!companyId) throw new Error('Company ID required');
  const env = validateServerEnv();
  const supabase = createServiceRoleClient();

  const { data, error } = await supabase
    .from('company_certificates')
    .select('*')
    .eq('company_id', companyId)
    .eq('is_active', true)
    .maybeSingle();

  if (error) throw new Error(error.message);
  if (!data) return null;

  const password = decrypt(data.pfx_password_encrypted);

  const { data: fileBlob, error: dlError } = await supabase.storage
    .from(env.nfseCertBucket || 'nfse-certs')
    .download(data.pfx_storage_path);

  if (dlError) throw new Error('File download failed');

  const pfxBuffer = await fileBlob.arrayBuffer();

  return {
    pfxBuffer,
    password,
    meta: {
      valid_from: new Date(data.valid_from),
      valid_to: new Date(data.valid_to),
      thumbprint: data.thumbprint
    }
  };
};

export default { getActiveCertificate };
