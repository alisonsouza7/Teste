
import forge from 'node-forge';
import { logger } from './logger';

/**
 * CryptoVault
 * AES-256-GCM Encryption/Decryption for sensitive certificate data.
 */

// Retrieve key from environment
const getEnvKey = () => {
  if (typeof import.meta !== 'undefined' && import.meta.env && import.meta.env.VITE_CERT_ENCRYPTION_KEY) {
    return import.meta.env.VITE_CERT_ENCRYPTION_KEY;
  }
  
  return null;
};

// Cache the key buffer
let keyBuffer = null;

/**
 * Validates and normalizes the encryption key.
 * @returns {string} The raw binary key string (node-forge expects this)
 */
export const getKey = () => {
  if (keyBuffer) return keyBuffer;

  const envKey = getEnvKey();

  if (!envKey) {
    // Throwing here is correct as this is a critical security component
    // The bootstrap process catches this error to report it gracefully
    throw new Error('CRITICAL: VITE_CERT_ENCRYPTION_KEY not set in environment.');
  }

  try {
    // Attempt hex
    if (/^[0-9a-fA-F]{64}$/.test(envKey)) {
      keyBuffer = forge.util.hexToBytes(envKey);
    } 
    // Attempt Base64 (32 bytes = ~44 chars)
    else {
      keyBuffer = forge.util.decode64(envKey);
    }

    if (keyBuffer.length !== 32) {
      throw new Error(`Invalid key length: ${keyBuffer.length} bytes. Expected 32 bytes (256 bits).`);
    }

    return keyBuffer;
  } catch (error) {
    logger.error('Failed to load encryption key', { error: error.message });
    throw new Error('Encryption System Error: Invalid Key Configuration');
  }
};

/**
 * Encrypts a plain text string using AES-256-GCM
 * @param {string} plainText 
 * @returns {string} Base64 encoded payload (IV + Tag + Ciphertext)
 */
export const encrypt = (plainText) => {
  if (!plainText) {
    throw new Error('Encryption Error: Empty input');
  }

  try {
    const key = getKey();
    // IV (Nonce) - 12 bytes recommended for GCM
    const iv = forge.random.getBytesSync(12);
    
    const cipher = forge.cipher.createCipher('AES-GCM', key);
    cipher.start({ iv: iv, tagLength: 128 });
    cipher.update(forge.util.createBuffer(plainText, 'utf8'));
    
    if (!cipher.finish()) {
      throw new Error('Cipher finish failed');
    }

    const encrypted = cipher.output.getBytes();
    const tag = cipher.mode.tag.getBytes();

    // Format: IV (12) + Tag (16) + Ciphertext (Variable)
    // We encode everything to Base64 for storage
    const payload = forge.util.encode64(iv + tag + encrypted);
    return payload;

  } catch (error) {
    logger.error('Encryption failed', { error: error.message });
    throw new Error('Encryption failed');
  }
};

/**
 * Decrypts a payload string using AES-256-GCM
 * @param {string} payloadBase64 
 * @returns {string} The original plain text
 */
export const decrypt = (payloadBase64) => {
  if (!payloadBase64) {
    throw new Error('Decryption Error: Empty input');
  }

  try {
    const key = getKey();
    const raw = forge.util.decode64(payloadBase64);

    if (raw.length < 28) {
      throw new Error('Invalid payload length (too short)');
    }

    const iv = raw.substring(0, 12);
    const tag = raw.substring(12, 28);
    const ciphertext = raw.substring(28);

    const decipher = forge.cipher.createDecipher('AES-GCM', key);
    decipher.start({ 
      iv: iv, 
      tagLength: 128, 
      tag: forge.util.createBuffer(tag) 
    });
    
    decipher.update(forge.util.createBuffer(ciphertext));
    
    const success = decipher.finish();
    if (!success) {
      throw new Error('Authentication tag mismatch (Integrity check failed)');
    }

    return decipher.output.toString('utf8');

  } catch (error) {
    // Ensure we don't leak why it failed (bad key vs bad data) to the caller, but log internally
    logger.error('Decryption failed', { error: error.message });
    throw new Error('Decryption failed or invalid credentials');
  }
};

export default {
  encrypt,
  decrypt,
  getKey
};
