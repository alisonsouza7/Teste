
import { ErrorCodes } from './types';

/**
 * Validation Utilities for Certificates
 */

const MAX_SIZE_BYTES = 5 * 1024 * 1024; // 5MB

export const validateFile = (fileObj) => {
  if (!fileObj) {
    throw { code: ErrorCodes.VALIDATION_ERROR, message: 'Arquivo não fornecido.' };
  }
  
  // Check size
  const size = fileObj.size || fileObj.byteLength || 0;
  if (size > MAX_SIZE_BYTES) {
    throw { code: ErrorCodes.VALIDATION_ERROR, message: 'Arquivo excede o limite de 5MB.' };
  }

  // Check extension (if available via name)
  if (fileObj.name) {
    const name = fileObj.name.toLowerCase();
    if (!name.endsWith('.pfx') && !name.endsWith('.p12')) {
       throw { code: ErrorCodes.VALIDATION_ERROR, message: 'Tipo de arquivo inválido. Use .pfx ou .p12.' };
    }
  }
};

export const validateCompanyId = (id) => {
  const uuidRegex = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
  if (!id || !uuidRegex.test(id)) {
    throw { code: ErrorCodes.VALIDATION_ERROR, message: 'ID da empresa inválido.' };
  }
};

export const validatePassword = (pwd) => {
  if (!pwd || typeof pwd !== 'string' || pwd.trim().length === 0) {
    throw { code: ErrorCodes.VALIDATION_ERROR, message: 'Senha é obrigatória.' };
  }
};

export const validateDates = (validFrom, validTo) => {
  const now = new Date();
  
  if (validTo < now) {
    throw { code: ErrorCodes.CERT_EXPIRED, message: 'Certificado expirado.' };
  }
  
  if (validFrom > now) {
    throw { code: ErrorCodes.CERT_NOT_YET_VALID, message: 'Certificado ainda não é válido.' };
  }
};

export const sanitizeError = (error) => {
  if (error.code && Object.values(ErrorCodes).includes(error.code)) {
    return { status: 'error', code: error.code, message: error.message };
  }
  return { status: 'error', code: 'INTERNAL_ERROR', message: 'Ocorreu um erro interno.' };
};

export default {
  validateFile,
  validateCompanyId,
  validatePassword,
  validateDates,
  sanitizeError
};
