
import forge from 'node-forge';
import { logger } from './logger';
import { ErrorCodes } from './types';
import { Buffer } from 'buffer'; // Polyfill Buffer for browser compatibility

/**
 * PfxInspector
 * 
 * Can be used in both Backend (Node) and Frontend (Browser) contexts
 * provided the input is handled correctly.
 * 
 * Parses and validates PKCS#12 (.pfx) files.
 */

export const inspectPfx = (pfxBuffer, password) => {
  try {
    let pfxDer;
    
    // Handle different input types (Node Buffer, ArrayBuffer, String)
    if (typeof Buffer !== 'undefined' && Buffer.isBuffer(pfxBuffer)) {
      pfxDer = forge.util.createBuffer(pfxBuffer.toString('binary'), 'binary');
    } else if (pfxBuffer instanceof ArrayBuffer) {
      // Convert ArrayBuffer to binary string for Forge
      const bytes = new Uint8Array(pfxBuffer);
      let binary = '';
      // Use a chunked approach for large files to avoid stack overflow
      const chunkSize = 0x8000; // 32k
      for (let i = 0; i < bytes.length; i += chunkSize) {
        binary += String.fromCharCode.apply(null, bytes.subarray(i, i + chunkSize));
      }
      pfxDer = forge.util.createBuffer(binary, 'binary');
    } else {
      // Try treating as string or forge buffer
      pfxDer = forge.util.createBuffer(pfxBuffer);
    }
    
    const pfxAsn1 = forge.asn1.fromDer(pfxDer);
    
    let p12;
    try {
      p12 = forge.pkcs12.pkcs12FromAsn1(pfxAsn1, false, password);
    } catch (e) {
      if (e.message && (e.message.includes('password') || e.message.includes('MAC'))) {
        const error = new Error('Senha incorreta.');
        error.code = ErrorCodes.INVALID_PASSWORD;
        throw error;
      }
      throw e;
    }

    const bags = p12.getBags({ bagType: forge.pki.oids.certBag });
    const certBag = bags[forge.pki.oids.certBag];

    if (!certBag || certBag.length === 0) {
      const err = new Error('O arquivo PFX não contém certificados X.509.');
      err.code = ErrorCodes.INVALID_PFX;
      throw err;
    }

    const cert = certBag[0].cert;
    if (!cert) {
       const err = new Error('Certificado malformado.');
       err.code = ErrorCodes.INVALID_PFX;
       throw err;
    }

    const validFrom = cert.validity.notBefore;
    const validTo = cert.validity.notAfter;

    const certAsn1 = forge.pki.certificateToAsn1(cert);
    const certDer = forge.asn1.toDer(certAsn1).getBytes();
    const md = forge.md.sha1.create();
    md.update(certDer);
    const thumbprint = md.digest().toHex();

    const commonName = cert.subject.getField('CN')?.value || 'Desconhecido';
    const issuer = cert.issuer.getField('CN')?.value || 'Desconhecido';

    return {
      valid_from: validFrom,
      valid_to: validTo,
      thumbprint: thumbprint,
      commonName,
      issuer
    };

  } catch (error) {
    if (error.code) throw error;
    
    logger.error('PFX Inspection Error', { error: error.message });
    const genericError = new Error('Erro ao processar arquivo do certificado: ' + error.message);
    genericError.code = ErrorCodes.INVALID_PFX;
    throw genericError;
  }
};

export default { inspectPfx };
