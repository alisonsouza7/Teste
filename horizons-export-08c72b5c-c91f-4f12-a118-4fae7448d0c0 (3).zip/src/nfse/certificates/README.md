
# NFSe Digital Certificate Management

This module handles the secure storage, validation, and usage of A1 Digital Certificates (PFX/PKCS#12) for NFS-e emission.

## Security Overview

- **Storage**: PFX files are stored in Supabase Storage (`nfse-certs` bucket), which is private (no public URL).
- **Encryption**: Certificate passwords are encrypted using AES-256-GCM before storage in the database.
- **Access Control**: Only users with `admin` or `contador` roles can manage certificates.

## Environment Setup

To enable secure encryption, you must set the encryption key.

1. Generate a 32-byte (256-bit) random key. You can use OpenSSL:
   