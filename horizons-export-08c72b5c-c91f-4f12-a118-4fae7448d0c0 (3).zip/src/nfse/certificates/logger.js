
/**
 * Structured logger for Certificate Management.
 * ensures no sensitive data (passwords, PFX content, keys) is ever logged.
 */

const MASKED = '***MASKED***';

/**
 * Standardized log levels
 */
const LEVELS = {
  INFO: 'INFO',
  WARN: 'WARN',
  ERROR: 'ERROR',
  DEBUG: 'DEBUG'
};

const getTimestamp = () => new Date().toISOString();

/**
 * Sanitizes context objects to remove sensitive keys.
 * @param {Object} context 
 * @returns {Object}
 */
const sanitizeContext = (context) => {
  if (!context) return {};
  const safe = { ...context };
  
  // List of keys to mask
  const sensitiveKeys = ['password', 'pfx', 'pfxBuffer', 'key', 'secret', 'token', 'authorization'];
  
  Object.keys(safe).forEach(key => {
    if (sensitiveKeys.some(s => key.toLowerCase().includes(s))) {
      safe[key] = MASKED;
    }
  });

  return safe;
};

/**
 * Internal log function
 */
const log = (level, message, context = {}) => {
  // Check LOG_LEVEL environment variable if available
  const configuredLevel = (import.meta.env.VITE_LOG_LEVEL || 'INFO').toUpperCase();
  const levelPriority = { DEBUG: 0, INFO: 1, WARN: 2, ERROR: 3 };
  
  if (levelPriority[level] < levelPriority[configuredLevel]) {
    return;
  }

  const entry = {
    timestamp: getTimestamp(),
    level,
    module: 'CertificateManager',
    message,
    context: sanitizeContext(context)
  };

  if (level === 'ERROR') {
    console.error(JSON.stringify(entry));
  } else if (level === 'WARN') {
    console.warn(JSON.stringify(entry));
  } else {
    console.log(JSON.stringify(entry));
  }
};

export const logger = {
  info: (msg, ctx) => log(LEVELS.INFO, msg, ctx),
  warn: (msg, ctx) => log(LEVELS.WARN, msg, ctx),
  error: (msg, ctx) => log(LEVELS.ERROR, msg, ctx),
  debug: (msg, ctx) => log(LEVELS.DEBUG, msg, ctx),
  
  // Specific event helpers
  auditUpload: (companyId, thumbprint, validTo, filename, size) => {
    log(LEVELS.INFO, 'CERT_UPLOAD', { companyId, thumbprint, validTo, filename, size });
  },
  
  auditTestOk: (companyId, thumbprint) => {
    log(LEVELS.INFO, 'CERT_TEST_OK', { companyId, thumbprint });
  },
  
  auditTestFail: (companyId, errorType) => {
    log(LEVELS.WARN, 'CERT_TEST_FAIL', { companyId, errorType });
  },
  
  auditDeactivate: (companyId, thumbprint) => {
    log(LEVELS.INFO, 'CERT_DEACTIVATE', { companyId, thumbprint });
  }
};

export default logger;
