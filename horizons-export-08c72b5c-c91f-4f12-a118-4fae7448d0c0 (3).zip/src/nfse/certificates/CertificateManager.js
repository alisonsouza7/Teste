
import { createServiceRoleClient } from '@/lib/supabaseServiceRole';
import { encrypt, decrypt } from './CryptoVault';
import { inspectPfx } from './PfxInspector';
import { logger } from './logger';
import Validation from './validation';
import { ErrorCodes } from './types';

/**
 * CertificateManager
 * Business logic for Certificate Lifecycle Management.
 */

const getSupabase = () => {
  const client = createServiceRoleClient();
  if (!client) {
    throw new Error('Failed to initialize Supabase Service Role Client. Check VITE_SUPABASE_SERVICE_ROLE_KEY.');
  }
  return client;
};

const BUCKET_NAME = import.meta.env.VITE_NFSE_CERT_BUCKET || 'nfse-certs';

/**
 * (1) Upsert Certificate
 * Uploads PFX, Encrypts Password, Extracts Metadata, Inserts DB Record.
 */
export const upsertCertificate = async ({ companyId, pfxBuffer, password, filename }) => {
  const context = { companyId, filename };
  
  try {
    Validation.validateCompanyId(companyId);
    Validation.validatePassword(password);
    
    // 1. Inspect PFX (validates password & structure)
    const metadata = inspectPfx(pfxBuffer, password);
    context.thumbprint = metadata.thumbprint;
    
    // 2. Validate Validity Dates
    Validation.validateDates(metadata.valid_from, metadata.valid_to);

    // 3. Encrypt Password
    const encryptedPassword = encrypt(password);

    // 4. Upload to Storage
    const supabase = getSupabase();
    const timestamp = new Date().toISOString().replace(/[-:.]/g, ''); // Compact TS
    const storagePath = `${companyId}/${timestamp}-cert.pfx`;
    
    const { error: uploadError } = await supabase.storage
      .from(BUCKET_NAME)
      .upload(storagePath, pfxBuffer, {
        contentType: 'application/x-pkcs12',
        upsert: true
      });

    if (uploadError) {
      throw { code: ErrorCodes.STORAGE_ERROR, message: 'Upload failed: ' + uploadError.message };
    }

    // 5. Deactivate old certificates
    await deactivateCertificate(companyId);

    // 6. Insert new record
    const { error: dbError } = await supabase
      .from('company_certificates')
      .insert({
        company_id: companyId,
        pfx_storage_path: storagePath,
        pfx_password_encrypted: encryptedPassword,
        thumbprint: metadata.thumbprint,
        valid_from: metadata.valid_from,
        valid_to: metadata.valid_to,
        is_active: true
      });

    if (dbError) {
      // Rollback storage best effort
      await supabase.storage.from(BUCKET_NAME).remove([storagePath]);
      throw { code: ErrorCodes.DB_ERROR, message: dbError.message };
    }

    logger.auditUpload(companyId, metadata.thumbprint, metadata.valid_to, filename, pfxBuffer.byteLength);

    return {
      success: true,
      thumbprint: metadata.thumbprint,
      valid_to: metadata.valid_to,
      common_name: metadata.commonName
    };

  } catch (error) {
    logger.error('upsertCertificate failed', { ...context, error: error.message });
    throw error;
  }
};

/**
 * (2) Get Active Certificate
 * Retrieves and decrypts the active certificate for a company.
 */
export const getActiveCertificate = async (companyId) => {
  try {
    Validation.validateCompanyId(companyId);
    const supabase = getSupabase();

    // Fetch Record
    const { data, error } = await supabase
      .from('company_certificates')
      .select('*')
      .eq('company_id', companyId)
      .eq('is_active', true)
      .order('created_at', { ascending: false })
      .limit(1)
      .maybeSingle();

    if (error) throw { code: ErrorCodes.DB_ERROR, message: error.message };
    if (!data) return null;

    // Decrypt Password
    const password = decrypt(data.pfx_password_encrypted);

    // Download File
    const { data: fileBlob, error: dlError } = await supabase.storage
      .from(BUCKET_NAME)
      .download(data.pfx_storage_path);

    if (dlError) throw { code: ErrorCodes.STORAGE_ERROR, message: 'File download failed' };

    const pfxBuffer = await fileBlob.arrayBuffer();

    return {
      pfxBuffer,
      password,
      metadata: {
        valid_from: new Date(data.valid_from),
        valid_to: new Date(data.valid_to),
        thumbprint: data.thumbprint
      }
    };

  } catch (error) {
    logger.error('getActiveCertificate failed', { companyId, error: error.message });
    throw error;
  }
};

/**
 * (3) Get Certificate Metadata
 * Returns public info about active cert.
 */
export const getCertificateMeta = async (companyId) => {
  try {
    Validation.validateCompanyId(companyId);
    const supabase = getSupabase();

    const { data, error } = await supabase
      .from('company_certificates')
      .select('valid_from, valid_to, thumbprint, created_at, is_active')
      .eq('company_id', companyId)
      .eq('is_active', true)
      .maybeSingle();

    if (error) throw { code: ErrorCodes.DB_ERROR, message: error.message };
    return data;

  } catch (error) {
    logger.error('getCertificateMeta failed', { companyId, error: error.message });
    throw error;
  }
};

/**
 * (4) Deactivate Certificate
 */
export const deactivateCertificate = async (companyId) => {
  try {
    Validation.validateCompanyId(companyId);
    const supabase = getSupabase();

    // Get current active to log thumbprint
    const current = await getCertificateMeta(companyId);
    
    const { error } = await supabase
      .from('company_certificates')
      .update({ is_active: false })
      .eq('company_id', companyId);

    if (error) throw { code: ErrorCodes.DB_ERROR, message: error.message };

    if (current) {
      logger.auditDeactivate(companyId, current.thumbprint);
    }

    return true;
  } catch (error) {
    logger.error('deactivateCertificate failed', { companyId, error: error.message });
    throw error;
  }
};

export default {
  upsertCertificate,
  getActiveCertificate,
  getCertificateMeta,
  deactivateCertificate
};
