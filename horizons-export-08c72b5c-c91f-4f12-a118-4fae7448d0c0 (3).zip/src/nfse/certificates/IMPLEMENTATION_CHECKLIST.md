
# Certificate Management Implementation Checklist

## Core Security & Cryptography
- [x] **AES-256-GCM Encryption**: `CryptoVault` implements AES-GCM with `node-forge`.
- [x] **Key Validation**: Boot process checks for 32-byte key in `CERT_ENCRYPTION_KEY`.
- [x] **Secure Random**: Uses `forge.random.getBytesSync` for IV generation.
- [x] **No Password Leak**: Logger masks `password`, `pfx`, etc.

## PFX Processing
- [x] **Validation**: `PfxInspector` checks if PFX opens with password.
- [x] **Metadata Extraction**: Extracts `valid_from`, `valid_to`, `thumbprint`.
- [x] **Extension Check**: Validation rejects non-.pfx/.p12 files.
- [x] **Size Limit**: Enforces 5MB limit.

## Database & Storage
- [x] **Service Role**: `CertificateManager` uses isolated Service Role client.
- [x] **Storage Path**: Saves to `company_id/<timestamp>-cert.pfx`.
- [x] **Table Upsert**: `company_certificates` table logic implemented.
- [x] **Active Flag**: Handles `is_active` logic (disabling old ones).

## API & Access Control
- [x] **Role Check**: `api/certificados.js` enforces `admin` or `contador`.
- [x] **Audit Logs**: Events `CERT_UPLOAD`, `CERT_TEST_OK` etc. are logged.
- [x] **Endpoints**: 
    - `upload` (POST)
    - `get` (GET)
    - `test` (POST)
    - `deactivate` (POST)

## Test Scenarios (Manual)
1. **Upload Valid Cert**:
   - Input: Valid .pfx + correct password.
   - Expected: Success, DB record created, file in Storage, Audit Log entry.
2. **Upload Invalid Password**:
   - Input: Valid .pfx + wrong password.
   - Expected: Error "Senha incorreta", no DB change.
3. **Upload Corrupted File**:
   - Input: Random binary file named .pfx.
   - Expected: Error "Arquivo inválido/malformado".
4. **Test Active Cert**:
   - Action: Call `/test`.
   - Expected: Returns validity dates and days remaining.
5. **Test Expired Cert**:
   - Action: Upload expired cert -> Call `/test`.
   - Expected: Error/Warning "Certificado expirado".
6. **Access Control**:
   - Action: Call as 'cliente' role.
   - Expected: Error "Acesso negado".

## Deployment Checks
- [ ] Set `VITE_CERT_ENCRYPTION_KEY` (32 bytes hex).
- [ ] Set `VITE_SUPABASE_SERVICE_ROLE_KEY`.
- [ ] Create Bucket `nfse-certs` in Supabase (Private).
- [ ] Run `npm run nfse:anexos-worker` if using the worker process.
