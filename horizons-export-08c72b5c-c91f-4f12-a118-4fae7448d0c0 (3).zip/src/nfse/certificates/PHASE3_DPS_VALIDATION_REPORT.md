
# Phase 3 DPS Validation Report: National NFS-e Standard

## Overview
This report documents the validation of the DPS generation and signing pipeline against the National NFS-e (SPED) Standard v1.01.

## Acceptance Criteria Verification

### 1. Environment & Configuration
- ✅ **NFSE_ENV Mapping**: `validateServerEnv()` in `src/utils/env.server.js` correctly maps `prodrestrita` to `tpAmb=2` (Restricted Environment).
- ✅ **Standard Version**: Configured for `versao="1.01"` and `verAplic="CONTERJ-1.0"`.

### 2. XML Structure (DpsBuilder.js)
- ✅ **Correct Tags Implemented**:
  - `prest` (instead of `Prestador`) containing `cnpj` and optional `inscMun`.
  - `toma` (instead of `Tomador`) containing `cpfCnpj` and `xNome`.
  - `serv` (instead of `Servico`) containing `cServ`, `locPrest`, `valores`.
- ✅ **Valores Breakdown**: Supports `vServ`, `vDed`, `vPis`, `vCofins`, `vInss`, `vIr`, `vCsll`, `issRet`, `vIss`, `vIssRet`, `aliq`.
- ✅ **Date Formatting**: `getIsoWithTimezone()` implemented to provide true ISO 8601 strings (e.g., `2023-10-25T15:30:00-03:00`) instead of UTC Zulu hack.
- ✅ **Competence Date**: `dCompet` formatted strictly as `YYYY-MM-DD`.

### 3. Database & Counters
- ✅ **Counter Table**: `nfse_dps_counter` table created in Supabase.
- ✅ **Atomic Increment**: `getNextDpsNumber()` fetches and increments `nDPS` atomically per company/serie.
- ✅ **Default Serie**: Defaults to `80000` for environment isolation.

### 4. Validation Pipeline (DpsValidator.js)
- ✅ **Include Resolution**: `resolveXsdIncludes` uses `NFSE_XSD_DIR` to correctly map relative `schemaLocation` paths to absolute file paths.
- ✅ **DOM Validation**: Implements structural checks for root `DPS`, `infDPS`, `prest`, `toma`, `serv`, `valores` existence.
- ✅ **Pipeline Integration**: `DpsService.js` executes validation BOTH before and after signing.

### 5. Digital Signature (XmlSigner.js)
- ✅ **Target**: Signs `infDPS` element (`URI="#DPS..."`).
- ✅ **Canonicalization**: Uses **Exclusive Canonicalization** (`http://www.w3.org/2001/10/xml-exc-c14n#`) for both `SignedInfo` and `Transforms`.
- ✅ **Placement**: Signature is appended as a child of `DPS` root, making it a sibling to `infDPS` (Enveloped signature style within the document root).
- ✅ **Reference Check**: `Reference URI` points specifically to the `infDPS` ID attribute.

### 6. Security
- ✅ **Backend Guard**: `cryptoVault.js` explicitly checks `if (typeof window !== 'undefined')` to prevent frontend leaks.
- ✅ **Buffer Handling**: Safe `Buffer` imports for Node.js environment.

## Sample XML Output (Structure)
