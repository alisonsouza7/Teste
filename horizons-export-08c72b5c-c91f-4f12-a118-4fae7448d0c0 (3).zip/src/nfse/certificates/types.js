
/**
 * @fileoverview Type definitions for Certificate Management module.
 * Since we are in a JavaScript-only environment, we use JSDoc to define types.
 */

/**
 * @typedef {Object} CertificateMetadata
 * @property {Date} valid_from - The NotBefore date of the certificate
 * @property {Date} valid_to - The NotAfter date of the certificate
 * @property {string} thumbprint - SHA-1 fingerprint of the certificate (hex)
 * @property {string} [commonName] - Common Name (CN) from Subject
 * @property {string} [issuer] - Common Name of the Issuer
 */

/**
 * @typedef {Object} CertificateInspection
 * @property {Buffer} pfxBuffer - The raw PFX file content
 * @property {string} password - The certificate password
 * @property {CertificateMetadata} metadata - Extracted metadata
 */

/**
 * @typedef {Object} EncryptedCertificateRecord
 * @property {string} company_id - UUID of the company
 * @property {string} pfx_storage_path - Path in Supabase Storage
 * @property {string} pfx_password_encrypted - Encrypted password (Base64 IV+Tag+Cipher)
 * @property {string} thumbprint - SHA-1 fingerprint
 * @property {string} valid_from - ISO string date
 * @property {string} valid_to - ISO string date
 * @property {boolean} is_active - Whether this is the active certificate
 */

/**
 * @typedef {Object} CertificateError
 * @property {string} code - Error code (e.g., 'CERT_EXPIRED', 'INVALID_PASSWORD')
 * @property {string} message - User-friendly error message
 * @property {string} [details] - Technical details (safe to log, maybe unsafe to show user)
 */

export const ErrorCodes = {
  INVALID_PFX: 'INVALID_PFX',
  INVALID_PASSWORD: 'INVALID_PASSWORD',
  CERT_EXPIRED: 'CERT_EXPIRED',
  CERT_NOT_YET_VALID: 'CERT_NOT_YET_VALID',
  STORAGE_ERROR: 'STORAGE_ERROR',
  DB_ERROR: 'DB_ERROR',
  CRYPTO_ERROR: 'CRYPTO_ERROR',
  VALIDATION_ERROR: 'VALIDATION_ERROR'
};

export default {
  ErrorCodes
};
