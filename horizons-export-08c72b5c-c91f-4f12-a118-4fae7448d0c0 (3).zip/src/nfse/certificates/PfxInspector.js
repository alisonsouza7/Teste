
import forge from 'node-forge';

/**
 * PfxInspector: Parses .pfx (PKCS#12) files to validate them and extract metadata.
 */

export const inspectPfx = (pfxArrayBuffer, password) => {
    if (!pfxArrayBuffer) throw new Error('PFX data is missing');
    
    // Convert ArrayBuffer to binary string for forge
    const pfxDer = forge.util.createBuffer(pfxArrayBuffer);
    const pfxAsn1 = forge.asn1.fromDer(pfxDer);
    
    let p12;
    try {
        // Attempt to parse PKCS#12 with password
        // forge expects binary string or buffer for PFX
        p12 = forge.pkcs12.pkcs12FromAsn1(pfxAsn1, false, password);
    } catch (e) {
        if (e.message && (e.message.includes('password') || e.message.includes('MAC'))) {
            throw new Error('Senha do certificado incorreta ou arquivo corrompido.');
        }
        throw new Error('Falha ao ler arquivo PFX: ' + e.message);
    }

    // Iterate bags to find the user certificate (usually inside safeContents)
    // We look for a bag that has a certificate and matches the "localKeyId" or just the first cert
    let cert = null;
    
    // Helper to traverse bags
    const bags = p12.getBags({ bagType: forge.pki.oids.certBag });
    const certBag = bags[forge.pki.oids.certBag];

    if (!certBag || certBag.length === 0) {
        throw new Error('Nenhum certificado encontrado no arquivo PFX.');
    }

    // Usually the last one or the one with a localKeyId is the main one, but taking the first valid one works for A1
    cert = certBag[0].cert;

    if (!cert) {
        throw new Error('Estrutura do certificado inválida.');
    }

    // Extract metadata
    const metadata = {
        valid_from: cert.validity.notBefore,
        valid_to: cert.validity.notAfter,
        subject: cert.subject.attributes.map(attr => ({
            name: attr.name || attr.shortName,
            value: attr.value
        })),
        issuer: cert.issuer.attributes.map(attr => ({
            name: attr.name || attr.shortName,
            value: attr.value
        })),
        serialNumber: cert.serialNumber
    };

    // Calculate Thumbprint (SHA-1 hash of DER encoded cert)
    const certAsn1 = forge.pki.certificateToAsn1(cert);
    const certDer = forge.asn1.toDer(certAsn1).getBytes();
    const md = forge.md.sha1.create();
    md.update(certDer);
    metadata.thumbprint = md.digest().toHex();

    // Extract CN (Common Name) for easier display
    const commonName = cert.subject.getField('CN')?.value || 'Desconhecido';
    metadata.commonName = commonName;

    return metadata;
};

export default {
    inspectPfx
};
