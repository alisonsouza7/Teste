
/**
 * Types and Interfaces for NFSe Anexos Processing
 * 
 * @typedef {Object} FileMetadata
 * @property {string} name - The name of the file
 * @property {number} size - The size of the file in bytes
 * @property {string} [lastModified] - ISO timestamp of last modification
 * 
 * @typedef {Object} SheetData
 * @property {string} sheetName - The name of the worksheet
 * @property {Array<Object>} rows - Array of row objects
 * @property {number} columnCount - Number of columns detected
 * 
 * @typedef {Object} ImportResult
 * @property {string} status - 'success', 'partial', 'error'
 * @property {string[]} processedFiles - List of filenames processed
 * @property {Record<string, number>} linesBySheet - Map of sheet names to line counts
 * @property {Array<{file: string, error: string}>} errors - List of errors encountered
 * 
 * @typedef {Object} Municipio
 * @property {string} codigo_ibge - Código IBGE do município
 * @property {string} nome - Nome do município
 * @property {string} uf - Sigla da UF
 * 
 * @typedef {Object} Pais
 * @property {string} codigo_iso - Código ISO do país
 * @property {string} nome - Nome do país
 * 
 * @typedef {Object} NBS
 * @property {string} nbs_code - Código NBS
 * @property {string} description - Descrição do serviço
 * @property {boolean} active - Se está ativo
 * 
 * @typedef {Object} ServicoNacional
 * @property {number} item
 * @property {number} subitem
 * @property {number} desdobro
 * @property {string} tributacao_nacional_code
 * @property {string} description
 * @property {boolean} active
 * 
 * @typedef {Object} IndOp
 * @property {string} codigo
 * @property {string} descricao
 */

export const Types = {};
