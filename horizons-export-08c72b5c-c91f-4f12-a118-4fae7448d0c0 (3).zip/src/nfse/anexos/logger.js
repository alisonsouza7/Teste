
/**
 * Structured logging for NFSe Anexos
 * Designed for backend/worker usage.
 */

const getTimestamp = () => new Date().toISOString();

const formatLog = (level, type, message, data = {}) => {
  return JSON.stringify({
    timestamp: getTimestamp(),
    level,
    type,
    message,
    data
  });
};

/**
 * Logs file processing start/status
 */
export const logFile = (fileName, size, status) => {
  console.log(formatLog('INFO', 'FILE_STATUS', `Processing file: ${fileName}`, { fileName, size, status }));
};

/**
 * Logs sheet processing statistics
 */
export const logSheet = (fileName, sheetName, rowsRead, rowsInserted, errors) => {
  console.log(formatLog('INFO', 'SHEET_STATS', `Sheet processed: ${sheetName}`, { 
    fileName, 
    sheetName, 
    rowsRead, 
    rowsInserted, 
    errors 
  }));
};

/**
 * Logs error on a specific line
 * sanitized to avoid logging sensitive data
 */
export const logLine = (fileName, sheetName, rowIndex, error) => {
  console.error(formatLog('ERROR', 'LINE_ERROR', `Error on line ${rowIndex}`, { 
    fileName, 
    sheetName, 
    rowIndex, 
    error: typeof error === 'object' ? error.message : error 
  }));
};

/**
 * Logs final summary of the import job
 */
export const logSummary = (totalTime, filesProcessed, totalLines, totalErrors) => {
  console.log(formatLog('INFO', 'JOB_SUMMARY', 'Import job completed', { 
    durationMs: totalTime, 
    filesProcessed, 
    totalLines, 
    totalErrors 
  }));
};

export default {
  logFile,
  logSheet,
  logLine,
  logSummary
};
