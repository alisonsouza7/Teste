
import { normalizeHeader, findColumn, getRowValue } from '../sheetReader';

/**
 * Mapper for Anexo A: Municipios and Paises
 */

const cleanString = (val) => val ? String(val).trim() : null;

export const mapMunicipios = (sheetData) => {
  if (!sheetData || sheetData.length === 0) return [];
  
  // Headers are usually first row (0) if using array-of-arrays, or keys if using json
  // Assuming input is array of objects from sheet_to_json, keys are headers.
  // But to use sheetReader robustly, strictly we might want array-of-arrays.
  // However, sheet_to_json is standard. Let's adapt.
  
  // If sheetData is array of objects, we inspect the keys of the first object to find mappings
  if (sheetData.length === 0) return [];
  const sampleRow = sheetData[0];
  const headers = Object.keys(sampleRow);
  
  const idxCodigo = findColumn(headers, ['codigo', 'codigo ibge', 'cod ibge', 'mun ibge']);
  const idxNome = findColumn(headers, ['nome', 'municipio', 'nome municipio']);
  const idxUf = findColumn(headers, ['uf', 'estado']);
  
  // If we can't find columns by name, we assume standard order:
  // Col 1 (index 0 usually): Codigo
  // Col 2: Municipio
  // Col 3: UF
  // Note: Object keys order isn't guaranteed in JS strictly, but mostly works in V8.
  // Better fallback: if keys are missing, we can't do positional easily with objects.
  // We will assume if not found, we try looking at values.
  
  return sheetData.map(row => {
    // Get values either by found key or fallback logic
    let codigo = null;
    let nome = null;
    let uf = null;

    const values = Object.values(row); // fallback to positional values if keys fail completely
    
    if (idxCodigo !== -1) codigo = row[headers[idxCodigo]];
    else codigo = values[0]; // Fallback pos 0

    if (idxNome !== -1) nome = row[headers[idxNome]];
    else nome = values[1]; // Fallback pos 1

    if (idxUf !== -1) uf = row[headers[idxUf]];
    else uf = values[2]; // Fallback pos 2

    if (!codigo) return null;

    return {
      codigo_ibge: cleanString(codigo),
      nome: cleanString(nome),
      uf: cleanString(uf)
    };
  }).filter(item => item !== null && item.codigo_ibge);
};

export const mapPaises = (sheetData) => {
  if (!sheetData || sheetData.length === 0) return [];
  
  const sampleRow = sheetData[0];
  const headers = Object.keys(sampleRow);
  
  const idxIso = findColumn(headers, ['iso', 'iso2', 'codigo iso']);
  const idxNome = findColumn(headers, ['pais', 'nome', 'nome pais']);
  
  return sheetData.map(row => {
    let codigo_iso = null;
    let nome = null;
    const values = Object.values(row);

    if (idxIso !== -1) codigo_iso = row[headers[idxIso]];
    else codigo_iso = values[0];

    if (idxNome !== -1) nome = row[headers[idxNome]];
    else nome = values[1];

    if (!codigo_iso) return null;

    return {
      codigo_iso: cleanString(codigo_iso),
      nome: cleanString(nome)
    };
  }).filter(item => item !== null && item.codigo_iso);
};

export default {
  mapMunicipios,
  mapPaises
};
