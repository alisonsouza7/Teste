
import { normalizeHeader, findColumn, getRowValue } from '../sheetReader';

/**
 * Mapper for Anexo B: NBS and Servicos Nacionais
 */

const cleanString = (val) => val ? String(val).trim() : null;

export const mapNBS = (sheetData) => {
  if (!sheetData || sheetData.length === 0) return [];
  const headers = Object.keys(sheetData[0]);
  
  const idxCode = findColumn(headers, ['codigo', 'nbs', 'codigo nbs']);
  const idxDesc = findColumn(headers, ['descricao', 'nome']);

  return sheetData.map(row => {
    const values = Object.values(row);
    
    let nbs_code = idxCode !== -1 ? row[headers[idxCode]] : values[0];
    let description = idxDesc !== -1 ? row[headers[idxDesc]] : values[1];

    if (!nbs_code) return null;

    return {
      nbs_code: cleanString(nbs_code),
      description: cleanString(description),
      active: true
    };
  }).filter(i => i !== null);
};

export const mapServicos = (sheetData) => {
  if (!sheetData || sheetData.length === 0) return [];
  const headers = Object.keys(sheetData[0]);
  
  // Specific columns for Servicos Nacionais
  const idxItem = findColumn(headers, ['item']);
  const idxSub = findColumn(headers, ['sub', 'subitem']);
  const idxDesdobro = findColumn(headers, ['desdobro']);
  const idxTrib = findColumn(headers, ['tributacao', 'trib nac', 'cod tributacao']);
  const idxDesc = findColumn(headers, ['descricao', 'desc']);

  return sheetData.map(row => {
    const values = Object.values(row);
    
    // Fallback indices based on common layout: Item(0), Sub(1), Desd(2), Trib(3), Desc(4)
    let item = idxItem !== -1 ? row[headers[idxItem]] : values[0];
    let subitem = idxSub !== -1 ? row[headers[idxSub]] : values[1];
    let desdobro = idxDesdobro !== -1 ? row[headers[idxDesdobro]] : values[2];
    let trib = idxTrib !== -1 ? row[headers[idxTrib]] : values[3];
    let description = idxDesc !== -1 ? row[headers[idxDesc]] : values[4];

    // Basic validation
    if (item === undefined || subitem === undefined) return null;

    return {
      item: parseInt(item) || 0,
      subitem: parseInt(subitem) || 0,
      desdobro: parseInt(desdobro) || 0,
      tributacao_nacional_code: cleanString(trib),
      description: cleanString(description),
      active: true
    };
  }).filter(i => i !== null && i.description);
};

export default {
  mapNBS,
  mapServicos
};
