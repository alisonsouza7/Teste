
import { normalizeHeader, findColumn, getRowValue } from '../sheetReader';

/**
 * Mapper for Anexo C: IndOp
 */

const cleanString = (val) => val ? String(val).trim() : null;

export const mapIndOp = (sheetData) => {
  if (!sheetData || sheetData.length === 0) return [];
  const headers = Object.keys(sheetData[0]);
  
  const idxCodigo = findColumn(headers, ['codigo', 'cod']);
  const idxDesc = findColumn(headers, ['descricao', 'desc']);
  
  return sheetData.map(row => {
    const values = Object.values(row);
    
    let codigo = idxCodigo !== -1 ? row[headers[idxCodigo]] : values[0];
    let descricao = idxDesc !== -1 ? row[headers[idxDesc]] : values[1];

    if (!codigo) return null;

    return {
      codigo: cleanString(codigo),
      descricao: cleanString(descricao)
    };
  }).filter(i => i !== null);
};

export default {
  mapIndOp
};
