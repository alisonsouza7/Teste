
import * as XLSX from 'xlsx';

/**
 * Parser for XLSX files using SheetJS
 */

/**
 * Parses an XLSX buffer and returns a workbook object
 * @param {ArrayBuffer} buffer 
 * @returns {XLSX.WorkBook}
 */
export const parseXlsxBuffer = (buffer) => {
    try {
        return XLSX.read(buffer, { type: 'array' });
    } catch (error) {
        throw new Error(`Failed to parse XLSX buffer: ${error.message}`);
    }
};

/**
 * Gets list of sheet names from a workbook
 * @param {XLSX.WorkBook} workbook 
 * @returns {string[]}
 */
export const getSheetNames = (workbook) => {
    return workbook.SheetNames || [];
};

/**
 * Extracts rows from a specific sheet as JSON objects
 * @param {XLSX.WorkBook} workbook 
 * @param {string} sheetName 
 * @returns {Array<Object>}
 */
export const parseSheet = (workbook, sheetName) => {
    const sheet = workbook.Sheets[sheetName];
    if (!sheet) {
        throw new Error(`Sheet "${sheetName}" not found in workbook.`);
    }

    // Convert to JSON with raw values to avoid auto-formatting issues
    return XLSX.utils.sheet_to_json(sheet, { defval: null });
};

export default {
    parseXlsxBuffer,
    getSheetNames,
    parseSheet
};
