
/**
 * Sheet Reader Utilities
 * Robust header normalization and value extraction.
 */

/**
 * Normalizes a header string for comparison
 * @param {string} header 
 * @returns {string}
 */
export const normalizeHeader = (header) => {
  if (!header) return '';
  return String(header)
    .toLowerCase()
    .normalize('NFD') // Decompose accented characters
    .replace(/[\u0300-\u036f]/g, '') // Remove diacritics
    .replace(/[^\w\s]/g, '') // Remove punctuation
    .trim();
};

/**
 * Finds a column index based on search terms
 * @param {string[]} headers - The actual headers from the sheet row 0
 * @param {string[]} searchTerms - Array of normalized terms to look for
 * @returns {number} - The column index or -1 if not found
 */
export const findColumn = (headers, searchTerms) => {
  if (!headers || headers.length === 0) return -1;
  
  const normalizedHeaders = headers.map(h => normalizeHeader(h));
  
  for (const term of searchTerms) {
    const normalizedTerm = normalizeHeader(term);
    const index = normalizedHeaders.findIndex(h => h === normalizedTerm || h.includes(normalizedTerm));
    if (index !== -1) return index;
  }
  
  return -1;
};

/**
 * Safely gets a value from a row
 * @param {Array} row - The row data
 * @param {number} columnIndex - The identified column index
 * @param {number} fallbackIndex - A fallback positional index if column was not found
 * @returns {any}
 */
export const getRowValue = (row, columnIndex, fallbackIndex) => {
  if (!row) return null;
  
  // Prefer identified column
  if (columnIndex !== -1 && columnIndex < row.length) {
    return row[columnIndex];
  }
  
  // Fallback to position
  if (fallbackIndex !== undefined && fallbackIndex < row.length) {
    return row[fallbackIndex];
  }
  
  return null;
};

export default {
  normalizeHeader,
  findColumn,
  getRowValue
};
