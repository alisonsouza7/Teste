
/**
 * Mappers to transform raw sheet rows into normalized database objects
 */

const cleanString = (val) => val ? String(val).trim() : null;

/**
 * Maps Anexo A (Municipios and Paises)
 * @param {Array<Object>} municipiosSheet 
 * @param {Array<Object>} paisesSheet 
 */
export const mapAnexoA = (municipiosSheet, paisesSheet) => {
    const municipios = municipiosSheet.map(row => {
        // Expected columns: "Código IBGE", "Nome", "UF" (example keys)
        // We handle potential variations in column headers case-insensitively or by position if critical
        // For now assuming headers match requirements or standard layout
        return {
            codigo_ibge: cleanString(row['Código IBGE'] || row['CODIGO_IBGE'] || row['MunIBGE']),
            nome: cleanString(row['Nome'] || row['NOME'] || row['NomeMunicipio']),
            uf: cleanString(row['UF'] || row['uf'])
        };
    }).filter(m => m.codigo_ibge); // Filter out empty rows

    const paises = paisesSheet.map(row => ({
        codigo_iso: cleanString(row['Código ISO'] || row['CODIGO_ISO'] || row['PaisISO']),
        nome: cleanString(row['Nome'] || row['NOME'] || row['NomePais'])
    })).filter(p => p.codigo_iso);

    return { municipios, paises };
};

/**
 * Maps Anexo B (NBS and Servico Nacional)
 * @param {Array<Object>} nbsSheet 
 * @param {Array<Object>} servicosSheet 
 */
export const mapAnexoB = (nbsSheet, servicosSheet) => {
    const nbs = nbsSheet.map(row => ({
        nbs_code: cleanString(row['Código NBS'] || row['CODIGO_NBS']),
        description: cleanString(row['Descrição'] || row['DESCRICAO']),
        active: true
    })).filter(n => n.nbs_code);

    const servicos = servicosSheet.map(row => {
        // Logic to parse item/subitem usually separated by dots "1.01"
        const fullCode = cleanString(row['Código'] || row['CODIGO']);
        let item = null, subitem = null;
        
        if (fullCode) {
            const parts = fullCode.split('.');
            if (parts.length >= 1) item = parseInt(parts[0]);
            if (parts.length >= 2) subitem = parseInt(parts[1]);
        }

        return {
            item,
            subitem,
            desdobro: 0, // Default usually
            tributacao_nacional_code: cleanString(row['Trib Nac'] || row['TRIBUTACAO']),
            description: cleanString(row['Descrição'] || row['DESCRICAO']),
            active: true
        };
    }).filter(s => s.tributacao_nacional_code);

    return { nbs, servicos };
};

/**
 * Maps Anexo C (IndOp - Indicadores Operacionais)
 * @param {Array<Object>} indopSheet 
 */
export const mapAnexoC = (indopSheet) => {
    return indopSheet.map(row => ({
        codigo: cleanString(row['Código'] || row['CODIGO']),
        descricao: cleanString(row['Descrição'] || row['DESCRICAO'])
    })).filter(i => i.codigo);
};

export default {
    mapAnexoA,
    mapAnexoB,
    mapAnexoC
};
