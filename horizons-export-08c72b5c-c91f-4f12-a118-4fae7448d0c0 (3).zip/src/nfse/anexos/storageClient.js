
import { createServiceRoleClient } from '@/lib/supabaseServiceRole';

const supabase = createServiceRoleClient();
const BUCKET_NAME = 'nfse-tabelas';

/**
 * Lists all XLSX files in the bucket with pagination
 * @returns {Promise<string[]>}
 */
export const listAllXlsxFiles = async () => {
  let allFiles = [];
  let page = 0;
  const PAGE_SIZE = 100;
  let hasMore = true;

  while (hasMore) {
    const { data, error } = await supabase.storage
      .from(BUCKET_NAME)
      .list('', {
        limit: PAGE_SIZE,
        offset: page * PAGE_SIZE,
        sortBy: { column: 'name', order: 'asc' }
      });

    if (error) throw error;

    if (!data || data.length === 0) {
      hasMore = false;
    } else {
      // Filter for xlsx/xls
      const xlsxFiles = data.filter(f => f.name && (f.name.endsWith('.xlsx') || f.name.endsWith('.xls')));
      allFiles = [...allFiles, ...xlsxFiles.map(f => f.name)];
      
      if (data.length < PAGE_SIZE) hasMore = false;
      page++;
    }
  }

  return allFiles;
};

export default {
  listAllXlsxFiles
};
