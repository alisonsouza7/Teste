
/* global process */
import { DOMParser } from '@xmldom/xmldom';

/**
 * XmlVerifier
 * 
 * BACKEND ONLY - NO BROWSER
 * 
 * Performs structural validation of XML Signatures.
 * Does NOT perform cryptographic verification (requires public key infrastructure).
 */

if (typeof window !== 'undefined') {
  throw new Error('XmlVerifier must only run on backend');
}

export const hasSignature = (xml) => {
  if (!xml) return false;
  const doc = new DOMParser().parseFromString(xml, 'text/xml');
  const signatures = doc.getElementsByTagNameNS('http://www.w3.org/2000/09/xmldsig#', 'Signature');
  return signatures.length > 0;
};

export const extractReferenceUri = (xml) => {
  if (!xml) return null;
  const doc = new DOMParser().parseFromString(xml, 'text/xml');
  const references = doc.getElementsByTagNameNS('http://www.w3.org/2000/09/xmldsig#', 'Reference');
  
  if (references.length > 0) {
    return references[0].getAttribute('URI');
  }
  return null;
};

export const extractSignatureAlgorithms = (xml) => {
  const info = {
    signatureMethod: null,
    digestMethod: null,
    canonicalizationMethod: null
  };

  if (!xml) return info;
  
  const doc = new DOMParser().parseFromString(xml, 'text/xml');
  
  const sigMethodNode = doc.getElementsByTagNameNS('http://www.w3.org/2000/09/xmldsig#', 'SignatureMethod')[0];
  if (sigMethodNode) info.signatureMethod = sigMethodNode.getAttribute('Algorithm');

  const digestMethodNode = doc.getElementsByTagNameNS('http://www.w3.org/2000/09/xmldsig#', 'DigestMethod')[0];
  if (digestMethodNode) info.digestMethod = digestMethodNode.getAttribute('Algorithm');

  const c14nMethodNode = doc.getElementsByTagNameNS('http://www.w3.org/2000/09/xmldsig#', 'CanonicalizationMethod')[0];
  if (c14nMethodNode) info.canonicalizationMethod = c14nMethodNode.getAttribute('Algorithm');

  return info;
};

export const validateStructure = (xml, expectedReferenceId) => {
  const errors = [];
  
  if (!xml) {
    return { ok: false, errors: ['Empty XML'] };
  }

  const doc = new DOMParser().parseFromString(xml, 'text/xml');
  const signature = doc.getElementsByTagNameNS('http://www.w3.org/2000/09/xmldsig#', 'Signature')[0];

  if (!signature) {
    errors.push('Missing <Signature> element');
    return { ok: false, errors };
  }

  // Check SignedInfo
  const signedInfo = signature.getElementsByTagNameNS('http://www.w3.org/2000/09/xmldsig#', 'SignedInfo')[0];
  if (!signedInfo) {
    errors.push('Missing <SignedInfo> element');
  }

  // Check Reference URI
  const reference = signedInfo?.getElementsByTagNameNS('http://www.w3.org/2000/09/xmldsig#', 'Reference')[0];
  if (reference) {
    const uri = reference.getAttribute('URI');
    if (uri !== `#${expectedReferenceId}`) {
      errors.push(`Invalid Reference URI. Expected "#${expectedReferenceId}", found "${uri}"`);
    }
  } else {
    errors.push('Missing <Reference> element in SignedInfo');
  }

  // Check SignatureValue
  const sigValue = signature.getElementsByTagNameNS('http://www.w3.org/2000/09/xmldsig#', 'SignatureValue')[0];
  if (!sigValue || !sigValue.textContent.trim()) {
    errors.push('Missing or empty <SignatureValue>');
  }

  // Check DigestValue
  const digestValue = reference?.getElementsByTagNameNS('http://www.w3.org/2000/09/xmldsig#', 'DigestValue')[0];
  if (!digestValue || !digestValue.textContent.trim()) {
    errors.push('Missing or empty <DigestValue>');
  }

  // Check X509Data
  const x509Data = signature.getElementsByTagNameNS('http://www.w3.org/2000/09/xmldsig#', 'X509Data')[0];
  if (!x509Data) {
    errors.push('Missing <X509Data> (Certificate info)');
  }

  // Check Referenced Element existence
  // Supports both Id and id
  let referencedElement = doc.getElementById(expectedReferenceId);
  if (!referencedElement) {
      // XPath fallback check for case sensitivity
      const idMatch = doc.documentElement.getAttribute('Id') === expectedReferenceId || 
                      doc.documentElement.getAttribute('id') === expectedReferenceId;
      if (!idMatch) {
         // Deep check manually if getElementById fails (depends on DOCTYPE/Schema which might be missing)
         // Simple traverse
         const allElements = doc.getElementsByTagName('*');
         let found = false;
         for (let i = 0; i < allElements.length; i++) {
             if (allElements[i].getAttribute('Id') === expectedReferenceId || 
                 allElements[i].getAttribute('id') === expectedReferenceId) {
                 found = true;
                 break;
             }
         }
         if (!found) errors.push(`Referenced element with Id="${expectedReferenceId}" not found in document`);
      }
  }

  return {
    ok: errors.length === 0,
    errors
  };
};

export default { hasSignature, extractReferenceUri, extractSignatureAlgorithms, validateStructure };
