
# NFSe XML Digital Signature Module (Backend)

This module handles the creation and verification of XML Digital Signatures (XMLDSig) for Brazilian Electronic Service Invoices (NFS-e).

## Architecture

- **Backend Only**: This code must strictly run in a Node.js environment (Supabase Edge Function or Worker). It contains cryptographic operations and accesses the `CertificateManager`.
- **Enveloped Signature**: The signature is inserted *inside* the XML document being signed.
- **Transforms**: Uses `enveloped-signature` (to exclude the signature element itself from the hash) and `C14N` (Canonicalization) to normalize the XML.

## Configuration

Environment variables in `.env` (Backend):

