
/**
 * certificateAuth.js
 * Middleware-like utility to check permissions for certificate operations.
 * 
 * In a pure frontend app, we don't have true middleware chains like Express.
 * This function validates the user object provided by AuthContext.
 */

export const checkCertificatePermission = (user, userRole) => {
    if (!user) {
        throw new Error('Acesso negado: Usuário não autenticado.');
    }

    // UPDATED: Added 'cliente' to allowed roles to permit users to manage their own certificates.
    // This allows business owners (clients) to upload their own .pfx files.
    const allowedRoles = ['admin', 'contador', 'cliente'];
    
    // In some contexts role might be inside user.app_metadata or user.user_metadata
    // But we rely on the AuthContext providing the resolved role
    // Defaulting to 'cliente' ensures that if a role is missing but user is auth'd, 
    // they are treated as a client (least privilege for auth'd users vs anon).
    const role = userRole || user?.app_metadata?.role || user?.user_metadata?.role || 'cliente';

    if (!allowedRoles.includes(role)) {
        throw new Error('Acesso proibido: Permissão insuficiente para gerenciar certificados digitais.');
    }

    return true;
};

export default checkCertificatePermission;
