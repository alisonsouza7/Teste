
/* global process, window */
import express from 'express';
import { consultarNfsePorDps, fetchNfseXml } from '../services/nfseConsultaService';
import { checkDpsStatus } from '../http/nfseHttpClient';

if (typeof window !== 'undefined') {
  throw new Error('Backend module loaded in browser');
}

const router = express.Router();

// GET /dps/:dps_id/status
router.get('/dps/:dps_id/status', async (req, res) => {
    try {
        const { dps_id } = req.params;
        const { company_id } = req.query; // Pass via query for GET
        
        const result = await checkDpsStatus(company_id, dps_id);
        res.json({
            status: result.status === 200 ? 'AUTHORIZED' : 'PROCESSING',
            http_status: result.status
        });
    } catch (e) {
        res.status(500).json({ error: e.message });
    }
});

// POST /dps/:dps_id/nfse (Orchestrates full flow)
router.post('/dps/:dps_id/nfse', async (req, res) => {
    try {
        const { dps_id } = req.params;
        const { company_id } = req.body;
        
        const result = await consultarNfsePorDps(company_id, dps_id);
        res.json(result);
    } catch (e) {
        res.status(500).json({ error: e.message });
    }
});

// GET /nfse/:chaveAcesso
router.get('/nfse/:chaveAcesso', async (req, res) => {
    try {
        const { chaveAcesso } = req.params;
        const { company_id, dps_id } = req.query;
        
        const result = await fetchNfseXml(company_id, chaveAcesso, dps_id);
        res.json(result);
    } catch (e) {
        res.status(500).json({ error: e.message });
    }
});

export default router;
