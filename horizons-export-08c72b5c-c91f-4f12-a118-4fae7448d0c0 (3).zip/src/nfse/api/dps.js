
/* global process */
import express from 'express';
import { createSignedDps } from '../dps/DpsService';
import { sendDpsToNfse } from '../http/nfseHttpClient';
import { createServiceRoleClient } from '@/lib/supabaseServiceRole';
import { checkIdempotency, updateRequestStatus } from '../services/idempotencyService';
import { updateDpsStatus } from '../services/statusMachine';
import { saveRequestXml, saveSendResponseXml } from '../services/storageService';
import { normalizeHttpError } from '../parsers/XmlResponseParser';
import { resolveProvider } from '../providers/providerResolver';
import nacionalAdnAdapter from '../providers/adapters/nacionalAdnAdapter';

if (typeof window !== 'undefined') {
  throw new Error('API Service must run on backend only');
}

const router = express.Router();
const supabase = createServiceRoleClient();

/**
 * POST /send
 * Full Pipeline:
 * Idempotency -> Build -> Sign -> Resolve Provider -> Send -> Persist
 */
router.post('/send', async (req, res) => {
    const { company_id, payload, idempotencyKey } = req.body;
    
    // 1. Idempotency Check
    let reqRecordId;
    try {
        const { isNew, request } = await checkIdempotency(company_id, idempotencyKey, 'SEND_DPS', payload);
        if (!isNew) {
            // Return cached result if completed, or status if processing
            return res.json({ 
                status: request.status, 
                message: 'Idempotent replay', 
                data: request.response_summary 
            });
        }
        reqRecordId = request.id;
    } catch (e) {
        return res.status(500).json({ error: 'Idempotency failed', details: e.message });
    }

    try {
        // 2. Build & Sign (Includes Validation)
        const dps = await createSignedDps({ company_id, payload });
        
        // 3. Persist "Draft/Signed" State
        // Insert into nfse_dps
        const { data: dpsRecord, error: dbError } = await supabase
            .from('nfse_dps')
            .insert({
                company_id,
                reference_id: dps.referenceId,
                serie: dps.serie,
                ndps: dps.nDPS,
                status: 'SIGNED',
                attempts: 0
            })
            .select()
            .single();

        if (dbError) throw dbError;

        // Save XMLs to Storage
        // Not implemented: saving raw XML before sign, but we save signedXml here
        // await saveRequestXml(company_id, dps.referenceId, dps.signedXml); 

        // 4. Resolve Provider (Municipalization)
        // Extract cLocEmi from payload or use default
        const cLocEmi = payload.servico?.codigo_municipio || '0000000';
        const providerContext = await resolveProvider({ company_id, cLocEmi });
        
        // 5. Update Status -> TRANSMITTING
        await updateDpsStatus(dpsRecord.id, 'TRANSMITTING');

        // 6. Send to Provider
        // Currently hardcoded to Nacional Adapter, but ideally dynamic based on provider_code
        let response;
        if (providerContext.provider_code === 'NACIONAL') {
             response = await nacionalAdnAdapter.sendDps(company_id, dps.signedXml, providerContext);
        } else {
             // Fallback or specific adapter
             response = await sendDpsToNfse(company_id, dps.signedXml);
        }

        // 7. Save Response XML
        if (response.data) {
             await saveSendResponseXml(company_id, dps.referenceId, response.data);
        }

        // 8. Handle Success (Synchronous) or Async Queue
        // Assuming sync success for now (status 200/201)
        const summary = { dpsId: dpsRecord.id, remoteStatus: response.status };
        
        await updateDpsStatus(dpsRecord.id, 'AUTHORIZED', {
            // In real world, parse XML to get Chave
            chaveAcesso: 'MOCK_CHAVE', 
            numeroNfse: '123' 
        });

        await updateRequestStatus(reqRecordId, 'COMPLETED', summary, dpsRecord.id);

        res.json({ ok: true, ...summary });

    } catch (error) {
        // Error Handling
        const normError = normalizeHttpError(error, error.response?.data);
        
        // Update DPS Status to ERROR/REJECTED
        // We need dpsRecord ID if created. If not, just fail request.
        // Simplified: we rely on global try/catch
        
        await updateRequestStatus(reqRecordId, 'FAILED', { error: normError });
        
        console.error('Send Pipeline Failed:', error);
        res.status(500).json({ error: normError });
    }
});

router.get('/requests/:request_id', async (req, res) => {
    const { request_id } = req.params;
    const { data, error } = await supabase
        .from('nfse_requests')
        .select('*')
        .eq('id', request_id)
        .single();
        
    if (error) return res.status(404).json({ error: 'Request not found' });
    res.json(data);
});

// Existing routes...
router.post('/sign', async (req, res) => {
    try {
        const { company_id, payload } = req.body;
        const result = await createSignedDps({ company_id, payload });
        res.json(result);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

export default router;
