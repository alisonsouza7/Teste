
import { supabase } from '@/lib/customSupabaseClient'; // Client for Auth check
import queue from '../anexos/queue';

/**
 * API Endpoints for NFSe Anexos
 * Authenticated access only (admin/contador).
 */

const checkAuth = async () => {
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) throw new Error('Unauthorized');
  
  // Check role
  const { data: roleData } = await supabase
    .from('users')
    .select('tipo')
    .eq('id', user.id)
    .single();
    
  if (!roleData || !['admin', 'contador'].includes(roleData.tipo)) {
    throw new Error('Forbidden: Admin/Contador access required');
  }
  return user;
};

/**
 * POST /api/nfse/anexos/import
 */
export const triggerImport = async (fileNames = []) => {
  try {
    await checkAuth();
    const jobId = await queue.enqueueImportJob({ fileNames });
    return {
      status: 200,
      data: {
        job_id: jobId,
        status: 'pending',
        message: 'Job enqueued successfully'
      }
    };
  } catch (err) {
    return {
      status: err.message.includes('Forbidden') ? 403 : 500,
      error: err.message
    };
  }
};

/**
 * GET /api/nfse/anexos/import/:jobId
 */
export const getImportStatus = async (jobId) => {
  try {
    await checkAuth();
    const job = await queue.getJob(jobId);
    return {
      status: 200,
      data: job
    };
  } catch (err) {
     return {
      status: 500,
      error: err.message
    };
  }
};

export default {
  triggerImport,
  getImportStatus
};
