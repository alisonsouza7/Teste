
/* global process */
import { signXml } from '../xml/XmlSigner';
import { validateStructure, extractSignatureAlgorithms, hasSignature, extractReferenceUri } from '../xml/XmlVerifier';
import { createServiceRoleClient } from '@/lib/supabaseServiceRole';

if (typeof window !== 'undefined') {
  throw new Error('API Service must only run on backend');
}

/**
 * POST /api/nfse/xml/sign/test
 */
export const handleSignTest = async ({ company_id }) => {
  try {
    const referenceId = 'T1';
    const testXml = `<Test Id="${referenceId}"><Value>SystemCheck</Value><Timestamp>${Date.now()}</Timestamp></Test>`;
    
    const result = await signXml({
      company_id,
      xml: testXml,
      referenceId,
      signatureInsertion: 'after',
      idAttribute: 'Id'
    });

    const algorithms = extractSignatureAlgorithms(result.signedXml);
    const refUri = extractReferenceUri(result.signedXml);

    return {
      status: "OK",
      thumbprint: result.thumbprint,
      hasSignature: hasSignature(result.signedXml),
      referenceUri: refUri,
      algorithms,
      signaturePlacement: result.signaturePlacement,
      structureOk: result.structureOk,
      structureErrors: result.structureErrors,
      signedXmlPreview: {
        start: result.signedXml.substring(0, 300),
        end: result.signedXml.substring(result.signedXml.length - 100)
      }
    };
  } catch (error) {
    return {
      status: "ERROR",
      message: error.message
    };
  }
};

/**
 * POST /api/nfse/xml/sign
 */
export const handleSign = async ({ company_id, xml, referenceId }) => {
  try {
    const result = await signXml({
      company_id,
      xml,
      referenceId
    });

    const algorithms = extractSignatureAlgorithms(result.signedXml);
    const refUri = extractReferenceUri(result.signedXml);

    return {
      success: true,
      hasSignature: true,
      referenceUri: refUri,
      algorithms,
      signedXml: result.signedXml,
      signaturePlacement: result.signaturePlacement
    };
  } catch (error) {
    return {
      success: false,
      error: error.message
    };
  }
};

export const handleVerifyStructure = async ({ xml, expectedReferenceId }) => {
  try {
    const validation = validateStructure(xml, expectedReferenceId);
    return validation;
  } catch (error) {
    return {
      ok: false,
      errors: [error.message]
    };
  }
};

export default { handleSignTest, handleSign, handleVerifyStructure };
