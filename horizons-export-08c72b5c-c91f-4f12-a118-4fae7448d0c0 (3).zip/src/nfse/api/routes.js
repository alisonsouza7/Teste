
/* global process, window */
import express from 'express';
import dpsRouter from './dps';
import consultaRouter from './consulta';

if (typeof window !== 'undefined') {
  throw new Error('Backend module loaded in browser');
}

const router = express.Router();

router.use('/dps', dpsRouter);
router.use('/consulta', consultaRouter);

// Placeholders for ops/eventos if not existing
router.use('/ops', (req, res) => res.status(501).send('Not Implemented'));
router.use('/eventos', (req, res) => res.status(501).send('Not Implemented'));

export default router;
