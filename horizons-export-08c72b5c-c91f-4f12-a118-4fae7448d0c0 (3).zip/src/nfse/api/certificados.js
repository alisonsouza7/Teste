
import * as Manager from '../certificates/CertificateManager';
import Validation from '../certificates/validation';
import { logger } from '../certificates/logger';

/**
 * API Emulation Layer
 * Emulates REST endpoints locally by calling the Manager service.
 * Handles request parsing, permission checks, and response formatting.
 */

// Helper: Ensure user has permissions (Admin/Contador)
const checkPermissions = (user) => {
  // In a real backend, we check req.user.role
  // Here we assume the caller (frontend) passes the user object
  const allowedRoles = ['admin', 'contador', 'administrador'];
  const userRole = user?.app_metadata?.role || user?.role || user?.tipo;
  
  // Also check public.users table if available in context, but simpler here:
  if (!allowedRoles.includes(userRole)) {
     // Special case: Proprietario might be allowed for their own company?
     // Constraint says "restricted to admin/contador"
     // We will stick to strict constraint unless user is owner (optional)
     throw new Error('Acesso negado: Requer permissão de Admin ou Contador.');
  }
};

/**
 * POST /api/nfse/certificados/upload
 */
export const upload = async ({ user, companyId, file, password }) => {
  try {
    checkPermissions(user);
    Validation.validateCompanyId(companyId);
    Validation.validateFile(file);

    // Convert Browser File to ArrayBuffer
    const pfxBuffer = await file.arrayBuffer();

    const result = await Manager.upsertCertificate({
      companyId,
      pfxBuffer,
      password,
      filename: file.name
    });

    return { status: 200, data: result };

  } catch (error) {
    const sanitized = Validation.sanitizeError(error);
    return { status: 400, error: sanitized };
  }
};

/**
 * GET /api/nfse/certificados/:company_id
 */
export const get = async ({ user, companyId }) => {
  try {
    checkPermissions(user);
    const data = await Manager.getCertificateMeta(companyId);
    
    if (!data) return { status: 404, error: 'Certificado não encontrado.' };
    return { status: 200, data };

  } catch (error) {
    return { status: 500, error: error.message };
  }
};

/**
 * POST /api/nfse/certificados/:company_id/test
 */
export const test = async ({ user, companyId }) => {
  try {
    checkPermissions(user);
    
    const cert = await Manager.getActiveCertificate(companyId);
    if (!cert) {
      logger.auditTestFail(companyId, 'NOT_FOUND');
      return { status: 404, message: 'Nenhum certificado ativo.' };
    }

    try {
      Validation.validateDates(cert.metadata.valid_from, cert.metadata.valid_to);
      
      const now = new Date();
      const validTo = cert.metadata.valid_to;
      const days = Math.ceil((validTo - now) / (1000 * 60 * 60 * 24));

      logger.auditTestOk(companyId, cert.metadata.thumbprint);

      return {
        status: 200,
        data: {
          status: 'OK',
          valid_from: cert.metadata.valid_from,
          valid_to: cert.metadata.valid_to,
          dias_para_expirar: days
        }
      };

    } catch (dateError) {
      logger.auditTestFail(companyId, dateError.code);
      return { status: 400, error: dateError.message };
    }

  } catch (error) {
    logger.auditTestFail(companyId, 'INTERNAL_ERROR');
    return { status: 500, error: error.message };
  }
};

/**
 * POST /api/nfse/certificados/:company_id/deactivate
 */
export const deactivate = async ({ user, companyId }) => {
  try {
    checkPermissions(user);
    await Manager.deactivateCertificate(companyId);
    return { status: 200, message: 'Certificado desativado com sucesso.' };
  } catch (error) {
    return { status: 500, error: error.message };
  }
};

// Map as if they were routes for easier import
export default {
  upload,
  get,
  test,
  deactivate
};
