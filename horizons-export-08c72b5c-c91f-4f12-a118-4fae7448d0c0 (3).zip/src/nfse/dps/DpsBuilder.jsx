
/* global process, window */
import { randomUUID } from 'crypto';
import { validateServerEnv } from '@/utils/env.server';
import { getNextDpsNumber } from './dpsCounter';

if (typeof window !== 'undefined') {
  throw new Error('Backend module loaded in browser');
}

const getIsoWithTimezone = (dateStr) => {
    const date = dateStr ? new Date(dateStr) : new Date();
    const tzo = -date.getTimezoneOffset();
    const dif = tzo >= 0 ? '+' : '-';
    const pad = (num) => {
        const norm = Math.floor(Math.abs(num));
        return (norm < 10 ? '0' : '') + norm;
    };
    return date.getFullYear() +
        '-' + pad(date.getMonth() + 1) +
        '-' + pad(date.getDate()) +
        'T' + pad(date.getHours()) +
        ':' + pad(date.getMinutes()) +
        ':' + pad(date.getSeconds()) +
        dif + pad(tzo / 60) + ':' + pad(tzo % 60);
};

export const buildDpsXml = async (payload, company_id) => {
  const env = validateServerEnv();
  
  // 1. Get Counter
  const { serie, nDPS } = await getNextDpsNumber(company_id);
  
  // 2. Generate IDs
  const uuid = randomUUID().replace(/-/g, '');
  const dpsId = `DPS${uuid}`;
  const referenceId = dpsId;

  // 3. Format Data
  const { prestador, tomador, servico, dataEmissao, valores } = payload;
  const dhEmi = getIsoWithTimezone(dataEmissao);
  const dCompet = (dataEmissao ? new Date(dataEmissao) : new Date()).toISOString().split('T')[0];
  
  // 4. XML Construction
  const NS_NFSE = 'http://www.sped.fazenda.gov.br/nfse';
  const NS_DSIG = 'http://www.w3.org/2000/09/xmldsig#';
  
  const xml = `
<DPS xmlns="${NS_NFSE}" xmlns:ds="${NS_DSIG}" versao="${env.nfseDpsVersao}">
  <infDPS Id="${dpsId}" versao="${env.nfseDpsVersao}">
    <tpAmb>${env.nfseTpAmb}</tpAmb>
    <dhEmi>${dhEmi}</dhEmi>
    <verAplic>${env.nfseDpsVerAplicacao}</verAplic>
    <serie>${serie}</serie>
    <nDPS>${nDPS}</nDPS>
    <dCompet>${dCompet}</dCompet>
    <tpEmit>${env.nfseDpsTpEmit}</tpEmit>
    <cLocEmi>${servico.codigo_municipio || '0000000'}</cLocEmi>
    <prest>
      <cnpj>${prestador.cnpj_cpf.replace(/\D/g,'')}</cnpj>
      ${prestador.inscricao_municipal ? `<inscMun>${prestador.inscricao_municipal}</inscMun>` : ''}
    </prest>
    <toma>
      <cpfCnpj>
         ${tomador.cnpj_cpf.length > 11 
           ? `<cnpj>${tomador.cnpj_cpf.replace(/\D/g,'')}</cnpj>`
           : `<cpf>${tomador.cnpj_cpf.replace(/\D/g,'')}</cpf>`}
      </cpfCnpj>
      ${tomador.razao_social ? `<xNome>${tomador.razao_social}</xNome>` : ''}
    </toma>
    <serv>
      <locPrest>
         <cLocPrestacao>${servico.codigo_municipio || '0000000'}</cLocPrestacao>
      </locPrest>
      <cServ>
         <cTribNac>${servico.item_lista_servico}</cTribNac>
         <xDescServ>${servico.discriminacao}</xDescServ>
      </cServ>
      <valores>
        <vServ>${Number(valores?.vServ || servico.valor || 0).toFixed(2)}</vServ>
      </valores>
    </serv>
  </infDPS>
</DPS>
`.trim();

  return { xml, referenceId, serie, nDPS };
};

export default { buildDpsXml };
