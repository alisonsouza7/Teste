
/* global process, window */
import { buildDpsXml } from './DpsBuilder';
import { validateXmlAgainstXsd } from './DpsValidator';
import { signXml } from '../xml/XmlSigner';
import { validateStructure } from '../xml/XmlVerifier';
import { validateServerEnv } from '@/utils/env.server';

if (typeof window !== 'undefined') {
  throw new Error('Backend module loaded in browser');
}

export const createSignedDps = async ({ company_id, payload }) => {
  const env = validateServerEnv();

  // 1. Build
  const { xml: rawXml, referenceId, serie, nDPS } = await buildDpsXml(payload, company_id);

  // 2. Validate PRE-SIGNATURE
  const preValidation = validateXmlAgainstXsd(rawXml, env.nfseDpsXsdPath);
  if (!preValidation.ok) {
    throw new Error(`Pre-Sign Validation Failed: ${JSON.stringify(preValidation.errors)}`);
  }

  // 3. Sign
  const { signedXml, thumbprint } = await signXml({
    company_id,
    xml: rawXml,
    referenceId
  });

  // 4. Validate Structure
  const structureValidation = validateStructure(signedXml, referenceId);
  if (!structureValidation.ok) {
    throw new Error(`Signature Structure Failed: ${structureValidation.errors.join(', ')}`);
  }

  // 5. Validate POST-SIGNATURE
  const postValidation = validateXmlAgainstXsd(signedXml, env.nfseDpsXsdPath);
  if (!postValidation.ok) {
    throw new Error(`Post-Sign Validation Failed: ${JSON.stringify(postValidation.errors)}`);
  }

  return {
    referenceId,
    serie,
    nDPS,
    xsdValidation: { pre: preValidation, post: postValidation },
    signature: { ok: true, thumbprint },
    signedXml
  };
};

export default { createSignedDps };
