
/**
 * Builds the 42-digit DPS Identifier
 * Format: "DPS" + cLocEmi (7) + tpInscr (1) + inscrFed (14) + serie (5) + nDPS (9)
 */
export const buildDpsId = ({ cLocEmi, tpInscr, inscrFed, serie, nDPS }) => {
    // Pad values
    const cLoc = cLocEmi.toString().padStart(7, '0');
    const tp = tpInscr.toString();
    const inscr = inscrFed.toString().replace(/\D/g,'').padStart(14, '0');
    const ser = serie.toString().padStart(5, '0');
    const num = nDPS.toString().padStart(9, '0');
    
    return `DPS${cLoc}${tp}${inscr}${ser}${num}`;
};

export default { buildDpsId };
