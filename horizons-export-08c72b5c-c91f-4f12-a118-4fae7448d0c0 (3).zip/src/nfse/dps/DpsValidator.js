
/* global process, window */
import fs from 'fs';
import path from 'path';
import libxmljs from 'libxmljs2'; 
import { validateServerEnv } from '@/utils/env.server';

if (typeof window !== 'undefined') {
  throw new Error('Backend module loaded in browser');
}

export const validateXmlAgainstXsd = (xml, xsdPath) => {
  const env = validateServerEnv();
  const xsdDir = env.nfseXsdDir;

  try {
    if (!fs.existsSync(xsdPath)) {
      return { ok: false, errors: [{ message: `XSD not found at ${xsdPath}` }] };
    }

    const xsdContent = fs.readFileSync(xsdPath, 'utf8');

    const processedXsd = xsdContent.replace(
      /schemaLocation=["']([^"']+)["']/g, 
      (match, filename) => {
        if (filename.startsWith('http')) return match;
        const absPath = path.resolve(xsdDir, filename);
        return `schemaLocation="${absPath}"`;
      }
    );

    const xsdDoc = libxmljs.parseXml(processedXsd);
    const xmlDoc = libxmljs.parseXml(xml);

    if (!xmlDoc.validate(xsdDoc)) {
      const errors = xmlDoc.validationErrors.map(e => ({
        message: e.message,
        line: e.line,
        column: e.column
      }));
      return { ok: false, errors };
    }

    return { ok: true, errors: [] };

  } catch (error) {
    console.error('XSD Validation Error:', error.message);
    return { ok: false, errors: [{ message: error.message }] };
  }
};

export default { validateXmlAgainstXsd };
