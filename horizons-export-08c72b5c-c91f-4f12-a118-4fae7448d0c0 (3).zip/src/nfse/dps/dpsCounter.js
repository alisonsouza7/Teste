
import { createServiceRoleClient } from '@/lib/supabaseServiceRole';
import { validateServerEnv } from '@/utils/env.server';

export const getNextDpsNumber = async (company_id) => {
    if (!company_id) throw new Error('Company ID required');

    const supabase = createServiceRoleClient();
    if (!supabase) {
        throw new Error('Service Role Client unavailable. Cannot generate DPS number.');
    }

    const env = validateServerEnv();
    const defaultSerie = parseInt(env.nfseDpsSerie || '80000');
    
    const { data, error } = await supabase.rpc('rpc_get_next_dps', {
        p_company_id: company_id,
        p_serie: defaultSerie
    });

    if (error || !data || data.length === 0) {
        throw new Error(`Failed to get next DPS number: ${error?.message}`);
    }

    const result = data[0]; 

    return { serie: result.serie, nDPS: result.n_dps };
};

export default { getNextDpsNumber };
