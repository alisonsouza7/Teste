
import { DOMParser } from '@xmldom/xmldom';

if (typeof window !== 'undefined') {
  throw new Error('XmlResponseParser must run on backend only');
}

export const detectIfXml = (text) => {
    return typeof text === 'string' && text.trim().startsWith('<');
};

export const extractSoapFault = (xmlText) => {
    try {
        const doc = new DOMParser().parseFromString(xmlText, 'text/xml');
        const fault = doc.getElementsByTagName('Fault')[0] || 
                      doc.getElementsByTagName('soap:Fault')[0] ||
                      doc.getElementsByTagName('S:Fault')[0];
        
        if (fault) {
            const code = fault.getElementsByTagName('faultcode')[0]?.textContent || 'SOAP_FAULT';
            const string = fault.getElementsByTagName('faultstring')[0]?.textContent || 'Unknown Fault';
            return { code, message: string };
        }
    } catch (e) {
        // Ignore parsing errors
    }
    return null;
};

export const extractErrorCodes = (xmlText) => {
    // Looks for standard NFSe <Mensagem> or <Erro> tags
    // This is a generic heuristic; real implementations need provider-specific parsers
    const errors = [];
    try {
        const doc = new DOMParser().parseFromString(xmlText, 'text/xml');
        
        // National Standard
        const messages = doc.getElementsByTagName('Mensagem');
        for (let i = 0; i < messages.length; i++) {
             const code = messages[i].getElementsByTagName('Codigo')[0]?.textContent;
             const desc = messages[i].getElementsByTagName('Descricao')[0]?.textContent;
             if (code) errors.push({ code, message: desc });
        }

    } catch (e) {
        // Ignore
    }
    return errors;
};

export const normalizeHttpError = (error, responseData) => {
    // 1. Network/System Errors
    if (error.code === 'ECONNRESET') return { type: 'TRANSIENT', code: 'NETWORK_RESET', message: 'Connection reset' };
    if (error.code === 'ETIMEDOUT') return { type: 'TRANSIENT', code: 'TIMEOUT', message: 'Connection timed out' };

    // 2. HTTP Status Errors
    if (error.response) {
        const status = error.response.status;
        if (status >= 500) return { type: 'TRANSIENT', code: `HTTP_${status}`, message: 'Server Error' };
        if (status === 429) return { type: 'TRANSIENT', code: 'RATE_LIMIT', message: 'Too Many Requests' };
        if (status === 401 || status === 403) return { type: 'FATAL', code: 'AUTH_ERROR', message: 'Authentication Failed' };
    }

    // 3. XML Content Errors (SOAP Faults)
    if (responseData && detectIfXml(responseData)) {
        const soapFault = extractSoapFault(responseData);
        if (soapFault) {
            return { type: 'FATAL', code: soapFault.code, message: soapFault.message };
        }
        
        const bizErrors = extractErrorCodes(responseData);
        if (bizErrors.length > 0) {
            return { type: 'FATAL', code: bizErrors[0].code, message: bizErrors[0].message, details: bizErrors };
        }
    }

    return { type: 'UNKNOWN', code: 'UNKNOWN_ERROR', message: error.message };
};

export default { normalizeHttpError };
