import { supabase } from '@/lib/customSupabaseClient';
import { addDays, addWeeks, addMonths, addYears, format, isAfter, isBefore, isValid, parseISO } from 'date-fns';

/**
 * Calculates the next date based on recurrence rules.
 * Handles different frequency types: Daily, Weekly, Monthly, Yearly.
 * 
 * @param {string|Date} currentDateStr - The baseline date
 * @param {string} type - 'diario', 'semanal', 'mensal', 'anual'
 * @param {number} interval - Step size (e.g., 2 for "every 2 weeks")
 * @returns {Date|null} The calculated next date or null if invalid
 */
const calculateNextDate = (currentDateStr, type, interval = 1) => {
    const date = typeof currentDateStr === 'string' ? parseISO(currentDateStr) : currentDateStr;
    if (!isValid(date)) return null;

    switch (type) {
        case 'diario': return addDays(date, interval);
        case 'semanal': return addWeeks(date, interval);
        case 'mensal': return addMonths(date, interval);
        case 'anual': return addYears(date, interval);
        default: return addMonths(date, interval);
    }
};

/**
 * Creates a new recurrence rule linked to a template transaction.
 * This is typically called immediately after a user saves a new transaction
 * with the "Repeat" toggle enabled.
 * 
 * @param {string} templateTxId - UUID of the source transaction
 * @param {object} config - Configuration object { recurrence_type, interval_count, end_date, ... }
 */
export const createRecurrence = async (templateTxId, config) => {
    if (!templateTxId || !config) throw new Error("Template ID and config are required");

    // 1. Fetch the template to determine the baseline start date
    // We use the transaction's competence date as the anchor.
    const { data: tx, error: txError } = await supabase
        .from('finance_transactions')
        .select('data_competencia, company_id')
        .eq('id', templateTxId)
        .single();
    
    if (txError) throw txError;

    const startDate = config.start_date || tx.data_competencia;
    
    // 2. Calculate the FIRST execution date. 
    // Usually, if I create a transaction for Jan 1st and repeat monthly, 
    // the next one should be Feb 1st.
    const nextDate = calculateNextDate(startDate, config.recurrence_type, config.interval_count);

    const payload = {
        company_id: tx.company_id,
        template_transaction_id: templateTxId,
        recurrence_type: config.recurrence_type, 
        interval_count: Number(config.interval_count) || 1,
        start_date: startDate,
        end_date: config.end_date || null,
        next_execution_date: format(nextDate, 'yyyy-MM-dd'),
        is_active: config.is_active ?? true,
        metadata: config.metadata || {}
    };

    const { data, error } = await supabase
        .from('finance_recurrences')
        .insert(payload)
        .select()
        .single();

    if (error) throw error;
    
    // 3. Link the template transaction to this new recurrence rule
    // This allows UI to show "Recurrent" badge on the original tx too.
    await supabase
        .from('finance_transactions')
        .update({ recurrence_id: data.id })
        .eq('id', templateTxId);

    return data;
};

/**
 * Checks for due recurrences and generates transactions.
 * Designed to be idempotent: running it multiple times won't create duplicates.
 * 
 * Logic Flow:
 * 1. Find active rules where `next_execution_date` <= Today.
 * 2. For each rule:
 *    a. Check if a transaction already exists for (Rule ID + Target Date).
 *    b. If NO -> Insert new transaction (Copy of template).
 *    c. Update Rule's `next_execution_date` to the subsequent period.
 * 
 * @param {string} companyId 
 * @returns {object} { generated: number }
 */
export const generateNextOccurrences = async (companyId) => {
    const today = new Date().toISOString().split('T')[0];

    // 1. Fetch active recurrences due for execution
    const { data: recurrences, error } = await supabase
        .from('finance_recurrences')
        .select(`
            *,
            template:finance_transactions!finance_recurrences_template_transaction_id_fkey(*)
        `)
        .eq('company_id', companyId)
        .eq('is_active', true)
        .lte('next_execution_date', today);

    if (error) throw error;
    if (!recurrences || recurrences.length === 0) return { generated: 0 };

    let generatedCount = 0;
    const updates = [];

    for (const rec of recurrences) {
        // Safety check: if template is deleted (soft delete), we disable the recurrence
        if (!rec.template) {
            updates.push(supabase.from('finance_recurrences').update({ is_active: false }).eq('id', rec.id));
            continue;
        }

        // Check global end_date constraint
        if (rec.end_date && isAfter(parseISO(rec.next_execution_date), parseISO(rec.end_date))) {
            updates.push(supabase.from('finance_recurrences').update({ is_active: false }).eq('id', rec.id));
            continue;
        }

        // Prepare new transaction data based on template
        const newDate = rec.next_execution_date;
        const newTx = {
            ...rec.template,
            id: undefined, // Remove ID to generate new UUID
            created_at: undefined,
            updated_at: undefined,
            deleted_at: null,
            liquidado: false, // Auto-generated tx are usually Pending
            data_liquidacao: null,
            data_competencia: newDate,
            vencimento: newDate, // Simplified assumption: Due Date = Competence Date
            data_lancamento: today,
            recurrence_id: rec.id, // Link back to rule
            origem: 'recorrencia_automatica',
            descricao: `${rec.template.descricao} (Automático)` // Visual cue
        };

        // DEDUPLICATION CRITICAL STEP
        // Check if we already created a transaction for this Rule + Date
        const { data: existing } = await supabase
            .from('finance_transactions')
            .select('id')
            .eq('recurrence_id', rec.id)
            .eq('data_competencia', newDate)
            .maybeSingle();

        // Calculate subsequent date for update
        const subsequentDate = calculateNextDate(newDate, rec.recurrence_type, rec.interval_count);
        const nextDateStr = format(subsequentDate, 'yyyy-MM-dd');

        if (!existing) {
            // INSERT
            const { error: insertError } = await supabase
                .from('finance_transactions')
                .insert(newTx);
            
            if (!insertError) {
                generatedCount++;
                // Update next execution date
                updates.push(
                    supabase.from('finance_recurrences')
                        .update({ next_execution_date: nextDateStr })
                        .eq('id', rec.id)
                );
            } else {
                console.error("Failed to insert recurring tx", insertError);
            }
        } else {
            // ALREADY EXISTS
            // Just advance the date so we don't get stuck checking this one forever
            updates.push(
                supabase.from('finance_recurrences')
                    .update({ next_execution_date: nextDateStr })
                    .eq('id', rec.id)
            );
        }
    }

    // Execute all updates in parallel
    await Promise.all(updates);
    return { generated: generatedCount };
};

export const updateRecurrenceStatus = async (recurrenceId, isActive) => {
    const { error } = await supabase
        .from('finance_recurrences')
        .update({ is_active: isActive })
        .eq('id', recurrenceId);
    if (error) throw error;
};

export const deleteRecurrence = async (recurrenceId) => {
    // Hard delete of rule.
    // Generated transactions remain (history preservation), 
    // but their recurrence_id might point to nowhere unless FK is ON DELETE SET NULL.
    // Our schema used ON DELETE CASCADE for template_id, but usually transactions->recurrence is set nullable.
    const { error } = await supabase
        .from('finance_recurrences')
        .delete()
        .eq('id', recurrenceId);
    if (error) throw error;
};