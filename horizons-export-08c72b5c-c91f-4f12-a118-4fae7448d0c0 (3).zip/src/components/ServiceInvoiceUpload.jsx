
import React, { useState, useRef, useEffect } from 'react';
import { supabase } from '@/lib/customSupabaseClient';
import { useCompany } from '@/contexts/CompanyContext';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { useToast } from '@/components/ui/use-toast';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Upload, Loader2, AlertTriangle } from 'lucide-react';
import { parseNfseXml } from '@/lib/xmlParsingUtils';
import AccountSelectorDialog from '@/components/finance/AccountSelectorDialog';
import { useCompanyFiscalData } from '@/hooks/useCompanyFiscalData';

const ServiceInvoiceUpload = ({ onUploadSuccess, open: controlledOpen, onOpenChange: setControlledOpen }) => {
    const { selectedCompany } = useCompany();
    const { user } = useAuth();
    const { toast } = useToast();
    const { fiscalData } = useCompanyFiscalData();

    // Internal state for uncontrolled usage
    const [internalOpen, setInternalOpen] = useState(false);
    const isControlled = controlledOpen !== undefined;
    const isOpen = isControlled ? controlledOpen : internalOpen;
    const setIsOpen = isControlled ? setControlledOpen : setInternalOpen;

    const [isUploading, setIsUploading] = useState(false);
    const fileInputRef = useRef(null);

    // Account selection
    const [selectedAccount, setSelectedAccount] = useState(null);
    const [showAccountSelector, setShowAccountSelector] = useState(false);
    const [needsAccountSelection, setNeedsAccountSelection] = useState(false);

    const [formData, setFormData] = useState({
        numero_nota: '',
        serie: '',
        data_emissao: new Date().toISOString().split('T')[0],
        valor_servico: '',
        descricao_servico: '',
        emitente_documento: '',
        emitente_nome: '',
        tomador_documento: '',
        tomador_nome: ''
    });
    const [selectedFile, setSelectedFile] = useState(null);

    useEffect(() => {
        if (isOpen && selectedCompany) {
            checkAccounts();
        }
    }, [isOpen, selectedCompany]);

    const checkAccounts = async () => {
        try {
            const { data, error } = await supabase
                .from('finance_accounts')
                .select('id, nome_conta')
                .eq('company_id', selectedCompany.id)
                .is('deleted_at', null);

            if (error) throw error;

            if (data && data.length === 1) {
                setSelectedAccount(data[0]);
                setNeedsAccountSelection(false);
            } else if (data && data.length > 1) {
                setNeedsAccountSelection(true);
                setSelectedAccount(null);
            } else {
                setNeedsAccountSelection(false);
                setSelectedAccount(null);
            }
        } catch (err) {
            console.error('Error checking accounts:', err);
        }
    };

    const parseXML = async (file) => {
        try {
            const text = await file.text();
            const parser = new DOMParser();
            const xmlDoc = parser.parseFromString(text, "text/xml");

            const parserError = xmlDoc.getElementsByTagName("parsererror");
            if (parserError.length > 0) {
                toast({ 
                    variant: "destructive", 
                    title: "Erro de Leitura", 
                    description: "Não foi possível ler o XML da NFS-e." 
                });
                return;
            }

            const extractedData = parseNfseXml(xmlDoc);

            if (extractedData.numero_nota) {
                setFormData(prev => ({
                    ...prev,
                    ...extractedData,
                    data_emissao: extractedData.data_emissao || prev.data_emissao
                }));
                toast({ title: "XML Processado", description: "Dados extraídos com sucesso." });
            } else {
                toast({ variant: "destructive", title: "Dados incompletos", description: "Não foi possível identificar o número da nota." });
            }

        } catch (e) {
            console.error(e);
            toast({ variant: "destructive", title: "Erro", description: "Falha ao processar arquivo XML." });
        }
    };

    const handleFileChange = async (e) => {
        const file = e.target.files[0];
        if (!file) return;
        
        if (file.type !== 'text/xml' && !file.name.endsWith('.xml')) {
             toast({ 
                 variant: "destructive", 
                 title: "Arquivo inválido", 
                 description: "Selecione apenas arquivos XML." 
             });
             e.target.value = ''; 
             return;
        }
        
        setSelectedFile(file);
        await parseXML(file);
    };

    const ensurePartyExists = async (companyId, documento, nome) => {
        if (!documento) return null;
        try {
            const { data: existing } = await supabase
                .from('finance_parties')
                .select('id')
                .eq('company_id', companyId)
                .eq('documento', documento)
                .is('deleted_at', null)
                .maybeSingle();
            
            if (existing) return existing.id;

            const { data: newParty, error } = await supabase
                .from('finance_parties')
                .insert({
                    company_id: companyId,
                    tipo: 'cliente',
                    nome: nome || 'Importado via XML',
                    documento: documento
                })
                .select('id')
                .single();
            
            if (error) return null;
            return newParty.id;
        } catch (err) {
            return null;
        }
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        
        if (!selectedAccount && needsAccountSelection) {
            setShowAccountSelector(true);
            return;
        }
        
        processSubmit();
    };

    const processSubmit = async () => {
        if (!selectedCompany || !user) return;

        const companyCnpj = selectedCompany.cnpj_cpf.replace(/\D/g, '');
        const invoiceCnpj = formData.emitente_documento ? formData.emitente_documento.replace(/\D/g, '') : '';

        if (!invoiceCnpj || companyCnpj !== invoiceCnpj) {
             toast({ 
                 variant: "destructive", 
                 title: "Erro de Validação", 
                 description: "Esta NFS-e não pertence à empresa selecionada." 
             });
             return;
        }

        // Validate limit
        const val = parseFloat(String(formData.valor_servico).replace('.', '').replace(',', '.'));
        const limit = fiscalData?.limite_faturamento_anual;
        const currentTotal = fiscalData?.faturamento_12_meses || 0;
        
        if (limit && limit > 0 && (currentTotal + val) > limit) {
             toast({
                 variant: "warning",
                 title: "Atenção: Limite de Faturamento",
                 description: "Esta nota pode fazer com que a empresa exceda o limite do regime tributário."
             });
        }

        setIsUploading(true);
        try {
            const partyId = await ensurePartyExists(selectedCompany.id, formData.tomador_documento, formData.tomador_nome);

            let fileUrl = null;
            if (selectedFile) {
                const fileExt = 'xml';
                const fileName = `${selectedCompany.id}/${Date.now()}_${formData.numero_nota}.${fileExt}`;
                
                const { error: uploadError } = await supabase.storage
                    .from('service-invoices')
                    .upload(fileName, selectedFile);

                if (uploadError) throw uploadError;
                fileUrl = fileName; 
            }

            const payload = {
                company_id: selectedCompany.id,
                user_id: user.id,
                numero_nota: formData.numero_nota,
                serie: formData.serie || null,
                emitente_documento: formData.emitente_documento,
                emitente_nome: formData.emitente_nome || null,
                tomador_documento: formData.tomador_documento,
                tomador_nome: formData.tomador_nome || null,
                data_emissao: formData.data_emissao,
                valor_servico: val,
                descricao_servico: formData.descricao_servico,
                arquivo_url: fileUrl,
                status: 'valida',
                party_id: partyId
            };

            const { data: invoiceData, error: dbError } = await supabase
                .from('service_invoices')
                .insert(payload)
                .select('id')
                .single();

            if (dbError) {
                if (dbError.code === '23505') {
                    throw new Error("Esta NFS-e já foi cadastrada anteriormente.");
                }
                throw dbError;
            }

            const { data: categoryData } = await supabase
                .from('finance_chart_of_accounts')
                .select('id')
                .eq('company_id', selectedCompany.id)
                .eq('tipo', 'receita')
                .ilike('nome_conta', '%Prestação de Serviços%')
                .is('deleted_at', null)
                .limit(1)
                .maybeSingle();
            
            let categoryId = categoryData?.id;
            if (!categoryId) {
                 const { data: fallbackCat } = await supabase
                    .from('finance_chart_of_accounts')
                    .select('id')
                    .eq('company_id', selectedCompany.id)
                    .eq('tipo', 'receita')
                    .is('deleted_at', null)
                    .limit(1)
                    .maybeSingle();
                 categoryId = fallbackCat?.id;
            }

            if (categoryId) {
                const { data: existingTx } = await supabase
                    .from('finance_transactions')
                    .select('id')
                    .eq('service_invoice_id', invoiceData.id)
                    .maybeSingle();

                if (!existingTx) {
                    const transactionPayload = {
                        company_id: selectedCompany.id,
                        service_invoice_id: invoiceData.id,
                        tipo: 'receita',
                        valor: payload.valor_servico,
                        data_competencia: payload.data_emissao,
                        data_lancamento: payload.data_emissao,
                        categoria_id: categoryId,
                        party_id: partyId,
                        liquidado: false,
                        origem: 'nfse',
                        descricao: `NFS-e ${payload.numero_nota} - ${payload.descricao_servico ? payload.descricao_servico.substring(0, 50) : 'Serviços'}`
                    };

                    if (selectedAccount?.id) {
                        transactionPayload.conta_id = selectedAccount.id;
                    }

                    await supabase.from('finance_transactions').insert(transactionPayload);
                }
            }

            toast({ title: "Sucesso!", description: "NFS-e enviada e lançamento financeiro criado." });
            setIsOpen(false);
            setFormData({
                numero_nota: '',
                serie: '',
                data_emissao: new Date().toISOString().split('T')[0],
                valor_servico: '',
                descricao_servico: '',
                emitente_documento: '',
                emitente_nome: '',
                tomador_documento: '',
                tomador_nome: ''
            });
            setSelectedFile(null);
            if (onUploadSuccess) onUploadSuccess();

        } catch (error) {
            console.error(error);
            toast({ 
                variant: "destructive", 
                title: "Erro ao salvar", 
                description: error.message || "Ocorreu um erro ao salvar a nota fiscal." 
            });
        } finally {
            setIsUploading(false);
        }
    };

    return (
        <>
        <Dialog open={isOpen} onOpenChange={setIsOpen}>
            {!isControlled && (
                <DialogTrigger asChild>
                    <Button variant="outline" className="gap-2"><Upload className="w-4 h-4" /> Nova NFS-e</Button>
                </DialogTrigger>
            )}
            <DialogContent className="sm:max-w-[600px] max-h-[90vh] overflow-y-auto">
                <DialogHeader>
                    <DialogTitle>Cadastrar Nota Fiscal de Serviço (NFS-e)</DialogTitle>
                </DialogHeader>
                <form onSubmit={handleSubmit} className="space-y-4 py-4">
                    <div className="grid w-full max-w-sm items-center gap-1.5">
                        <Label htmlFor="file">Arquivo XML da NFS-e</Label>
                        <Input id="file" type="file" accept=".xml" onChange={handleFileChange} ref={fileInputRef} required />
                        <p className="text-xs text-muted-foreground">O sistema lerá os dados automaticamente do XML.</p>
                    </div>

                    {selectedAccount && (
                        <div className="text-sm bg-blue-50 border border-blue-200 p-3 rounded-md">
                            <p className="font-medium text-blue-900">
                                Conta selecionada: {selectedAccount.nome_conta}
                            </p>
                            <p className="text-xs text-blue-700 mt-1">
                                O lançamento será vinculado a esta conta.
                            </p>
                        </div>
                    )}

                    {needsAccountSelection && !selectedAccount && (
                        <div className="text-sm bg-yellow-50 border border-yellow-200 p-3 rounded-md">
                            <p className="font-medium text-yellow-900">
                                Atenção: Você possui múltiplas contas bancárias.
                            </p>
                            <p className="text-xs text-yellow-700 mt-1">
                                Clique em "Salvar NFS-e" para escolher a conta.
                            </p>
                        </div>
                    )}

                    <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-2">
                            <Label htmlFor="numero">Número da Nota</Label>
                            <Input 
                                id="numero" 
                                value={formData.numero_nota} 
                                onChange={e => setFormData({...formData, numero_nota: e.target.value})} 
                                required 
                            />
                        </div>
                        <div className="space-y-2">
                            <Label htmlFor="serie">Série</Label>
                            <Input 
                                id="serie" 
                                value={formData.serie} 
                                onChange={e => setFormData({...formData, serie: e.target.value})} 
                            />
                        </div>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-2">
                            <Label htmlFor="data">Data Emissão</Label>
                            <Input 
                                id="data" 
                                type="date" 
                                value={formData.data_emissao} 
                                onChange={e => setFormData({...formData, data_emissao: e.target.value})} 
                                required 
                            />
                        </div>
                        <div className="space-y-2">
                            <Label htmlFor="valor">Valor Líquido (R$)</Label>
                            <Input 
                                id="valor" 
                                type="number" 
                                step="0.01" 
                                value={formData.valor_servico} 
                                onChange={e => setFormData({...formData, valor_servico: e.target.value})} 
                                required 
                            />
                        </div>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                         <div className="space-y-2">
                            <Label htmlFor="emitente">CNPJ Emitente</Label>
                            <Input 
                                id="emitente" 
                                value={formData.emitente_documento} 
                                readOnly
                                className="bg-gray-50"
                            />
                        </div>
                        <div className="space-y-2">
                            <Label htmlFor="tomador">CNPJ Tomador</Label>
                            <Input 
                                id="tomador" 
                                value={formData.tomador_documento} 
                                onChange={e => setFormData({...formData, tomador_documento: e.target.value})} 
                            />
                        </div>
                    </div>

                    <div className="space-y-2">
                        <Label htmlFor="descricao">Descrição (xTribNac)</Label>
                        <Textarea 
                            id="descricao" 
                            value={formData.descricao_servico} 
                            onChange={e => setFormData({...formData, descricao_servico: e.target.value})} 
                            rows={3}
                        />
                    </div>

                    {formData.emitente_documento && selectedCompany && selectedCompany.cnpj_cpf.replace(/\D/g, '') !== formData.emitente_documento.replace(/\D/g, '') && (
                        <div className="p-3 bg-red-50 border border-red-200 rounded text-sm text-red-600 flex items-start gap-2">
                            <AlertTriangle className="w-4 h-4 mt-0.5" />
                            <span>O CNPJ do XML não corresponde à empresa selecionada. A importação será bloqueada.</span>
                        </div>
                    )}

                    <div className="flex justify-end gap-3 pt-4">
                        <Button type="button" variant="outline" onClick={() => setIsOpen(false)}>Cancelar</Button>
                        <Button type="submit" disabled={isUploading}>
                            {isUploading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                            {isUploading ? 'Salvar NFS-e' : 'Salvar NFS-e'}
                        </Button>
                    </div>
                </form>
            </DialogContent>
        </Dialog>

        <AccountSelectorDialog
            isOpen={showAccountSelector}
            onClose={() => setShowAccountSelector(false)}
            onSelectAccount={(account) => {
                setSelectedAccount(account);
                setShowAccountSelector(false);
                setTimeout(() => processSubmit(), 100);
            }}
            companyId={selectedCompany?.id}
            title="Selecionar Conta para Lançamento"
            description="Escolha a conta bancária onde o lançamento da nota fiscal será vinculado."
        />
        </>
    );
};

export default ServiceInvoiceUpload;
