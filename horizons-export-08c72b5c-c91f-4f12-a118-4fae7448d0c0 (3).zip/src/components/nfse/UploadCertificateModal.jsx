
import React, { useState } from 'react';
import { 
  Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogFooter 
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Loader2, ShieldCheck, Upload, CheckCircle2 } from 'lucide-react';
import CertificateUploadField from './CertificateUploadField';
import { useCertificateData } from '@/hooks/useCertificateData';

const UploadCertificateModal = ({ open, onOpenChange, companyId, onSuccess }) => {
  const { uploadCertificate, testLocalCertificate, loading } = useCertificateData();
  
  const [file, setFile] = useState(null);
  const [fileError, setFileError] = useState(null);
  const [password, setPassword] = useState('');
  const [isValidated, setIsValidated] = useState(false);
  const [validationData, setValidationData] = useState(null);

  const handleFileSelect = (selectedFile, error) => {
    setFile(selectedFile);
    setFileError(error);
    setIsValidated(false);
    setValidationData(null);
  };

  const handleTest = async () => {
    if (!file || !password) return;
    
    const result = await testLocalCertificate(file, password);
    if (result.success) {
      setIsValidated(true);
      setValidationData(result.metadata);
    }
  };

  const handleInstall = async () => {
    if (!file || !password || !isValidated) return;
    
    const success = await uploadCertificate(companyId, file, password);
    if (success) {
      onSuccess?.();
      handleClose();
    }
  };

  const handleClose = () => {
    setFile(null);
    setPassword('');
    setIsValidated(false);
    setValidationData(null);
    setFileError(null);
    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={(val) => !loading && handleClose()}>
      <DialogContent className="sm:max-w-[425px] p-0 overflow-hidden gap-0 rounded-xl">
        <DialogHeader className="px-6 pt-6 pb-4">
          <DialogTitle className="flex items-center gap-2 text-xl">
            <Upload className="h-5 w-5 text-primary" />
            Instalar Certificado A1
          </DialogTitle>
          <DialogDescription>
            Importe o arquivo .PFX do seu certificado digital para habilitar a emissão de notas.
          </DialogDescription>
        </DialogHeader>

        <div className="px-6 py-4 space-y-5 bg-muted/20">
          <CertificateUploadField 
            onFileSelect={handleFileSelect} 
            selectedFile={file} 
            error={fileError}
          />

          <div className="space-y-2">
            <Label htmlFor="cert-password">Senha do Certificado</Label>
            <Input 
              id="cert-password"
              type="password" 
              placeholder="Digite a senha do arquivo .pfx"
              value={password}
              onChange={(e) => {
                setPassword(e.target.value);
                setIsValidated(false);
              }}
              className="bg-white"
            />
          </div>

          {isValidated && validationData && (
            <div className="bg-green-50 border border-green-200 rounded-lg p-3 flex gap-3 animate-in fade-in zoom-in-95">
              <CheckCircle2 className="h-5 w-5 text-green-600 shrink-0 mt-0.5" />
              <div className="text-sm">
                <p className="font-semibold text-green-900">Certificado Validado!</p>
                <p className="text-green-700 text-xs mt-1">
                  Emitido para: {validationData.commonName}<br/>
                  Válido até: {new Date(validationData.valid_to).toLocaleDateString()}
                </p>
              </div>
            </div>
          )}
        </div>

        <DialogFooter className="px-6 py-4 bg-gray-50/50 border-t flex flex-row gap-2 sm:justify-end">
          {!isValidated ? (
            <Button 
              className="w-full sm:w-auto" 
              onClick={handleTest}
              disabled={!file || !password || !!fileError || loading}
            >
              {loading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <ShieldCheck className="mr-2 h-4 w-4" />}
              Testar Certificado
            </Button>
          ) : (
            <Button 
              className="w-full sm:w-auto bg-green-600 hover:bg-green-700"
              onClick={handleInstall}
              disabled={loading}
            >
              {loading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Upload className="mr-2 h-4 w-4" />}
              Instalar Agora
            </Button>
          )}
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default UploadCertificateModal;
