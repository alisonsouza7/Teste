
import React from 'react';
import { FileCheck, AlertTriangle, Clock } from 'lucide-react';
import { cn } from '@/lib/utils';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';

const CertificateStatus = ({ certificate }) => {
  if (!certificate) return null;

  const validTo = new Date(certificate.valid_to);
  const now = new Date();
  const isExpired = validTo < now;
  const daysRemaining = Math.ceil((validTo - now) / (1000 * 60 * 60 * 24));
  
  // Status Logic
  let statusColor = "text-green-600";
  let statusBg = "bg-green-50";
  let statusBorder = "border-green-200";
  let Icon = FileCheck;
  let statusText = "Ativo";
  let progressColor = "bg-green-500";
  
  if (isExpired) {
    statusColor = "text-red-600";
    statusBg = "bg-red-50";
    statusBorder = "border-red-200";
    Icon = AlertTriangle;
    statusText = "Expirado";
    progressColor = "bg-red-500";
  } else if (daysRemaining <= 30) {
    statusColor = "text-yellow-600";
    statusBg = "bg-yellow-50";
    statusBorder = "border-yellow-200";
    Icon = Clock;
    statusText = "Vencendo";
    progressColor = "bg-yellow-500";
  }

  // Thumbprint formatting
  const thumb = certificate.thumbprint ? certificate.thumbprint.slice(-8).toUpperCase() : '????';

  return (
    <div className={cn("rounded-lg border p-4 space-y-4", statusBg, statusBorder)}>
      <div className="flex items-start justify-between">
        <div className="flex items-center gap-3">
          <div className={cn("p-2 rounded-full bg-white shadow-sm border", statusBorder)}>
            <Icon className={cn("h-5 w-5", statusColor)} />
          </div>
          <div>
            <h4 className={cn("font-semibold text-sm", statusColor)}>Certificado Digital A1</h4>
            <p className="text-xs text-muted-foreground mt-0.5">
              Thumbprint: <span className="font-mono">...{thumb}</span>
            </p>
          </div>
        </div>
        <Badge variant={isExpired ? "destructive" : "outline"} className={cn("capitalize shadow-none", isExpired ? "" : "bg-white text-gray-700 border-gray-200")}>
          {statusText}
        </Badge>
      </div>

      <div className="space-y-2">
        <div className="flex justify-between text-xs font-medium">
          <span className="text-muted-foreground">Validade</span>
          <span className={statusColor}>
            {isExpired 
              ? `Expirou há ${Math.abs(daysRemaining)} dias` 
              : `${daysRemaining} dias restantes`
            }
          </span>
        </div>
        
        {/* Visual progress bar for validity (assuming 1 year = 365 days max) */}
        {!isExpired && (
          <Progress 
            value={Math.min(100, (daysRemaining / 365) * 100)} 
            className="h-2 bg-white/50" 
            indicatorClassName={progressColor}
          />
        )}
        
        <div className="pt-1 flex justify-between items-center text-xs">
           <span className="text-muted-foreground">Expira em:</span>
           <span className="font-mono font-medium">{validTo.toLocaleDateString('pt-BR')}</span>
        </div>
      </div>
    </div>
  );
};

export default CertificateStatus;
