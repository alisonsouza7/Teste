
import React, { useRef, useState } from 'react';
import { Upload, FileKey, X, CheckCircle } from 'lucide-react';
import { cn } from '@/lib/utils';
import { Button } from '@/components/ui/button';

const CertificateUploadField = ({ onFileSelect, selectedFile, error }) => {
  const fileInputRef = useRef(null);
  const [isDragging, setIsDragging] = useState(false);

  const handleDragOver = (e) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = () => {
    setIsDragging(false);
  };

  const validateAndSelect = (file) => {
    if (!file) return;

    // Check extension
    const fileName = file.name.toLowerCase();
    if (!fileName.endsWith('.pfx') && !fileName.endsWith('.p12')) {
      onFileSelect(null, 'Apenas arquivos .pfx ou .p12 são permitidos.');
      return;
    }

    // Check size (5MB)
    if (file.size > 5 * 1024 * 1024) {
      onFileSelect(null, 'O arquivo deve ter no máximo 5MB.');
      return;
    }

    onFileSelect(file, null);
  };

  const handleDrop = (e) => {
    e.preventDefault();
    setIsDragging(false);
    const file = e.dataTransfer.files[0];
    validateAndSelect(file);
  };

  const handleFileInput = (e) => {
    const file = e.target.files[0];
    validateAndSelect(file);
  };

  const clearFile = () => {
    onFileSelect(null, null);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  return (
    <div className="space-y-2">
      <div
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        onDrop={handleDrop}
        className={cn(
          "relative border-2 border-dashed rounded-xl p-6 transition-all duration-200 text-center cursor-pointer",
          isDragging ? "border-primary bg-primary/5" : "border-muted-foreground/25 hover:border-primary/50 hover:bg-muted/5",
          selectedFile ? "bg-green-50/50 border-green-200" : "",
          error ? "bg-red-50/50 border-red-200" : ""
        )}
        onClick={() => !selectedFile && fileInputRef.current?.click()}
      >
        <input
          type="file"
          ref={fileInputRef}
          className="hidden"
          accept=".pfx,.p12"
          onChange={handleFileInput}
        />

        {selectedFile ? (
          <div className="flex items-center justify-between gap-4">
            <div className="flex items-center gap-3 text-left">
              <div className="h-10 w-10 rounded-full bg-green-100 flex items-center justify-center shrink-0">
                <FileKey className="h-5 w-5 text-green-600" />
              </div>
              <div className="overflow-hidden">
                <p className="font-medium text-sm truncate max-w-[200px] text-green-900">
                  {selectedFile.name}
                </p>
                <p className="text-xs text-green-700">
                  {(selectedFile.size / 1024).toFixed(1)} KB
                </p>
              </div>
            </div>
            <Button
              variant="ghost"
              size="icon"
              className="h-8 w-8 text-green-700 hover:text-red-600 hover:bg-red-50"
              onClick={(e) => {
                e.stopPropagation();
                clearFile();
              }}
            >
              <X className="h-4 w-4" />
            </Button>
          </div>
        ) : (
          <div className="flex flex-col items-center justify-center gap-2 py-4">
            <div className="h-12 w-12 rounded-full bg-muted/50 flex items-center justify-center mb-1 group-hover:scale-110 transition-transform">
              <Upload className="h-6 w-6 text-muted-foreground" />
            </div>
            <div className="space-y-1">
              <p className="text-sm font-medium text-foreground">
                Clique para selecionar ou arraste aqui
              </p>
              <p className="text-xs text-muted-foreground">
                Suporta arquivos .PFX ou .P12 (Máx. 5MB)
              </p>
            </div>
          </div>
        )}
      </div>
      
      {error && (
        <p className="text-sm text-red-500 font-medium animate-in slide-in-from-top-1">
          {error}
        </p>
      )}
    </div>
  );
};

export default CertificateUploadField;
