
import React, { useEffect, useState } from 'react';
import { 
  FileCheck, 
  Trash2, 
  RefreshCw, 
  AlertTriangle,
  Loader2,
  Upload,
  ShieldCheck,
  Shield,
  Key,
  CheckCircle2,
  AlertCircle
} from 'lucide-react';
import { Card, CardHeader, CardTitle, CardDescription, CardContent, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';
import { Badge } from '@/components/ui/badge';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";

import { useCertificateData } from '@/hooks/useCertificateData';
import UploadCertificateModal from './UploadCertificateModal';

const CertificateSection = ({ companyId }) => {
  const { certificate, loading, getCertificateData, deactivateCertificate } = useCertificateData();
  const [showUploadModal, setShowUploadModal] = useState(false);
  const [showDeleteModal, setShowDeleteModal] = useState(false);

  useEffect(() => {
    if (companyId) {
      getCertificateData(companyId);
    }
  }, [companyId, getCertificateData]);

  if (loading && !certificate) {
    return (
      <Card className="rounded-xl shadow-lg border-muted">
        <CardHeader>
          <Skeleton className="h-6 w-48 mb-2" />
          <Skeleton className="h-4 w-72" />
        </CardHeader>
        <CardContent>
          <Skeleton className="h-24 w-full rounded-lg" />
        </CardContent>
      </Card>
    );
  }

  const hasCertificate = !!certificate && certificate.is_active;
  const isExpired = hasCertificate && new Date(certificate.valid_to) < new Date();
  
  // Vibrant theme constants
  const theme = {
    active: {
      border: "border-emerald-200",
      bg: "bg-gradient-to-br from-emerald-50 to-teal-50",
      icon: "text-emerald-600",
      iconBg: "bg-white",
      status: "bg-emerald-100 text-emerald-800 border-emerald-200"
    },
    expired: {
      border: "border-red-200",
      bg: "bg-gradient-to-br from-red-50 to-orange-50",
      icon: "text-red-600",
      iconBg: "bg-white",
      status: "bg-red-100 text-red-800 border-red-200"
    },
    empty: {
      border: "border-slate-200",
      bg: "bg-gradient-to-br from-slate-50 to-gray-50",
      icon: "text-slate-400",
      iconBg: "bg-white",
      status: "bg-slate-100 text-slate-800"
    }
  };

  const currentTheme = !hasCertificate ? theme.empty : (isExpired ? theme.expired : theme.active);

  return (
    <>
      <Card className={`rounded-xl shadow-md transition-all duration-300 hover:shadow-lg border-l-4 ${!hasCertificate ? 'border-l-slate-400' : (isExpired ? 'border-l-red-500' : 'border-l-emerald-500')}`}>
        <CardHeader className="pb-3">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div className="flex items-start gap-3">
              <div className={`p-2.5 rounded-lg shadow-sm ${currentTheme.iconBg}`}>
                {hasCertificate ? (
                   isExpired ? <AlertTriangle className={`h-6 w-6 ${currentTheme.icon}`} /> : <ShieldCheck className={`h-6 w-6 ${currentTheme.icon}`} />
                ) : (
                   <Key className={`h-6 w-6 ${currentTheme.icon}`} />
                )}
              </div>
              <div className="space-y-1">
                <CardTitle className="text-lg font-bold text-gray-900 flex items-center gap-2">
                  Certificado Digital A1
                  {hasCertificate && (
                    <Badge variant="outline" className={`${currentTheme.status} px-2.5 py-0.5 font-semibold`}>
                      {isExpired ? 'Expirado' : 'Ativo'}
                    </Badge>
                  )}
                </CardTitle>
                <CardDescription className="text-gray-500">
                  Essencial para a emissão automática de Notas Fiscais de Serviço (NFS-e).
                </CardDescription>
              </div>
            </div>
            
            {hasCertificate && (
               <div className="flex items-center gap-2">
                 <TooltipProvider>
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <Button 
                        variant="ghost" 
                        size="icon" 
                        className="text-red-400 hover:text-red-600 hover:bg-red-50"
                        onClick={() => setShowDeleteModal(true)}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </TooltipTrigger>
                    <TooltipContent>
                      <p>Remover certificado</p>
                    </TooltipContent>
                  </Tooltip>
                 </TooltipProvider>
               </div>
            )}
          </div>
        </CardHeader>
        
        <CardContent className="pb-3">
          {hasCertificate ? (
             <div className={`rounded-lg p-4 border ${currentTheme.border} ${currentTheme.bg}`}>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-1">
                    <span className="text-xs font-medium text-gray-500 uppercase tracking-wider">Titular</span>
                    <p className="font-semibold text-gray-800 truncate" title={certificate.subject_name || 'Desconhecido'}>
                      {certificate.subject_name || 'Certificado Importado'}
                    </p>
                  </div>
                   <div className="space-y-1">
                    <span className="text-xs font-medium text-gray-500 uppercase tracking-wider">Vencimento</span>
                    <div className="flex items-center gap-2">
                       <p className={`font-mono font-semibold ${isExpired ? 'text-red-600' : 'text-emerald-700'}`}>
                        {new Date(certificate.valid_to).toLocaleDateString()}
                       </p>
                       {!isExpired && (
                         <span className="text-xs text-emerald-600 bg-emerald-100 px-2 py-0.5 rounded-full">
                           {Math.ceil((new Date(certificate.valid_to) - new Date()) / (1000 * 60 * 60 * 24))} dias
                         </span>
                       )}
                    </div>
                  </div>
                  <div className="col-span-1 md:col-span-2 pt-2 border-t border-dashed border-gray-300/50 mt-1">
                     <p className="text-xs text-gray-400 font-mono truncate">
                       Thumbprint: {certificate.thumbprint}
                     </p>
                  </div>
                </div>
             </div>
          ) : (
            <div className="bg-slate-50 border border-dashed border-slate-300 rounded-lg p-6 flex flex-col items-center justify-center text-center space-y-3">
               <div className="p-3 bg-white rounded-full shadow-sm">
                 <Upload className="h-6 w-6 text-indigo-500" />
               </div>
               <div className="max-w-md">
                 <h4 className="font-medium text-gray-900 mb-1">Instale seu Certificado A1</h4>
                 <p className="text-sm text-gray-500">
                   Faça o upload do arquivo .PFX para habilitar a emissão de notas fiscais pelo sistema.
                 </p>
               </div>
            </div>
          )}
        </CardContent>

        <CardFooter className="pt-2 pb-6 flex justify-end px-6">
          <Button 
            className={`shadow-md transition-all hover:scale-[1.02] ${hasCertificate ? 'bg-indigo-600 hover:bg-indigo-700' : 'bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700'}`}
            onClick={() => setShowUploadModal(true)}
            size={hasCertificate ? "sm" : "default"}
          >
            {hasCertificate ? (
              <>
                <RefreshCw className="h-4 w-4 mr-2" />
                Atualizar / Renovar
              </>
            ) : (
              <>
                <ShieldCheck className="h-4 w-4 mr-2" />
                Instalar Certificado
              </>
            )}
          </Button>
        </CardFooter>
      </Card>

      <UploadCertificateModal 
        open={showUploadModal} 
        onOpenChange={setShowUploadModal}
        companyId={companyId}
        onSuccess={() => getCertificateData(companyId)}
      />

      <Dialog open={showDeleteModal} onOpenChange={setShowDeleteModal}>
        <DialogContent className="rounded-xl">
          <DialogHeader>
            <div className="flex items-center gap-2 text-red-600">
              <AlertTriangle className="h-5 w-5" />
              <DialogTitle>Desativar Certificado</DialogTitle>
            </div>
            <DialogDescription>
              Esta ação removerá o certificado do sistema. Sua empresa <strong>não poderá emitir novas Notas Fiscais</strong> até que um novo certificado seja instalado.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowDeleteModal(false)}>
              Cancelar
            </Button>
            <Button 
              onClick={async () => {
                await deactivateCertificate(companyId);
                setShowDeleteModal(false);
              }}
              className="bg-red-600 hover:bg-red-700 text-white"
            >
              {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : "Confirmar Desativação"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
};

export default CertificateSection;
