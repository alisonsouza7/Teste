
import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Alert, AlertTitle, AlertDescription } from '@/components/ui/alert';
import { Loader2, CheckCircle, AlertTriangle, FileCode, Search } from 'lucide-react';
import { consultarNfse, obterStatusDps } from '@/lib/apiClient';
import { cn } from '@/lib/utils';
import { validate as uuidValidate } from 'uuid';

const NfseConsultaModal = ({ open, onOpenChange, companyId, onSuccess }) => {
  const [activeTab, setActiveTab] = useState('consulta');
  const [dpsId, setDpsId] = useState('');
  const [targetCompanyId, setTargetCompanyId] = useState(companyId || '');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [result, setResult] = useState(null);

  const resetState = () => {
    setError(null);
    setResult(null);
  };

  const handleTabChange = (value) => {
    setActiveTab(value);
    resetState();
  };

  const validateInputs = () => {
    // Reset error
    setError(null);

    // Validate DPS ID / Chave (Must be 42 digits numeric)
    // Note: The prompt specifically asked for "exactly 42 digits".
    const dpsClean = dpsId.replace(/\D/g, '');
    if (dpsClean.length !== 42) {
      setError('O ID informado (Chave de Acesso) deve conter exatamente 42 dígitos numéricos.');
      return false;
    }

    // Validate Company ID (UUID)
    if (!targetCompanyId) {
        setError('O ID da empresa é obrigatório.');
        return false;
    }
    
    if (!uuidValidate(targetCompanyId)) {
        setError('O ID da empresa informado não é um UUID válido.');
        return false;
    }

    return true;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    resetState();

    if (!validateInputs()) return;

    setLoading(true);
    try {
      let data;
      // We send the clean numeric ID
      const cleanDpsId = dpsId.replace(/\D/g, '');

      if (activeTab === 'consulta') {
        data = await consultarNfse(cleanDpsId, targetCompanyId);
      } else {
        data = await obterStatusDps(cleanDpsId, targetCompanyId);
      }

      setResult(data);
      if (onSuccess && (data?.status === 'concluido' || data?.status === 'AUTHORIZED')) {
        onSuccess(data);
      }
    } catch (err) {
      console.error(err);
      const msg = err.response?.data?.message || err.message || 'Erro ao realizar a consulta.';
      setError(msg);
    } finally {
      setLoading(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
            <DialogTitle>Consulta NFS-e</DialogTitle>
            <DialogDescription>
                Consulte o status ou recupere o XML da NFS-e utilizando a Chave de Acesso (42 dígitos).
            </DialogDescription>
        </DialogHeader>

        <Tabs value={activeTab} onValueChange={handleTabChange} className="w-full">
            <TabsList className="grid w-full grid-cols-2">
                <TabsTrigger value="consulta">Consultar NFS-e (1-Clique)</TabsTrigger>
                <TabsTrigger value="status">Obter Status</TabsTrigger>
            </TabsList>

            <div className="mt-4 space-y-4">
                <form onSubmit={handleSubmit} className="space-y-4 border p-4 rounded-md bg-slate-50">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div className="space-y-2">
                            <Label htmlFor="dpsId">
                                Chave de Acesso (42 dígitos)
                            </Label>
                            <Input
                                id="dpsId"
                                placeholder="0000..."
                                value={dpsId}
                                onChange={(e) => setDpsId(e.target.value)}
                                disabled={loading}
                            />
                            <p className="text-[0.8rem] text-muted-foreground">
                                Insira apenas números.
                            </p>
                        </div>
                        <div className="space-y-2">
                            <Label htmlFor="companyId">ID da Empresa (UUID)</Label>
                            <Input
                                id="companyId"
                                placeholder="UUID da empresa"
                                value={targetCompanyId}
                                onChange={(e) => setTargetCompanyId(e.target.value)}
                                disabled={loading}
                            />
                        </div>
                    </div>

                    <div className="flex justify-end pt-2">
                        <Button type="submit" disabled={loading} className="w-full md:w-auto">
                            {loading ? (
                                <>
                                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                                    Processando...
                                </>
                            ) : (
                                <>
                                    <Search className="mr-2 h-4 w-4" />
                                    {activeTab === 'consulta' ? 'Consultar e Baixar' : 'Verificar Status'}
                                </>
                            )}
                        </Button>
                    </div>
                </form>

                {error && (
                    <Alert variant="destructive">
                        <AlertTriangle className="h-4 w-4" />
                        <AlertTitle>Erro na requisição</AlertTitle>
                        <AlertDescription>{error}</AlertDescription>
                    </Alert>
                )}

                {result && (
                    <div className="space-y-4 animate-in fade-in-50">
                        <div className={cn(
                            "p-4 rounded-lg border",
                            result.status === 'concluido' || result.status === 'AUTHORIZED' || result.status === 'autorizado' ? "bg-green-50 border-green-200" :
                            result.status === 'erro' || result.status === 'rejeitado' ? "bg-red-50 border-red-200" :
                            "bg-yellow-50 border-yellow-200"
                        )}>
                            <div className="flex items-center gap-2 mb-2">
                                {result.status === 'concluido' || result.status === 'AUTHORIZED' || result.status === 'autorizado' ? (
                                    <CheckCircle className="h-5 w-5 text-green-600" />
                                ) : (
                                    <Loader2 className="h-5 w-5 text-yellow-600 animate-spin" />
                                )}
                                <h3 className="font-semibold capitalize text-lg">
                                    Status: {result.status || 'Desconhecido'}
                                </h3>
                            </div>
                            
                            {result.message && <p className="text-sm text-gray-700 mb-2">{result.message}</p>}
                            {result.error_message && <p className="text-sm text-red-700 mb-2">{result.error_message}</p>}
                            
                            <div className="grid grid-cols-1 gap-2 text-sm mt-3">
                                {(result.chaveAcesso || result.chave_acesso) && (
                                    <div className="flex flex-col">
                                        <span className="font-medium text-gray-500">Chave de Acesso:</span>
                                        <span className="font-mono break-all">{result.chaveAcesso || result.chave_acesso}</span>
                                    </div>
                                )}
                                {result.nfseXmlPath && (
                                    <div className="flex items-center gap-2 mt-2">
                                        <FileCode className="h-4 w-4" />
                                        <span className="text-green-700 font-medium">XML Disponível no Storage</span>
                                    </div>
                                )}
                            </div>
                        </div>

                        {/* XML Preview Section */}
                        {(result.preview || result.xml_content) && (
                            <div className="border rounded-md overflow-hidden">
                                <div className="bg-gray-100 px-4 py-2 text-xs font-medium text-gray-500 border-b flex justify-between items-center">
                                    <span>Pré-visualização do XML</span>
                                </div>
                                <pre className="bg-slate-900 text-slate-50 p-4 overflow-x-auto text-xs font-mono max-h-60">
                                    {result.preview || result.xml_content}
                                </pre>
                            </div>
                        )}
                    </div>
                )}
            </div>
            
            <TabsContent value="consulta" className="mt-0 h-0 p-0 overflow-hidden" />
            <TabsContent value="status" className="mt-0 h-0 p-0 overflow-hidden" />
        </Tabs>
      </DialogContent>
    </Dialog>
  );
};

export default NfseConsultaModal;
