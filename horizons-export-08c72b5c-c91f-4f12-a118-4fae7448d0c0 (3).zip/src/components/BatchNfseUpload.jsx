
import React, { useState, useRef, useEffect } from 'react';
import { supabase } from '@/lib/customSupabaseClient';
import { useCompany } from '@/contexts/CompanyContext';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useToast } from '@/components/ui/use-toast';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogFooter
} from '@/components/ui/dialog';
import {
  Upload,
  Loader2,
  FileText,
  RefreshCw,
  AlertTriangle
} from 'lucide-react';
import { Progress } from '@/components/ui/progress';
import { parseNfseXml } from '@/lib/xmlParsingUtils';
import { ScrollArea } from '@/components/ui/scroll-area';
import AccountSelectorDialog from '@/components/finance/AccountSelectorDialog';
import { useCompanyFiscalData } from '@/hooks/useCompanyFiscalData';

const BatchNfseUpload = ({ onUploadSuccess, open: controlledOpen, onOpenChange: setControlledOpen }) => {
  const { selectedCompany } = useCompany();
  const { user } = useAuth();
  const { toast } = useToast();
  const { fiscalData } = useCompanyFiscalData();

  // Internal state for when component is used uncontrolled
  const [internalOpen, setInternalOpen] = useState(false);
  
  // Determine if controlled or uncontrolled
  const isControlled = controlledOpen !== undefined;
  const isOpen = isControlled ? controlledOpen : internalOpen;
  const setIsOpen = isControlled ? setControlledOpen : setInternalOpen;

  const [isProcessing, setIsProcessing] = useState(false);
  const [files, setFiles] = useState([]);
  const [progress, setProgress] = useState(0);

  // Results Arrays
  const [results, setResults] = useState(null); // { success: [], duplicated: [], errors: [] }
  const [replacingId, setReplacingId] = useState(null);

  // Account selection
  const [selectedAccount, setSelectedAccount] = useState(null);
  const [showAccountSelector, setShowAccountSelector] = useState(false);
  const [needsAccountSelection, setNeedsAccountSelection] = useState(false);

  const fileInputRef = useRef(null);

  // Check accounts when company changes or modal opens
  useEffect(() => {
    if (isOpen && selectedCompany) {
      checkAccounts();
    }
  }, [isOpen, selectedCompany]);

  const checkAccounts = async () => {
    try {
      const { data, error } = await supabase
        .from('finance_accounts')
        .select('id, nome_conta')
        .eq('company_id', selectedCompany.id)
        .is('deleted_at', null);

      if (error) throw error;

      if (data && data.length === 1) {
        // Auto-select if only one account
        setSelectedAccount(data[0]);
        setNeedsAccountSelection(false);
      } else if (data && data.length > 1) {
        // Need user selection
        setNeedsAccountSelection(true);
        setSelectedAccount(null);
      } else {
        // No accounts
        setNeedsAccountSelection(false);
        setSelectedAccount(null);
      }
    } catch (err) {
      console.error('Error checking accounts:', err);
    }
  };

  const handleFileSelect = (e) => {
    if (!selectedCompany) {
      toast({
        variant: 'destructive',
        title: 'Erro',
        description: 'Selecione uma empresa antes de importar as notas.'
      });
      return;
    }

    const selectedFiles = Array.from(e.target.files || []);
    const xmlFiles = selectedFiles.filter(
      (f) => f.type === 'text/xml' || f.name.endsWith('.xml')
    );

    if (xmlFiles.length === 0) {
      toast({
        variant: 'destructive',
        title: 'Arquivo inválido',
        description: 'Nenhum arquivo XML selecionado.'
      });
      return;
    }

    setFiles(xmlFiles);
    setResults(null);
    setProgress(0);
  };

  const ensurePartyExists = async (companyId, documento, nome) => {
    if (!documento) return null;

    try {
      const { data: existing, error: existingError } = await supabase
        .from('finance_parties')
        .select('id')
        .eq('company_id', companyId)
        .eq('documento', documento)
        .is('deleted_at', null)
        .maybeSingle();

      if (existingError) {
        console.error('Erro ao buscar party existente (batch):', existingError);
      }

      if (existing) return existing.id;

      const { data: newParty, error: insertError } = await supabase
        .from('finance_parties')
        .insert({
          company_id: companyId,
          tipo: 'cliente',
          nome: nome || 'Importado via XML',
          documento
        })
        .select('id')
        .single();

      if (insertError) {
        console.error('Erro ao criar party (batch):', insertError);
        return null;
      }

      return newParty.id;
    } catch (err) {
      console.error('Erro geral em ensurePartyExists (batch):', err);
      return null;
    }
  };

  const handleStartProcessing = () => {
    if (!selectedAccount && needsAccountSelection) {
      setShowAccountSelector(true);
      return;
    }
    processFiles();
  };

  const processFiles = async () => {
    if (files.length === 0 || !selectedCompany) return;

    setIsProcessing(true);

    const importadasSucesso = [];
    const duplicadas = [];
    const erros = [];

    const companyCnpj = selectedCompany.cnpj_cpf.replace(/\D/g, '');
    let currentTotalRevenue = fiscalData?.faturamento_12_meses || 0;
    const limit = fiscalData?.limite_faturamento_anual;

    for (let i = 0; i < files.length; i++) {
      const file = files[i];
      const currentProgress = Math.round(((i + 1) / files.length) * 100);
      setProgress(currentProgress);

      try {
        const text = await file.text();
        const parser = new DOMParser();
        const xmlDoc = parser.parseFromString(text, 'text/xml');

        const parserError = xmlDoc.getElementsByTagName('parsererror');
        if (parserError.length > 0) throw new Error('Erro ao ler estrutura do XML');

        const data = parseNfseXml(xmlDoc);

        // Validações básicas
        if (!data.numero_nota) throw new Error('Número da nota não encontrado');
        if (!data.data_emissao) throw new Error('Data de emissão não encontrada');
        if (data.valor_servico === undefined || data.valor_servico === null) {
          throw new Error('Valor do serviço não encontrado');
        }
        if (!data.emitente_documento) throw new Error('CNPJ do emitente não encontrado');

        const emitenteCnpj = data.emitente_documento.replace(/\D/g, '');
        if (emitenteCnpj !== companyCnpj) {
          throw new Error(
            `CNPJ do emitente (${emitenteCnpj}) não confere com a empresa (${companyCnpj})`
          );
        }

        // Normalizar valor_servico
        let valorNumber;
        if (typeof data.valor_servico === 'number') {
          valorNumber = data.valor_servico;
        } else {
          const raw = (data.valor_servico ?? '').toString().trim();
          if (!raw) {
            throw new Error('Valor do serviço vazio ou inválido no XML');
          }
          const cleaned = raw.replace(/\./g, '').replace(',', '.');
          const parsed = Number(cleaned);

          if (Number.isNaN(parsed)) {
            throw new Error(`Valor do serviço em formato inválido: ${raw}`);
          }
          valorNumber = parsed;
        }
        
        // Regime Limit Check (Warning only, does not block)
        if (limit && limit > 0) {
            if ((currentTotalRevenue + valorNumber) > limit) {
                // We add a warning but proceed
                toast({
                    variant: 'warning',
                    title: 'Atenção: Limite de Faturamento',
                    description: `A nota ${data.numero_nota} pode exceder o limite anual do regime tributário.`
                });
            }
            // Increment local counter to check subsequent files in same batch
            currentTotalRevenue += valorNumber; 
        }

        // Upload do XML
        const fileExt = 'xml';
        const fileName = `${selectedCompany.id}/${Date.now()}_${data.numero_nota}.${fileExt}`;
        const { error: uploadError } = await supabase.storage
          .from('service-invoices')
          .upload(fileName, file);

        if (uploadError) {
          throw new Error(`Erro no upload: ${uploadError.message}`);
        }

        const payload = {
          company_id: selectedCompany.id,
          user_id: user.id,
          numero_nota: data.numero_nota,
          serie: data.serie || null,
          emitente_documento: data.emitente_documento,
          emitente_nome: data.emitente_nome || null,
          tomador_documento: data.tomador_documento,
          tomador_nome: data.tomador_nome || null,
          data_emissao: data.data_emissao,
          valor_servico: valorNumber,
          descricao_servico: data.descricao_servico,
          arquivo_url: fileName,
          status: 'valida'
        };

        const { data: insertedData, error: dbError } = await supabase
          .from('service_invoices')
          .insert(payload)
          .select()
          .single();

        if (dbError) {
          if (dbError.code === '23505') {
            const { data: existing } = await supabase
              .from('service_invoices')
              .select('id')
              .eq('company_id', selectedCompany.id)
              .eq('numero_nota', data.numero_nota)
              .maybeSingle();

            if (existing) {
              duplicadas.push({
                fileName: file.name,
                numero_nota: data.numero_nota,
                idExistente: existing.id,
                dadosNovos: payload
              });
            } else {
              throw new Error('Duplicidade detectada mas registro original não encontrado.');
            }
          } else {
            throw new Error(dbError.message);
          }
        } else {
          try {
            const documento = data.tomador_documento || data.emitente_documento || null;
            const nomeParty =
              data.tomador_nome || data.emitente_nome || 'Cliente/Fornecedor não identificado';

            const partyId = await ensurePartyExists(selectedCompany.id, documento, nomeParty);

            if (partyId) {
              await supabase
                .from('service_invoices')
                .update({ party_id: partyId })
                .eq('id', insertedData.id);
            }

            const { data: categoryData } = await supabase
              .from('finance_chart_of_accounts')
              .select('id')
              .eq('company_id', selectedCompany.id)
              .eq('tipo', 'receita')
              .ilike('nome_conta', '%Prestação de Serviços%')
              .is('deleted_at', null)
              .limit(1)
              .maybeSingle();

            let categoryId = categoryData?.id;
            if (!categoryId) {
              const { data: fallbackCat } = await supabase
                .from('finance_chart_of_accounts')
                .select('id')
                .eq('company_id', selectedCompany.id)
                .eq('tipo', 'receita')
                .is('deleted_at', null)
                .limit(1)
                .maybeSingle();
              categoryId = fallbackCat?.id;
            }

            if (categoryId) {
              const { data: existingTx } = await supabase
                .from('finance_transactions')
                .select('id')
                .eq('service_invoice_id', insertedData.id)
                .maybeSingle();

              if (!existingTx) {
                const transactionPayload = {
                  company_id: selectedCompany.id,
                  service_invoice_id: insertedData.id,
                  tipo: 'receita',
                  valor: valorNumber,
                  data_competencia: data.data_emissao,
                  data_lancamento: data.data_emissao,
                  categoria_id: categoryId,
                  party_id: partyId,
                  liquidado: false,
                  origem: 'nfse',
                  descricao: `NFS-e ${data.numero_nota} - ${data.descricao_servico
                      ? data.descricao_servico.substring(0, 50)
                      : 'Serviços'
                    }`
                };

                if (selectedAccount?.id) {
                  transactionPayload.conta_id = selectedAccount.id;
                }

                await supabase
                  .from('finance_transactions')
                  .insert(transactionPayload);
              }
            }

            importadasSucesso.push({
              fileName: file.name,
              numero_nota: data.numero_nota,
              valor_servico: valorNumber
            });
          } catch (innerErr) {
            console.error(innerErr);
            erros.push({
              fileName: file.name,
              motivo: 'Nota importada, mas falha ao criar cliente/lançamento: ' + innerErr.message
            });
          }
        }
      } catch (err) {
        console.error(err);
        erros.push({ fileName: file.name, motivo: err.message || String(err) });
      }
    }

    setResults({
      success: importadasSucesso,
      duplicated: duplicadas,
      errors: erros
    });

    setIsProcessing(false);
    if (onUploadSuccess) onUploadSuccess();
  };

  const handleReplace = async (duplicateItem) => {
    setReplacingId(duplicateItem.idExistente);
    try {
      const { error } = await supabase
        .from('service_invoices')
        .update({
          ...duplicateItem.dadosNovos,
          updated_at: new Date().toISOString()
        })
        .eq('id', duplicateItem.idExistente);

      if (error) throw error;

      toast({ title: 'Sucesso', description: `Nota ${duplicateItem.numero_nota} atualizada.` });

      setResults((prev) => ({
        ...prev,
        duplicated: prev.duplicated.filter(
          (item) => item.idExistente !== duplicateItem.idExistente
        ),
        success: [
          ...prev.success,
          {
            fileName: duplicateItem.fileName,
            numero_nota: duplicateItem.numero_nota,
            valor_servico: duplicateItem.dadosNovos.valor_servico
          }
        ]
      }));

      if (onUploadSuccess) onUploadSuccess();
    } catch (error) {
      console.error(error);
      toast({
        variant: 'destructive',
        title: 'Erro',
        description: 'Falha ao substituir a nota.'
      });
    } finally {
      setReplacingId(null);
    }
  };

  const resetModal = () => {
    setFiles([]);
    setResults(null);
    setProgress(0);
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const handleOpenChange = (open) => {
    if (!open && isProcessing) return;
    setIsOpen(open);
    if (!open) resetModal();
  };

  return (
    <>
      <Dialog open={isOpen} onOpenChange={handleOpenChange}>
        {!isControlled && (
            <DialogTrigger asChild>
            <Button className="gap-2 bg-green-600 hover:bg-green-700">
                <Upload className="w-4 h-4" /> Importar em Lote (XML)
            </Button>
            </DialogTrigger>
        )}
        <DialogContent className="sm:max-w-[700px]">
          <DialogHeader>
            <DialogTitle>Importação em Lote de NFS-e</DialogTitle>
          </DialogHeader>

          {!results ? (
            <div className="space-y-4 py-4">
              <div className="grid w-full gap-1.5">
                <Label htmlFor="batch-file">Selecione arquivos XML</Label>
                <Input
                  id="batch-file"
                  type="file"
                  multiple
                  accept=".xml"
                  onChange={handleFileSelect}
                  ref={fileInputRef}
                  disabled={isProcessing}
                />
                <p className="text-xs text-muted-foreground">
                  Selecione múltiplas notas fiscais para importar de uma vez.
                </p>
              </div>

              {files.length > 0 && (
                <div className="text-sm text-gray-600 bg-gray-50 p-3 rounded-md border border-gray-200">
                  <FileText className="w-4 h-4 inline mr-2" />
                  {files.length} arquivos selecionados.
                </div>
              )}

              {selectedAccount && (
                <div className="text-sm bg-blue-50 border border-blue-200 p-3 rounded-md">
                  <p className="font-medium text-blue-900">
                    Conta selecionada: {selectedAccount.nome_conta}
                  </p>
                  <p className="text-xs text-blue-700 mt-1">
                    Os lançamentos serão vinculados a esta conta.
                  </p>
                </div>
              )}

              {needsAccountSelection && !selectedAccount && (
                <div className="text-sm bg-yellow-50 border border-yellow-200 p-3 rounded-md">
                  <p className="font-medium text-yellow-900">
                    Atenção: Você possui múltiplas contas bancárias.
                  </p>
                  <p className="text-xs text-yellow-700 mt-1">
                    Clique em "Iniciar Importação" para escolher a conta.
                  </p>
                </div>
              )}

              {isProcessing && (
                <div className="space-y-2 mt-4">
                  <div className="flex justify-between text-sm">
                    <span>Processando...</span>
                    <span>{progress}%</span>
                  </div>
                  <Progress value={progress} />
                </div>
              )}
            </div>
          ) : (
            <div className="py-4 space-y-6">
              {/* Summary Cards */}
              <div className="grid grid-cols-3 gap-4 text-center">
                <div className="bg-green-50 p-4 rounded-lg border border-green-100">
                  <div className="text-3xl font-bold text-green-600">
                    {results.success.length}
                  </div>
                  <div className="text-sm text-green-800 font-medium">Sucesso</div>
                </div>
                <div className="bg-yellow-50 p-4 rounded-lg border border-yellow-100">
                  <div className="text-3xl font-bold text-yellow-600">
                    {results.duplicated.length}
                  </div>
                  <div className="text-sm text-yellow-800 font-medium">Duplicadas</div>
                </div>
                <div className="bg-red-50 p-4 rounded-lg border border-red-100">
                  <div className="text-3xl font-bold text-red-600">
                    {results.errors.length}
                  </div>
                  <div className="text-sm text-red-800 font-medium">Erros</div>
                </div>
              </div>

              {results.duplicated.length > 0 && (
                <div className="border rounded-md p-4 bg-yellow-50/50">
                  <h4 className="text-sm font-semibold mb-3 text-yellow-800 flex items-center gap-2">
                    <AlertTriangle className="w-4 h-4" /> Notas Duplicadas
                  </h4>
                  <ScrollArea className="h-[180px] pr-4">
                    <div className="space-y-3">
                      {results.duplicated.map((item, idx) => (
                        <div
                          key={idx}
                          className="flex items-center justify-between bg-white p-3 rounded border text-sm shadow-sm"
                        >
                          <div>
                            <p className="font-medium text-gray-800">
                              Nota {item.numero_nota}
                            </p>
                            <p className="text-xs text-gray-500">
                              Arquivo: {item.fileName}
                            </p>
                          </div>
                          <Button
                            size="sm"
                            variant="outline"
                            className="border-yellow-300 hover:bg-yellow-50 text-yellow-700"
                            onClick={() => handleReplace(item)}
                            disabled={replacingId === item.idExistente}
                          >
                            {replacingId === item.idExistente ? (
                              <Loader2 className="w-3 h-3 animate-spin" />
                            ) : (
                              <RefreshCw className="w-3 h-3 mr-1" />
                            )}
                            Substituir
                          </Button>
                        </div>
                      ))}
                    </div>
                  </ScrollArea>
                </div>
              )}

              {results.errors.length > 0 && (
                <div className="border rounded-md p-4 bg-red-50/50">
                  <h4 className="text-sm font-semibold mb-2 text-red-800">
                    Erros Encontrados
                  </h4>
                  <ScrollArea className="h-[100px]">
                    <ul className="space-y-2">
                      {results.errors.map((err, idx) => (
                        <li
                          key={idx}
                          className="text-xs text-red-600 flex items-start gap-2"
                        >
                          <span className="font-bold">• {err.fileName}:</span> {err.motivo}
                        </li>
                      ))}
                    </ul>
                  </ScrollArea>
                </div>
              )}
            </div>
          )}

          <DialogFooter>
            {!results ? (
              <>
                <Button
                  variant="outline"
                  onClick={() => setIsOpen(false)}
                  disabled={isProcessing}
                >
                  Cancelar
                </Button>
                <Button
                  onClick={handleStartProcessing}
                  disabled={files.length === 0 || isProcessing}
                >
                  {isProcessing && (
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  )}
                  {isProcessing ? 'Importando...' : 'Iniciar Importação'}
                </Button>
              </>
            ) : (
              <Button className="w-full" onClick={() => setIsOpen(false)}>
                Concluir
              </Button>
            )}
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <AccountSelectorDialog
        isOpen={showAccountSelector}
        onClose={() => setShowAccountSelector(false)}
        onSelectAccount={(account) => {
          setSelectedAccount(account);
          setShowAccountSelector(false);
          setTimeout(() => processFiles(), 100);
        }}
        companyId={selectedCompany?.id}
        title="Selecionar Conta para Lançamentos"
        description="Escolha a conta bancária onde os lançamentos serão vinculados."
      />
    </>
  );
};

export default BatchNfseUpload;
