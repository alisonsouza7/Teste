
import React, { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { Shield, Menu, X, LayoutDashboard, Building2, Users, Link as LinkIcon, Receipt, FileText, Settings, LogOut, Calculator, LayoutGrid } from 'lucide-react';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';

const navItems = [
  { href: '/admin/dashboard', icon: LayoutDashboard, label: 'Dashboard' },
  { href: '/admin/tarefas', icon: LayoutGrid, label: 'Painel de Tarefas' },
  { href: '/admin/accounting', icon: Calculator, label: 'Máquina Contábil' },
  { href: '/admin/empresas', icon: Building2, label: 'Empresas' },
  { href: '/admin/usuarios', icon: Users, label: 'Usuários' },
  { href: '/admin/vinculos', icon: LinkIcon, label: 'Vínculos' },
  { href: '/admin/notas', icon: Receipt, label: 'Notas Fiscais' },
  { href: '/admin/guias', icon: FileText, label: 'Guias de Impostos' },
  { href: '/admin/config', icon: Settings, label: 'Configurações' },
];

const Sidebar = ({ isMobileMenuOpen, closeMobileMenu }) => {
  const location = useLocation();

  return (
    <aside className="w-64 flex-shrink-0 bg-slate-900 text-white flex flex-col">
      <div className="h-16 flex items-center justify-between px-4 border-b border-slate-800 bg-slate-950">
        <div className="flex items-center gap-3">
          <Shield className="w-8 h-8 text-indigo-500" />
          <span className="text-xl font-bold tracking-tight">Admin Conterj</span>
        </div>
        {isMobileMenuOpen && (
          <Button variant="ghost" size="icon" onClick={closeMobileMenu} className="lg:hidden text-white hover:bg-slate-800">
            <X className="h-6 w-6" />
          </Button>
        )}
      </div>
      <nav className="flex-1 px-2 py-4 space-y-1">
        {navItems.map((item) => (
          <Link
            key={item.label}
            to={item.href}
            onClick={closeMobileMenu}
            className={`flex items-center px-4 py-3 text-sm font-medium rounded-md transition-all ${
              location.pathname.startsWith(item.href)
                ? 'bg-indigo-600 text-white shadow-md'
                : 'text-slate-300 hover:bg-slate-800 hover:text-white'
            }`}
          >
            <item.icon className="mr-3 h-5 w-5" />
            {item.label}
          </Link>
        ))}
      </nav>
      <div className="p-4 border-t border-slate-800">
          <div className="flex items-center gap-3 px-2">
             <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse"></div>
             <span className="text-xs text-slate-400">Sistema Online</span>
          </div>
      </div>
    </aside>
  );
};

const Header = ({ onMenuClick }) => {
  const { user, signOut } = useAuth();

  const getInitials = (name) => {
    if (!name) return 'AD';
    const names = name.split(' ');
    const first = names[0]?.[0] || '';
    const last = names.length > 1 ? names[names.length - 1]?.[0] : '';
    return (first + last).toUpperCase();
  };

  return (
    <header className="h-16 bg-white shadow-sm flex items-center justify-between px-4 sm:px-6 lg:px-8 z-10 border-b">
      <div className="flex items-center gap-4">
        <Button variant="ghost" size="icon" onClick={onMenuClick} className="lg:hidden">
          <Menu className="h-6 w-6" />
        </Button>
        <h2 className="text-lg font-semibold text-slate-800 hidden md:block">
            Área Administrativa
        </h2>
      </div>

      <div className="flex-1 flex justify-end items-center gap-4">
        <div className="flex items-center gap-3">
            <div className="text-right hidden sm:block">
                <p className="text-sm font-bold text-slate-800">Administrador</p>
                <p className="text-xs text-slate-500">{user?.email}</p>
            </div>
             <Avatar className="h-9 w-9 border-2 border-indigo-100">
                <AvatarImage src={user?.user_metadata?.avatar_url} />
                <AvatarFallback className="bg-indigo-100 text-indigo-700">{getInitials(user?.user_metadata?.nome)}</AvatarFallback>
            </Avatar>
        </div>

        <Button onClick={signOut} variant="ghost" size="icon" className="text-slate-600 hover:bg-red-50 hover:text-red-600 transition-colors">
          <LogOut className="w-5 h-5" />
        </Button>
      </div>
    </header>
  );
};

const AdminLayout = ({ children }) => {
  const [isMobileMenuOpen, setMobileMenuOpen] = useState(false);

  return (
    <div className="min-h-screen flex bg-slate-50">
      <div className="hidden lg:flex">
        <Sidebar />
      </div>
      
      <AnimatePresence>
        {isMobileMenuOpen && (
          <motion.div
            initial={{ x: '-100%' }}
            animate={{ x: 0 }}
            exit={{ x: '-100%' }}
            transition={{ type: 'spring', stiffness: 300, damping: 30 }}
            className="fixed inset-y-0 left-0 z-40 lg:hidden"
          >
            <Sidebar isMobileMenuOpen={isMobileMenuOpen} closeMobileMenu={() => setMobileMenuOpen(false)} />
          </motion.div>
        )}
      </AnimatePresence>
      {isMobileMenuOpen && <div className="fixed inset-0 bg-black/50 z-30 lg:hidden" onClick={() => setMobileMenuOpen(false)}></div>}

      <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
        <Header onMenuClick={() => setMobileMenuOpen(true)} />
        <main className="flex-1 p-4 sm:p-6 lg:p-8 overflow-y-auto overflow-x-hidden">
          {children}
        </main>
      </div>
    </div>
  );
};

export default AdminLayout;
