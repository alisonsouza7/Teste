import React, { useState } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { useCompany } from '@/contexts/CompanyContext';
import { cn } from '@/lib/utils';
import { motion, AnimatePresence } from 'framer-motion';

import {
  LogOut,
  LayoutDashboard,
  FileText,
  PieChart,
  User,
  Menu,
  X,
  Building2,
  ChevronDown,
  CreditCard,
  DollarSign,
  Settings
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Separator } from '@/components/ui/separator';

const ClientLayout = ({ children }) => {
  const { signOut, user } = useAuth();
  const { companies, selectedCompany, setSelectedCompany, isPF } = useCompany();
  const navigate = useNavigate();
  const location = useLocation();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  // Updated Nav Items with better structure
  const mainNav = [
    { label: 'Visão Geral', path: '/cliente/dashboard', icon: LayoutDashboard },
    { label: 'Financeiro', path: '/cliente/financeiro', icon: DollarSign },
    { label: 'Notas Fiscais', path: '/cliente/notas-fiscais', icon: FileText, hidden: isPF },
    { label: 'Impostos', path: '/cliente/guias', icon: CreditCard, hidden: isPF },
    { label: 'Relatórios', path: '/cliente/relatorios', icon: PieChart },
  ].filter(x => !x.hidden);

  const handleSignOut = async () => {
    await signOut();
    navigate('/login');
  };

  const isActive = (path) => {
    if (path === '/cliente/financeiro') {
      return location.pathname.startsWith('/cliente/financeiro');
    }
    return location.pathname === path;
  };

  return (
    <div className="flex min-h-screen flex-col bg-background selection:bg-primary/20">
      
      {/* --- DESKTOP HEADER --- */}
      <header className="sticky top-0 z-50 hidden w-full border-b bg-white/80 backdrop-blur-md shadow-sm md:block">
        <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-4 sm:px-6 lg:px-8">
          
          <div className="flex items-center gap-8">
            {/* Brand */}
            <button onClick={() => navigate('/cliente/dashboard')} className="flex items-center gap-2 group">
              <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-primary text-white shadow-lg group-hover:bg-primary/90 transition-all">
                <Building2 className="h-5 w-5" />
              </div>
              <span className="text-xl font-bold tracking-tight text-foreground">Conterj</span>
            </button>

            {/* Main Navigation */}
            <nav className="flex items-center gap-1">
              {mainNav.map((item) => (
                <Button
                  key={item.path}
                  variant="ghost"
                  size="sm"
                  onClick={() => navigate(item.path)}
                  className={cn(
                    "relative h-9 px-4 font-medium transition-all rounded-full hover:bg-slate-100",
                    isActive(item.path) 
                      ? "text-primary bg-primary/10 font-semibold" 
                      : "text-slate-600 hover:text-slate-900"
                  )}
                >
                  <item.icon className={cn("mr-2 h-4 w-4", isActive(item.path) ? "text-primary" : "text-slate-500")} />
                  {item.label}
                </Button>
              ))}
            </nav>
          </div>

          <div className="flex items-center gap-4">
            {/* Company Selector */}
            {companies.length > 0 && (
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="outline" size="sm" className="h-9 gap-2 min-w-[160px] justify-between rounded-full border-slate-200 bg-slate-50 hover:bg-white hover:border-slate-300">
                    <span className="truncate max-w-[140px] font-medium text-slate-700">{selectedCompany?.nome || 'Selecione'}</span>
                    <ChevronDown className="h-3 w-3 shrink-0 opacity-50" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-[240px] p-2">
                  <DropdownMenuLabel className="text-xs text-muted-foreground uppercase tracking-wider">Trocar Empresa</DropdownMenuLabel>
                  {companies.map((company) => (
                    <DropdownMenuItem
                      key={company.id}
                      onClick={() => setSelectedCompany(company)}
                      className={cn(
                        "rounded-md cursor-pointer mb-1",
                        selectedCompany?.id === company.id && "bg-primary/5 text-primary font-medium"
                      )}
                    >
                      {company.nome}
                    </DropdownMenuItem>
                  ))}
                </DropdownMenuContent>
              </DropdownMenu>
            )}

            <div className="h-6 w-px bg-slate-200" />

            {/* Profile Menu */}
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="icon" className="rounded-full h-9 w-9 border border-slate-200 bg-white">
                  <Avatar className="h-full w-full">
                    <AvatarFallback className="bg-gradient-brand text-white text-xs">
                      {user?.email?.substring(0, 2).toUpperCase()}
                    </AvatarFallback>
                  </Avatar>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-56 p-2">
                <div className="px-2 py-1.5">
                  <p className="text-sm font-semibold text-foreground">Minha Conta</p>
                  <p className="text-xs text-muted-foreground truncate">{user?.email}</p>
                </div>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={() => navigate('/cliente/perfil')} className="cursor-pointer">
                  <User className="mr-2 h-4 w-4" /> Perfil
                </DropdownMenuItem>
                <DropdownMenuItem onClick={handleSignOut} className="text-red-600 focus:text-red-600 focus:bg-red-50 cursor-pointer">
                  <LogOut className="mr-2 h-4 w-4" /> Sair
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>
      </header>

      {/* --- MOBILE HEADER --- */}
      <header className="sticky top-0 z-50 flex h-16 w-full items-center justify-between border-b bg-white px-4 md:hidden shadow-sm">
        <div className="flex items-center gap-3">
          <Button variant="ghost" size="icon" onClick={() => setMobileMenuOpen(true)} className="-ml-2">
            <Menu className="h-6 w-6 text-slate-700" />
          </Button>
          <span className="font-bold text-lg text-primary">Conterj</span>
        </div>
        
        <div className="flex items-center gap-2">
          {companies.length > 1 && (
             <DropdownMenu>
               <DropdownMenuTrigger asChild>
                 <Button variant="ghost" size="sm" className="max-w-[140px]">
                    <span className="truncate text-sm font-medium">{selectedCompany?.nome}</span>
                    <ChevronDown className="h-3 w-3 ml-1 opacity-50" />
                 </Button>
               </DropdownMenuTrigger>
               <DropdownMenuContent align="end">
                  {companies.map(c => (
                    <DropdownMenuItem key={c.id} onClick={() => setSelectedCompany(c)}>{c.nome}</DropdownMenuItem>
                  ))}
               </DropdownMenuContent>
             </DropdownMenu>
          )}
          <Avatar className="h-8 w-8 border border-slate-200">
            <AvatarFallback className="bg-primary text-white text-[10px]">
              {user?.email?.substring(0, 2).toUpperCase()}
            </AvatarFallback>
          </Avatar>
        </div>
      </header>

      {/* --- MOBILE DRAWER --- */}
      <AnimatePresence>
        {mobileMenuOpen && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 z-[60] bg-black/40 backdrop-blur-sm md:hidden"
              onClick={() => setMobileMenuOpen(false)}
            />
            <motion.div
              initial={{ x: '-100%' }}
              animate={{ x: 0 }}
              exit={{ x: '-100%' }}
              transition={{ type: 'spring', damping: 25, stiffness: 300 }}
              className="fixed left-0 top-0 bottom-0 z-[70] w-[80%] max-w-[300px] bg-white shadow-2xl flex flex-col md:hidden"
            >
              <div className="h-16 flex items-center px-6 border-b">
                 <Building2 className="h-6 w-6 text-primary mr-2" />
                 <span className="text-xl font-bold text-primary">Conterj</span>
                 <Button variant="ghost" size="icon" className="ml-auto" onClick={() => setMobileMenuOpen(false)}>
                   <X className="h-5 w-5" />
                 </Button>
              </div>

              <div className="flex-1 overflow-y-auto py-6 px-4 space-y-1">
                {mainNav.map((item) => (
                  <button
                    key={item.path}
                    onClick={() => { navigate(item.path); setMobileMenuOpen(false); }}
                    className={cn(
                      "flex w-full items-center gap-3 rounded-lg px-4 py-3 text-sm font-medium transition-colors",
                      isActive(item.path)
                        ? "bg-primary text-white shadow-md"
                        : "text-slate-600 hover:bg-slate-50"
                    )}
                  >
                    <item.icon className={cn("h-5 w-5", isActive(item.path) ? "text-white" : "text-slate-400")} />
                    {item.label}
                  </button>
                ))}
              </div>

              <div className="p-4 border-t bg-slate-50">
                <Button variant="outline" className="w-full justify-start text-red-600 hover:text-red-700 hover:bg-red-50 border-red-100" onClick={handleSignOut}>
                  <LogOut className="mr-2 h-4 w-4" /> Sair do Sistema
                </Button>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>

      {/* --- MAIN CONTENT --- */}
      <main className="flex-1 w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
         {children}
      </main>

    </div>
  );
};

export default ClientLayout;