import React from 'react';
import { MoreHorizontal, Edit2, Trash2, Eye } from 'lucide-react';
import { Button } from '@/components/ui/button';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuSeparator
} from '@/components/ui/dropdown-menu';

/**
 * ActionMenu Component (The "Kebab" Menu)
 * 
 * DESIGN DECISION:
 * - Hides clutter (Edit/Delete buttons) behind a menu to keep tables clean.
 * - Uses specific colors for destructive actions (Red) to prevent accidental clicks.
 * - Consistent icon usage for fast recognition.
 */
const ActionMenu = ({ 
  onEdit, 
  onDelete, 
  onView, 
  customActions = [], 
  align = "end" 
}) => {
  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="ghost" size="icon" className="h-8 w-8 text-muted-foreground hover:text-foreground">
          <MoreHorizontal className="h-4 w-4" />
          <span className="sr-only">Ações</span>
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align={align} className="w-[160px]">
        {onView && (
          <DropdownMenuItem onClick={onView}>
            <Eye className="mr-2 h-4 w-4 text-muted-foreground" />
            Ver detalhes
          </DropdownMenuItem>
        )}
        {onEdit && (
          <DropdownMenuItem onClick={onEdit}>
            <Edit2 className="mr-2 h-4 w-4 text-muted-foreground" />
            Editar
          </DropdownMenuItem>
        )}
        {customActions.map((action, idx) => (
           <React.Fragment key={idx}>
             {action.separatorBefore && <DropdownMenuSeparator />}
             <DropdownMenuItem onClick={action.onClick} className={action.className}>
               {action.icon && <action.icon className="mr-2 h-4 w-4" />}
               {action.label}
             </DropdownMenuItem>
           </React.Fragment>
        ))}
        {onDelete && (
          <>
            <DropdownMenuSeparator />
            <DropdownMenuItem onClick={onDelete} className="text-red-600 focus:text-red-600 focus:bg-red-50">
              <Trash2 className="mr-2 h-4 w-4" />
              Excluir
            </DropdownMenuItem>
          </>
        )}
      </DropdownMenuContent>
    </DropdownMenu>
  );
};

export default ActionMenu;