import React from 'react';
import { Card } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Search } from 'lucide-react';
import { cn } from '@/lib/utils';

/**
 * DataTableShell Component
 * 
 * DESIGN DECISION:
 * - Wraps standard tables to enforce consistent toolbar layout (Search left, Actions right).
 * - Uses a subtle background for the header area to distinguish controls from data.
 * - Handles the "Card" containment so pages don't need to repeat the Card wrapper code.
 */
const DataTableShell = ({ 
  children, 
  title,
  searchPlaceholder = "Buscar...",
  onSearchChange,
  searchValue,
  filters,
  actions,
  className
}) => {
  return (
    <Card className={cn("border shadow-subtle overflow-hidden flex flex-col h-full", className)}>
      {/* Header Toolbar: Gray background to separate controls from data */}
      <div className="p-4 sm:p-5 border-b flex flex-col sm:flex-row gap-4 justify-between items-start sm:items-center bg-slate-50/30">
        
        {/* Title & Search Group */}
        <div className="flex flex-1 items-center gap-4 w-full sm:w-auto">
          {title && <h3 className="font-semibold text-lg whitespace-nowrap hidden md:block">{title}</h3>}
          
          <div className="relative w-full sm:max-w-xs">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input 
              placeholder={searchPlaceholder}
              className="pl-9 h-10 bg-white border-slate-200 focus-visible:ring-primary/20"
              value={searchValue}
              onChange={onSearchChange}
            />
          </div>
        </div>

        {/* Actions & Filters Group */}
        <div className="flex items-center gap-2 w-full sm:w-auto justify-end">
          {filters}
          {actions}
        </div>
      </div>

      {/* Main Content Area: White background */}
      <div className="flex-1 overflow-auto bg-white min-h-[300px]">
        {children}
      </div>
    </Card>
  );
};

export default DataTableShell;