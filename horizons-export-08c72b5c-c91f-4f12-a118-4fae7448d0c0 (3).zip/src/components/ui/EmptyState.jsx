import React from 'react';
import { PackageOpen } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';

/**
 * EmptyState Component
 * 
 * DESIGN DECISION:
 * - Uses whitespace effectively to communicate "nothing here" without looking broken.
 * - Central icon is large but uses muted colors to remain subtle.
 * - Includes animation (zoom-in) to make the state change feel deliberate.
 */
const EmptyState = ({ 
  title = "Nenhum dado encontrado", 
  description = "Tente ajustar seus filtros ou crie um novo registro.", 
  icon: Icon = PackageOpen,
  actionLabel,
  onAction,
  className
}) => {
  return (
    <div className={cn("flex flex-col items-center justify-center py-16 px-4 text-center animate-in fade-in zoom-in-95 duration-300", className)}>
      <div className="bg-slate-50 p-4 rounded-full mb-4 ring-1 ring-slate-100">
        <Icon className="h-8 w-8 text-muted-foreground/60" />
      </div>
      <h3 className="text-lg font-semibold text-foreground mb-1">{title}</h3>
      <p className="text-sm text-muted-foreground max-w-sm mb-6">{description}</p>
      
      {actionLabel && onAction && (
        <Button onClick={onAction} variant="default" className="gap-2">
          {actionLabel}
        </Button>
      )}
    </div>
  );
};

export default EmptyState;