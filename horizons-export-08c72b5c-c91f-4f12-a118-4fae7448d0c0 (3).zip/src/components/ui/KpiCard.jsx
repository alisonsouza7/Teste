import React from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { cn } from '@/lib/utils';
import { ArrowUpRight, ArrowDownRight, Minus } from 'lucide-react';

/**
 * KpiCard Component
 * 
 * DESIGN DECISION:
 * - Supports 'visual variants' (primary/secondary) to allow the dashboard to guide the user's eye 
 *   to the most important numbers (e.g., Faturamento).
 * - Includes 'trend' visualization to provide context (better or worse than last month) instantly.
 * - Uses shadow-card by default but hover-elevation to make it feel interactive.
 * 
 * @param {string} title - Label for the metric
 * @param {string|number} value - The main number to display
 * @param {number} trend - Percentage change (positive/negative)
 * @param {string} variant - 'default' (white), 'primary' (navy), 'secondary' (yellow)
 */
const KpiCard = ({ 
  title, 
  value, 
  icon: Icon, 
  trend, 
  trendLabel = "vs mês anterior", 
  variant = 'default', 
  className 
}) => {
  const isPositive = trend > 0;
  const isNegative = trend < 0;
  const isNeutral = trend === 0 || trend === undefined;

  // Variant Styling Maps
  const bgStyles = {
    default: "bg-white",
    primary: "bg-primary text-primary-foreground", // Navy Background
    secondary: "bg-secondary text-secondary-foreground" // Yellow Background
  };

  const trendColor = {
    default: isPositive ? "text-emerald-600" : isNegative ? "text-red-600" : "text-muted-foreground",
    primary: "text-white/80", // Lighter text on dark background
    secondary: "text-primary/80" // Dark text on yellow background
  };

  return (
    <Card className={cn(
      "border shadow-card hover:shadow-elevated transition-all duration-200", 
      bgStyles[variant],
      className
    )}>
      <CardContent className="p-6">
        <div className="flex justify-between items-start mb-4">
          {/* Icon Container: Uses translucent backgrounds for depth */}
          <div className={cn(
            "p-2 rounded-lg",
            variant === 'default' ? "bg-primary/5 text-primary" : "bg-white/20 text-white"
          )}>
            {Icon && <Icon className="h-5 w-5" />}
          </div>
          
          {/* Trend Badge */}
          {trend !== undefined && (
            <div className={cn("flex items-center text-xs font-medium bg-white/50 px-2 py-1 rounded-full border border-black/5", trendColor[variant])}>
              {isPositive && <ArrowUpRight className="h-3 w-3 mr-1" />}
              {isNegative && <ArrowDownRight className="h-3 w-3 mr-1" />}
              {isNeutral && <Minus className="h-3 w-3 mr-1" />}
              {Math.abs(trend)}%
            </div>
          )}
        </div>

        <div className="space-y-1">
          <h3 className={cn("text-2xl font-bold tracking-tight", variant === 'primary' ? "text-white" : "text-foreground")}>
            {value}
          </h3>
          <p className={cn("text-sm font-medium", variant === 'primary' ? "text-blue-100" : "text-muted-foreground")}>
            {title}
          </p>
        </div>
      </CardContent>
    </Card>
  );
};

export default KpiCard;