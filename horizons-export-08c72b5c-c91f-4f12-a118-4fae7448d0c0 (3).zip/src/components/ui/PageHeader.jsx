import React from 'react';
import { ChevronRight } from 'lucide-react';
import { cn } from '@/lib/utils';
import { Button } from '@/components/ui/button';

/**
 * PageHeader Component
 * 
 * DESIGN DECISION:
 * - Uses a subtle top gradient to reinforce brand identity (Navy -> Yellow) without being overwhelming.
 * - Standardizes the layout of Title + Subtitle + Actions across the app.
 * - Handles breadcrumbs automatically to improve navigation depth awareness.
 * 
 * @param {string} title - Main page title (H1)
 * @param {string} subtitle - Descriptive text below title
 * @param {Array} breadcrumbs - Path segments for navigation context
 * @param {ReactNode} actions - Buttons/Controls to display on the right
 */
const PageHeader = ({ 
  title, 
  subtitle, 
  breadcrumbs = [], 
  actions, 
  className 
}) => {
  return (
    <div className={cn("flex flex-col gap-4 pb-6 border-b border-border/40 relative", className)}>
      {/* 
         DESIGN DECISION: 
         The top gradient adds a "premium" feel and frames the content area.
         Hidden on mobile to save vertical space.
      */}
      <div className="absolute top-[-1.5rem] left-0 right-0 h-1 bg-gradient-to-r from-primary/80 via-primary to-secondary/80 hidden md:block opacity-0" />

      {/* Breadcrumbs Navigation */}
      {breadcrumbs.length > 0 && (
        <nav className="flex items-center text-sm text-muted-foreground">
          {breadcrumbs.map((item, idx) => (
            <React.Fragment key={idx}>
              {idx > 0 && <ChevronRight className="h-4 w-4 mx-2 opacity-50" />}
              <span className={cn(
                idx === breadcrumbs.length - 1 ? "font-medium text-foreground" : "hover:text-primary transition-colors cursor-default"
              )}>
                {item.label}
              </span>
            </React.Fragment>
          ))}
        </nav>
      )}

      {/* Main Flex Container: Stacks on mobile, Row on Desktop */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div className="space-y-1">
          <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-foreground">{title}</h1>
          {subtitle && (
            <p className="text-muted-foreground text-sm sm:text-base max-w-2xl">{subtitle}</p>
          )}
        </div>

        {/* Actions Area */}
        {actions && (
          <div className="flex items-center gap-3 w-full md:w-auto">
            {actions}
          </div>
        )}
      </div>
    </div>
  );
};

export default PageHeader;