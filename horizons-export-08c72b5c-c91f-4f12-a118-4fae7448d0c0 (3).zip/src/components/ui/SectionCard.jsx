import React from 'react';
import { Card, CardHeader, CardTitle, CardContent, CardDescription } from '@/components/ui/card';
import { cn } from '@/lib/utils';

/**
 * SectionCard Component
 * 
 * DESIGN DECISION:
 * - Used for grouping major content blocks (like charts or lists) on the dashboard.
 * - Enforces a consistent header style with Title + Description + Action.
 * - Uses a flex-column layout to ensure height consistency when used in grids.
 */
const SectionCard = ({
  title,
  description,
  action,
  children,
  className,
  contentClassName,
  headerClassName,
  compact = false
}) => {
  return (
    <Card className={cn("border shadow-card h-full flex flex-col", className)}>
      <CardHeader className={cn(
        "flex flex-row items-start justify-between space-y-0 border-b bg-slate-50/40",
        compact ? "p-4 pb-3" : "p-6 pb-4",
        headerClassName
      )}>
        <div className="space-y-1">
          <CardTitle className="text-base font-semibold text-foreground">{title}</CardTitle>
          {description && <CardDescription>{description}</CardDescription>}
        </div>
        {action && <div className="pl-4">{action}</div>}
      </CardHeader>
      <CardContent className={cn(compact ? "p-4 flex-1" : "p-6 flex-1", contentClassName)}>
        {children}
      </CardContent>
    </Card>
  );
};

export default SectionCard;