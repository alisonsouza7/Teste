import React, { useState, useEffect, useRef } from 'react';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { ChevronLeft, ChevronRight, Filter, X } from 'lucide-react';
import { getPeriodDates } from '@/lib/periodHelpers';
import { cn } from '@/lib/utils';
import { motion, AnimatePresence } from 'framer-motion';

const SmartFilter = ({ onPeriodChange, children, className, initialType = 'monthly' }) => {
  const today = new Date();
  const [type, setType] = useState(initialType);
  const [year, setYear] = useState(today.getFullYear().toString());
  const [value, setValue] = useState(today.getMonth().toString()); // Month (0-11) or Quarter (1-4)
  const [isExpanded, setIsExpanded] = useState(false);

  // Helper to generate years
  const currentYear = today.getFullYear();
  const years = Array.from({ length: 11 }, (_, i) => (currentYear - 5 + i).toString());

  const months = [
    { value: '0', label: 'Janeiro' }, { value: '1', label: 'Fevereiro' }, { value: '2', label: 'Março' },
    { value: '3', label: 'Abril' }, { value: '4', label: 'Maio' }, { value: '5', label: 'Junho' },
    { value: '6', label: 'Julho' }, { value: '7', label: 'Agosto' }, { value: '8', label: 'Setembro' },
    { value: '9', label: 'Outubro' }, { value: '10', label: 'Novembro' }, { value: '11', label: 'Dezembro' },
  ];

  const quarters = [
    { value: '1', label: '1º Trimestre' }, { value: '2', label: '2º Trimestre' },
    { value: '3', label: '3º Trimestre' }, { value: '4', label: '4º Trimestre' },
  ];

  // Ref to prevent loop/duplicate updates
  const prevValues = useRef({ type: null, startDate: null, endDate: null });

  useEffect(() => {
    const { startDate, endDate } = getPeriodDates(type, year, value);
    
    if (
      prevValues.current.type !== type ||
      prevValues.current.startDate !== startDate ||
      prevValues.current.endDate !== endDate
    ) {
      prevValues.current = { type, startDate, endDate };
      onPeriodChange({ type, startDate, endDate, year, value });
    }
  }, [type, year, value, onPeriodChange]);

  const handlePrev = () => {
    if (type === 'monthly') {
      let m = parseInt(value) - 1;
      let y = parseInt(year);
      if (m < 0) { m = 11; y -= 1; }
      setValue(m.toString());
      setYear(y.toString());
    } else if (type === 'yearly') {
        setYear((parseInt(year) - 1).toString());
    }
  };

  const handleNext = () => {
    if (type === 'monthly') {
      let m = parseInt(value) + 1;
      let y = parseInt(year);
      if (m > 11) { m = 0; y += 1; }
      setValue(m.toString());
      setYear(y.toString());
    } else if (type === 'yearly') {
        setYear((parseInt(year) + 1).toString());
    }
  };

  const currentLabel = () => {
    if (type === 'monthly') return `${months.find(m => m.value === value)?.label} ${year}`;
    if (type === 'quarterly') return `${quarters.find(q => q.value === value)?.label} ${year}`;
    if (type === 'yearly') return `Ano ${year}`;
    return 'Todo o Período';
  };

  return (
    <div className={cn("w-full", className)}>
      {/* --- Mobile View (< 768px) --- */}
      <div className="md:hidden flex flex-col gap-2 bg-card border rounded-xl p-3 shadow-sm mb-4">
        <div className="flex items-center justify-between gap-2">
            {/* Month Nav Arrows */}
            <div className="flex items-center justify-between bg-muted/50 rounded-lg p-1 flex-1">
                <Button variant="ghost" size="icon" className="h-8 w-8" onClick={handlePrev} disabled={type === 'all'}>
                    <ChevronLeft className="h-4 w-4" />
                </Button>
                <span className="text-sm font-semibold truncate px-2 text-center flex-1">{currentLabel()}</span>
                <Button variant="ghost" size="icon" className="h-8 w-8" onClick={handleNext} disabled={type === 'all'}>
                    <ChevronRight className="h-4 w-4" />
                </Button>
            </div>
            
            {/* Expand Toggle */}
            <Button 
                variant={isExpanded ? "default" : "outline"} 
                size="icon" 
                className="h-10 w-10 shrink-0"
                onClick={() => setIsExpanded(!isExpanded)}
            >
                {isExpanded ? <X className="h-4 w-4" /> : <Filter className="h-4 w-4" />}
            </Button>
        </div>

        {/* Expanded Content (Mobile) */}
        <AnimatePresence>
            {isExpanded && (
                <motion.div 
                    initial={{ height: 0, opacity: 0 }} 
                    animate={{ height: 'auto', opacity: 1 }} 
                    exit={{ height: 0, opacity: 0 }}
                    className="overflow-hidden"
                >
                    <div className="pt-2 border-t space-y-3 mt-2">
                         <div className="grid grid-cols-2 gap-2">
                             <div className="space-y-1">
                                <span className="text-[10px] uppercase font-bold text-muted-foreground">Tipo</span>
                                <Select value={type} onValueChange={(v) => {
                                    setType(v);
                                    if (v === 'monthly') setValue(today.getMonth().toString());
                                    if (v === 'quarterly') setValue('1');
                                }}>
                                    <SelectTrigger className="h-9 text-xs"><SelectValue /></SelectTrigger>
                                    <SelectContent>
                                        <SelectItem value="monthly">Mensal</SelectItem>
                                        <SelectItem value="quarterly">Trimestral</SelectItem>
                                        <SelectItem value="yearly">Anual</SelectItem>
                                        <SelectItem value="all">Tudo</SelectItem>
                                    </SelectContent>
                                </Select>
                             </div>
                             {type !== 'all' && (
                                 <div className="space-y-1">
                                    <span className="text-[10px] uppercase font-bold text-muted-foreground">Ano</span>
                                    <Select value={year} onValueChange={setYear}>
                                        <SelectTrigger className="h-9 text-xs"><SelectValue /></SelectTrigger>
                                        <SelectContent>
                                            {years.map(y => <SelectItem key={y} value={y}>{y}</SelectItem>)}
                                        </SelectContent>
                                    </Select>
                                 </div>
                             )}
                         </div>
                         {/* Extra Children Filters */}
                         <div className="space-y-3">
                             {children}
                         </div>
                    </div>
                </motion.div>
            )}
        </AnimatePresence>
      </div>

      {/* --- Desktop View (>= 768px) --- */}
      <div className="hidden md:flex flex-wrap items-center gap-2">
         {/* Period Group */}
         <div className="flex items-center gap-2 bg-card border rounded-md p-1 shadow-sm h-10 px-2">
            <Select value={type} onValueChange={(v) => {
                setType(v);
                if (v === 'monthly') setValue(today.getMonth().toString());
                if (v === 'quarterly') setValue('1');
            }}>
                <SelectTrigger className="h-8 w-[100px] border-0 bg-transparent focus:ring-0 text-sm font-medium">
                   <SelectValue />
                </SelectTrigger>
                <SelectContent>
                    <SelectItem value="monthly">Mensal</SelectItem>
                    <SelectItem value="quarterly">Trimestral</SelectItem>
                    <SelectItem value="yearly">Anual</SelectItem>
                    <SelectItem value="all">Tudo</SelectItem>
                </SelectContent>
            </Select>

            {type !== 'all' && (
                <>
                    <div className="h-4 w-px bg-border mx-1" />
                    <Select value={year} onValueChange={setYear}>
                        <SelectTrigger className="h-8 w-[70px] border-0 bg-transparent focus:ring-0 text-sm">
                             <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                             {years.map(y => <SelectItem key={y} value={y}>{y}</SelectItem>)}
                        </SelectContent>
                    </Select>
                </>
            )}

             {type === 'monthly' && (
                 <>
                    <div className="h-4 w-px bg-border mx-1" />
                    <Select value={value} onValueChange={setValue}>
                        <SelectTrigger className="h-8 w-[110px] border-0 bg-transparent focus:ring-0 text-sm">
                             <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                             {months.map(m => <SelectItem key={m.value} value={m.value}>{m.label}</SelectItem>)}
                        </SelectContent>
                    </Select>
                 </>
            )}

            {type === 'quarterly' && (
                 <>
                    <div className="h-4 w-px bg-border mx-1" />
                    <Select value={value} onValueChange={setValue}>
                        <SelectTrigger className="h-8 w-[120px] border-0 bg-transparent focus:ring-0 text-sm">
                             <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                             {quarters.map(q => <SelectItem key={q.value} value={q.value}>{q.label}</SelectItem>)}
                        </SelectContent>
                    </Select>
                 </>
            )}
         </div>

         {/* Children Filters (In Line) */}
         <div className="flex items-center gap-2">
             {children}
         </div>
      </div>
    </div>
  );
};

export default SmartFilter;