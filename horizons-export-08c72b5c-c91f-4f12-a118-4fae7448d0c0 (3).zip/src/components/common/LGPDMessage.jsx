
import React from 'react';
import { Lock } from 'lucide-react';
import { cn } from '@/lib/utils';

const LGPDMessage = ({ className }) => {
  return (
    <div className={cn("flex items-start gap-3 p-4 rounded-lg bg-slate-50 border border-slate-100 text-slate-500", className)}>
      <div className="p-1.5 bg-slate-100 rounded-md shrink-0">
        <Lock className="h-4 w-4 text-slate-400" />
      </div>
      <div className="text-xs leading-relaxed max-w-2xl">
        <p>
          <strong className="font-semibold text-slate-600 block mb-0.5">Segurança de Dados (LGPD)</strong>
          Seus dados de certificado e informações fiscais são criptografados e armazenados com segurança em total conformidade com a Lei Geral de Proteção de Dados. Nenhum terceiro não autorizado terá acesso às suas chaves privadas.
        </p>
      </div>
    </div>
  );
};

export default LGPDMessage;
