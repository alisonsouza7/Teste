
import React from 'react';
import { useForm } from 'react-hook-form';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Label } from '@/components/ui/label';
import { Loader2 } from 'lucide-react';

const TemplateModal = ({ open, onOpenChange, onSave }) => {
  const { register, handleSubmit, formState: { errors, isSubmitting }, setValue } = useForm();

  const onSubmit = async (data) => {
    await onSave(data);
    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[600px]">
        <DialogHeader>
          <DialogTitle>Novo Modelo de Tarefa Recorrente</DialogTitle>
        </DialogHeader>

        <form onSubmit={handleSubmit(onSubmit)} className="space-y-4 py-4">
          <div className="space-y-2">
            <Label htmlFor="title">Nome do Modelo <span className="text-red-500">*</span></Label>
            <Input id="title" {...register('title', { required: 'Obrigatório' })} placeholder="Ex: Fechamento Folha Mensal" />
            {errors.title && <span className="text-red-500 text-xs">{errors.title.message}</span>}
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>Categoria</Label>
              <Select onValueChange={(val) => setValue('category', val)} defaultValue="Folha">
                <SelectTrigger>
                  <SelectValue placeholder="Selecione" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Folha">Departamento Pessoal</SelectItem>
                  <SelectItem value="Fiscal">Fiscal</SelectItem>
                  <SelectItem value="Financeiro">Financeiro / Contábil</SelectItem>
                  <SelectItem value="Entrega">Legalização / Entregas</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label>Recorrência</Label>
              <Select onValueChange={(val) => setValue('recurrence_type', val)} defaultValue="monthly">
                <SelectTrigger>
                  <SelectValue placeholder="Selecione" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="monthly">Mensal</SelectItem>
                  <SelectItem value="quarterly">Trimestral</SelectItem>
                  <SelectItem value="biannual">Semestral</SelectItem>
                  <SelectItem value="annual">Anual</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="grid grid-cols-3 gap-4">
            <div className="space-y-2">
                <Label>Dia Recorrência</Label>
                <Input type="number" min="1" max="31" {...register('recurrence_day', { required: true })} placeholder="Ex: 5" />
            </div>
            
            <div className="space-y-2">
                <Label>Horas Est.</Label>
                <Input type="number" step="0.5" {...register('estimated_hours')} placeholder="Ex: 2.5" />
            </div>

             <div className="space-y-2">
              <Label>Prioridade</Label>
              <Select onValueChange={(val) => setValue('priority_level', val)} defaultValue="C">
                <SelectTrigger>
                  <SelectValue placeholder="Selecione" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="A">A - Alta</SelectItem>
                  <SelectItem value="B">B - Média</SelectItem>
                  <SelectItem value="C">C - Baixa</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          
          <div className="space-y-2">
              <Label>Prazo Legal (Opcional)</Label>
              <Input type="date" {...register('legal_deadline')} />
              <p className="text-xs text-gray-500">Se preenchido, define um prazo legal fixo para referência.</p>
          </div>

          <div className="space-y-2">
            <Label htmlFor="description">Descrição / Instruções</Label>
            <Textarea id="description" {...register('description')} className="min-h-[100px]" />
          </div>

           <div className="space-y-2">
              <Label>Cor do Card</Label>
              <Input type="color" {...register('color')} className="h-10 w-20 p-1 cursor-pointer" defaultValue="#3b82f6" />
          </div>

          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>Cancelar</Button>
            <Button type="submit" disabled={isSubmitting} className="bg-blue-600 text-white hover:bg-blue-700">
              {isSubmitting && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              Criar Modelo
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
};

export default TemplateModal;
