
import React, { useEffect } from 'react';
import { useForm, useFieldArray } from 'react-hook-form';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Label } from '@/components/ui/label';
import { Loader2, Plus, Trash2 } from 'lucide-react';
import { Badge } from '@/components/ui/badge';

const TaskModal = ({ open, onOpenChange, taskToEdit, clientName, onSave }) => {
  const { register, control, handleSubmit, reset, setValue, formState: { errors, isSubmitting } } = useForm({
      defaultValues: {
          documents_required: []
      }
  });

  const { fields, append, remove } = useFieldArray({
    control,
    name: "documents_required"
  });

  useEffect(() => {
    if (open) {
      if (taskToEdit) {
        reset({
          title: taskToEdit.title,
          description: taskToEdit.description || '',
          category: taskToEdit.category || 'Fiscal',
          status: taskToEdit.status || 'pending',
          priority_level: taskToEdit.priority || 'C',
          due_date: taskToEdit.due_date ? taskToEdit.due_date.split('T')[0] : '',
          legal_deadline: taskToEdit.legal_deadline || '',
          estimated_hours: taskToEdit.estimated_hours || '',
          documents_required: taskToEdit.documents_required || [], // Assuming this is stored as JSON array
          color: taskToEdit.color || '#3b82f6',
        });
      } else {
        reset({
            title: '',
            category: 'Fiscal',
            status: 'pending',
            priority_level: 'C',
            documents_required: []
        });
      }
    }
  }, [open, taskToEdit, reset]);

  const onSubmit = async (data) => {
    await onSave(data, taskToEdit?.id);
    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[700px] max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>
              {taskToEdit ? 'Editar Tarefa' : 'Nova Tarefa'}
              {clientName && <Badge variant="secondary" className="ml-2 text-xs font-normal">{clientName}</Badge>}
          </DialogTitle>
        </DialogHeader>

        <form onSubmit={handleSubmit(onSubmit)} className="space-y-6 py-4">
          <div className="space-y-2">
            <Label htmlFor="title">Título da Tarefa <span className="text-red-500">*</span></Label>
            <Input id="title" {...register('title', { required: 'Obrigatório' })} placeholder="Ex: Apuração ICMS Competência 05/24" />
            {errors.title && <span className="text-red-500 text-xs">{errors.title.message}</span>}
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>Status</Label>
              <Select onValueChange={(val) => setValue('status', val)} defaultValue={taskToEdit?.status || 'pending'}>
                <SelectTrigger>
                  <SelectValue placeholder="Selecione" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="pending">⏳ Pendente</SelectItem>
                  <SelectItem value="in_appraisal">🧐 Em Análise</SelectItem>
                  <SelectItem value="in_review">👀 Em Revisão</SelectItem>
                  <SelectItem value="in_delivery">🚚 Em Entrega</SelectItem>
                  <SelectItem value="completed">✅ Concluído</SelectItem>
                  <SelectItem value="blocked">⛔ Bloqueado</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label>Prioridade</Label>
              <Select onValueChange={(val) => setValue('priority_level', val)} defaultValue={taskToEdit?.priority || 'C'}>
                <SelectTrigger>
                  <SelectValue placeholder="Selecione" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="A">🔴 Alta (A)</SelectItem>
                  <SelectItem value="B">🟠 Média (B)</SelectItem>
                  <SelectItem value="C">🟡 Baixa (C)</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="grid grid-cols-3 gap-4">
             <div className="space-y-2">
                <Label>Data de Vencimento</Label>
                <Input type="date" {...register('due_date')} />
             </div>
             <div className="space-y-2">
                <Label>Prazo Legal</Label>
                <Input type="date" {...register('legal_deadline')} />
             </div>
             <div className="space-y-2">
                <Label>Horas Estimadas</Label>
                <Input type="number" step="0.5" {...register('estimated_hours')} placeholder="1.0" />
             </div>
          </div>

          <div className="space-y-2 border p-3 rounded-lg bg-gray-50">
             <div className="flex justify-between items-center mb-2">
                 <Label>Documentos Necessários</Label>
                 <Button type="button" size="sm" variant="outline" onClick={() => append({ name: '' })}>
                     <Plus className="w-3 h-3 mr-1" /> Add
                 </Button>
             </div>
             <div className="space-y-2">
                 {fields.map((field, index) => (
                     <div key={field.id} className="flex gap-2">
                         <Input {...register(`documents_required.${index}.name`)} placeholder="Nome do documento (ex: Extrato)" size="sm" />
                         <Button type="button" size="icon" variant="ghost" onClick={() => remove(index)} className="text-red-500">
                             <Trash2 className="w-4 h-4" />
                         </Button>
                     </div>
                 ))}
                 {fields.length === 0 && <p className="text-xs text-gray-400 italic">Nenhum documento específico listado.</p>}
             </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="description">Descrição</Label>
            <Textarea id="description" {...register('description')} className="min-h-[100px]" />
          </div>
          
           <div className="space-y-2">
              <Label>Cor de Destaque</Label>
              <Input type="color" {...register('color')} className="h-10 w-20 p-1 cursor-pointer" />
          </div>

          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>Cancelar</Button>
            <Button type="submit" disabled={isSubmitting} className="bg-blue-600 text-white hover:bg-blue-700">
              {isSubmitting && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              {taskToEdit ? 'Salvar Alterações' : 'Criar Tarefa'}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
};

export default TaskModal;
