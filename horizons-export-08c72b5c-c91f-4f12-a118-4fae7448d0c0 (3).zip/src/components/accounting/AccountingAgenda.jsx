
import React from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { format, isToday, isPast, isTomorrow, parseISO, addDays, isSameDay } from 'date-fns';
import ptBR from 'date-fns/locale/pt-BR';
import { Calendar, AlertCircle, Clock } from 'lucide-react';

const TaskItem = ({ task }) => {
  const isOverdue = task.due_date && isPast(parseISO(task.due_date)) && !isToday(parseISO(task.due_date));
  
  return (
    <div className={`flex items-center p-3 mb-2 rounded-lg border ${isOverdue ? 'bg-red-50 border-red-100' : 'bg-white border-gray-100 hover:border-gray-200'} transition-all`}>
        <div className={`w-1 h-10 rounded-full mr-3 ${task.priority === 'A' ? 'bg-red-500' : task.priority === 'B' ? 'bg-orange-500' : 'bg-yellow-400'}`}></div>
        <div className="flex-1 min-w-0">
            <div className="flex justify-between mb-1">
                <span className="text-xs font-semibold text-gray-500 uppercase tracking-wider">{task.accounting_clients?.name}</span>
                {isOverdue && <Badge variant="destructive" className="text-[10px] h-5 px-1">Atrasado</Badge>}
            </div>
            <h4 className="text-sm font-medium text-gray-900 truncate">{task.title}</h4>
            <div className="flex items-center gap-2 mt-1">
                <Badge variant="outline" className="text-[10px] font-normal text-gray-500 border-gray-200">{task.category}</Badge>
                <div className="flex items-center text-xs text-gray-400">
                    <Clock className="w-3 h-3 mr-1" />
                    {task.due_date ? format(parseISO(task.due_date), "HH:mm") : '--:--'}
                </div>
            </div>
        </div>
    </div>
  );
};

const AccountingAgenda = ({ tasks }) => {
  const today = new Date();
  
  const overdueTasks = tasks.filter(t => t.due_date && isPast(parseISO(t.due_date)) && !isSameDay(parseISO(t.due_date), today) && t.status !== 'completed' && t.status !== 'blocked');
  const todayTasks = tasks.filter(t => t.due_date && isSameDay(parseISO(t.due_date), today) && t.status !== 'completed');
  
  const next7Days = Array.from({ length: 7 }, (_, i) => addDays(today, i + 1));

  return (
    <div className="space-y-6 h-full overflow-y-auto pr-2">
        {/* Overdue Section */}
        {overdueTasks.length > 0 && (
            <div className="space-y-3">
                <h3 className="text-sm font-bold text-red-600 flex items-center gap-2">
                    <AlertCircle className="w-4 h-4" />
                    Atrasadas ({overdueTasks.length})
                </h3>
                <div className="space-y-1">
                    {overdueTasks.map(task => <TaskItem key={task.id} task={task} />)}
                </div>
            </div>
        )}

        {/* Today Section */}
        <div className="space-y-3">
            <h3 className="text-sm font-bold text-blue-700 flex items-center gap-2">
                <Calendar className="w-4 h-4" />
                Hoje, {format(today, "d 'de' MMMM", { locale: ptBR })}
            </h3>
            {todayTasks.length > 0 ? (
                <div className="space-y-1">
                     {todayTasks.map(task => <TaskItem key={task.id} task={task} />)}
                </div>
            ) : (
                <div className="p-4 text-center text-sm text-gray-400 bg-gray-50 rounded-lg border border-dashed">
                    Nenhuma tarefa para hoje.
                </div>
            )}
        </div>

        {/* Upcoming Days */}
        <div className="space-y-4 pt-2">
            <h3 className="text-sm font-bold text-gray-700">Próximos 7 dias</h3>
            {next7Days.map(date => {
                const dayTasks = tasks.filter(t => t.due_date && isSameDay(parseISO(t.due_date), date) && t.status !== 'completed');
                if (dayTasks.length === 0) return null;

                return (
                    <div key={date.toISOString()} className="space-y-2">
                         <h4 className="text-xs font-semibold text-gray-500 border-b pb-1">
                            {format(date, "EEEE, d/MM", { locale: ptBR })}
                         </h4>
                         {dayTasks.map(task => <TaskItem key={task.id} task={task} />)}
                    </div>
                );
            })}
        </div>
    </div>
  );
};

export default AccountingAgenda;
