
import React from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { format, isToday, parseISO, isPast } from 'date-fns';
import ptBR from 'date-fns/locale/pt-BR';
import { CheckCircle, AlertTriangle, Coffee } from 'lucide-react';

const TaskCard = ({ task, onComplete }) => (
    <div className="flex items-center justify-between p-4 bg-white rounded-lg shadow-sm border border-slate-100 hover:shadow-md transition-all">
        <div className="flex-1">
            <div className="flex items-center gap-2 mb-1">
                <Badge variant={task.priority === 'A' ? 'destructive' : 'secondary'} className="text-[10px] h-5">
                    {task.priority === 'A' ? 'Prioridade Alta' : task.priority === 'B' ? 'Média' : 'Baixa'}
                </Badge>
                <span className="text-xs text-slate-400 font-medium uppercase">{task.category}</span>
            </div>
            <h3 className="font-medium text-slate-800">{task.title}</h3>
            <p className="text-sm text-slate-500">{task.accounting_clients?.name}</p>
        </div>
        <Button 
            size="sm" 
            variant="ghost" 
            className="text-green-600 hover:text-green-700 hover:bg-green-50"
            onClick={() => onComplete(task)}
        >
            <CheckCircle className="w-5 h-5 mr-1" />
            Concluir
        </Button>
    </div>
);

const TodayPanel = ({ tasks, onTaskComplete }) => {
  const today = new Date();
  
  // Tasks for today + overdue tasks that are not completed
  const activeTasks = tasks.filter(t => {
      if (t.status === 'completed' || t.status === 'blocked') return false;
      const dueDate = t.due_date ? parseISO(t.due_date) : null;
      return dueDate && (isToday(dueDate) || isPast(dueDate));
  });

  const highPriority = activeTasks.filter(t => t.priority === 'A');
  const otherPriority = activeTasks.filter(t => t.priority !== 'A');

  return (
    <div className="space-y-6">
        <div className="bg-gradient-to-r from-blue-600 to-indigo-600 rounded-xl p-6 text-white shadow-lg">
            <h2 className="text-2xl font-bold mb-1">Olá, vamos trabalhar! 🚀</h2>
            <p className="text-blue-100 mb-4">
                Hoje é {format(today, "EEEE, d 'de' MMMM", { locale: ptBR })}.
                Você tem <strong className="text-white">{activeTasks.length}</strong> tarefas pendentes.
            </p>
        </div>

        {highPriority.length > 0 && (
             <div className="space-y-3">
                <div className="flex items-center gap-2 text-red-600 font-bold text-sm bg-red-50 p-3 rounded-lg border border-red-100">
                    <AlertTriangle className="w-4 h-4" />
                    Prioridade Alta / Atrasadas ({highPriority.length})
                </div>
                {highPriority.map(task => (
                    <TaskCard key={task.id} task={task} onComplete={onTaskComplete} />
                ))}
            </div>
        )}

        <div className="space-y-3">
             <h3 className="text-sm font-bold text-slate-700">Tarefas Normais</h3>
             {otherPriority.length > 0 ? (
                 otherPriority.map(task => (
                    <TaskCard key={task.id} task={task} onComplete={onTaskComplete} />
                 ))
             ) : (
                 <div className="text-center p-8 bg-slate-50 rounded-lg border border-dashed text-slate-400">
                     <Coffee className="w-8 h-8 mx-auto mb-2 opacity-50" />
                     <p>Tudo limpo por aqui! Aproveite seu café.</p>
                 </div>
             )}
        </div>
    </div>
  );
};

export default TodayPanel;
