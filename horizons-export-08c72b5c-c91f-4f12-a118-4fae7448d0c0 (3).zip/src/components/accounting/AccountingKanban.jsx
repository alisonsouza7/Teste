
import React from 'react';
import { DragDropContext, Droppable, Draggable } from '@hello-pangea/dnd';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Calendar, Paperclip, AlertTriangle, AlertCircle, Link as LinkIcon, Lock } from 'lucide-react';
import { format, parseISO, isPast } from 'date-fns';
import ptBR from 'date-fns/locale/pt-BR';

const COLUMNS = {
  pending: { id: 'pending', title: 'Pendente', color: 'bg-gray-100 border-gray-200' },
  in_appraisal: { id: 'in_appraisal', title: 'Em Análise', color: 'bg-blue-50 border-blue-200' },
  in_review: { id: 'in_review', title: 'Em Revisão', color: 'bg-indigo-50 border-indigo-200' },
  in_delivery: { id: 'in_delivery', title: 'Em Entrega', color: 'bg-purple-50 border-purple-200' },
  completed: { id: 'completed', title: 'Concluído', color: 'bg-green-50 border-green-200' },
  blocked: { id: 'blocked', title: 'Bloqueado', color: 'bg-red-50 border-red-200' },
};

const PriorityBadge = ({ priority }) => {
  const colors = {
    A: 'bg-red-100 text-red-800 border-red-200',
    B: 'bg-orange-100 text-orange-800 border-orange-200',
    C: 'bg-yellow-100 text-yellow-800 border-yellow-200',
  };
  return (
    <span className={`text-xs font-bold px-2 py-0.5 rounded border ${colors[priority] || colors.C}`}>
      {priority}
    </span>
  );
};

const AccountingKanban = ({ tasks, onTaskMove, onTaskClick }) => {
  
  const getTasksByColumn = (columnId) => {
    return tasks.filter(task => task.status === columnId || (!Object.keys(COLUMNS).includes(task.status) && columnId === 'pending'));
  };

  const handleDragEnd = (result) => {
    if (!result.destination) return;
    onTaskMove(result);
  };

  return (
    <DragDropContext onDragEnd={handleDragEnd}>
      <div className="flex h-full overflow-x-auto gap-4 pb-4">
        {Object.values(COLUMNS).map((column) => (
          <div key={column.id} className="flex-shrink-0 w-80 flex flex-col h-full rounded-lg bg-gray-50/50">
            <div className={`p-3 font-semibold text-sm border-b-2 ${column.color} rounded-t-lg flex justify-between items-center`}>
              <span>{column.title}</span>
              <span className="bg-white/50 px-2 py-0.5 rounded-full text-xs text-gray-600">
                {getTasksByColumn(column.id).length}
              </span>
            </div>
            
            <Droppable droppableId={column.id}>
              {(provided) => (
                <div
                  {...provided.droppableProps}
                  ref={provided.innerRef}
                  className="flex-1 p-2 overflow-y-auto min-h-[150px]"
                >
                  {getTasksByColumn(column.id).map((task, index) => {
                     const isOverdue = task.due_date && isPast(parseISO(task.due_date)) && task.status !== 'completed';
                     
                     return (
                      <Draggable key={task.id} draggableId={task.id} index={index}>
                        {(provided) => (
                          <div
                            ref={provided.innerRef}
                            {...provided.draggableProps}
                            {...provided.dragHandleProps}
                            onClick={() => onTaskClick(task)}
                            className="mb-3"
                          >
                            <Card className={`hover:shadow-md transition-shadow cursor-pointer ${isOverdue ? 'border-l-4 border-l-red-500' : ''}`}>
                              <CardContent className="p-3 space-y-2">
                                <div className="flex justify-between items-start">
                                  <Badge variant="outline" className="text-[10px] truncate max-w-[120px]">
                                    {task.accounting_clients?.name || 'Sem Cliente'}
                                  </Badge>
                                  <PriorityBadge priority={task.priority || 'C'} />
                                </div>
                                
                                <h4 className="font-medium text-sm line-clamp-2 text-slate-800">
                                  {task.title}
                                </h4>

                                <div className="flex flex-wrap gap-2 text-xs text-gray-500">
                                  {task.due_date && (
                                    <div className={`flex items-center gap-1 ${isOverdue ? 'text-red-600 font-medium' : ''}`}>
                                      <Calendar className="w-3 h-3" />
                                      {format(parseISO(task.due_date), "dd/MM", { locale: ptBR })}
                                    </div>
                                  )}
                                  
                                  {task.dependencies && task.dependencies.length > 0 && (
                                      <div className="flex items-center gap-1 text-amber-600" title="Possui dependências">
                                          <LinkIcon className="w-3 h-3" />
                                      </div>
                                  )}

                                  {task.category && (
                                    <Badge variant="secondary" className="text-[10px] h-5 px-1.5">
                                        {task.category}
                                    </Badge>
                                  )}
                                </div>

                                {task.documents_count > 0 && (
                                  <div className="flex items-center gap-1 text-xs text-blue-600 bg-blue-50 px-2 py-1 rounded w-fit">
                                    <Paperclip className="w-3 h-3" />
                                    <span>{task.documents_completed || 0}/{task.documents_count} docs</span>
                                  </div>
                                )}
                              </CardContent>
                            </Card>
                          </div>
                        )}
                      </Draggable>
                    );
                  })}
                  {provided.placeholder}
                </div>
              )}
            </Droppable>
          </div>
        ))}
      </div>
    </DragDropContext>
  );
};

export default AccountingKanban;
