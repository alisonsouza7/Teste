
import React, { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { Alert, AlertTitle, AlertDescription } from '@/components/ui/alert';
import { Loader2, AlertCircle, FileText, Send, CheckCircle2 } from 'lucide-react';
import { enviarDps } from '@/lib/apiClient';
import { v4 as uuidv4 } from 'uuid';
import { cn } from '@/lib/utils';
import { useToast } from '@/components/ui/use-toast';

const initialFormState = {
    // Tomador
    tomador_tipo: 'PJ', // PJ or PF
    tomador_documento: '',
    tomador_nome: '',
    tomador_email: '',
    tomador_endereco_logradouro: '',
    tomador_endereco_numero: '',
    tomador_endereco_complemento: '',
    tomador_endereco_bairro: '',
    tomador_endereco_cep: '',
    tomador_endereco_municipio_codigo: '', // IBGE code
    tomador_endereco_uf: '',
    
    // Serviço
    servico_codigo_lista: '01.07', // Default example
    servico_descricao: '',
    servico_valor: '',
    servico_iss_retido: false,
    
    // Valores/Impostos
    valor_deducoes: '0',
    valor_pis: '0',
    valor_cofins: '0',
    valor_inss: '0',
    valor_ir: '0',
    valor_csll: '0',
};

const NfseEmissaoModal = ({ open, onOpenChange, companyId, onSuccess }) => {
    const { toast } = useToast();
    const [formData, setFormData] = useState(initialFormState);
    const [activeTab, setActiveTab] = useState('tomador');
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState(null);
    const [result, setResult] = useState(null);

    // Reset state when opening
    useEffect(() => {
        if (open) {
            setFormData(initialFormState);
            setResult(null);
            setError(null);
            setActiveTab('tomador');
        }
    }, [open]);

    const handleChange = (e) => {
        const { id, value } = e.target;
        setFormData(prev => ({ ...prev, [id]: value }));
    };

    const handleSelectChange = (field, value) => {
        setFormData(prev => ({ ...prev, [field]: value }));
    };

    const handleCheckboxChange = (field, checked) => {
        setFormData(prev => ({ ...prev, [field]: checked }));
    };

    const validateForm = () => {
        if (!formData.tomador_documento) return "Documento do tomador é obrigatório";
        if (!formData.tomador_nome) return "Nome do tomador é obrigatório";
        if (!formData.servico_descricao) return "Descrição do serviço é obrigatória";
        if (!formData.servico_valor || parseFloat(formData.servico_valor) <= 0) return "Valor do serviço inválido";
        return null;
    };

    const handleSubmit = async () => {
        const validationError = validateForm();
        if (validationError) {
            setError(validationError);
            toast({ variant: "destructive", title: "Erro na validação", description: validationError });
            return;
        }

        setLoading(true);
        setError(null);
        
        try {
            const idempotencyKey = uuidv4();
            
            // Construct payload based on minimal DPS structure
            const payload = {
                company_id: companyId,
                dps: {
                    serie: 1, // Default series
                    tomador: {
                        tipo: formData.tomador_tipo === 'PJ' ? 2 : 1, // 1=PF, 2=PJ typically
                        documento: formData.tomador_documento.replace(/\D/g, ''),
                        razao_social: formData.tomador_nome,
                        endereco: {
                            logradouro: formData.tomador_endereco_logradouro,
                            numero: formData.tomador_endereco_numero,
                            complemento: formData.tomador_endereco_complemento,
                            bairro: formData.tomador_endereco_bairro,
                            codigo_municipio: formData.tomador_endereco_municipio_codigo,
                            uf: formData.tomador_endereco_uf,
                            cep: formData.tomador_endereco_cep.replace(/\D/g, '')
                        },
                        contato: {
                            email: formData.tomador_email
                        }
                    },
                    servico: {
                        codigo: formData.servico_codigo_lista,
                        discriminacao: formData.servico_descricao,
                        iss_retido: formData.servico_iss_retido,
                        valores: {
                            servico: parseFloat(formData.servico_valor || 0),
                            deducoes: parseFloat(formData.valor_deducoes || 0),
                            pis: parseFloat(formData.valor_pis || 0),
                            cofins: parseFloat(formData.valor_cofins || 0),
                            inss: parseFloat(formData.valor_inss || 0),
                            ir: parseFloat(formData.valor_ir || 0),
                            csll: parseFloat(formData.valor_csll || 0),
                        }
                    }
                }
            };

            const response = await enviarDps(payload, idempotencyKey);
            setResult(response);
            
            toast({
                title: "Sucesso!",
                description: "DPS enviada para processamento.",
            });

            if (onSuccess) onSuccess(response);

        } catch (err) {
            console.error(err);
            const msg = err.response?.data?.message || err.message || "Erro ao emitir NFS-e";
            setError(msg);
        } finally {
            setLoading(false);
        }
    };

    if (result) {
        return (
            <Dialog open={open} onOpenChange={onOpenChange}>
                <DialogContent className="sm:max-w-[500px]">
                    <DialogHeader>
                        <DialogTitle className="flex items-center gap-2 text-green-600">
                            <CheckCircle2 className="h-6 w-6" /> Emissão Iniciada
                        </DialogTitle>
                        <DialogDescription>
                            A DPS foi enviada com sucesso para o Ambiente Nacional.
                        </DialogDescription>
                    </DialogHeader>
                    
                    <div className="py-4 space-y-4">
                        <div className="bg-slate-50 p-4 rounded-lg border space-y-2">
                            <div className="flex justify-between">
                                <span className="text-sm font-medium text-slate-500">Status</span>
                                <span className="text-sm font-bold text-slate-900 uppercase">{result.status}</span>
                            </div>
                            <div className="flex justify-between">
                                <span className="text-sm font-medium text-slate-500">ID do Pedido (DPS)</span>
                                <span className="text-xs font-mono bg-white px-2 py-1 rounded border">{result.id || result.dps_id}</span>
                            </div>
                        </div>
                        
                        <Alert>
                            <FileText className="h-4 w-4" />
                            <AlertTitle>O que acontece agora?</AlertTitle>
                            <AlertDescription>
                                O sistema nacional está processando sua nota. Você pode consultar o status final utilizando o ID acima na tela de consultas.
                            </AlertDescription>
                        </Alert>
                    </div>

                    <DialogFooter>
                        <Button onClick={() => onOpenChange(false)} className="w-full">Fechar</Button>
                    </DialogFooter>
                </DialogContent>
            </Dialog>
        );
    }

    return (
        <Dialog open={open} onOpenChange={onOpenChange}>
            <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
                <DialogHeader>
                    <DialogTitle>Emitir Nova NFS-e</DialogTitle>
                    <DialogDescription>
                        Preencha os dados abaixo para emitir uma Nota Fiscal de Serviço Eletrônica.
                    </DialogDescription>
                </DialogHeader>

                <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full mt-4">
                    <TabsList className="grid w-full grid-cols-3">
                        <TabsTrigger value="tomador">1. Tomador (Cliente)</TabsTrigger>
                        <TabsTrigger value="servico">2. Serviço</TabsTrigger>
                        <TabsTrigger value="valores">3. Impostos e Totais</TabsTrigger>
                    </TabsList>

                    <div className="mt-6 space-y-4">
                        {/* Tab: Tomador */}
                        <TabsContent value="tomador" className="space-y-4">
                            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                                <div className="space-y-2">
                                    <Label>Tipo de Pessoa</Label>
                                    <Select 
                                        value={formData.tomador_tipo} 
                                        onValueChange={(val) => handleSelectChange('tomador_tipo', val)}
                                    >
                                        <SelectTrigger>
                                            <SelectValue />
                                        </SelectTrigger>
                                        <SelectContent>
                                            <SelectItem value="PJ">Pessoa Jurídica (CNPJ)</SelectItem>
                                            <SelectItem value="PF">Pessoa Física (CPF)</SelectItem>
                                        </SelectContent>
                                    </Select>
                                </div>
                                <div className="space-y-2 col-span-2">
                                    <Label htmlFor="tomador_documento">Documento (CPF/CNPJ)</Label>
                                    <Input 
                                        id="tomador_documento" 
                                        value={formData.tomador_documento} 
                                        onChange={handleChange} 
                                        placeholder="000.000.000-00" 
                                    />
                                </div>
                            </div>

                            <div className="space-y-2">
                                <Label htmlFor="tomador_nome">Nome / Razão Social</Label>
                                <Input 
                                    id="tomador_nome" 
                                    value={formData.tomador_nome} 
                                    onChange={handleChange} 
                                    placeholder="Nome completo do cliente" 
                                />
                            </div>

                            <div className="space-y-2">
                                <Label htmlFor="tomador_email">Email para envio (Opcional)</Label>
                                <Input 
                                    id="tomador_email" 
                                    type="email"
                                    value={formData.tomador_email} 
                                    onChange={handleChange} 
                                    placeholder="cliente@email.com" 
                                />
                            </div>
                            
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 border-t pt-4">
                                <div className="space-y-2">
                                    <Label htmlFor="tomador_endereco_cep">CEP</Label>
                                    <Input id="tomador_endereco_cep" value={formData.tomador_endereco_cep} onChange={handleChange} placeholder="00000-000" />
                                </div>
                                <div className="space-y-2">
                                    <Label htmlFor="tomador_endereco_municipio_codigo">Código IBGE Município</Label>
                                    <Input id="tomador_endereco_municipio_codigo" value={formData.tomador_endereco_municipio_codigo} onChange={handleChange} placeholder="Ex: 3304557 (Rio de Janeiro)" />
                                </div>
                            </div>
                            
                            <div className="grid grid-cols-3 gap-4">
                                <div className="space-y-2 col-span-2">
                                    <Label htmlFor="tomador_endereco_logradouro">Logradouro</Label>
                                    <Input id="tomador_endereco_logradouro" value={formData.tomador_endereco_logradouro} onChange={handleChange} />
                                </div>
                                <div className="space-y-2">
                                    <Label htmlFor="tomador_endereco_numero">Número</Label>
                                    <Input id="tomador_endereco_numero" value={formData.tomador_endereco_numero} onChange={handleChange} />
                                </div>
                            </div>

                            <div className="grid grid-cols-2 gap-4">
                                <div className="space-y-2">
                                    <Label htmlFor="tomador_endereco_bairro">Bairro</Label>
                                    <Input id="tomador_endereco_bairro" value={formData.tomador_endereco_bairro} onChange={handleChange} />
                                </div>
                                <div className="space-y-2">
                                    <Label htmlFor="tomador_endereco_uf">UF</Label>
                                    <Input id="tomador_endereco_uf" value={formData.tomador_endereco_uf} onChange={handleChange} maxLength={2} placeholder="Ex: RJ" />
                                </div>
                            </div>
                        </TabsContent>

                        {/* Tab: Serviço */}
                        <TabsContent value="servico" className="space-y-4">
                            <div className="space-y-2">
                                <Label htmlFor="servico_codigo_lista">Código do Serviço (LC 116)</Label>
                                <Input 
                                    id="servico_codigo_lista" 
                                    value={formData.servico_codigo_lista} 
                                    onChange={handleChange} 
                                    placeholder="Ex: 01.07" 
                                />
                                <p className="text-xs text-muted-foreground">Consulte a lista de serviços nacional.</p>
                            </div>

                            <div className="space-y-2">
                                <Label htmlFor="servico_descricao">Discriminação do Serviço</Label>
                                <textarea 
                                    id="servico_descricao"
                                    className="flex min-h-[120px] w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                                    value={formData.servico_descricao}
                                    onChange={handleChange}
                                    placeholder="Descreva detalhadamente o serviço prestado..."
                                />
                            </div>

                             <div className="flex items-center space-x-2 py-2">
                                <Checkbox 
                                    id="servico_iss_retido" 
                                    checked={formData.servico_iss_retido}
                                    onCheckedChange={(checked) => handleCheckboxChange('servico_iss_retido', checked)}
                                />
                                <Label htmlFor="servico_iss_retido" className="font-normal cursor-pointer">
                                    O ISS é retido pelo tomador?
                                </Label>
                            </div>
                        </TabsContent>

                        {/* Tab: Valores */}
                        <TabsContent value="valores" className="space-y-4">
                            <div className="bg-slate-50 p-4 rounded-md border mb-4">
                                <div className="space-y-2">
                                    <Label htmlFor="servico_valor" className="text-lg font-semibold text-slate-900">Valor Total do Serviço (R$)</Label>
                                    <Input 
                                        id="servico_valor" 
                                        type="number"
                                        step="0.01"
                                        className="text-lg h-12"
                                        value={formData.servico_valor} 
                                        onChange={handleChange} 
                                        placeholder="0,00" 
                                    />
                                </div>
                            </div>

                            <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                                <div className="space-y-2">
                                    <Label htmlFor="valor_deducoes">Deduções (R$)</Label>
                                    <Input id="valor_deducoes" type="number" step="0.01" value={formData.valor_deducoes} onChange={handleChange} />
                                </div>
                                <div className="space-y-2">
                                    <Label htmlFor="valor_pis">PIS (R$)</Label>
                                    <Input id="valor_pis" type="number" step="0.01" value={formData.valor_pis} onChange={handleChange} />
                                </div>
                                <div className="space-y-2">
                                    <Label htmlFor="valor_cofins">COFINS (R$)</Label>
                                    <Input id="valor_cofins" type="number" step="0.01" value={formData.valor_cofins} onChange={handleChange} />
                                </div>
                                <div className="space-y-2">
                                    <Label htmlFor="valor_inss">INSS (R$)</Label>
                                    <Input id="valor_inss" type="number" step="0.01" value={formData.valor_inss} onChange={handleChange} />
                                </div>
                                <div className="space-y-2">
                                    <Label htmlFor="valor_ir">IR (R$)</Label>
                                    <Input id="valor_ir" type="number" step="0.01" value={formData.valor_ir} onChange={handleChange} />
                                </div>
                                <div className="space-y-2">
                                    <Label htmlFor="valor_csll">CSLL (R$)</Label>
                                    <Input id="valor_csll" type="number" step="0.01" value={formData.valor_csll} onChange={handleChange} />
                                </div>
                            </div>
                            
                            <div className="bg-blue-50 p-3 rounded text-sm text-blue-800 flex gap-2 mt-4">
                                <AlertCircle className="w-4 h-4 mt-0.5 shrink-0" />
                                <p>Os valores de impostos federais (PIS, COFINS, etc) são apenas informativos na nota, a menos que haja retenção.</p>
                            </div>
                        </TabsContent>
                    </div>
                </Tabs>

                {error && (
                    <Alert variant="destructive" className="mt-4">
                        <AlertCircle className="h-4 w-4" />
                        <AlertTitle>Erro ao emitir</AlertTitle>
                        <AlertDescription>{error}</AlertDescription>
                    </Alert>
                )}

                <DialogFooter className="mt-6 gap-2">
                    <Button variant="outline" onClick={() => onOpenChange(false)} disabled={loading}>
                        Cancelar
                    </Button>
                    <div className="flex-1"></div>
                    {activeTab !== 'valores' ? (
                        <Button onClick={() => {
                            const tabs = ['tomador', 'servico', 'valores'];
                            const idx = tabs.indexOf(activeTab);
                            if (idx < 2) setActiveTab(tabs[idx + 1]);
                        }}>
                            Próximo
                        </Button>
                    ) : (
                        <Button onClick={handleSubmit} disabled={loading} className="bg-purple-600 hover:bg-purple-700 text-white min-w-[150px]">
                            {loading ? (
                                <>
                                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                                    Emitindo...
                                </>
                            ) : (
                                <>
                                    <Send className="mr-2 h-4 w-4" />
                                    Emitir NFS-e
                                </>
                            )}
                        </Button>
                    )}
                </DialogFooter>
            </DialogContent>
        </Dialog>
    );
};

export default NfseEmissaoModal;
