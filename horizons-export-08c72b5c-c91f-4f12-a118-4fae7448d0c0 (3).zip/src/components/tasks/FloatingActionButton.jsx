
import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Plus, FolderPlus, CheckSquare, Target, Tag, Calendar } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

const FloatingActionButton = ({ 
    onCreateTask, 
    onCreateProject, 
    onCreateGoal,
    onCreateTag,
    onCreateEvent
}) => {
  const [isOpen, setIsOpen] = useState(false);

  const toggleOpen = () => setIsOpen(!isOpen);

  const actions = [
      { icon: CheckSquare, label: 'Nova Tarefa', color: 'bg-blue-500', onClick: onCreateTask },
      { icon: Target, label: 'Nova Meta SMART', color: 'bg-purple-500', onClick: onCreateGoal },
      { icon: FolderPlus, label: 'Novo Projeto', color: 'bg-green-500', onClick: onCreateProject },
      { icon: Tag, label: 'Nova Tag', color: 'bg-orange-500', onClick: onCreateTag },
      { icon: Calendar, label: 'Novo Evento', color: 'bg-pink-500', onClick: onCreateEvent },
  ];

  return (
    <div className="fixed bottom-8 right-8 z-50 flex flex-col items-end gap-3">
      <AnimatePresence>
        {isOpen && (
          <div className="flex flex-col gap-3 mb-2">
            {actions.map((action, index) => (
              <motion.div
                key={action.label}
                initial={{ opacity: 0, y: 20, scale: 0.8 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                exit={{ opacity: 0, y: 20, scale: 0.8 }}
                transition={{ delay: index * 0.05 }}
                className="flex items-center gap-3 justify-end"
              >
                <span className="bg-white px-3 py-1 rounded-md shadow-md text-sm font-medium text-gray-700">
                    {action.label}
                </span>
                <Button
                  size="icon"
                  className={`${action.color} h-10 w-10 rounded-full shadow-lg hover:brightness-110 text-white border-none`}
                  onClick={() => {
                      action.onClick && action.onClick();
                      setIsOpen(false);
                  }}
                >
                  <action.icon className="h-5 w-5" />
                </Button>
              </motion.div>
            ))}
          </div>
        )}
      </AnimatePresence>

      <motion.button
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.95 }}
        onClick={toggleOpen}
        className={`h-14 w-14 rounded-full shadow-xl flex items-center justify-center text-white focus:outline-none focus:ring-4 focus:ring-blue-200 transition-colors ${isOpen ? 'bg-gray-800' : 'bg-blue-600 hover:bg-blue-700'}`}
      >
        <motion.div
            animate={{ rotate: isOpen ? 45 : 0 }}
            transition={{ duration: 0.2 }}
        >
            <Plus className="h-8 w-8" />
        </motion.div>
      </motion.button>
    </div>
  );
};

export default FloatingActionButton;
