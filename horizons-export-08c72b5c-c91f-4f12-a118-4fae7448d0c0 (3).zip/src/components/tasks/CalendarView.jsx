
import React, { useState } from 'react';
import { format, startOfMonth, endOfMonth, startOfWeek, endOfWeek, eachDayOfInterval, isSameMonth, isSameDay, addMonths, subMonths, isToday } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { ChevronLeft, ChevronRight, Plus } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';
import { Badge } from '@/components/ui/badge';

const CalendarView = ({ tasks, onTaskClick, onDateClick }) => {
  const [currentMonth, setCurrentMonth] = useState(new Date());
  const [selectedDate, setSelectedDate] = useState(new Date());

  const monthStart = startOfMonth(currentMonth);
  const monthEnd = endOfMonth(monthStart);
  const startDate = startOfWeek(monthStart);
  const endDate = endOfWeek(monthEnd);

  const calendarDays = eachDayOfInterval({ start: startDate, end: endDate });

  const tasksForDay = (date) => {
    return tasks.filter(task => task.due_date && isSameDay(new Date(task.due_date), date));
  };

  const nextMonth = () => setCurrentMonth(addMonths(currentMonth, 1));
  const prevMonth = () => setCurrentMonth(subMonths(currentMonth, 1));
  const goToToday = () => {
      const today = new Date();
      setCurrentMonth(today);
      setSelectedDate(today);
  };

  return (
    <div className="flex flex-col lg:flex-row gap-6 h-full">
      {/* Calendar Grid */}
      <div className="flex-1 bg-white rounded-xl border shadow-sm p-4">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-4">
             <h2 className="text-xl font-bold capitalize text-gray-800">
                {format(currentMonth, 'MMMM yyyy', { locale: ptBR })}
             </h2>
             <div className="flex items-center bg-gray-100 rounded-md p-0.5">
                 <Button variant="ghost" size="icon" onClick={prevMonth} className="h-7 w-7"><ChevronLeft className="h-4 w-4" /></Button>
                 <Button variant="ghost" size="sm" onClick={goToToday} className="h-7 text-xs px-2">Hoje</Button>
                 <Button variant="ghost" size="icon" onClick={nextMonth} className="h-7 w-7"><ChevronRight className="h-4 w-4" /></Button>
             </div>
          </div>
        </div>

        <div className="grid grid-cols-7 gap-1 mb-2 text-center text-sm font-medium text-gray-500">
          {['Dom', 'Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb'].map(day => (
            <div key={day} className="py-2">{day}</div>
          ))}
        </div>

        <div className="grid grid-cols-7 gap-1 auto-rows-fr">
          {calendarDays.map((day, idx) => {
             const dayTasks = tasksForDay(day);
             const isSelected = isSameDay(day, selectedDate);
             return (
                 <div 
                    key={day.toString()} 
                    onClick={() => setSelectedDate(day)}
                    className={cn(
                        "min-h-[100px] border rounded-lg p-2 cursor-pointer transition-colors relative hover:border-blue-300",
                        !isSameMonth(day, monthStart) ? "bg-gray-50 text-gray-400" : "bg-white",
                        isSelected ? "ring-2 ring-blue-600 ring-offset-1 z-10" : "",
                        isToday(day) ? "bg-blue-50/50" : ""
                    )}
                 >
                     <div className={cn("text-sm font-medium w-6 h-6 flex items-center justify-center rounded-full mb-1", isToday(day) ? "bg-blue-600 text-white" : "")}>
                         {format(day, 'd')}
                     </div>
                     <div className="space-y-1 overflow-hidden">
                         {dayTasks.slice(0, 3).map(task => (
                             <div 
                                key={task.id} 
                                className={cn(
                                    "text-[10px] truncate px-1.5 py-0.5 rounded border-l-2 cursor-pointer hover:opacity-80",
                                    task.priority_abcde === 'A' ? "bg-red-50 border-red-500 text-red-700" : "bg-blue-50 border-blue-500 text-blue-700"
                                )}
                                onClick={(e) => {
                                    e.stopPropagation();
                                    onTaskClick(task);
                                }}
                             >
                                 {task.title}
                             </div>
                         ))}
                         {dayTasks.length > 3 && (
                             <div className="text-[10px] text-gray-500 text-center font-medium">
                                 + {dayTasks.length - 3} mais
                             </div>
                         )}
                     </div>
                 </div>
             )
          })}
        </div>
      </div>

      {/* Side Panel */}
      <div className="w-full lg:w-80 bg-white rounded-xl border shadow-sm p-4 flex flex-col">
          <h3 className="font-semibold text-lg mb-4 capitalize">
              {format(selectedDate, "EEEE, d 'de' MMMM", { locale: ptBR })}
          </h3>
          
          <div className="flex-1 overflow-y-auto space-y-3">
              {tasksForDay(selectedDate).length === 0 ? (
                  <div className="text-center text-gray-400 py-10">
                      Nenhuma tarefa para este dia.
                  </div>
              ) : (
                  tasksForDay(selectedDate).map(task => (
                      <div key={task.id} onClick={() => onTaskClick(task)} className="p-3 border rounded-lg hover:bg-gray-50 cursor-pointer group">
                          <div className="flex justify-between items-start mb-1">
                              <Badge variant="outline" className="text-[10px]">{task.status}</Badge>
                              <Badge className={cn("text-[10px]", task.priority_abcde === 'A' ? 'bg-red-100 text-red-700' : 'bg-gray-100 text-gray-700')}>
                                  {task.priority_abcde}
                              </Badge>
                          </div>
                          <p className="text-sm font-medium line-clamp-2">{task.title}</p>
                      </div>
                  ))
              )}
          </div>
          
          <Button className="mt-4 w-full" onClick={() => onDateClick && onDateClick(selectedDate)}>
              <Plus className="w-4 h-4 mr-2" /> Adicionar Tarefa
          </Button>
      </div>
    </div>
  );
};

export default CalendarView;
