
import React, { useState } from 'react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { Search, Filter, X, ChevronDown, ChevronUp } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { cn } from '@/lib/utils';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible';

const AdvancedFiltersBar = ({ 
    projects, 
    selectedProject, 
    onProjectChange,
    filters,
    onFilterChange,
    onClearFilters
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const activeFiltersCount = Object.keys(filters).filter(k => filters[k] && filters[k] !== 'all' && filters[k] !== false).length;

  return (
    <div className="bg-white rounded-lg border shadow-sm mb-6 overflow-hidden">
       {/* Primary Bar */}
       <div className="p-3 flex flex-col lg:flex-row gap-3 items-center">
           {/* Project Selector */}
           <div className="w-full lg:w-64">
               <Select value={selectedProject || ''} onValueChange={onProjectChange}>
                   <SelectTrigger className="w-full font-medium bg-gray-50">
                       <SelectValue placeholder="Selecione um Projeto" />
                   </SelectTrigger>
                   <SelectContent>
                       {projects.map(p => (
                           <SelectItem key={p.id} value={p.id}>{p.title}</SelectItem>
                       ))}
                   </SelectContent>
               </Select>
           </div>

           <div className="h-8 w-px bg-gray-200 hidden lg:block mx-2" />

           {/* Quick Search */}
           <div className="flex-1 relative w-full">
               <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-gray-500" />
               <Input 
                   placeholder="Buscar tarefas..." 
                   className="pl-9" 
                   value={filters.search || ''}
                   onChange={(e) => onFilterChange('search', e.target.value)}
               />
           </div>

           {/* Toggle Advanced */}
           <Collapsible open={isOpen} onOpenChange={setIsOpen}>
               <CollapsibleTrigger asChild>
                   <Button variant="outline" className="gap-2 w-full lg:w-auto">
                       <Filter className="h-4 w-4" />
                       Filtros Avançados
                       {activeFiltersCount > 0 && (
                           <Badge variant="secondary" className="ml-1 h-5 px-1.5 bg-blue-100 text-blue-700">{activeFiltersCount}</Badge>
                       )}
                       {isOpen ? <ChevronUp className="h-4 w-4 ml-1" /> : <ChevronDown className="h-4 w-4 ml-1" />}
                   </Button>
               </CollapsibleTrigger>
           </Collapsible>
       </div>

       {/* Advanced Filters Panel */}
       <Collapsible open={isOpen} onOpenChange={setIsOpen}>
           <CollapsibleContent>
               <div className="p-4 border-t bg-gray-50 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                   <div className="space-y-2">
                       <label className="text-xs font-medium text-gray-500">Status</label>
                       <Select value={filters.status || 'all'} onValueChange={(val) => onFilterChange('status', val === 'all' ? null : val)}>
                           <SelectTrigger className="bg-white"><SelectValue placeholder="Todos" /></SelectTrigger>
                           <SelectContent>
                               <SelectItem value="all">Todos</SelectItem>
                               <SelectItem value="todo">A Fazer</SelectItem>
                               <SelectItem value="in_progress">Em Andamento</SelectItem>
                               <SelectItem value="completed">Concluído</SelectItem>
                           </SelectContent>
                       </Select>
                   </div>

                   <div className="space-y-2">
                       <label className="text-xs font-medium text-gray-500">Prioridade ABCDE</label>
                       <Select value={filters.priority || 'all'} onValueChange={(val) => onFilterChange('priority', val === 'all' ? null : val)}>
                           <SelectTrigger className="bg-white"><SelectValue placeholder="Todas" /></SelectTrigger>
                           <SelectContent>
                               <SelectItem value="all">Todas</SelectItem>
                               <SelectItem value="A">A - Crítica</SelectItem>
                               <SelectItem value="B">B - Importante</SelectItem>
                               <SelectItem value="C">C - Normal</SelectItem>
                               <SelectItem value="D">D - Delegável</SelectItem>
                               <SelectItem value="E">E - Eliminável</SelectItem>
                           </SelectContent>
                       </Select>
                   </div>

                   <div className="space-y-2">
                       <label className="text-xs font-medium text-gray-500">Contexto GTD</label>
                       <Select value={filters.context || 'all'} onValueChange={(val) => onFilterChange('context', val === 'all' ? null : val)}>
                           <SelectTrigger className="bg-white"><SelectValue placeholder="Todos" /></SelectTrigger>
                           <SelectContent>
                               <SelectItem value="all">Todos</SelectItem>
                               <SelectItem value="@computer">@Computador</SelectItem>
                               <SelectItem value="@phone">@Telefone</SelectItem>
                               <SelectItem value="@office">@Escritório</SelectItem>
                               <SelectItem value="@home">@Casa</SelectItem>
                           </SelectContent>
                       </Select>
                   </div>

                   <div className="space-y-2">
                       <label className="text-xs font-medium text-gray-500">Energia</label>
                       <Select value={filters.energy || 'all'} onValueChange={(val) => onFilterChange('energy', val === 'all' ? null : val)}>
                           <SelectTrigger className="bg-white"><SelectValue placeholder="Qualquer nível" /></SelectTrigger>
                           <SelectContent>
                               <SelectItem value="all">Todos</SelectItem>
                               <SelectItem value="high">Alta ⚡</SelectItem>
                               <SelectItem value="medium">Média 🔋</SelectItem>
                               <SelectItem value="low">Baixa ☕</SelectItem>
                           </SelectContent>
                       </Select>
                   </div>
                   
                   <div className="flex items-center space-x-2 pt-6">
                        <Checkbox 
                            id="overdue" 
                            checked={filters.overdue || false}
                            onCheckedChange={(checked) => onFilterChange('overdue', checked)}
                        />
                        <label
                            htmlFor="overdue"
                            className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70 text-red-600"
                        >
                            Apenas Atrasadas
                        </label>
                   </div>
                   
                   <div className="space-y-2">
                       <label className="text-xs font-medium text-gray-500">Vencimento</label>
                       <Input 
                           type="date" 
                           className="bg-white"
                           value={filters.dueDate || ''}
                           onChange={(e) => onFilterChange('dueDate', e.target.value)}
                       />
                   </div>
               </div>
               
               {activeFiltersCount > 0 && (
                   <div className="bg-gray-50 px-4 pb-3 flex justify-end">
                       <Button variant="ghost" size="sm" onClick={onClearFilters} className="text-red-600 hover:text-red-700 hover:bg-red-50">
                           <X className="h-4 w-4 mr-1" /> Limpar Filtros ({activeFiltersCount})
                       </Button>
                   </div>
               )}
           </CollapsibleContent>
       </Collapsible>
    </div>
  );
};

export default AdvancedFiltersBar;
