
import React, { useState, useEffect, useRef } from 'react';
import { Card, CardHeader, CardContent, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Play, Pause, RotateCcw, Coffee, Zap, CheckCircle } from 'lucide-react';
import { usePomodoro } from '@/hooks/usePomodoro';
import { cn } from '@/lib/utils';
import { useToast } from '@/components/ui/use-toast';

const PomodoroWidget = ({ tasks }) => {
  const [timeLeft, setTimeLeft] = useState(25 * 60);
  const [isActive, setIsActive] = useState(false);
  const [mode, setMode] = useState('focus'); // focus | break
  const [selectedTaskId, setSelectedTaskId] = useState(null);
  const intervalRef = useRef(null);
  
  const { saveSession, getTodayStats } = usePomodoro();
  const { toast } = useToast();
  const stats = getTodayStats();

  useEffect(() => {
    if (isActive && timeLeft > 0) {
      intervalRef.current = setInterval(() => {
        setTimeLeft((prev) => prev - 1);
      }, 1000);
    } else if (timeLeft === 0) {
      handleTimerComplete();
    }

    return () => clearInterval(intervalRef.current);
  }, [isActive, timeLeft]);

  const handleTimerComplete = () => {
    setIsActive(false);
    clearInterval(intervalRef.current);
    
    // Play sound notification (browser permitting)
    try {
        const audio = new Audio('https://assets.mixkit.co/active_storage/sfx/2869/2869-preview.mp3'); // Generic beep
        audio.play().catch(e => console.log('Audio play failed', e));
    } catch (e) {}

    if (mode === 'focus') {
        toast({ title: "Sessão Concluída!", description: "Hora de uma pausa.", className: "bg-green-500 text-white" });
        if (selectedTaskId) {
            saveSession({ taskId: selectedTaskId, durationMinutes: 25, notes: 'Foco total' });
        }
        setMode('break');
        setTimeLeft(5 * 60);
    } else {
        toast({ title: "Pausa Finalizada!", description: "Volte ao trabalho.", className: "bg-blue-500 text-white" });
        setMode('focus');
        setTimeLeft(25 * 60);
    }
  };

  const toggleTimer = () => setIsActive(!isActive);

  const resetTimer = () => {
      setIsActive(false);
      setTimeLeft(mode === 'focus' ? 25 * 60 : 5 * 60);
  };

  const formatTime = (seconds) => {
      const m = Math.floor(seconds / 60);
      const s = seconds % 60;
      return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  const progress = mode === 'focus' 
      ? ((25 * 60 - timeLeft) / (25 * 60)) * 100 
      : ((5 * 60 - timeLeft) / (5 * 60)) * 100;

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Main Timer */}
        <Card className="lg:col-span-2 shadow-lg border-2 border-blue-50">
            <CardHeader className="text-center">
                <CardTitle className="flex justify-center items-center gap-2 text-2xl">
                    {mode === 'focus' ? <Zap className="text-yellow-500" /> : <Coffee className="text-blue-500" />}
                    {mode === 'focus' ? 'Modo Foco' : 'Hora da Pausa'}
                </CardTitle>
            </CardHeader>
            <CardContent className="flex flex-col items-center gap-8 py-8">
                {/* Timer Display */}
                <div className="relative flex items-center justify-center w-64 h-64 rounded-full bg-gray-50 shadow-inner">
                    <svg className="absolute w-full h-full transform -rotate-90 p-4">
                        <circle cx="50%" cy="50%" r="45%" fill="transparent" stroke="#e2e8f0" strokeWidth="8" />
                        <circle 
                            cx="50%" cy="50%" r="45%" 
                            fill="transparent" 
                            stroke={mode === 'focus' ? '#ef4444' : '#3b82f6'} 
                            strokeWidth="8" 
                            strokeDasharray="283"
                            strokeDashoffset={283 - (283 * progress) / 100}
                            pathLength="100"
                            strokeLinecap="round"
                            className="transition-all duration-1000 ease-linear"
                        />
                    </svg>
                    <div className="text-6xl font-mono font-bold text-gray-800">
                        {formatTime(timeLeft)}
                    </div>
                </div>

                {/* Controls */}
                <div className="w-full max-w-sm space-y-4">
                    <Select value={selectedTaskId} onValueChange={setSelectedTaskId}>
                        <SelectTrigger>
                            <SelectValue placeholder="Selecione uma tarefa para focar..." />
                        </SelectTrigger>
                        <SelectContent>
                            {tasks.filter(t => t.status !== 'completed').map(t => (
                                <SelectItem key={t.id} value={t.id}>{t.title}</SelectItem>
                            ))}
                        </SelectContent>
                    </Select>

                    <div className="flex justify-center gap-4">
                        <Button 
                            size="lg" 
                            className={cn("w-32 text-lg", isActive ? "bg-yellow-500 hover:bg-yellow-600" : "bg-blue-600 hover:bg-blue-700")}
                            onClick={toggleTimer}
                        >
                            {isActive ? <><Pause className="mr-2" /> Pausar</> : <><Play className="mr-2" /> Iniciar</>}
                        </Button>
                        <Button size="icon" variant="outline" className="h-12 w-12" onClick={resetTimer}>
                            <RotateCcw />
                        </Button>
                    </div>
                </div>
            </CardContent>
        </Card>

        {/* Stats Panel */}
        <div className="space-y-4">
            <Card className="bg-gradient-to-br from-indigo-500 to-purple-600 text-white border-none">
                <CardHeader>
                    <CardTitle className="text-lg">Resumo de Hoje</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                    <div className="flex justify-between items-center border-b border-white/20 pb-2">
                        <span>Sessões Completas</span>
                        <span className="text-2xl font-bold">{stats.totalSessions}</span>
                    </div>
                    <div className="flex justify-between items-center border-b border-white/20 pb-2">
                        <span>Minutos em Foco</span>
                        <span className="text-2xl font-bold">{stats.totalMinutes}m</span>
                    </div>
                    <div className="flex justify-between items-center">
                        <span>Pontuação Foco</span>
                        <Badge variant="secondary" className="bg-white/20 text-white hover:bg-white/30">
                            {stats.focusScore}%
                        </Badge>
                    </div>
                </CardContent>
            </Card>

            <Card>
                <CardHeader>
                    <CardTitle className="text-sm font-medium text-gray-500">Últimas Sessões</CardTitle>
                </CardHeader>
                <CardContent className="space-y-2">
                   <div className="text-sm text-gray-500 text-center py-4 italic">
                       Histórico detalhado em breve
                   </div>
                </CardContent>
            </Card>
        </div>
    </div>
  );
};

export default PomodoroWidget;
