
import React, { useState, useMemo } from 'react';
import { DragDropContext, Droppable, Draggable } from '@hello-pangea/dnd';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Plus, MoreHorizontal, Calendar, Zap, Tag } from 'lucide-react';
import { cn } from '@/lib/utils';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';

const KanbanBoard = ({ 
    columns, 
    tasks, 
    onTaskMove, 
    onTaskClick, 
    onAddClick,
    loading 
}) => {
  // Group tasks by column
  const tasksByColumn = useMemo(() => {
    const map = {};
    columns.forEach(col => map[col.id] = []);
    tasks.forEach(task => {
      if (map[task.column_id]) {
        map[task.column_id].push(task);
      } else {
        // Fallback for tasks with deleted columns or integrity issues
        // console.warn('Task in unknown column', task);
      }
    });
    // Sort by position
    Object.keys(map).forEach(key => {
        map[key].sort((a, b) => a.position - b.position);
    });
    return map;
  }, [columns, tasks]);

  const onDragEnd = (result) => {
    const { destination, source, draggableId } = result;

    if (!destination) return;
    if (destination.droppableId === source.droppableId && destination.index === source.index) return;

    onTaskMove(result);
  };

  if (loading) {
      return (
          <div className="flex gap-4 overflow-x-auto p-4 h-full">
              {[1,2,3,4].map(i => (
                  <div key={i} className="min-w-[300px] bg-gray-100/50 rounded-xl h-96 animate-pulse" />
              ))}
          </div>
      )
  }

  return (
    <DragDropContext onDragEnd={onDragEnd}>
      <div className="flex gap-4 overflow-x-auto pb-4 h-full items-start">
        {columns.map((column) => (
          <div key={column.id} className="min-w-[300px] w-[300px] flex flex-col bg-gray-100/50 dark:bg-slate-800/50 rounded-xl max-h-full">
            <div className="p-3 flex items-center justify-between border-b border-gray-200/50">
                <div className="flex items-center gap-2">
                    <h3 className="font-semibold text-gray-700 dark:text-gray-200">{column.title}</h3>
                    <Badge variant="secondary" className="text-xs px-1.5 h-5">
                        {tasksByColumn[column.id]?.length || 0}
                        {column.wip_limit > 0 && ` / ${column.wip_limit}`}
                    </Badge>
                </div>
                <Button variant="ghost" size="icon" className="h-6 w-6">
                    <MoreHorizontal className="h-4 w-4" />
                </Button>
            </div>
            
            <Droppable droppableId={column.id}>
              {(provided, snapshot) => (
                <div
                  {...provided.droppableProps}
                  ref={provided.innerRef}
                  className={cn(
                    "flex-1 p-2 flex flex-col gap-2 overflow-y-auto min-h-[150px] transition-colors",
                    snapshot.isDraggingOver ? "bg-blue-50/50 dark:bg-blue-900/10" : ""
                  )}
                >
                  {tasksByColumn[column.id]?.map((task, index) => (
                    <Draggable key={task.id} draggableId={task.id} index={index}>
                      {(provided, snapshot) => (
                        <Card
                          ref={provided.innerRef}
                          {...provided.draggableProps}
                          {...provided.dragHandleProps}
                          onClick={() => onTaskClick(task)}
                          className={cn(
                            "cursor-pointer hover:shadow-md transition-all border-l-4",
                            snapshot.isDragging ? "shadow-lg scale-105 rotate-1" : "",
                            task.priority_abcde === 'A' ? "border-l-red-500" :
                            task.priority_abcde === 'B' ? "border-l-orange-400" :
                            task.priority_abcde === 'C' ? "border-l-blue-400" : "border-l-gray-300"
                          )}
                        >
                          <CardContent className="p-3 space-y-2">
                             <div className="flex justify-between items-start">
                                 <span className="text-sm font-medium leading-snug line-clamp-2">{task.title}</span>
                             </div>
                             
                             <div className="flex items-center gap-2 flex-wrap">
                                 {task.context_gtd && (
                                     <Badge variant="outline" className="text-[10px] h-5 px-1 bg-white">
                                         {task.context_gtd}
                                     </Badge>
                                 )}
                                 {task.due_date && (
                                     <div className={cn(
                                         "flex items-center text-[10px] gap-1 px-1.5 py-0.5 rounded-md",
                                         new Date(task.due_date) < new Date() ? "bg-red-100 text-red-700" : "bg-gray-100 text-gray-600"
                                     )}>
                                         <Calendar className="h-3 w-3" />
                                         {format(new Date(task.due_date), 'dd/MM', { locale: ptBR })}
                                     </div>
                                 )}
                                 {task.energy_level === 'high' && <Zap className="h-3 w-3 text-yellow-500" />}
                             </div>
                          </CardContent>
                        </Card>
                      )}
                    </Draggable>
                  ))}
                  {provided.placeholder}
                </div>
              )}
            </Droppable>

            <div className="p-2 pt-0">
                <Button 
                    variant="ghost" 
                    className="w-full justify-start text-gray-500 hover:text-gray-900"
                    onClick={() => onAddClick(column.id)}
                >
                    <Plus className="mr-2 h-4 w-4" /> Adicionar Tarefa
                </Button>
            </div>
          </div>
        ))}
        
        {/* Add Column Button Placeholder */}
        <div className="min-w-[50px] flex items-start pt-2">
             <Button variant="ghost" size="icon" className="bg-gray-100 hover:bg-gray-200">
                 <Plus className="h-5 w-5" />
             </Button>
        </div>
      </div>
    </DragDropContext>
  );
};

export default KanbanBoard;
