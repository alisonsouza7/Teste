
import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { ChevronDown, ChevronRight, Edit, Circle, Layout } from 'lucide-react';
import { cn } from '@/lib/utils';
import { Badge } from '@/components/ui/badge';

const MindMapNode = ({ label, type, children, expanded = true, onToggle, actions, color }) => {
  return (
    <div className="flex flex-col relative pl-6">
      <div className="flex items-center gap-2 mb-2 group">
        {children && children.length > 0 && (
          <button 
            onClick={onToggle}
            className="w-5 h-5 flex items-center justify-center rounded-full hover:bg-gray-200 transition-colors"
          >
            {expanded ? <ChevronDown className="w-4 h-4" /> : <ChevronRight className="w-4 h-4" />}
          </button>
        )}
        {!children && <div className="w-5" />} {/* Spacer */}
        
        <div className={cn(
            "flex items-center gap-3 px-4 py-2 rounded-full border shadow-sm transition-all hover:shadow-md cursor-default",
            "bg-white z-10 min-w-[150px]",
            type === 'project' && "border-blue-500 border-l-4",
            type === 'status' && "border-purple-400 border-l-4",
            type === 'task' && "border-green-400 border-l-4"
        )}>
            <div className={cn("w-2 h-2 rounded-full shrink-0", color)} />
            <span className="font-medium text-sm whitespace-nowrap">{label}</span>
            {actions && <div className="ml-auto pl-2 opacity-0 group-hover:opacity-100 transition-opacity">{actions}</div>}
        </div>
        
        {/* Connector Line */}
        <div className="absolute left-0 top-3 w-6 h-px bg-gray-300 -translate-y-1/2" />
      </div>
      
      {/* Vertical Line for Children */}
      {expanded && children && (
        <div className="border-l border-gray-300 ml-[9px] pl-4 space-y-2 py-1">
          {children}
        </div>
      )}
    </div>
  );
};

const MindMapView = ({ tasks, onTaskClick }) => {
  const [expandedNodes, setExpandedNodes] = useState({ 'root': true });

  const toggleNode = (id) => {
    setExpandedNodes(prev => ({ ...prev, [id]: !prev[id] }));
  };

  // Group tasks by Status for the MindMap structure
  const groupedTasks = React.useMemo(() => {
      const groups = {
          'A Fazer': tasks.filter(t => t.status === 'todo' || !t.status),
          'Em Andamento': tasks.filter(t => t.status === 'in_progress'),
          'Concluído': tasks.filter(t => t.status === 'completed')
      };
      return groups;
  }, [tasks]);

  return (
    <div className="p-8 bg-gray-50/50 min-h-[600px] overflow-auto rounded-xl border border-dashed relative">
      <div className="absolute top-4 right-4 bg-white p-3 rounded-lg shadow-sm border text-xs space-y-2 z-20">
          <div className="font-bold mb-1">Legenda</div>
          <div className="flex items-center gap-2"><div className="w-2 h-2 rounded-full bg-blue-500"/> Projeto Central</div>
          <div className="flex items-center gap-2"><div className="w-2 h-2 rounded-full bg-purple-500"/> Status / Fase</div>
          <div className="flex items-center gap-2"><div className="w-2 h-2 rounded-full bg-green-500"/> Tarefa</div>
      </div>

      <div className="ml-4">
          {/* Root Node: Project */}
          <MindMapNode 
            label="Projeto Atual" 
            type="project" 
            color="bg-blue-500"
            expanded={expandedNodes['root']}
            onToggle={() => toggleNode('root')}
          >
            {Object.entries(groupedTasks).map(([status, statusTasks]) => (
                <MindMapNode
                    key={status}
                    label={`${status} (${statusTasks.length})`}
                    type="status"
                    color="bg-purple-500"
                    expanded={expandedNodes[status]}
                    onToggle={() => toggleNode(status)}
                >
                    {statusTasks.map(task => (
                        <MindMapNode
                            key={task.id}
                            label={task.title}
                            type="task"
                            color="bg-green-500"
                            actions={
                                <Button variant="ghost" size="icon" className="h-5 w-5" onClick={() => onTaskClick(task)}>
                                    <Edit className="w-3 h-3" />
                                </Button>
                            }
                        />
                    ))}
                </MindMapNode>
            ))}
          </MindMapNode>
      </div>
    </div>
  );
};

export default MindMapView;
