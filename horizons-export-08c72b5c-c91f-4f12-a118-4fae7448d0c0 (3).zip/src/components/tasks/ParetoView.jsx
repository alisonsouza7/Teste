
import React, { useMemo } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { useTaskAutomations } from '@/hooks/useTaskAutomations';
import { ResponsiveContainer, ComposedChart, Line, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, Area } from 'recharts';
import { TrendingUp, AlertTriangle, ArrowRight } from 'lucide-react';
import { cn } from '@/lib/utils';

const ParetoView = ({ tasks, onTaskClick }) => {
  const { recalculatePareto } = useTaskAutomations();
  
  const { top20, bottom80, scoredTasks } = useMemo(() => recalculatePareto(tasks), [tasks, recalculatePareto]);

  const totalImpact = scoredTasks.reduce((acc, t) => acc + t.impact_score, 0);
  const top20Impact = top20.reduce((acc, t) => acc + t.impact_score, 0);
  const impactPercentage = totalImpact > 0 ? Math.round((top20Impact / totalImpact) * 100) : 0;

  // Chart Data: Cumulative Impact
  const chartData = useMemo(() => {
    let cumulative = 0;
    return scoredTasks.map((t, idx) => {
      cumulative += t.impact_score;
      return {
        name: `T${idx + 1}`,
        impact: t.impact_score,
        cumulativeImpact: cumulative,
        cumulativePercentage: totalImpact > 0 ? Math.round((cumulative / totalImpact) * 100) : 0
      };
    }).slice(0, 20); // Show top 20 items in chart for readability
  }, [scoredTasks, totalImpact]);

  return (
    <div className="space-y-6">
      {/* KPI Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card className="bg-gradient-to-br from-indigo-50 to-white">
            <CardContent className="p-6">
                <p className="text-sm font-medium text-indigo-600">Tarefas no Top 20%</p>
                <h3 className="text-4xl font-bold text-gray-900 mt-2">{top20.length}</h3>
                <p className="text-xs text-gray-500 mt-1">De {tasks.length} tarefas totais</p>
            </CardContent>
        </Card>
        <Card className="bg-gradient-to-br from-emerald-50 to-white">
            <CardContent className="p-6">
                <p className="text-sm font-medium text-emerald-600">Impacto Gerado</p>
                <h3 className="text-4xl font-bold text-gray-900 mt-2">{impactPercentage}%</h3>
                <p className="text-xs text-gray-500 mt-1">Do resultado total esperado</p>
            </CardContent>
        </Card>
        <Card className="bg-gradient-to-br from-blue-50 to-white">
            <CardContent className="p-6">
                <p className="text-sm font-medium text-blue-600">Pontuação Total</p>
                <h3 className="text-4xl font-bold text-gray-900 mt-2">{totalImpact}</h3>
                <p className="text-xs text-gray-500 mt-1">Soma dos scores de impacto</p>
            </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Chart Section */}
          <div className="lg:col-span-2">
             <Card className="h-full">
                 <CardHeader>
                     <CardTitle className="text-lg flex items-center gap-2">
                         <TrendingUp className="w-5 h-5 text-blue-500" />
                         Curva de Pareto (Impacto Acumulado)
                     </CardTitle>
                 </CardHeader>
                 <CardContent className="h-[400px]">
                     <ResponsiveContainer width="100%" height="100%">
                         <ComposedChart data={chartData} margin={{ top: 20, right: 20, bottom: 20, left: 20 }}>
                             <CartesianGrid stroke="#f5f5f5" />
                             <XAxis dataKey="name" scale="band" fontSize={10} />
                             <YAxis yAxisId="left" orientation="left" stroke="#8884d8" fontSize={10} />
                             <YAxis yAxisId="right" orientation="right" stroke="#82ca9d" unit="%" fontSize={10} />
                             <Tooltip />
                             <Legend />
                             <Bar yAxisId="left" dataKey="impact" barSize={20} fill="#8884d8" name="Impacto Individual" />
                             <Line yAxisId="right" type="monotone" dataKey="cumulativePercentage" stroke="#82ca9d" strokeWidth={3} name="% Acumulado" dot={false} />
                         </ComposedChart>
                     </ResponsiveContainer>
                 </CardContent>
             </Card>
          </div>

          {/* Top 20% List */}
          <div className="lg:col-span-1">
             <Card className="h-full flex flex-col">
                 <CardHeader className="bg-indigo-50 pb-4">
                     <CardTitle className="text-lg text-indigo-900 flex items-center justify-between">
                         <span>Vital Few (Top 20%)</span>
                         <Badge variant="default" className="bg-indigo-600">Foco Total</Badge>
                     </CardTitle>
                 </CardHeader>
                 <div className="flex-1 overflow-y-auto p-4 space-y-3">
                     {top20.map((task, idx) => (
                         <div 
                            key={task.id} 
                            className="flex items-start gap-3 p-3 border rounded-lg hover:bg-indigo-50/50 cursor-pointer transition-colors"
                            onClick={() => onTaskClick(task)}
                        >
                             <div className="bg-indigo-100 text-indigo-700 font-bold w-8 h-8 rounded-full flex items-center justify-center shrink-0">
                                 {idx + 1}
                             </div>
                             <div className="min-w-0">
                                 <p className="text-sm font-semibold text-gray-800 line-clamp-2">{task.title}</p>
                                 <div className="flex items-center gap-2 mt-1">
                                     <Badge variant="outline" className="text-[10px] border-indigo-200 text-indigo-600">Score: {task.impact_score}</Badge>
                                     <span className="text-xs text-gray-400">P: {task.priority_abcde}</span>
                                 </div>
                             </div>
                         </div>
                     ))}
                     {top20.length === 0 && <div className="text-center text-gray-400 mt-10">Nenhuma tarefa encontrada</div>}
                 </div>
             </Card>
          </div>
      </div>

      {/* Bottom 80% Grid */}
      <Card>
          <CardHeader>
              <CardTitle className="text-lg text-gray-600 flex items-center gap-2">
                  Trivial Many (Bottom 80%)
                  <span className="text-sm font-normal text-gray-400 ml-auto">Mostrando primeiros 10 itens</span>
              </CardTitle>
          </CardHeader>
          <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
                  {bottom80.slice(0, 10).map((task) => (
                      <div key={task.id} className="p-3 border rounded bg-gray-50 opacity-70 hover:opacity-100 transition-opacity">
                          <p className="text-xs font-medium truncate mb-2" title={task.title}>{task.title}</p>
                          <div className="flex justify-between items-center">
                              <Badge variant="secondary" className="text-[10px] scale-90 origin-left">{task.status}</Badge>
                              <span className="text-[10px] text-gray-400">S: {task.impact_score}</span>
                          </div>
                      </div>
                  ))}
              </div>
              <div className="mt-4 p-4 bg-yellow-50 rounded-lg border border-yellow-100 flex items-start gap-3">
                  <AlertTriangle className="w-5 h-5 text-yellow-600 shrink-0 mt-0.5" />
                  <div>
                      <h4 className="text-sm font-bold text-yellow-800">Recomendação do Sistema</h4>
                      <p className="text-sm text-yellow-700 mt-1">
                          Concentre-se exclusivamente nas tarefas da lista "Vital Few". Elas representam 80% do impacto potencial do seu projeto. 
                          As tarefas do "Trivial Many" devem ser delegadas, agendadas para depois ou eliminadas se possível.
                      </p>
                  </div>
              </div>
          </CardContent>
      </Card>
    </div>
  );
};

export default ParetoView;
