
import React, { useEffect } from 'react';
import { useForm } from 'react-hook-form';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Loader2, Tag } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';

const TagModal = ({ open, onOpenChange, tagToEdit, onSave }) => {
  const { register, handleSubmit, reset, watch, formState: { errors, isSubmitting } } = useForm();
  const { toast } = useToast();

  const selectedColor = watch('color', '#6366f1');
  const selectedName = watch('name', '');

  useEffect(() => {
    if (open) {
      if (tagToEdit) {
        reset({
          name: tagToEdit.name,
          color: tagToEdit.color || '#6366f1',
        });
      } else {
        reset({
          name: '',
          color: '#6366f1',
        });
      }
    }
  }, [open, tagToEdit, reset]);

  const onSubmit = async (data) => {
    try {
      await onSave(data, tagToEdit?.id);
      onOpenChange(false);
      toast({
        title: "Sucesso",
        description: `Tag ${tagToEdit ? 'atualizada' : 'criada'} com sucesso.`,
      });
    } catch (error) {
      console.error(error);
      toast({
        title: "Erro",
        description: "Falha ao salvar a tag.",
        variant: "destructive"
      });
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[400px]">
        <DialogHeader>
          <DialogTitle>{tagToEdit ? 'Editar Tag' : 'Nova Tag'}</DialogTitle>
        </DialogHeader>

        <form onSubmit={handleSubmit(onSubmit)} className="space-y-4 py-4">
          <div className="space-y-2">
            <Label htmlFor="name">Nome da Tag <span className="text-red-500">*</span></Label>
            <Input
              id="name"
              {...register('name', { required: 'Nome é obrigatório' })}
              placeholder="Ex: Urgente, Financeiro, Bug"
            />
            {errors.name && <span className="text-red-500 text-xs">{errors.name.message}</span>}
          </div>

          <div className="space-y-2">
            <Label htmlFor="color">Cor</Label>
            <div className="flex items-center gap-4">
              <Input
                id="color"
                type="color"
                {...register('color')}
                className="w-16 h-10 p-1 cursor-pointer"
              />
              <div className="flex items-center gap-2 px-3 py-1 rounded-full border text-sm font-medium" 
                   style={{ backgroundColor: `${selectedColor}20`, color: selectedColor, borderColor: selectedColor }}>
                <Tag className="w-4 h-4" />
                <span>{selectedName || 'Visualização'}</span>
              </div>
            </div>
          </div>

          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>Cancelar</Button>
            <Button type="submit" disabled={isSubmitting} className="bg-blue-600 hover:bg-blue-700 text-white">
              {isSubmitting && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              {tagToEdit ? 'Salvar' : 'Criar Tag'}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
};

export default TagModal;
