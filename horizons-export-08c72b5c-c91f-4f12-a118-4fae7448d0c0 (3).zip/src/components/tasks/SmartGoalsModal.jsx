
import React, { useEffect } from 'react';
import { useForm } from 'react-hook-form';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Label } from '@/components/ui/label';
import { Progress } from '@/components/ui/progress';
import { Loader2 } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';

const SmartGoalsModal = ({ open, onOpenChange, onSave, goalToEdit }) => {
  const { register, handleSubmit, reset, setValue, watch, formState: { errors, isSubmitting } } = useForm();
  
  // Calculate completeness of the SMART goal definition
  const watchedFields = watch();
  const completeness = React.useMemo(() => {
      let count = 0;
      if (watchedFields.specific) count++;
      if (watchedFields.measurable) count++;
      if (watchedFields.achievable) count++;
      if (watchedFields.relevant) count++;
      if (watchedFields.time_bound) count++;
      return (count / 5) * 100;
  }, [watchedFields]);

  useEffect(() => {
      if (open) {
          if (goalToEdit) {
              reset(goalToEdit);
          } else {
              reset({
                  title: '',
                  specific: '',
                  measurable: '',
                  achievable: '',
                  relevant: '',
                  time_bound: ''
              });
          }
      }
  }, [open, goalToEdit, reset]);

  const onSubmit = async (data) => {
      await onSave(data, goalToEdit?.id);
      onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[700px] max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{goalToEdit ? 'Editar Meta SMART' : 'Nova Meta SMART'}</DialogTitle>
        </DialogHeader>

        <form onSubmit={handleSubmit(onSubmit)} className="space-y-6 py-4">
            <div className="space-y-2">
                <Label>Título da Meta</Label>
                <Input {...register('title', { required: true })} placeholder="Ex: Aumentar faturamento em 20%" />
            </div>

            <div className="bg-blue-50 p-4 rounded-lg space-y-4">
                <div className="flex justify-between items-center mb-2">
                    <span className="text-sm font-semibold text-blue-800">Qualidade da Meta (SMART)</span>
                    <span className="text-xs font-bold text-blue-600">{completeness}%</span>
                </div>
                <Progress value={completeness} className="h-2" />
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                        <Label className="text-blue-900">S - Específico (Specific)</Label>
                        <Textarea 
                            {...register('specific')} 
                            placeholder="O que exatamente você quer alcançar?" 
                            className="h-20 text-xs"
                        />
                    </div>
                    <div className="space-y-2">
                        <Label className="text-blue-900">M - Mensurável (Measurable)</Label>
                        <Textarea 
                            {...register('measurable')} 
                            placeholder="Como você saberá que atingiu a meta?" 
                            className="h-20 text-xs"
                        />
                    </div>
                    <div className="space-y-2">
                        <Label className="text-blue-900">A - Atingível (Achievable)</Label>
                        <Textarea 
                            {...register('achievable')} 
                            placeholder="Como a meta pode ser realizada?" 
                            className="h-20 text-xs"
                        />
                    </div>
                    <div className="space-y-2">
                        <Label className="text-blue-900">R - Relevante (Relevant)</Label>
                        <Textarea 
                            {...register('relevant')} 
                            placeholder="Por que isso importa agora?" 
                            className="h-20 text-xs"
                        />
                    </div>
                </div>
                
                <div className="space-y-2">
                    <Label className="text-blue-900">T - Temporal (Time-bound)</Label>
                    <Input type="date" {...register('time_bound')} />
                </div>
            </div>

            <DialogFooter>
                <Button type="button" variant="ghost" onClick={() => onOpenChange(false)}>Cancelar</Button>
                <Button type="submit" disabled={isSubmitting} className="bg-blue-600 text-white">
                    {isSubmitting && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                    Salvar Meta
                </Button>
            </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
};

export default SmartGoalsModal;
