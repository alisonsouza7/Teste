
import React, { useEffect } from 'react';
import { useForm } from 'react-hook-form';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Label } from '@/components/ui/label';
import { Loader2 } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';

const ProjectModal = ({ open, onOpenChange, projectToEdit, onSave }) => {
  const { register, handleSubmit, reset, setValue, formState: { errors, isSubmitting } } = useForm();
  const { toast } = useToast();

  useEffect(() => {
    if (open) {
      if (projectToEdit) {
        reset({
          title: projectToEdit.title,
          description: projectToEdit.description || '',
          methodology_mode: projectToEdit.methodology_mode || 'kanban',
          color: projectToEdit.color || '#3b82f6',
        });
      } else {
        reset({
          title: '',
          description: '',
          methodology_mode: 'kanban',
          color: '#3b82f6',
        });
      }
    }
  }, [open, projectToEdit, reset]);

  const onSubmit = async (data) => {
    try {
      await onSave(data, projectToEdit?.id);
      onOpenChange(false);
      toast({
        title: "Sucesso",
        description: `Projeto ${projectToEdit ? 'atualizado' : 'criado'} com sucesso.`,
      });
    } catch (error) {
      console.error(error);
      toast({
        title: "Erro",
        description: "Falha ao salvar o projeto.",
        variant: "destructive"
      });
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle>{projectToEdit ? 'Editar Projeto' : 'Novo Projeto'}</DialogTitle>
        </DialogHeader>

        <form onSubmit={handleSubmit(onSubmit)} className="space-y-4 py-4">
          <div className="space-y-2">
            <Label htmlFor="title">Nome do Projeto <span className="text-red-500">*</span></Label>
            <Input
              id="title"
              {...register('title', { required: 'Nome é obrigatório' })}
              placeholder="Ex: Lançamento Site 2024"
            />
            {errors.title && <span className="text-red-500 text-xs">{errors.title.message}</span>}
          </div>

          <div className="space-y-2">
            <Label htmlFor="description">Descrição</Label>
            <Textarea
              id="description"
              {...register('description')}
              placeholder="Objetivos e escopo do projeto..."
              className="resize-none"
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="methodology">Metodologia Principal</Label>
              <Select
                onValueChange={(val) => setValue('methodology_mode', val)}
                defaultValue={projectToEdit?.methodology_mode || 'kanban'}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Selecione" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="kanban">Kanban</SelectItem>
                  <SelectItem value="gtd">GTD (Getting Things Done)</SelectItem>
                  <SelectItem value="pomodoro">Pomodoro</SelectItem>
                  <SelectItem value="smart">Metas SMART</SelectItem>
                  <SelectItem value="abcde">Método ABCDE</SelectItem>
                  <SelectItem value="pareto">Pareto (80/20)</SelectItem>
                  <SelectItem value="mindmap">Mapa Mental</SelectItem>
                  <SelectItem value="waterfall">Waterfall</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="color">Cor de Identificação</Label>
              <div className="flex gap-2 items-center">
                <Input
                  id="color"
                  type="color"
                  {...register('color')}
                  className="w-12 h-10 p-1 cursor-pointer"
                />
                <span className="text-xs text-gray-500">Escolha uma cor</span>
              </div>
            </div>
          </div>

          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>Cancelar</Button>
            <Button type="submit" disabled={isSubmitting} className="bg-blue-600 hover:bg-blue-700 text-white">
              {isSubmitting && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              {projectToEdit ? 'Salvar Alterações' : 'Criar Projeto'}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
};

export default ProjectModal;
