
import React from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { MoreHorizontal, Trash2, UserPlus, Edit } from 'lucide-react';
import { cn } from '@/lib/utils';
import { ScrollArea } from '@/components/ui/scroll-area';

const PrioritySection = ({ 
    priority, 
    title, 
    description, 
    tasks, 
    color, 
    bgColor, 
    actionLabel, 
    onAction, 
    onTaskClick 
}) => {
  const totalImpact = tasks.length * (priority === 'A' ? 10 : priority === 'B' ? 8 : priority === 'C' ? 5 : priority === 'D' ? 3 : 1);
  const avgUrgency = tasks.length > 0 ? 'Alta' : '-'; // Simulated

  return (
    <Card className="h-full flex flex-col overflow-hidden border-t-4" style={{ borderTopColor: color }}>
      <div className={cn("p-4 border-b", bgColor)}>
        <div className="flex justify-between items-start mb-2">
            <div>
                <h3 className="text-lg font-bold flex items-center gap-2" style={{ color }}>
                    {priority} - {title}
                </h3>
                <p className="text-xs text-gray-600 mt-1">{description}</p>
            </div>
            <Badge variant="secondary" className="text-lg font-mono">{tasks.length}</Badge>
        </div>
        <div className="flex gap-4 text-xs text-gray-500 mt-2">
            <span>Impacto: <strong>{totalImpact}</strong></span>
            <span>Urgência: <strong>{avgUrgency}</strong></span>
        </div>
      </div>
      
      <ScrollArea className="flex-1 p-0">
        <div className="p-3 space-y-2">
            {tasks.map((task, idx) => (
                <div key={task.id} className="group flex items-start gap-3 p-3 bg-white border rounded-lg hover:shadow-sm transition-all">
                    <span className="font-mono text-xs font-bold text-gray-400 mt-1">#{idx + 1}</span>
                    <div className="flex-1 min-w-0">
                        <p 
                            className="text-sm font-medium text-gray-800 cursor-pointer hover:text-blue-600 truncate"
                            onClick={() => onTaskClick(task)}
                        >
                            {task.title}
                        </p>
                        <div className="flex items-center gap-2 mt-1">
                            <Badge variant="outline" className="text-[10px] h-4 px-1">{task.status}</Badge>
                            {task.due_date && <span className="text-[10px] text-gray-400">Due: {task.due_date.split('T')[0]}</span>}
                        </div>
                    </div>
                    <div className="opacity-0 group-hover:opacity-100 flex gap-1 transition-opacity">
                         <Button variant="ghost" size="icon" className="h-6 w-6" onClick={() => onTaskClick(task)}>
                             <Edit className="w-3 h-3" />
                         </Button>
                    </div>
                </div>
            ))}
            {tasks.length === 0 && (
                <div className="text-center py-8 text-gray-300 text-sm italic">
                    Nenhuma tarefa
                </div>
            )}
        </div>
      </ScrollArea>

      {actionLabel && (
        <div className="p-3 border-t bg-gray-50">
            <Button 
                variant="outline" 
                className="w-full text-xs h-8 border-dashed" 
                onClick={onAction}
            >
                {priority === 'D' ? <UserPlus className="w-3 h-3 mr-2" /> : <Trash2 className="w-3 h-3 mr-2" />}
                {actionLabel}
            </Button>
        </div>
      )}
    </Card>
  );
};

const ABCDEView = ({ tasks, onTaskClick }) => {
  const getTasks = (p) => tasks.filter(t => t.priority_abcde === p);

  return (
    <div className="space-y-6 h-full flex flex-col">
      <div className="bg-white p-4 rounded-lg border shadow-sm mb-2">
          <h2 className="text-xl font-bold text-gray-800 mb-2">Matriz ABCDE</h2>
          <p className="text-sm text-gray-500">
              Método de priorização: <strong>A</strong> (Crítico - Fazer Agora), <strong>B</strong> (Importante - Agendar), <strong>C</strong> (Útil - Se der tempo), <strong>D</strong> (Delegável - Passar para outro), <strong>E</strong> (Eliminável - Não fazer).
          </p>
      </div>

      <div className="flex-1 grid grid-cols-1 md:grid-cols-3 lg:grid-cols-5 gap-4 min-h-[500px]">
        <PrioritySection 
            priority="A" 
            title="Crítico" 
            description="Consequências graves se não fizer hoje."
            tasks={getTasks('A')}
            color="#ef4444"
            bgColor="bg-red-50"
            onTaskClick={onTaskClick}
        />
        <PrioritySection 
            priority="B" 
            title="Importante" 
            description="Consequências leves se adiar."
            tasks={getTasks('B')}
            color="#f97316"
            bgColor="bg-orange-50"
            onTaskClick={onTaskClick}
        />
        <PrioritySection 
            priority="C" 
            title="Desejável" 
            description="Sem consequências se não fizer."
            tasks={getTasks('C')}
            color="#3b82f6"
            bgColor="bg-blue-50"
            onTaskClick={onTaskClick}
        />
        <PrioritySection 
            priority="D" 
            title="Delegar" 
            description="Alguém pode fazer por você?"
            tasks={getTasks('D')}
            color="#8b5cf6"
            bgColor="bg-purple-50"
            actionLabel="Delegar Todas em D"
            onAction={() => alert('Função de delegar em lote em breve')}
            onTaskClick={onTaskClick}
        />
        <PrioritySection 
            priority="E" 
            title="Eliminar" 
            description="Tarefas que não agregam valor."
            tasks={getTasks('E')}
            color="#6b7280"
            bgColor="bg-gray-100"
            actionLabel="Arquivar/Excluir E"
            onAction={() => alert('Função de limpar em lote em breve')}
            onTaskClick={onTaskClick}
        />
      </div>
    </div>
  );
};

export default ABCDEView;
