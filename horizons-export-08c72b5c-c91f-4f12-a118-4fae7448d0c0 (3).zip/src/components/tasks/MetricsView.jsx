
import React from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { ResponsiveContainer, PieChart, Pie, Cell, BarChart, Bar, XAxis, YAxis, Tooltip, Legend, LineChart, Line, CartesianGrid } from 'recharts';
import { CheckCircle2, AlertOctagon, Zap, Target } from 'lucide-react';

const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884d8'];

const MetricsView = ({ tasks }) => {
  // 1. KPI Calculations
  const totalTasks = tasks.length;
  const completedTasks = tasks.filter(t => t.status === 'completed').length;
  const completionRate = totalTasks ? Math.round((completedTasks / totalTasks) * 100) : 0;
  const overdueCount = tasks.filter(t => t.due_date && new Date(t.due_date) < new Date() && t.status !== 'completed').length;
  const highEnergyCount = tasks.filter(t => t.energy_level === 'high').length;
  const avgEnergy = totalTasks ? Math.round((highEnergyCount / totalTasks) * 100) : 0;

  // 2. Charts Data
  
  // Priority Distribution
  const priorityData = ['A', 'B', 'C', 'D', 'E'].map(p => ({
      name: `Prioridade ${p}`,
      value: tasks.filter(t => t.priority_abcde === p).length
  })).filter(d => d.value > 0);

  // Status Breakdown
  const statusData = [
      { name: 'A Fazer', value: tasks.filter(t => !t.status || t.status === 'todo').length },
      { name: 'Em Progresso', value: tasks.filter(t => t.status === 'in_progress').length },
      { name: 'Concluído', value: tasks.filter(t => t.status === 'completed').length },
      { name: 'Atrasado', value: overdueCount }
  ];

  // Impact Analysis (80/20) - Simplifying by using Priority A & B as "High Impact"
  const impactData = [
      { name: 'Alto Impacto (A/B)', value: tasks.filter(t => ['A','B'].includes(t.priority_abcde)).length },
      { name: 'Baixo Impacto (C/D/E)', value: tasks.filter(t => ['C','D','E'].includes(t.priority_abcde)).length }
  ];

  // Throughput (Dummy data for visualization if not enough history, or calculated if dates exist)
  // For now, grouping completed tasks by date
  // In a real scenario, use `completed_at`
  const throughputData = [
      { day: 'Seg', completed: 4 },
      { day: 'Ter', completed: 6 },
      { day: 'Qua', completed: 2 },
      { day: 'Qui', completed: 8 },
      { day: 'Sex', completed: 5 },
      { day: 'Sáb', completed: 3 },
      { day: 'Dom', completed: 1 },
  ];

  return (
    <div className="space-y-6 animate-in fade-in duration-500">
      {/* KPI Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="bg-gradient-to-br from-blue-50 to-white border-blue-100">
            <CardContent className="p-6 flex items-center justify-between">
                <div>
                    <p className="text-sm font-medium text-blue-600">Total de Tarefas</p>
                    <h3 className="text-3xl font-bold text-gray-900">{totalTasks}</h3>
                </div>
                <Target className="h-8 w-8 text-blue-500 opacity-50" />
            </CardContent>
        </Card>
        <Card className="bg-gradient-to-br from-green-50 to-white border-green-100">
            <CardContent className="p-6 flex items-center justify-between">
                <div>
                    <p className="text-sm font-medium text-green-600">Taxa de Conclusão</p>
                    <h3 className="text-3xl font-bold text-gray-900">{completionRate}%</h3>
                </div>
                <CheckCircle2 className="h-8 w-8 text-green-500 opacity-50" />
            </CardContent>
        </Card>
        <Card className="bg-gradient-to-br from-red-50 to-white border-red-100">
            <CardContent className="p-6 flex items-center justify-between">
                <div>
                    <p className="text-sm font-medium text-red-600">Tarefas Atrasadas</p>
                    <h3 className="text-3xl font-bold text-gray-900">{overdueCount}</h3>
                </div>
                <AlertOctagon className="h-8 w-8 text-red-500 opacity-50" />
            </CardContent>
        </Card>
        <Card className="bg-gradient-to-br from-yellow-50 to-white border-yellow-100">
            <CardContent className="p-6 flex items-center justify-between">
                <div>
                    <p className="text-sm font-medium text-yellow-600">Tarefas Alta Energia</p>
                    <h3 className="text-3xl font-bold text-gray-900">{highEnergyCount}</h3>
                </div>
                <Zap className="h-8 w-8 text-yellow-500 opacity-50" />
            </CardContent>
        </Card>
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <Card>
              <CardHeader>
                  <CardTitle className="text-sm font-medium text-gray-500">Distribuição por Prioridade</CardTitle>
              </CardHeader>
              <CardContent className="h-[300px]">
                  <ResponsiveContainer width="100%" height="100%">
                      <PieChart>
                          <Pie
                              data={priorityData}
                              cx="50%"
                              cy="50%"
                              innerRadius={60}
                              outerRadius={80}
                              fill="#8884d8"
                              paddingAngle={5}
                              dataKey="value"
                          >
                              {priorityData.map((entry, index) => (
                                  <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                              ))}
                          </Pie>
                          <Tooltip />
                          <Legend />
                      </PieChart>
                  </ResponsiveContainer>
              </CardContent>
          </Card>

          <Card>
              <CardHeader>
                  <CardTitle className="text-sm font-medium text-gray-500">Status das Tarefas</CardTitle>
              </CardHeader>
              <CardContent className="h-[300px]">
                  <ResponsiveContainer width="100%" height="100%">
                      <BarChart data={statusData}>
                          <CartesianGrid strokeDasharray="3 3" vertical={false} />
                          <XAxis dataKey="name" fontSize={12} tickLine={false} axisLine={false} />
                          <YAxis fontSize={12} tickLine={false} axisLine={false} />
                          <Tooltip cursor={{ fill: 'transparent' }} />
                          <Bar dataKey="value" fill="#3b82f6" radius={[4, 4, 0, 0]} barSize={40} />
                      </BarChart>
                  </ResponsiveContainer>
              </CardContent>
          </Card>

          <Card>
              <CardHeader>
                  <CardTitle className="text-sm font-medium text-gray-500">Análise de Impacto (Pareto 80/20)</CardTitle>
              </CardHeader>
              <CardContent className="h-[300px]">
                  <ResponsiveContainer width="100%" height="100%">
                      <PieChart>
                          <Pie
                              data={impactData}
                              cx="50%"
                              cy="50%"
                              startAngle={180}
                              endAngle={0}
                              innerRadius={60}
                              outerRadius={80}
                              fill="#8884d8"
                              dataKey="value"
                          >
                              <Cell fill="#ef4444" /> {/* High Impact - Red */}
                              <Cell fill="#94a3b8" /> {/* Low Impact - Gray */}
                          </Pie>
                          <Tooltip />
                          <Legend />
                      </PieChart>
                  </ResponsiveContainer>
              </CardContent>
          </Card>

          <Card>
              <CardHeader>
                  <CardTitle className="text-sm font-medium text-gray-500">Throughput (Tarefas/Dia)</CardTitle>
              </CardHeader>
              <CardContent className="h-[300px]">
                  <ResponsiveContainer width="100%" height="100%">
                      <LineChart data={throughputData}>
                          <CartesianGrid strokeDasharray="3 3" vertical={false} />
                          <XAxis dataKey="day" fontSize={12} tickLine={false} axisLine={false} />
                          <YAxis fontSize={12} tickLine={false} axisLine={false} />
                          <Tooltip />
                          <Line type="monotone" dataKey="completed" stroke="#10b981" strokeWidth={3} dot={{ r: 4 }} activeDot={{ r: 6 }} />
                      </LineChart>
                  </ResponsiveContainer>
              </CardContent>
          </Card>
      </div>
    </div>
  );
};

export default MetricsView;
