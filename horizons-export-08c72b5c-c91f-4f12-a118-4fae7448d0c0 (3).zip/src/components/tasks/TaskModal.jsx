
import React, { useEffect, useState } from 'react';
import { useForm } from 'react-hook-form';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Label } from '@/components/ui/label';
import { useToast } from '@/components/ui/use-toast';
import { Loader2 } from 'lucide-react';

const TaskModal = ({ open, onOpenChange, taskToEdit, projectId, columnId, onSave }) => {
  const { register, handleSubmit, reset, setValue, watch, formState: { errors, isSubmitting } } = useForm();
  const { toast } = useToast();
  
  // Watch values for sliders/previews
  const impactScore = watch('impact_score', 0);
  const urgencyScore = watch('urgency_score', 0);

  useEffect(() => {
    if (open) {
      if (taskToEdit) {
        reset({
          title: taskToEdit.title,
          description: taskToEdit.description || '',
          status: taskToEdit.status || 'todo',
          priority_abcde: taskToEdit.priority_abcde || 'C',
          energy_level: taskToEdit.energy_level || 'medium',
          context_gtd: taskToEdit.context_gtd || '',
          due_date: taskToEdit.due_date ? taskToEdit.due_date.split('T')[0] : '',
          column_id: taskToEdit.column_id,
          impact_score: taskToEdit.impact_score || 0,
          urgency_score: taskToEdit.urgency_score || 0,
          color: taskToEdit.color || '#ffffff',
        });
      } else {
        reset({
          title: '',
          description: '',
          status: 'todo',
          priority_abcde: 'C',
          energy_level: 'medium',
          context_gtd: '@computer',
          due_date: '',
          column_id: columnId,
          impact_score: 50,
          urgency_score: 50,
          color: '#ffffff',
        });
      }
    }
  }, [open, taskToEdit, columnId, reset]);

  const onSubmit = async (data) => {
    try {
      const payload = {
        ...data,
        project_id: projectId,
        due_date: data.due_date ? new Date(data.due_date).toISOString() : null,
      };

      await onSave(payload, taskToEdit?.id);
      
      toast({
        title: "Sucesso!",
        description: `Tarefa ${taskToEdit ? 'atualizada' : 'criada'} com sucesso.`,
      });
      onOpenChange(false);
    } catch (error) {
      console.error(error);
      toast({
        title: "Erro",
        description: "Falha ao salvar a tarefa.",
        variant: "destructive"
      });
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[700px] max-h-[90vh] flex flex-col p-0 gap-0">
        <div className="p-6 pb-2 border-b">
             <DialogHeader>
                <DialogTitle>{taskToEdit ? 'Editar Tarefa' : 'Nova Tarefa'}</DialogTitle>
            </DialogHeader>
        </div>
        
        <div className="flex-1 overflow-y-auto p-6 space-y-6">
            <form id="task-form" onSubmit={handleSubmit(onSubmit)} className="space-y-6">
            <div className="space-y-2">
                <Label htmlFor="title">Título <span className="text-red-500">*</span></Label>
                <Input 
                id="title" 
                {...register('title', { required: 'Título é obrigatório' })} 
                placeholder="Ex: Finalizar relatório financeiro"
                className="text-lg font-medium"
                />
                {errors.title && <span className="text-red-500 text-xs">{errors.title.message}</span>}
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-4">
                    <div className="space-y-2">
                        <Label>Status</Label>
                        <Select 
                            onValueChange={(val) => setValue('status', val)} 
                            defaultValue={taskToEdit?.status || 'todo'}
                        >
                            <SelectTrigger>
                                <SelectValue placeholder="Selecione" />
                            </SelectTrigger>
                            <SelectContent>
                                <SelectItem value="todo">A Fazer</SelectItem>
                                <SelectItem value="in_progress">Em Progresso</SelectItem>
                                <SelectItem value="completed">Concluído</SelectItem>
                                <SelectItem value="blocked">Bloqueado</SelectItem>
                            </SelectContent>
                        </Select>
                    </div>

                    <div className="space-y-2">
                        <Label>Prioridade (ABCDE)</Label>
                        <Select 
                            onValueChange={(val) => setValue('priority_abcde', val)} 
                            defaultValue={taskToEdit?.priority_abcde || 'C'}
                        >
                            <SelectTrigger>
                                <SelectValue placeholder="Selecione" />
                            </SelectTrigger>
                            <SelectContent>
                                <SelectItem value="A">A (Crítica)</SelectItem>
                                <SelectItem value="B">B (Importante)</SelectItem>
                                <SelectItem value="C">C (Normal)</SelectItem>
                                <SelectItem value="D">D (Delegável)</SelectItem>
                                <SelectItem value="E">E (Eliminável)</SelectItem>
                            </SelectContent>
                        </Select>
                    </div>

                    <div className="space-y-2">
                        <Label>Contexto GTD</Label>
                        <Select 
                            onValueChange={(val) => setValue('context_gtd', val)} 
                            defaultValue={taskToEdit?.context_gtd || '@computer'}
                        >
                            <SelectTrigger>
                                <SelectValue placeholder="Selecione" />
                            </SelectTrigger>
                            <SelectContent>
                                <SelectItem value="@computer">@Computador</SelectItem>
                                <SelectItem value="@phone">@Telefone</SelectItem>
                                <SelectItem value="@office">@Escritório</SelectItem>
                                <SelectItem value="@home">@Casa</SelectItem>
                                <SelectItem value="@errand">@Rua/Resolver</SelectItem>
                                <SelectItem value="@waiting">@Aguardando</SelectItem>
                            </SelectContent>
                        </Select>
                    </div>
                </div>

                <div className="space-y-4">
                     <div className="space-y-2">
                        <Label>Nível de Energia</Label>
                        <Select 
                            onValueChange={(val) => setValue('energy_level', val)} 
                            defaultValue={taskToEdit?.energy_level || 'medium'}
                        >
                            <SelectTrigger>
                                <SelectValue placeholder="Selecione" />
                            </SelectTrigger>
                            <SelectContent>
                                <SelectItem value="high">Alto ⚡</SelectItem>
                                <SelectItem value="medium">Médio 🔋</SelectItem>
                                <SelectItem value="low">Baixo ☕</SelectItem>
                            </SelectContent>
                        </Select>
                    </div>

                    <div className="space-y-2">
                        <Label>Data de Entrega</Label>
                        <Input 
                            id="due_date" 
                            type="date"
                            {...register('due_date')} 
                        />
                    </div>

                     <div className="space-y-2">
                        <Label>Cor do Cartão</Label>
                        <Input 
                            id="color" 
                            type="color"
                            {...register('color')} 
                            className="h-10 cursor-pointer"
                        />
                    </div>
                </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 p-4 bg-gray-50 rounded-lg border">
                <div className="space-y-2">
                    <div className="flex justify-between">
                        <Label>Impacto (0-100)</Label>
                        <span className="text-xs font-mono bg-blue-100 text-blue-800 px-2 py-0.5 rounded">{impactScore}</span>
                    </div>
                    <input 
                        type="range" 
                        className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer accent-blue-600"
                        min="0" max="100" 
                        {...register('impact_score')}
                    />
                    <p className="text-xs text-gray-500">Quanto esta tarefa impacta nos objetivos?</p>
                </div>

                <div className="space-y-2">
                    <div className="flex justify-between">
                        <Label>Urgência (0-100)</Label>
                        <span className="text-xs font-mono bg-red-100 text-red-800 px-2 py-0.5 rounded">{urgencyScore}</span>
                    </div>
                     <input 
                        type="range" 
                        className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer accent-red-600"
                        min="0" max="100" 
                        {...register('urgency_score')}
                    />
                    <p className="text-xs text-gray-500">Quão rápido isso precisa ser feito?</p>
                </div>
            </div>

            <div className="space-y-2">
                <Label htmlFor="description">Descrição Detalhada</Label>
                <Textarea 
                id="description" 
                {...register('description')} 
                placeholder="Detalhes adicionais, requisitos, notas..."
                className="min-h-[120px]"
                />
            </div>
            </form>
        </div>

        <div className="p-6 pt-2 border-t bg-gray-50 rounded-b-lg">
            <DialogFooter>
                <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>Cancelar</Button>
                <Button type="submit" form="task-form" disabled={isSubmitting} className="bg-blue-600 hover:bg-blue-700 text-white">
                {isSubmitting && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                {taskToEdit ? 'Salvar Alterações' : 'Criar Tarefa'}
                </Button>
            </DialogFooter>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default TaskModal;
