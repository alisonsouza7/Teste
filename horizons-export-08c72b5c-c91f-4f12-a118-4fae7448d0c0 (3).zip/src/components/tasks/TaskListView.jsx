
import React, { useState, useMemo } from 'react';
import { Card, CardHeader, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { format, isPast, isToday, isTomorrow } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { AlertCircle, Calendar, Zap, Tag, Edit, Trash2 } from 'lucide-react';
import { cn } from '@/lib/utils';

const TaskListView = ({ tasks, onTaskClick, onToggleComplete, onDeleteTask }) => {
  const [groupBy, setGroupBy] = useState('status');
  const [sortBy, setSortBy] = useState('priority');

  const groupedTasks = useMemo(() => {
    let sorted = [...tasks].sort((a, b) => {
        if (sortBy === 'due_date') {
            if (!a.due_date) return 1;
            if (!b.due_date) return -1;
            return new Date(a.due_date) - new Date(b.due_date);
        } else if (sortBy === 'priority') {
            return a.priority_abcde.localeCompare(b.priority_abcde);
        }
        return 0;
    });

    const groups = {};
    sorted.forEach(task => {
        let key = '';
        if (groupBy === 'status') key = task.status || 'Sem Status';
        else if (groupBy === 'priority') key = `Prioridade ${task.priority_abcde}`;
        else if (groupBy === 'context') key = task.context_gtd || 'Sem Contexto';
        else if (groupBy === 'energy') key = `Energia: ${task.energy_level === 'high' ? 'Alta' : task.energy_level === 'low' ? 'Baixa' : 'Média'}`;
        
        if (!groups[key]) groups[key] = [];
        groups[key].push(task);
    });
    return groups;
  }, [tasks, groupBy, sortBy]);

  const getPriorityColor = (p) => {
    const map = { A: 'bg-red-100 text-red-800', B: 'bg-orange-100 text-orange-800', C: 'bg-blue-100 text-blue-800', D: 'bg-green-100 text-green-800', E: 'bg-gray-100 text-gray-800' };
    return map[p] || 'bg-gray-100';
  };

  const formatDateSmart = (dateStr) => {
      if (!dateStr) return null;
      const d = new Date(dateStr);
      if (isToday(d)) return 'Hoje';
      if (isTomorrow(d)) return 'Amanhã';
      return format(d, 'dd/MM/yyyy', { locale: ptBR });
  };

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center bg-white p-3 rounded-lg border shadow-sm">
          <div className="flex items-center gap-4">
              <span className="text-sm font-medium text-gray-500">Agrupar por:</span>
              <Select value={groupBy} onValueChange={setGroupBy}>
                  <SelectTrigger className="w-[150px] h-8">
                      <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                      <SelectItem value="status">Status</SelectItem>
                      <SelectItem value="priority">Prioridade</SelectItem>
                      <SelectItem value="context">Contexto GTD</SelectItem>
                      <SelectItem value="energy">Nível de Energia</SelectItem>
                  </SelectContent>
              </Select>
          </div>
          <div className="flex items-center gap-4">
              <span className="text-sm font-medium text-gray-500">Ordenar por:</span>
              <Select value={sortBy} onValueChange={setSortBy}>
                  <SelectTrigger className="w-[150px] h-8">
                      <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                      <SelectItem value="priority">Prioridade (A-E)</SelectItem>
                      <SelectItem value="due_date">Data de Entrega</SelectItem>
                  </SelectContent>
              </Select>
          </div>
      </div>

      <div className="space-y-6">
          {Object.entries(groupedTasks).map(([group, tasksInGroup]) => (
              <div key={group} className="space-y-2">
                  <h3 className="font-semibold text-lg text-gray-800 flex items-center gap-2">
                      {group}
                      <Badge variant="secondary" className="rounded-full">{tasksInGroup.length}</Badge>
                  </h3>
                  <div className="space-y-2">
                      {tasksInGroup.map(task => (
                          <div key={task.id} className="group flex items-center justify-between p-3 bg-white border rounded-lg hover:shadow-md transition-all">
                              <div className="flex items-center gap-4 flex-1">
                                  <Checkbox 
                                      checked={task.status === 'completed'} 
                                      onCheckedChange={() => onToggleComplete(task)}
                                  />
                                  <div className="flex flex-col">
                                      <span className={cn("font-medium", task.status === 'completed' && "line-through text-gray-400")}>
                                          {task.title}
                                      </span>
                                      <div className="flex items-center gap-2 mt-1">
                                          <Badge className={cn("text-[10px] px-1.5 py-0", getPriorityColor(task.priority_abcde))}>
                                              {task.priority_abcde}
                                          </Badge>
                                          {task.context_gtd && (
                                              <span className="text-xs text-gray-500 flex items-center gap-1">
                                                  <Tag className="w-3 h-3" /> {task.context_gtd}
                                              </span>
                                          )}
                                          {task.energy_level === 'high' && (
                                              <span className="text-xs text-yellow-600 flex items-center gap-1 font-medium">
                                                  <Zap className="w-3 h-3" /> Alta Energia
                                              </span>
                                          )}
                                      </div>
                                  </div>
                              </div>
                              
                              <div className="flex items-center gap-6">
                                  {task.due_date && (
                                      <div className={cn("flex items-center gap-1 text-sm", 
                                          isPast(new Date(task.due_date)) && !isToday(new Date(task.due_date)) && task.status !== 'completed' ? "text-red-600 font-medium" : "text-gray-500"
                                      )}>
                                          <Calendar className="w-4 h-4" />
                                          {formatDateSmart(task.due_date)}
                                          {isPast(new Date(task.due_date)) && !isToday(new Date(task.due_date)) && task.status !== 'completed' && <AlertCircle className="w-4 h-4 ml-1" />}
                                      </div>
                                  )}
                                  
                                  <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                                      <Button variant="ghost" size="icon" onClick={() => onTaskClick(task)}>
                                          <Edit className="w-4 h-4 text-gray-600" />
                                      </Button>
                                      <Button variant="ghost" size="icon" onClick={() => onDeleteTask(task.id)}>
                                          <Trash2 className="w-4 h-4 text-red-600" />
                                      </Button>
                                  </div>
                              </div>
                          </div>
                      ))}
                  </div>
              </div>
          ))}
      </div>
    </div>
  );
};

export default TaskListView;
