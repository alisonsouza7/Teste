import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { format, parseISO } from 'date-fns';

const TransactionTable = ({ title, data, type }) => (
  <Card className="mt-6">
    <CardHeader>
      <CardTitle>{title}</CardTitle>
    </CardHeader>
    <CardContent>
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>Data</TableHead>
            <TableHead>Descrição</TableHead>
            <TableHead>Categoria</TableHead>
            <TableHead className="text-right">Valor</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {data.length === 0 ? (
            <TableRow>
              <TableCell colSpan={4} className="text-center text-gray-500">Nenhum registro encontrado</TableCell>
            </TableRow>
          ) : (
            data.map((t) => (
              <TableRow key={t.id}>
                <TableCell>{t.data_competencia ? format(parseISO(t.data_competencia), 'dd/MM/yyyy') : '-'}</TableCell>
                <TableCell>{t.descricao}</TableCell>
                <TableCell>{t.categoria?.nome_conta || '-'}</TableCell>
                <TableCell className={`text-right font-medium ${type === 'receita' ? 'text-green-600' : 'text-red-600'}`}>
                  {new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(t.valor)}
                </TableCell>
              </TableRow>
            ))
          )}
        </TableBody>
      </Table>
    </CardContent>
  </Card>
);

const DetailedTables = ({ incomeRows, expenseRows, loading }) => {
  if (loading) return <div className="h-64 bg-gray-100 animate-pulse rounded-lg" />;

  return (
    <div className="space-y-6">
      <TransactionTable title="Detalhamento de Receitas" data={incomeRows} type="receita" />
      <TransactionTable title="Detalhamento de Despesas" data={expenseRows} type="despesa" />
    </div>
  );
};

export default DetailedTables;