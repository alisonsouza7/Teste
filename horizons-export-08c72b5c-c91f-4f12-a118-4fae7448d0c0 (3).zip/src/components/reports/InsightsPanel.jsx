import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Lightbulb } from "lucide-react";

const InsightsPanel = ({ insights, loading }) => {
  if (loading || !insights?.length) return null;

  return (
    <Card className="bg-blue-50 border-blue-100">
      <CardHeader className="pb-2">
        <CardTitle className="flex items-center text-blue-800 text-lg">
          <Lightbulb className="h-5 w-5 mr-2" />
          Insights
        </CardTitle>
      </CardHeader>
      <CardContent>
        <ul className="list-disc list-inside space-y-1 text-blue-700">
          {insights.map((insight, idx) => (
            <li key={idx}>{insight}</li>
          ))}
        </ul>
      </CardContent>
    </Card>
  );
};

export default InsightsPanel;