import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

const FinancialIndexes = ({ indexes, loading }) => {
  if (loading) return null;

  return (
    <Card>
      <CardHeader>
        <CardTitle>Indicadores Financeiros</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="p-4 bg-gray-50 rounded-lg">
            <p className="text-sm text-gray-500">Burn Rate (Mensal Est.)</p>
            <p className="text-xl font-bold">
              {new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(indexes.burnRate * 30)}
            </p>
          </div>
          {/* Add more indexes as needed */}
        </div>
      </CardContent>
    </Card>
  );
};

export default FinancialIndexes;