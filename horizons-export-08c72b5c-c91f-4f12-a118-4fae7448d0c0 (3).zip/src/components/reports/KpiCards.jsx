import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ArrowUpCircle, ArrowDownCircle, DollarSign, Percent } from "lucide-react";

const KpiCard = ({ title, value, icon: Icon, trend, colorClass }) => (
  <Card>
    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
      <CardTitle className="text-sm font-medium text-gray-500">
        {title}
      </CardTitle>
      <Icon className={`h-4 w-4 ${colorClass}`} />
    </CardHeader>
    <CardContent>
      <div className="text-2xl font-bold">{value}</div>
      {trend && <p className="text-xs text-muted-foreground mt-1">{trend}</p>}
    </CardContent>
  </Card>
);

const formatCurrency = (val) => new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(val);

const KpiCards = ({ kpis, loading }) => {
  if (loading) return <div className="h-24 bg-gray-100 animate-pulse rounded-lg" />;

  return (
    <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
      <KpiCard 
        title="Receitas Totais" 
        value={formatCurrency(kpis.revenue)} 
        icon={ArrowUpCircle} 
        colorClass="text-green-600"
      />
      <KpiCard 
        title="Despesas Totais" 
        value={formatCurrency(kpis.expenses)} 
        icon={ArrowDownCircle} 
        colorClass="text-red-600"
      />
      <KpiCard 
        title="Resultado" 
        value={formatCurrency(kpis.result)} 
        icon={DollarSign} 
        colorClass={kpis.result >= 0 ? "text-green-600" : "text-red-600"}
      />
      <KpiCard 
        title="Margem" 
        value={`${kpis.margin.toFixed(1)}%`} 
        icon={Percent} 
        colorClass="text-blue-600"
      />
    </div>
  );
};

export default KpiCards;