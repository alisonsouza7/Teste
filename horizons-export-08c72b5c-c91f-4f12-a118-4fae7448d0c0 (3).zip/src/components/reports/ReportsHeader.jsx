import React from 'react';
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Download, RefreshCw } from "lucide-react";

const ReportsHeader = ({ companyName, filters, onChangeFilters, onRefresh, onExport, loading, periodLabel }) => {
  const handleChange = (key, value) => {
    onChangeFilters(prev => ({ ...prev, [key]: value }));
  };

  return (
    <div className="flex flex-col space-y-4 border-b p-6 bg-white rounded-t-2xl">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Relatório Financeiro</h1>
          <p className="text-sm text-gray-500">{companyName} • {periodLabel}</p>
        </div>
        <div className="flex items-center gap-2 no-print">
          <Button variant="outline" size="sm" onClick={onRefresh} disabled={loading}>
            <RefreshCw className={`h-4 w-4 mr-2 ${loading ? 'animate-spin' : ''}`} />
            Atualizar
          </Button>
          <Button variant="default" size="sm" onClick={onExport}>
            <Download className="h-4 w-4 mr-2" />
            Imprimir / PDF
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 p-4 bg-gray-50 rounded-lg no-print">
        <div className="space-y-2">
          <label className="text-xs font-medium text-gray-500">Regime</label>
          <Select 
            value={filters.viewType} 
            onValueChange={(val) => handleChange('viewType', val)}
          >
            <SelectTrigger className="bg-white">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="competencia">Competência</SelectItem>
              <SelectItem value="caixa">Caixa (Realizado)</SelectItem>
            </SelectContent>
          </Select>
        </div>
        
        <div className="space-y-2">
          <label className="text-xs font-medium text-gray-500">Data Início</label>
          <Input 
            type="date" 
            value={filters.startDate} 
            onChange={(e) => handleChange('startDate', e.target.value)}
            className="bg-white"
          />
        </div>

        <div className="space-y-2">
          <label className="text-xs font-medium text-gray-500">Data Fim</label>
          <Input 
            type="date" 
            value={filters.endDate} 
            onChange={(e) => handleChange('endDate', e.target.value)}
            className="bg-white"
          />
        </div>
      </div>
    </div>
  );
};

export default ReportsHeader;