import React from 'react';
import { NavLink } from 'react-router-dom';
import { cn } from '@/lib/utils';
import { 
  LayoutDashboard, 
  Receipt, 
  Wallet, 
  Users, 
  Repeat,
  FileBarChart,
  List,
  CreditCard
} from 'lucide-react';

const TabsMenu = ({ permissions }) => {
  // Ordered: Dashboard, Lançamentos, Contas, Plano de Contas, Clientes/Fornecedores, Recorrências, DRE
  const tabs = [
    { label: 'Dashboard', path: '/cliente/financeiro/painel', icon: LayoutDashboard },
    { label: 'Lançamentos', path: '/cliente/financeiro/lancamentos', icon: Receipt },
    { label: 'Contas', path: '/cliente/financeiro/contas', icon: Wallet },
    { label: 'Cartões', path: '/cliente/financeiro/cartoes', icon: CreditCard, condition: !!permissions?.canUseCreditCards },
    { label: 'Plano de Contas', path: '/cliente/financeiro/plano-contas', icon: List },
    { label: 'Clientes/Fornecedores', path: '/cliente/financeiro/clientes', icon: Users },
    { label: 'Recorrências', path: '/cliente/financeiro/recorrencias', icon: Repeat },
    { label: 'DRE', path: '/cliente/financeiro/dre', icon: FileBarChart },
  ];

  return (
    <div className="w-full">
      <div className="bg-slate-50/80 border border-border/60 rounded-xl shadow-sm p-2">
        <div className="flex flex-wrap items-center gap-2 sm:gap-3 px-1">
        {tabs.map((tab) => {
          if (tab.condition === false) return null;
          return (
            <NavLink
              key={tab.path}
              to={tab.path}
              className={({ isActive }) => cn(
                "flex items-center gap-2 px-3 py-2 text-sm font-medium rounded-full transition-all",
                isActive 
                  ? "bg-primary/10 text-primary shadow-sm" 
                  : "text-muted-foreground hover:text-foreground hover:bg-slate-100"
              )}
            >
              <tab.icon className="h-4 w-4" />
              {tab.label}
            </NavLink>
          );
        })}
        </div>
      </div>
    </div>
  );
};

export default TabsMenu;