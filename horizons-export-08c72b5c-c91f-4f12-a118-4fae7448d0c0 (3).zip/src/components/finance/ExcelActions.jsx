import React, { useState, useRef, useEffect, useMemo } from 'react';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter, DialogDescription } from '@/components/ui/dialog';
import { useToast } from '@/components/ui/use-toast';
import { FileDown, FileUp, Download, AlertTriangle, Loader2, CheckCircle, FileSpreadsheet, Plus, AlertCircle, RefreshCw, Link as LinkIcon } from 'lucide-react';
import { exportToExcel, parseExcelFile, downloadTemplate } from '@/lib/excelUtils';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Command, CommandEmpty, CommandGroup, CommandInput, CommandItem } from '@/components/ui/command';
import { cn } from '@/lib/utils';
import { Check } from 'lucide-react';

const ExcelActions = ({ 
  type, // 'TRANSACTIONS', 'ACCOUNTS', 'CATEGORIES', 'PARTIES'
  dataToExport, 
  onImport, // Async function that receives validated data array
  onValidate, // Async function: (data) => { valid, missingCategories, missingParties, errors }
  onCreateEntity, // Async function: (type, data) => success
  categories = [], // List of existing categories for mapping
  parties = [], // List of existing parties for mapping
  className 
}) => {
  const { toast } = useToast();
  const fileInputRef = useRef(null);
  const [isImportModalOpen, setIsImportModalOpen] = useState(false);
  
  // Status: idle -> parsing -> checking -> resolving -> validating -> uploading -> success -> error
  const [importStatus, setImportStatus] = useState('idle'); 
  const [parsedData, setParsedData] = useState([]);
  const [validationErrors, setValidationErrors] = useState([]);
  const [importSummary, setImportSummary] = useState(null);
  const [missingData, setMissingData] = useState({ categories: [], parties: [] });
  
  // Mappings: { "Imported Name": "Existing ID" }
  const [mappings, setMappings] = useState({ categories: {}, parties: {} });

  // Temporary state for entity creation
  const [creatingEntity, setCreatingEntity] = useState(null); // { type: 'category'|'party', name: '...' }

  const handleExport = () => {
    try {
      exportToExcel(dataToExport, `Exportacao_${type.toLowerCase()}`, type);
      toast({ title: 'Exportação iniciada', description: 'O download do arquivo começará em instantes.' });
    } catch (error) {
      console.error(error);
      toast({ variant: 'destructive', title: 'Erro na exportação', description: 'Não foi possível gerar o arquivo.' });
    }
  };

  const handleTemplateDownload = () => {
    downloadTemplate(type);
  };

  const validateData = async (data) => {
    if (!onValidate) {
        setImportStatus('validating');
        return;
    }

    setImportStatus('checking');
    try {
        const result = await onValidate(data, mappings);
        
        if (result.errors && result.errors.length > 0) {
            setValidationErrors(result.errors.map(e => ({ row: 'N/A', errors: [e] })));
            setImportStatus('error');
            return;
        }

        if ((result.missingCategories && result.missingCategories.length > 0) || 
            (result.missingParties && result.missingParties.length > 0)) {
            setMissingData({
                categories: result.missingCategories || [],
                parties: result.missingParties || []
            });
            setImportStatus('resolving');
        } else {
            setImportStatus('validating');
        }
    } catch (error) {
        console.error("Validation error:", error);
        setValidationErrors([{ row: 'Sistema', errors: ['Erro interno na validação de dados.'] }]);
        setImportStatus('error');
    }
  };

  const onFileChange = async (e) => {
    const file = e.target.files[0];
    if (!file) return;

    setImportStatus('parsing');
    setValidationErrors([]);
    setParsedData([]);
    setMissingData({ categories: [], parties: [] });
    setMappings({ categories: {}, parties: {} });

    try {
      const { data, errors } = await parseExcelFile(file, type);
      
      if (errors.length > 0) {
        setValidationErrors(errors);
        setImportStatus('error');
      } else {
        setParsedData(data);
        // Trigger validation logic if provided
        if (type === 'TRANSACTIONS' && onValidate) {
            validateData(data);
        } else {
            setImportStatus('validating');
        }
      }
    } catch (error) {
      console.error(error);
      setImportStatus('error');
      toast({ variant: 'destructive', title: 'Erro ao ler arquivo', description: 'Verifique se o formato está correto.' });
    }
    
    // Reset input
    e.target.value = '';
  };

  const confirmImport = async () => {
    if (parsedData.length === 0) return;

    setImportStatus('uploading');
    try {
      const result = await onImport(parsedData, mappings);
      setImportSummary(result);
      setImportStatus('success');
      toast({ title: 'Importação concluída', description: 'Os dados foram processados com sucesso.' });
    } catch (error) {
      console.error(error);
      setImportStatus('error');
      toast({ variant: 'destructive', title: 'Erro na importação', description: error.message || 'Falha ao salvar dados.' });
    }
  };

  const resetImport = () => {
    setIsImportModalOpen(false);
    setTimeout(() => {
        setImportStatus('idle');
        setParsedData([]);
        setValidationErrors([]);
        setImportSummary(null);
        setMissingData({ categories: [], parties: [] });
        setMappings({ categories: {}, parties: {} });
    }, 300);
  };

  const handleResolveItem = async (type, name, payload) => {
      setCreatingEntity({ type, name });
      try {
          await onCreateEntity(type, { ...payload, name });
          toast({ title: 'Criado com sucesso', description: `${name} foi adicionado ao sistema.` });
          // Re-validate to update lists
          validateData(parsedData);
      } catch (error) {
          console.error(error);
          toast({ variant: 'destructive', title: 'Erro ao criar', description: error.message || 'Não foi possível criar o item.' });
      } finally {
          setCreatingEntity(null);
      }
  };

  const handleMapItem = (type, name, existingId) => {
      setMappings(prev => ({
          ...prev,
          [type === 'category' ? 'categories' : 'parties']: {
              ...prev[type === 'category' ? 'categories' : 'parties'],
              [name]: existingId
          }
      }));
  };

  useEffect(() => {
    // Whenever mappings change, try to revalidate if we are in resolving state
    if (importStatus === 'resolving') {
        // Debounce slightly to avoid flicker
        const timer = setTimeout(() => {
             validateData(parsedData);
        }, 500);
        return () => clearTimeout(timer);
    }
  }, [mappings]);

  return (
    <div className={`flex gap-2 ${className}`}>
      <Button variant="outline" size="sm" onClick={handleExport} title="Exportar para Excel">
        <FileDown className="w-4 h-4 mr-2" />
        Exportar
      </Button>

      <Dialog open={isImportModalOpen} onOpenChange={(open) => !open && resetImport()}>
        <DialogTrigger asChild>
          <Button variant="outline" size="sm" onClick={() => setIsImportModalOpen(true)} title="Importar do Excel">
            <FileUp className="w-4 h-4 mr-2" />
            Importar
          </Button>
        </DialogTrigger>
        <DialogContent className="sm:max-w-3xl max-h-[90vh] overflow-hidden flex flex-col">
          <DialogHeader>
            <DialogTitle>Importar {type === 'TRANSACTIONS' ? 'Lançamentos' : 
                                  type === 'ACCOUNTS' ? 'Contas' : 
                                  type === 'CATEGORIES' ? 'Categorias' : 
                                  'Contatos'}</DialogTitle>
            <DialogDescription>
              Carregue uma planilha Excel para importar dados em massa.
            </DialogDescription>
          </DialogHeader>

          <div className="py-4 flex-1 overflow-y-auto pr-2">
            {importStatus === 'idle' && (
                <div className="space-y-6">
                    <div className="bg-slate-50 p-6 rounded-lg border border-slate-100 flex flex-col items-center text-center gap-3">
                        <div className="w-12 h-12 bg-blue-100 text-blue-600 rounded-full flex items-center justify-center">
                            <Download className="w-6 h-6" />
                        </div>
                        <div>
                            <h4 className="font-semibold text-slate-900">1. Baixe o modelo padrão</h4>
                            <p className="text-sm text-slate-500">Utilize nossa planilha modelo para garantir que seus dados estejam no formato correto.</p>
                        </div>
                        <Button variant="outline" onClick={handleTemplateDownload} className="mt-2">
                            Baixar Planilha Modelo
                        </Button>
                    </div>
                    
                    <div className="relative">
                        <div className="absolute inset-0 flex items-center"><span className="w-full border-t" /></div>
                        <div className="relative flex justify-center text-xs uppercase"><span className="bg-background px-2 text-muted-foreground">Depois</span></div>
                    </div>

                    <div className="bg-slate-50 p-6 rounded-lg border border-slate-100 flex flex-col items-center text-center gap-3">
                        <div className="w-12 h-12 bg-green-100 text-green-600 rounded-full flex items-center justify-center">
                            <FileSpreadsheet className="w-6 h-6" />
                        </div>
                        <div>
                            <h4 className="font-semibold text-slate-900">2. Envie o arquivo preenchido</h4>
                            <p className="text-sm text-slate-500">Selecione o arquivo Excel (.xlsx) do seu computador.</p>
                        </div>
                        <input 
                            type="file" 
                            accept=".xlsx, .xls" 
                            ref={fileInputRef}
                            className="hidden"
                            onChange={onFileChange}
                        />
                        <Button onClick={() => fileInputRef.current?.click()} className="mt-2 w-full sm:w-auto">
                            Selecionar Arquivo
                        </Button>
                    </div>
                </div>
            )}

            {(importStatus === 'parsing' || importStatus === 'checking') && (
                <div className="flex flex-col items-center justify-center py-12 text-muted-foreground">
                    <Loader2 className="w-10 h-10 animate-spin mb-4 text-blue-600" />
                    <span className="text-lg font-medium">{importStatus === 'parsing' ? 'Lendo arquivo...' : 'Verificando dados...'}</span>
                    <p className="text-sm mt-2">Isso pode levar alguns segundos.</p>
                </div>
            )}

            {importStatus === 'resolving' && (
                <div className="space-y-4">
                    <Alert variant="warning" className="bg-amber-50 border-amber-200 text-amber-900">
                        <AlertCircle className="w-4 h-4 text-amber-600" />
                        <AlertTitle className="text-amber-800">Atenção Necessária</AlertTitle>
                        <AlertDescription className="text-amber-700">
                            Alguns dados no seu arquivo não correspondem ao sistema. Crie novos itens ou vincule a existentes.
                        </AlertDescription>
                    </Alert>

                    {missingData.categories.length > 0 && (
                        <div className="border rounded-lg p-4 space-y-3 bg-white">
                            <h4 className="font-semibold text-sm flex items-center gap-2">
                                <span className="bg-red-100 text-red-700 text-xs px-2 py-0.5 rounded-full">{missingData.categories.length}</span>
                                Categorias não encontradas
                            </h4>
                            <div className="grid gap-2 max-h-60 overflow-y-auto">
                                {missingData.categories.map((catName, idx) => (
                                    <ResolveRow 
                                        key={idx} 
                                        name={catName} 
                                        type="category" 
                                        loading={creatingEntity?.name === catName}
                                        onResolve={(payload) => handleResolveItem('category', catName, payload)} 
                                        existingItems={categories}
                                        onMap={(id) => handleMapItem('category', catName, id)}
                                        mappedId={mappings.categories[catName]}
                                    />
                                ))}
                            </div>
                        </div>
                    )}

                    {missingData.parties.length > 0 && (
                        <div className="border rounded-lg p-4 space-y-3 bg-white">
                            <h4 className="font-semibold text-sm flex items-center gap-2">
                                <span className="bg-red-100 text-red-700 text-xs px-2 py-0.5 rounded-full">{missingData.parties.length}</span>
                                Clientes / Fornecedores não encontrados
                            </h4>
                            <div className="grid gap-2 max-h-60 overflow-y-auto">
                                {missingData.parties.map((partyName, idx) => (
                                    <ResolveRow 
                                        key={idx} 
                                        name={partyName} 
                                        type="party" 
                                        loading={creatingEntity?.name === partyName}
                                        onResolve={(payload) => handleResolveItem('party', partyName, payload)} 
                                        existingItems={parties}
                                        onMap={(id) => handleMapItem('party', partyName, id)}
                                        mappedId={mappings.parties[partyName]}
                                    />
                                ))}
                            </div>
                        </div>
                    )}
                    
                    <div className="flex justify-end pt-2">
                        <Button variant="outline" size="sm" onClick={() => validateData(parsedData)}>
                            <RefreshCw className="w-3 h-3 mr-2" /> Revalidar
                        </Button>
                    </div>
                </div>
            )}

            {importStatus === 'validating' && (
                <div className="space-y-4">
                    <Alert className="bg-green-50 border-green-200">
                        <CheckCircle className="w-4 h-4 text-green-600" />
                        <AlertTitle className="text-green-800">Arquivo Válido</AlertTitle>
                        <AlertDescription className="text-green-700">
                            {parsedData.length} registros prontos para importação. Todos as categorias e contatos foram verificados.
                        </AlertDescription>
                    </Alert>
                    
                    <div className="border rounded-md text-xs bg-slate-50 overflow-hidden">
                        <div className="bg-slate-100 px-3 py-2 border-b font-semibold text-slate-700">Pré-visualização (5 de {parsedData.length})</div>
                        <div className="p-2 space-y-1">
                            {parsedData.slice(0, 5).map((row, i) => (
                                <div key={i} className="grid grid-cols-3 gap-2 p-2 bg-white border rounded shadow-sm">
                                    <div className="col-span-2">
                                        <div className="font-medium truncate" title={row.descricao || 'Sem descrição'}>{row.descricao || 'Sem descrição'}</div>
                                        <div className="text-[10px] text-muted-foreground">{row.data_competencia ? new Date(row.data_competencia).toLocaleDateString('pt-BR') : '-'}</div>
                                    </div>
                                    <div className={`text-right font-medium ${row.tipo === 'receita' ? 'text-green-600' : 'text-red-600'}`}>
                                        {Number(row.valor).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}
                                    </div>
                                </div>
                            ))}
                        </div>
                    </div>
                </div>
            )}

            {importStatus === 'error' && validationErrors.length > 0 && (
                <div className="space-y-4">
                    <Alert variant="destructive">
                        <AlertTriangle className="w-4 h-4" />
                        <AlertTitle>Erros de Validação</AlertTitle>
                        <AlertDescription>
                            Não é possível importar o arquivo. Corrija os erros abaixo.
                        </AlertDescription>
                    </Alert>
                    <ScrollArea className="h-48 rounded border bg-red-50 p-4">
                        {validationErrors.map((err, i) => (
                            <div key={i} className="mb-3 text-sm text-red-800 border-b border-red-100 pb-2 last:border-0">
                                <span className="font-bold flex items-center gap-2">
                                    <AlertCircle className="w-3 h-3" />
                                    {err.row !== 'N/A' && err.row !== 'Sistema' ? `Linha ${err.row}` : 'Erro Geral'}
                                </span>
                                <ul className="list-disc pl-6 mt-1 text-xs space-y-1">
                                    {err.errors.map((e, j) => <li key={j}>{e}</li>)}
                                </ul>
                            </div>
                        ))}
                    </ScrollArea>
                    <div className="flex justify-end">
                        <Button variant="outline" onClick={() => setImportStatus('idle')}>Tentar Novamente</Button>
                    </div>
                </div>
            )}

            {importStatus === 'uploading' && (
                <div className="flex flex-col items-center justify-center py-12 text-blue-600">
                    <Loader2 className="w-10 h-10 animate-spin mb-4" />
                    <span className="text-lg font-medium">Salvando dados no sistema...</span>
                    <p className="text-sm mt-2 text-slate-500">Por favor, não feche esta janela.</p>
                </div>
            )}

            {importStatus === 'success' && (
                <div className="flex flex-col items-center justify-center py-8 text-center space-y-4">
                    <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center animate-in zoom-in duration-300">
                        <CheckCircle className="w-8 h-8 text-green-600" />
                    </div>
                    <div>
                        <h3 className="font-bold text-xl text-slate-900">Importação Concluída!</h3>
                        <p className="text-muted-foreground mt-1">
                            {importSummary?.imported || parsedData.length} registros foram importados com sucesso.
                        </p>
                    </div>
                    
                    {importSummary?.warnings?.length > 0 && (
                        <div className="w-full text-left bg-yellow-50 p-4 rounded-lg text-sm text-yellow-800 border border-yellow-200 mt-4 max-h-40 overflow-y-auto">
                            <p className="font-bold mb-2 flex items-center gap-2">
                                <AlertTriangle className="w-4 h-4" /> Avisos ({importSummary.warnings.length}):
                            </p>
                            <ul className="list-disc pl-4 space-y-1 text-xs">
                                {importSummary.warnings.map((w, i) => <li key={i}>{w}</li>)}
                            </ul>
                        </div>
                    )}
                </div>
            )}
          </div>

          <DialogFooter className="pt-2 border-t mt-auto">
            {importStatus === 'validating' && (
                <>
                    <Button variant="ghost" onClick={resetImport}>Cancelar</Button>
                    <Button onClick={confirmImport} className="bg-green-600 hover:bg-green-700 text-white">
                        Confirmar Importação
                    </Button>
                </>
            )}
            {importStatus === 'resolving' && (
                 <Button variant="ghost" onClick={resetImport} className="text-red-500 hover:text-red-600 hover:bg-red-50">Cancelar Importação</Button>
            )}
            {importStatus === 'success' && (
                <Button onClick={resetImport} className="w-full sm:w-auto">Fechar</Button>
            )}
            {importStatus === 'idle' && (
                 <Button variant="ghost" onClick={() => setIsImportModalOpen(false)}>Cancelar</Button>
            )}
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

// Sub-component for resolving items (Create or Link)
const ResolveRow = ({ name, type, onResolve, loading, existingItems, onMap, mappedId }) => {
    const [mode, setMode] = useState('create'); // 'create' or 'link'
    const [selectedType, setSelectedType] = useState(type === 'category' ? 'despesa' : 'fornecedor'); // Defaults
    const [openCombobox, setOpenCombobox] = useState(false);
    const [documento, setDocumento] = useState(''); // New state for document

    // Filter existing items based on type if possible, or search
    const mappedItemName = useMemo(() => {
        if (!mappedId) return null;
        const item = existingItems.find(i => i.id === mappedId);
        return item ? (type === 'category' ? item.nome_conta : item.nome) : null;
    }, [mappedId, existingItems, type]);

    if (mappedId) {
        return (
            <div className="flex items-center justify-between gap-3 p-3 bg-green-50 border border-green-200 rounded-md text-sm">
                <div className="flex items-center gap-2">
                    <CheckCircle className="w-4 h-4 text-green-600" />
                    <div>
                        <span className="font-medium line-through text-slate-500 mr-2">{name}</span>
                        <span className="text-green-700 font-semibold">→ {mappedItemName}</span>
                    </div>
                </div>
                <Button variant="ghost" size="sm" className="h-6 text-xs" onClick={() => onMap(null)}>
                    Desfazer
                </Button>
            </div>
        );
    }
    
    return (
        <div className="flex flex-col gap-2 p-3 bg-slate-50 border rounded-md text-sm">
            <div className="flex items-center gap-2 overflow-hidden mb-1">
                <Badge variant="outline" className="shrink-0">{type === 'category' ? 'Categoria' : 'Contato'}</Badge>
                <span className="font-medium truncate text-red-600" title={name}>{name}</span>
            </div>

            <div className="flex items-center gap-2">
                 <div className="flex rounded-md bg-white border shadow-sm p-0.5">
                    <button 
                        className={`px-3 py-1 text-xs font-medium rounded-sm transition-colors ${mode === 'create' ? 'bg-slate-100 text-slate-900' : 'text-slate-500 hover:text-slate-900'}`}
                        onClick={() => setMode('create')}
                    >
                        Criar Novo
                    </button>
                    <button 
                        className={`px-3 py-1 text-xs font-medium rounded-sm transition-colors ${mode === 'link' ? 'bg-slate-100 text-slate-900' : 'text-slate-500 hover:text-slate-900'}`}
                        onClick={() => setMode('link')}
                    >
                        Vincular
                    </button>
                 </div>

                 {mode === 'create' ? (
                     <>
                        <div className="w-28">
                            <Select value={selectedType} onValueChange={setSelectedType}>
                                <SelectTrigger className="h-8 text-xs bg-white">
                                    <SelectValue />
                                </SelectTrigger>
                                <SelectContent>
                                    {type === 'category' ? (
                                        <>
                                            <SelectItem value="receita">Receita</SelectItem>
                                            <SelectItem value="despesa">Despesa</SelectItem>
                                            <SelectItem value="custo">Custo</SelectItem>
                                        </>
                                    ) : (
                                        <>
                                            <SelectItem value="cliente">Cliente</SelectItem>
                                            <SelectItem value="fornecedor">Fornecedor</SelectItem>
                                            <SelectItem value="funcionario">Funcionário</SelectItem>
                                        </>
                                    )}
                                </SelectContent>
                            </Select>
                        </div>
                        
                        {type === 'party' && (
                            <div className="w-32">
                                <Input 
                                    placeholder="Doc (Opcional)" 
                                    className="h-8 text-xs bg-white" 
                                    value={documento}
                                    onChange={(e) => setDocumento(e.target.value)}
                                />
                            </div>
                        )}

                        <Button 
                            size="sm" 
                            className="h-8 text-xs"
                            onClick={() => onResolve({ tipo: selectedType, documento })}
                            disabled={loading}
                        >
                            {loading ? <Loader2 className="w-3 h-3 animate-spin" /> : <Plus className="w-3 h-3 mr-1" />}
                            Criar
                        </Button>
                     </>
                 ) : (
                     <div className="flex-1 flex gap-2">
                        <Popover open={openCombobox} onOpenChange={setOpenCombobox}>
                            <PopoverTrigger asChild>
                                <Button
                                    variant="outline"
                                    role="combobox"
                                    aria-expanded={openCombobox}
                                    className="w-full justify-between h-8 text-xs bg-white"
                                >
                                    {mappedId
                                        ? existingItems.find((i) => i.id === mappedId)?.[type === 'category' ? 'nome_conta' : 'nome']
                                        : `Buscar ${type === 'category' ? 'categoria' : 'contato'} existente...`}
                                    <LinkIcon className="ml-2 h-3 w-3 shrink-0 opacity-50" />
                                </Button>
                            </PopoverTrigger>
                            <PopoverContent className="w-[300px] p-0 z-[9999]">
                                <Command>
                                    <CommandInput placeholder="Buscar..." className="h-9" />
                                    <CommandEmpty>Nenhum item encontrado.</CommandEmpty>
                                    <CommandGroup className="max-h-64 overflow-auto">
                                        {existingItems.map((item) => (
                                            <CommandItem
                                                key={item.id}
                                                value={type === 'category' ? item.nome_conta : item.nome}
                                                onSelect={() => {
                                                    onMap(item.id);
                                                    setOpenCombobox(false);
                                                }}
                                                className="text-xs"
                                            >
                                                <Check
                                                    className={cn(
                                                        "mr-2 h-3 w-3",
                                                        mappedId === item.id ? "opacity-100" : "opacity-0"
                                                    )}
                                                />
                                                {type === 'category' ? item.nome_conta : item.nome}
                                            </CommandItem>
                                        ))}
                                    </CommandGroup>
                                </Command>
                            </PopoverContent>
                        </Popover>
                     </div>
                 )}
            </div>
        </div>
    );
}

export default ExcelActions;