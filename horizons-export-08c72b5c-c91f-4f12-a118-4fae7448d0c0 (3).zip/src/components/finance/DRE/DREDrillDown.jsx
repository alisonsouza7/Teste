import React from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { format } from 'date-fns';
import { Badge } from '@/components/ui/badge';

const formatCurrency = (val) => new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(val);

const DREDrillDown = ({ isOpen, onClose, categoryName, transactions }) => {
  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-3xl max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Detalhamento: {categoryName}</DialogTitle>
        </DialogHeader>
        
        <div className="mt-4">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Data</TableHead>
                <TableHead>Descrição</TableHead>
                <TableHead>Conta</TableHead>
                <TableHead>Status</TableHead>
                <TableHead className="text-right">Valor</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {transactions && transactions.length > 0 ? (
                transactions.map((tx) => (
                  <TableRow key={tx.id}>
                    <TableCell className="text-xs">
                        {tx.data_competencia ? format(new Date(tx.data_competencia), 'dd/MM/yyyy') : '-'}
                    </TableCell>
                    <TableCell className="font-medium text-sm">{tx.descricao}</TableCell>
                    <TableCell className="text-xs text-muted-foreground">{tx.finance_accounts?.nome_conta || '-'}</TableCell>
                    <TableCell>
                      <Badge variant={tx.liquidado ? "success" : "outline"} className="text-[10px]">
                        {tx.liquidado ? 'Realizado' : 'Aberto'}
                      </Badge>
                    </TableCell>
                    <TableCell className={`text-right font-semibold ${tx.valor < 0 ? 'text-red-600' : 'text-emerald-600'}`}>
                      {formatCurrency(tx.valor)}
                    </TableCell>
                  </TableRow>
                ))
              ) : (
                <TableRow>
                  <TableCell colSpan={5} className="text-center py-4 text-muted-foreground">
                    Nenhum lançamento encontrado para esta visualização.
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default DREDrillDown;