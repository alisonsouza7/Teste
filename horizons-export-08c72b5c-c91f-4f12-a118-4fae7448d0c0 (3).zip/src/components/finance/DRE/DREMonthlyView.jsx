import React from 'react';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { cn } from '@/lib/utils';

const formatCurrency = (val) => new Intl.NumberFormat('pt-BR', { style: 'decimal', minimumFractionDigits: 0, maximumFractionDigits: 0 }).format(val || 0);

const DREMonthlyView = ({ monthlyData, structure }) => {
  if (!monthlyData || Object.keys(monthlyData).length === 0) return <div className="p-4 text-center text-gray-500">Sem dados para o período.</div>;

  const months = Object.keys(monthlyData).sort(); // ['2024-01', '2024-02'...]

  return (
    <div className="overflow-x-auto">
      <Table className="w-full min-w-[800px]">
        <TableHeader>
          <TableRow>
            <TableHead className="w-[200px] sticky left-0 bg-white z-10 shadow-sm border-r">DRE / Período</TableHead>
            {months.map(m => (
              <TableHead key={m} className="text-right min-w-[100px]">{m}</TableHead>
            ))}
            <TableHead className="text-right min-w-[120px] font-bold">Total</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {structure.map(section => {
            // Calculate Row Total across months
            const rowTotal = months.reduce((acc, m) => acc + (monthlyData[m][section.id] || 0), 0);
            
            return (
              <TableRow 
                key={section.id} 
                className={cn(
                  section.type === 'total' ? 'bg-slate-50 font-bold border-t border-b-2' : 'hover:bg-slate-50/50'
                )}
              >
                <TableCell className={cn(
                  "sticky left-0 bg-white z-10 border-r", 
                  section.type === 'total' && "bg-slate-50"
                )}>
                  {section.label}
                </TableCell>
                {months.map(m => {
                  const val = monthlyData[m][section.id] || 0;
                  return (
                    <TableCell key={m} className={cn(
                      "text-right text-xs",
                      val < 0 && "text-red-600",
                      section.type === 'total' && val > 0 && "text-emerald-700"
                    )}>
                      {val !== 0 ? formatCurrency(val) : '-'}
                    </TableCell>
                  );
                })}
                <TableCell className="text-right font-bold text-xs">
                  {formatCurrency(rowTotal)}
                </TableCell>
              </TableRow>
            );
          })}
        </TableBody>
      </Table>
    </div>
  );
};

export default DREMonthlyView;