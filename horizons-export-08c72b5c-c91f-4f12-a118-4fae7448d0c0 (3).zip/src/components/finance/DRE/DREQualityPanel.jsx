import React from 'react';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { AlertTriangle, CheckCircle2 } from 'lucide-react';

const DREQualityPanel = ({ qualityReport }) => {
  if (!qualityReport) return null;

  const { unlinkedTransactions, unmappedCategories } = qualityReport;
  const hasIssues = unlinkedTransactions > 0 || unmappedCategories > 0;

  if (!hasIssues) return null;

  return (
    <Alert variant="warning" className="mb-6 bg-amber-50 border-amber-200 text-amber-900">
      <AlertTriangle className="h-4 w-4 text-amber-600" />
      <AlertTitle className="text-amber-800 font-semibold ml-2">Atenção aos dados da DRE</AlertTitle>
      <AlertDescription className="text-amber-700 ml-2 mt-1">
        Para garantir a precisão do relatório, verifique os seguintes pontos:
        <ul className="list-disc list-inside mt-2 text-sm space-y-1">
          {unlinkedTransactions > 0 && (
            <li>
              <strong>{unlinkedTransactions} lançamentos</strong> sem categoria vinculada. Eles podem não aparecer nos grupos corretos.
            </li>
          )}
          {unmappedCategories > 0 && (
            <li>
              <strong>{unmappedCategories} categorias</strong> com grupos desconhecidos ou não mapeados na estrutura padrão da DRE.
            </li>
          )}
        </ul>
      </AlertDescription>
    </Alert>
  );
};

export default DREQualityPanel;