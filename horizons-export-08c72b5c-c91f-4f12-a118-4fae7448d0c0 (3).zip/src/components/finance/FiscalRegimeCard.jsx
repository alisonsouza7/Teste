
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { Skeleton } from '@/components/ui/skeleton';
import { 
  AlertTriangle, 
  Building2, 
  RefreshCcw, 
  AlertCircle,
  TrendingUp,
  Info,
  Scale
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { cn } from '@/lib/utils';
import { useTaxRegimes } from '@/hooks/useTaxRegimes';
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";

const FiscalRegimeCard = ({ fiscalData, loading, error, onRetry, className }) => {
  const { getRegimeByCode } = useTaxRegimes();
  
  const formatMoney = (val) => new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(val || 0);

  if (loading) {
    return (
      <Card className={cn("overflow-hidden border shadow-sm", className)}>
        <div className="h-1.5 w-full bg-slate-200 animate-pulse" />
        <CardHeader className="pb-4">
          <div className="flex justify-between items-start">
            <div className="space-y-2">
               <Skeleton className="h-5 w-40" />
               <Skeleton className="h-4 w-60" />
            </div>
            <Skeleton className="h-8 w-8 rounded-lg" />
          </div>
        </CardHeader>
        <CardContent className="space-y-6">
           <Skeleton className="h-24 w-full rounded-lg" />
           <Skeleton className="h-12 w-full" />
        </CardContent>
      </Card>
    );
  }

  if (error) {
    return (
      <Card className={cn("overflow-hidden border-red-200 shadow-sm", className)}>
        <div className="h-1.5 w-full bg-red-200" />
        <CardContent className="pt-8 text-center space-y-4 pb-8">
          <div className="bg-red-50 p-3 rounded-full w-fit mx-auto">
             <AlertCircle className="h-8 w-8 text-red-500" />
          </div>
          <div className="space-y-1">
            <h3 className="font-semibold text-red-900">Erro ao carregar dados</h3>
            <p className="text-sm text-red-600">Não foi possível obter as informações fiscais.</p>
          </div>
          <Button variant="outline" size="sm" onClick={onRetry} className="border-red-200 text-red-700 hover:bg-red-50">
            <RefreshCcw className="h-3 w-3 mr-2" /> Tentar Novamente
          </Button>
        </CardContent>
      </Card>
    );
  }

  if (!fiscalData) return null;

  const { regime_tributario, regime_label, faturamento_12_meses, percentual_utilizado, limite_faturamento_anual } = fiscalData;
  
  const isNearLimit = percentual_utilizado >= 80;
  const isExceeded = percentual_utilizado >= 100;
  
  // Fetch detailed regime info to check if unlimited directly from hook as backup or for descriptions
  const regimeInfo = getRegimeByCode(regime_tributario);
  const isUnlimited = limite_faturamento_anual === null || (regimeInfo && regimeInfo.limite_faturamento === null);

  // Styling based on status
  const statusColor = isExceeded ? 'red' : (isNearLimit ? 'amber' : 'blue');
  const gradientClass = isExceeded 
    ? "from-red-500 to-orange-600" 
    : (isNearLimit ? "from-amber-400 to-orange-500" : "from-blue-500 to-indigo-600");

  return (
    <Card className={cn("overflow-hidden border shadow-md transition-all duration-300 hover:shadow-lg flex flex-col h-full", className)}>
      {/* Top Gradient Bar */}
      <div className={cn("h-1.5 w-full bg-gradient-to-r", gradientClass)} />
      
      <CardHeader className="pb-4">
        <div className="flex items-start justify-between">
            <div className="space-y-1.5">
                <CardTitle className="text-lg font-bold flex items-center gap-2 text-slate-900">
                    <Building2 className="h-5 w-5 text-slate-500" />
                    Regime Tributário
                </CardTitle>
                <CardDescription className="text-slate-500">
                    Monitoramento fiscal e limites.
                </CardDescription>
            </div>
            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Badge variant="outline" className="px-2.5 py-1 text-xs font-semibold uppercase tracking-wide bg-slate-50 text-slate-700 border-slate-200 cursor-help">
                    {regime_label}
                  </Badge>
                </TooltipTrigger>
                <TooltipContent>
                  <p>Código: {regime_tributario}</p>
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>
        </div>
      </CardHeader>

      <CardContent className="flex-1 space-y-5">
        {isUnlimited ? (
            <div className="flex flex-col items-center justify-center h-32 bg-slate-50 rounded-lg border border-dashed border-slate-200 text-center p-4">
                <Scale className="h-8 w-8 text-slate-300 mb-2" />
                <p className="text-sm font-medium text-slate-600">Sem limite definido</p>
                <p className="text-xs text-slate-400 max-w-[180px]">Este regime não possui teto de faturamento mensal cadastrado.</p>
            </div>
        ) : (
            <>
                {/* Main Progress Metric */}
                <div className="bg-slate-50 rounded-lg p-4 border border-slate-100 space-y-3">
                    <div className="flex justify-between items-end mb-1">
                        <div className="flex items-center gap-1.5 text-sm font-medium text-slate-600">
                           <TrendingUp className="h-4 w-4" />
                           Utilização do Limite
                        </div>
                        <span className={cn("text-2xl font-bold tracking-tight", isExceeded ? "text-red-600" : "text-slate-900")}>
                            {percentual_utilizado.toFixed(1)}<span className="text-base font-normal text-slate-400">%</span>
                        </span>
                    </div>
                    
                    <Progress 
                        value={Math.min(percentual_utilizado, 100)} 
                        className={cn("h-3 bg-slate-200")}
                        indicatorClassName={cn(
                            isExceeded ? "bg-red-500" : (isNearLimit ? "bg-amber-500" : "bg-indigo-600")
                        )}
                    />
                    
                    <div className="flex justify-between text-xs text-slate-400 pt-1 font-mono">
                        <span>0%</span>
                        <span>50%</span>
                        <span>100%</span>
                    </div>
                </div>

                {/* Details Grid */}
                <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-1">
                        <span className="text-xs text-slate-500 block">Faturamento (12m)</span>
                        <p className="font-semibold text-slate-900 truncate" title={formatMoney(faturamento_12_meses)}>
                            {formatMoney(faturamento_12_meses)}
                        </p>
                    </div>
                    <div className="space-y-1 text-right">
                         <span className="text-xs text-slate-500 block">Limite Anual</span>
                         <p className="font-semibold text-slate-900 truncate" title={formatMoney(limite_faturamento_anual)}>
                            {formatMoney(limite_faturamento_anual)}
                        </p>
                    </div>
                </div>

                {/* Alert Box */}
                {isNearLimit && (
                    <div className={cn("text-xs p-3 rounded-md flex items-start gap-2.5 border transition-colors", 
                        isExceeded 
                        ? "bg-red-50 text-red-800 border-red-100" 
                        : "bg-amber-50 text-amber-800 border-amber-100"
                    )}>
                        <AlertTriangle className={cn("h-4 w-4 shrink-0 mt-0.5", isExceeded ? "text-red-600" : "text-amber-600")} />
                        <div className="flex-1">
                            <span className="font-semibold block mb-0.5">
                                {isExceeded ? "Limite Excedido" : "Atenção ao Limite"}
                            </span>
                            <span className="opacity-90 leading-relaxed">
                                {isExceeded 
                                    ? "O faturamento ultrapassou o teto permitido. Contate seu contador." 
                                    : "Você está próximo do limite anual. Monitore seu faturamento."}
                            </span>
                        </div>
                    </div>
                )}
            </>
        )}
      </CardContent>
    </Card>
  );
};

export default FiscalRegimeCard;
