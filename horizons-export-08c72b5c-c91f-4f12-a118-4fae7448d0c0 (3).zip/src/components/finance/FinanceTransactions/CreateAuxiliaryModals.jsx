import React, { useState } from 'react';
import { Loader2 } from 'lucide-react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  DialogDescription,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";

// --- Create Category Dialog ---
export const CreateCategoryDialog = ({ isOpen, onClose, onSave, loading }) => {
  const [formData, setFormData] = useState({
    nome_conta: '',
    tipo: 'despesa',
    grupo: 'Outros'
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    onSave(formData);
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>Nova Categoria</DialogTitle>
          <DialogDescription>Crie uma nova categoria para seus lançamentos.</DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4 py-4">
          <div className="space-y-2">
            <Label>Nome da Categoria</Label>
            <Input 
              required 
              value={formData.nome_conta}
              onChange={e => setFormData(prev => ({ ...prev, nome_conta: e.target.value }))}
              placeholder="Ex: Marketing"
            />
          </div>
          <div className="space-y-2">
            <Label>Tipo</Label>
            <RadioGroup 
              value={formData.tipo} 
              onValueChange={val => setFormData(prev => ({ ...prev, tipo: val }))}
              className="flex space-x-4"
            >
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="receita" id="cat-receita" />
                <Label htmlFor="cat-receita">Receita</Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="despesa" id="cat-despesa" />
                <Label htmlFor="cat-despesa">Despesa</Label>
              </div>
            </RadioGroup>
          </div>
          <div className="space-y-2">
            <Label>Grupo</Label>
            <Input 
              value={formData.grupo}
              onChange={e => setFormData(prev => ({ ...prev, grupo: e.target.value }))}
              placeholder="Ex: Despesas Administrativas"
            />
          </div>
          <DialogFooter>
            <Button type="button" variant="outline" onClick={onClose} disabled={loading}>Cancelar</Button>
            <Button type="submit" disabled={loading}>
              {loading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              Criar
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
};

// --- Create Account Dialog ---
export const CreateAccountDialog = ({ isOpen, onClose, onSave, loading }) => {
  const [formData, setFormData] = useState({
    nome_conta: '',
    tipo: 'corrente',
    banco: '',
    saldo_inicial: '0'
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    onSave({
      ...formData,
      saldo_inicial: Number(formData.saldo_inicial) || 0
    });
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>Nova Conta</DialogTitle>
          <DialogDescription>Adicione uma nova conta bancária ou caixa.</DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4 py-4">
          <div className="space-y-2">
            <Label>Nome da Conta</Label>
            <Input 
              required 
              value={formData.nome_conta}
              onChange={e => setFormData(prev => ({ ...prev, nome_conta: e.target.value }))}
              placeholder="Ex: Nubank Principal"
            />
          </div>
          <div className="grid grid-cols-2 gap-4">
             <div className="space-y-2">
              <Label>Tipo</Label>
              <Select value={formData.tipo} onValueChange={val => setFormData(prev => ({ ...prev, tipo: val }))}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="corrente">Conta Corrente</SelectItem>
                  <SelectItem value="poupanca">Poupança</SelectItem>
                  <SelectItem value="caixa">Caixa Físico</SelectItem>
                  <SelectItem value="investimento">Investimento</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Banco (Opcional)</Label>
              <Input 
                value={formData.banco}
                onChange={e => setFormData(prev => ({ ...prev, banco: e.target.value }))}
                placeholder="Ex: Nubank"
              />
            </div>
          </div>
          <div className="space-y-2">
            <Label>Saldo Inicial</Label>
            <Input 
              type="number"
              step="0.01"
              value={formData.saldo_inicial}
              onChange={e => setFormData(prev => ({ ...prev, saldo_inicial: e.target.value }))}
            />
          </div>
          <DialogFooter>
            <Button type="button" variant="outline" onClick={onClose} disabled={loading}>Cancelar</Button>
            <Button type="submit" disabled={loading}>
              {loading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              Criar
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
};

// --- Create Party Dialog ---
export const CreatePartyDialog = ({ isOpen, onClose, onSave, loading }) => {
  const [formData, setFormData] = useState({
    nome: '',
    tipo: 'cliente',
    documento: ''
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    onSave(formData);
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>Novo Contato</DialogTitle>
          <DialogDescription>Cadastre um novo cliente ou fornecedor.</DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4 py-4">
          <div className="space-y-2">
            <Label>Nome</Label>
            <Input 
              required 
              value={formData.nome}
              onChange={e => setFormData(prev => ({ ...prev, nome: e.target.value }))}
              placeholder="Ex: Empresa X Ltda"
            />
          </div>
          <div className="grid grid-cols-2 gap-4">
             <div className="space-y-2">
              <Label>Tipo</Label>
              <Select value={formData.tipo} onValueChange={val => setFormData(prev => ({ ...prev, tipo: val }))}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="cliente">Cliente</SelectItem>
                  <SelectItem value="fornecedor">Fornecedor</SelectItem>
                  <SelectItem value="funcionario">Funcionário</SelectItem>
                  <SelectItem value="outro">Outro</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>CPF/CNPJ</Label>
              <Input 
                value={formData.documento}
                onChange={e => setFormData(prev => ({ ...prev, documento: e.target.value }))}
                placeholder="Apenas números"
              />
            </div>
          </div>
          <DialogFooter>
            <Button type="button" variant="outline" onClick={onClose} disabled={loading}>Cancelar</Button>
            <Button type="submit" disabled={loading}>
              {loading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              Criar
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
};