import React, { useState, useEffect, useMemo, useRef } from 'react';
import { format } from 'date-fns';
import { Loader2, Save, Repeat, Info, Plus, Check, ChevronsUpDown } from 'lucide-react';
import { supabase } from '@/lib/customSupabaseClient';

import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  DialogDescription,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

import {
  Command,
  CommandEmpty,
  CommandGroup,
  CommandInput,
  CommandItem,
  CommandList,
  CommandSeparator,
} from "@/components/ui/command";

import { Switch } from "@/components/ui/switch";
import { cn } from "@/lib/utils";
import {
  CreateCategoryDialog,
  CreateAccountDialog,
  CreatePartyDialog
} from './CreateAuxiliaryModals';

// ✅ IMPORTANT: usar Radix Popover direto (SEM Portal)
import * as PopoverPrimitive from "@radix-ui/react-popover";

const today = () => format(new Date(), 'yyyy-MM-dd');

const typeStyle = (tipo) => {
  if (tipo === 'receita') return { text: 'text-emerald-600', bg: 'bg-emerald-50', border: 'border-emerald-200' };
  if (tipo === 'despesa') return { text: 'text-red-600', bg: 'bg-red-50', border: 'border-red-200' };
  if (tipo === 'transferencia') return { text: 'text-amber-700', bg: 'bg-amber-50', border: 'border-amber-200' };
  return { text: 'text-slate-700', bg: 'bg-slate-50', border: 'border-slate-200' };
};

const PopoverInline = ({ open, onOpenChange, trigger, content, contentClassName }) => {
  return (
    <PopoverPrimitive.Root open={open} onOpenChange={onOpenChange}>
      <PopoverPrimitive.Trigger asChild>
        {trigger}
      </PopoverPrimitive.Trigger>

      {/* ✅ SEM Portal: content renderiza aqui mesmo */}
      <PopoverPrimitive.Content
        side="bottom"
        align="start"
        sideOffset={6}
        className={cn(
          "z-50 rounded-md border bg-popover text-popover-foreground shadow-md outline-none",
          "data-[state=open]:animate-in data-[state=closed]:animate-out",
          "data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0",
          "data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95",
          "data-[side=bottom]:slide-in-from-top-2 data-[side=top]:slide-in-from-bottom-2",
          contentClassName
        )}
        // impede Radix de tentar “auto focar” coisa errada
        onOpenAutoFocus={(e) => e.preventDefault()}
        onCloseAutoFocus={(e) => e.preventDefault()}
        // evita fechar por clique fora enquanto digita/rola
        onInteractOutside={(e) => {
          // deixa fechar clicando fora, mas não deixe eventos estranhos de foco atrapalharem
          // (mantém padrão, sem preventDefault total)
        }}
      >
        {content}
      </PopoverPrimitive.Content>
    </PopoverPrimitive.Root>
  );
};

const TransactionEditModal = ({
  isOpen,
  onClose,
  transaction,
  accounts = [],
  categories = [],
  parties = [],
  onSave,
  onCreate,
  auxHandlers = {},
  loading = false
}) => {
  const isEdit = !!transaction;

  const [showCatModal, setShowCatModal] = useState(false);
  const [showAccModal, setShowAccModal] = useState(false);
  const [showPartyModal, setShowPartyModal] = useState(false);
  const [auxLoading, setAuxLoading] = useState(false);

  const [partyPopoverOpen, setPartyPopoverOpen] = useState(false);
  const [catPopoverOpen, setCatPopoverOpen] = useState(false);
  const [accPopoverOpen, setAccPopoverOpen] = useState(false);

  const [partySearch, setPartySearch] = useState('');
  const [catSearch, setCatSearch] = useState('');
  const [accSearch, setAccSearch] = useState('');

  // ✅ ids reais pra focar (ref do CommandInput às vezes não resolve por causa do wrapper)
  const partySearchId = "party-search-input";
  const catSearchId = "cat-search-input";
  const accSearchId = "acc-search-input";

  const initialForm = useMemo(() => {
    const baseDate = today();

    return {
      descricao: transaction?.descricao || '',
      valor:
        transaction?.valor !== undefined && transaction?.valor !== null
          ? String(Math.abs(Number(transaction.valor)) || '')
          : '',
      tipo: transaction?.tipo || 'despesa',

      conta_id: transaction?.conta_id || '',

      conta_origem_id: '',
      conta_destino_id: '',

      categoria_id: transaction?.categoria_id || '',
      party_id: transaction?.party_id || '',
      data_competencia: transaction?.data_competencia || baseDate,
      vencimento: transaction?.vencimento || (transaction?.data_competencia || baseDate),
      liquidado: !!transaction?.liquidado,
      data_liquidacao: transaction?.data_liquidacao || '',

      is_recurring: !!transaction?.recurrence_id,
      recurrence_frequency: 'mensal',
      recurrence_start_date: baseDate,
      recurrence_end_date: '',
      recurrence_installments: ''
    };
  }, [transaction]);

  const [formData, setFormData] = useState(initialForm);

  useEffect(() => {
    setFormData(initialForm);
  }, [initialForm]);

  useEffect(() => {
    if (isEdit && transaction?.tipo === 'transferencia' && transaction?.transfer_group_id) {
      const fetchPeer = async () => {
        const { data, error } = await supabase
          .from('finance_transactions')
          .select('id, conta_id, valor')
          .eq('transfer_group_id', transaction.transfer_group_id)
          .neq('id', transaction.id)
          .single();

        if (!error && data) {
          if (transaction.valor < 0) {
            setFormData(prev => ({
              ...prev,
              conta_origem_id: transaction.conta_id,
              conta_destino_id: data.conta_id
            }));
          } else {
            setFormData(prev => ({
              ...prev,
              conta_origem_id: data.conta_id,
              conta_destino_id: transaction.conta_id
            }));
          }
        }
      };
      fetchPeer();
    }
  }, [isEdit, transaction]);

  const styles = typeStyle(formData.tipo);

  const handleChange = (key, value) => {
    setFormData(prev => ({ ...prev, [key]: value }));
  };

  const handleCreateCategory = async (data) => {
    if (!auxHandlers.createCategory) return;
    setAuxLoading(true);
    try {
      const newCat = await auxHandlers.createCategory(data);
      if (newCat) {
        setFormData(prev => ({ ...prev, categoria_id: newCat.id }));
        setShowCatModal(false);
      }
    } catch (e) { console.error(e); }
    setAuxLoading(false);
  };

  const handleCreateAccount = async (data) => {
    if (!auxHandlers.createAccount) return;
    setAuxLoading(true);
    try {
      const newAcc = await auxHandlers.createAccount(data);
      if (newAcc) {
        if (formData.tipo !== 'transferencia') {
          setFormData(prev => ({ ...prev, conta_id: newAcc.id }));
        }
        setShowAccModal(false);
      }
    } catch (e) { console.error(e); }
    setAuxLoading(false);
  };

  const handleCreateParty = async (data) => {
    if (!auxHandlers.createParty) return;
    setAuxLoading(true);
    try {
      const newParty = await auxHandlers.createParty(data);
      if (newParty) {
        setFormData(prev => ({ ...prev, party_id: newParty.id }));
        setShowPartyModal(false);
        setPartyPopoverOpen(false);
      }
    } catch (e) { console.error(e); }
    setAuxLoading(false);
  };

  const filteredParties = useMemo(() => {
    if (!partySearch) return parties;
    const term = partySearch.toLowerCase();
    return parties.filter(p =>
      (`${p.nome} ${p.documento || ''}`).toLowerCase().includes(term)
    );
  }, [parties, partySearch]);

  const filteredCategories = useMemo(() => {
    const tipo = formData.tipo;
    if (tipo === 'receita') return categories.filter(c => c.tipo === 'receita');
    if (tipo === 'despesa') return categories.filter(c => c.tipo === 'despesa');
    if (tipo === 'transferencia') return categories.filter(c => c.tipo === 'transferencia');
    return categories;
  }, [categories, formData.tipo]);

  const categoriesByGroup = useMemo(() => {
    const term = (catSearch || '').toLowerCase();
    const base = term
      ? filteredCategories.filter(cat => (cat.nome_conta || '').toLowerCase().includes(term))
      : filteredCategories;

    const map = new Map();
    const sorted = [...base].sort((a, b) => (a.nome_conta || '').localeCompare(b.nome_conta || '', 'pt-BR'));
    sorted.forEach((cat) => {
      const key = (cat.grupo || 'Sem grupo').trim();
      if (!map.has(key)) map.set(key, []);
      map.get(key).push(cat);
    });
    return Array.from(map.entries());
  }, [filteredCategories, catSearch]);

  const filteredAccounts = useMemo(() => {
    const tipo = formData.tipo;
    if (tipo === 'receita' || tipo === 'transferencia') {
      return accounts.filter(a => a.tipo !== 'cartao_credito');
    }
    return accounts;
  }, [accounts, formData.tipo]);

  const bankAccounts = useMemo(
    () => filteredAccounts.filter(a => a.tipo !== 'cartao_credito'),
    [filteredAccounts]
  );

  const visibleAccounts = useMemo(() => {
    if (!accSearch) return filteredAccounts;
    const term = accSearch.toLowerCase();
    return filteredAccounts.filter(a => (a.nome_conta || '').toLowerCase().includes(term));
  }, [filteredAccounts, accSearch]);
  const accountTypeLabel = (t) => {
    if (t === 'corrente') return 'Conta Corrente';
    if (t === 'poupanca') return 'Poupança';
    if (t === 'cartao_credito') return 'Cartão de Crédito';
    if (t === 'carteira') return 'Carteira';
    if (t === 'investimento') return 'Investimento';
    return (t || 'Outro').replace(/_/g, ' ').replace(/\b\w/g, (c) => c.toUpperCase());
  };
  const accountsByType = useMemo(() => {
    const groups = new Map();
    const sorted = [...visibleAccounts].sort((a, b) => (a.nome_conta || '').localeCompare(b.nome_conta || '', 'pt-BR'));
    sorted.forEach((acc) => {
      const key = acc.tipo || 'outro';
      if (!groups.has(key)) groups.set(key, []);
      groups.get(key).push(acc);
    });
    const weight = (t) => {
      if (t === 'corrente') return 1;
      if (t === 'carteira') return 2;
      if (t === 'poupanca') return 3;
      if (t === 'investimento') return 4;
      if (t === 'cartao_credito') return 5;
      return 99;
    };
    return Array.from(groups.entries()).sort((a, b) => weight(a[0]) - weight(b[0]));
  }, [visibleAccounts]);

  // ✅ foco garantido quando abrir (não depende de ref)
  useEffect(() => {
    if (partyPopoverOpen) setTimeout(() => document.getElementById(partySearchId)?.focus(), 0);
    else setPartySearch('');
  }, [partyPopoverOpen]);

  useEffect(() => {
    if (catPopoverOpen) setTimeout(() => document.getElementById(catSearchId)?.focus(), 0);
    else setCatSearch('');
  }, [catPopoverOpen]);

  useEffect(() => {
    if (accPopoverOpen) setTimeout(() => document.getElementById(accSearchId)?.focus(), 0);
    else setAccSearch('');
  }, [accPopoverOpen]);

  const stopKeys = (e) => {
    // ✅ impede o Dialog de “capturar” teclas e tentar realocar foco
    e.stopPropagation();
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (formData.is_recurring) {
      if (!formData.recurrence_frequency) { alert("Selecione a frequência."); return; }
      if (!formData.recurrence_start_date) { alert("Defina o início da recorrência."); return; }
      if (formData.recurrence_end_date && formData.recurrence_end_date < formData.recurrence_start_date) {
        alert("Data final inválida."); return;
      }
    }

    if (formData.tipo === 'transferencia') {
      if (!formData.conta_origem_id || !formData.conta_destino_id) {
        alert("Selecione as contas de origem e destino.");
        return;
      }
      if (formData.conta_origem_id === formData.conta_destino_id) {
        alert("As contas de origem e destino devem ser diferentes.");
        return;
      }
    } else {
      if (!formData.conta_id) { alert("Selecione uma conta."); return; }
      if (!formData.categoria_id) { alert("Selecione uma categoria."); return; }
    }

    const parsed = Number(String(formData.valor).replace(',', '.'));
    const absValor = isNaN(parsed) ? 0 : Math.abs(parsed);

    const payload = {
      ...formData,
      valor: absValor,
      vencimento: formData.vencimento || formData.data_competencia,
      party_id: formData.party_id || null
    };

    if (formData.tipo !== 'transferencia') {
      const selectedAcc = accounts.find(a => a.id === formData.conta_id);
      if (selectedAcc?.tipo === 'cartao_credito') {
        payload.origem = 'cartao_credito';
      } else {
        payload.origem = null;
      }
    }

    if (payload.liquidado && !payload.data_liquidacao) payload.data_liquidacao = today();
    if (!payload.liquidado) payload.data_liquidacao = null;

    if (!payload.is_recurring) {
      delete payload.recurrence_frequency;
      delete payload.recurrence_start_date;
      delete payload.recurrence_end_date;
      delete payload.recurrence_installments;
    }

    if (isEdit) {
      await onSave?.(transaction.id, payload);
    } else {
      await onCreate?.(payload);
    }
  };

  return (
    <>
      <Dialog open={isOpen} onOpenChange={(open) => !open && onClose()}>
        <DialogContent className="sm:max-w-[640px] max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{isEdit ? 'Editar Lançamento' : 'Novo Lançamento'}</DialogTitle>
            <DialogDescription>
              {isEdit ? 'Atualize os detalhes do lançamento abaixo.' : 'Preencha os dados para criar um novo lançamento.'}
            </DialogDescription>
          </DialogHeader>

          <form onSubmit={handleSubmit} className="space-y-4 py-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="tipo">Tipo</Label>
                <Select value={formData.tipo} onValueChange={(val) => handleChange('tipo', val)}>
                  <SelectTrigger id="tipo" className={cn("font-medium bg-white", styles.text, styles.bg, styles.border)}>
                    <SelectValue placeholder="Selecione o tipo" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="receita" className="text-emerald-600 font-medium">Receita</SelectItem>
                    <SelectItem value="despesa" className="text-red-600 font-medium">Despesa</SelectItem>
                    <SelectItem value="transferencia" className="text-amber-700 font-medium">Transferência</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="valor">Valor (R$)</Label>
                <Input
                  id="valor"
                  type="number"
                  step="0.01"
                  min="0"
                  required
                  value={formData.valor}
                  onChange={(e) => handleChange('valor', e.target.value)}
                  className={cn("font-bold bg-white", styles.text)}
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="descricao">Descrição</Label>
              <Input
                id="descricao"
                required
                value={formData.descricao}
                onChange={(e) => handleChange('descricao', e.target.value)}
                placeholder="Ex: Pagamento de fornecedor"
                className="bg-white"
              />
            </div>

            {formData.tipo === 'transferencia' ? (
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="conta_origem">Conta de Origem (Saiu)</Label>
                  <Select
                    value={formData.conta_origem_id || ''}
                    onValueChange={(val) => {
                      if (val === 'new') setShowAccModal(true);
                      else handleChange('conta_origem_id', val);
                    }}
                  >
                    <SelectTrigger className="bg-white border-red-200">
                      <SelectValue placeholder="Selecione..." />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="new" className="text-primary font-medium focus:bg-primary/5 focus:text-primary">
                        <div className="flex items-center gap-2">
                          <Plus className="h-4 w-4" /> Criar nova conta
                        </div>
                      </SelectItem>
                      {bankAccounts.map(acc => (
                        <SelectItem key={acc.id} value={acc.id}>{acc.nome_conta}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="conta_destino">Conta de Destino (Entrou)</Label>
                  <Select
                    value={formData.conta_destino_id || ''}
                    onValueChange={(val) => {
                      if (val === 'new') setShowAccModal(true);
                      else handleChange('conta_destino_id', val);
                    }}
                  >
                    <SelectTrigger className="bg-white border-emerald-200">
                      <SelectValue placeholder="Selecione..." />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="new" className="text-primary font-medium focus:bg-primary/5 focus:text-primary">
                        <div className="flex items-center gap-2">
                          <Plus className="h-4 w-4" /> Criar nova conta
                        </div>
                      </SelectItem>
                      {bankAccounts.map(acc => (
                        <SelectItem key={acc.id} value={acc.id}>{acc.nome_conta}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
            ) : (
              <>
                {/* PARTY */}
                <div className="space-y-2">
                  <Label htmlFor="party_id">
                    {formData.tipo === 'receita' ? 'Cliente' : 'Fornecedor'}
                  </Label>

                  <PopoverInline
                    open={partyPopoverOpen}
                    onOpenChange={setPartyPopoverOpen}
                    trigger={
                      <Button
                        type="button"
                        variant="outline"
                        role="combobox"
                        aria-expanded={partyPopoverOpen}
                        className={cn("w-full justify-between bg-white", styles.border, !formData.party_id && "text-muted-foreground")}
                      >
                        {formData.party_id
                          ? parties.find((party) => party.id === formData.party_id)?.nome
                          : `Selecione ${formData.tipo === 'receita' ? 'o cliente' : 'o fornecedor'}...`}
                        <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
                      </Button>
                    }
                    contentClassName="w-[420px] p-0"
                    content={
                      <Command onKeyDown={stopKeys}>
                        <CommandInput
                          id={partySearchId}
                          placeholder="Buscar cliente/fornecedor..."
                          value={partySearch}
                          onValueChange={setPartySearch}
                          onKeyDown={stopKeys}
                          onKeyDownCapture={stopKeys}
                        />
                        <CommandList>
                          <CommandEmpty>Nenhum encontrado.</CommandEmpty>

                          <CommandGroup>
                            {filteredParties.map((party) => (
                              <CommandItem
                                key={party.id}
                                value={`${party.nome} ${party.documento || ''}`}
                                onSelect={() => {
                                  handleChange('party_id', party.id === formData.party_id ? "" : party.id);
                                  setPartyPopoverOpen(false);
                                }}
                              >
                                <Check
                                  className={cn(
                                    "mr-2 h-4 w-4",
                                    formData.party_id === party.id ? "opacity-100" : "opacity-0"
                                  )}
                                />
                                <div className="flex flex-col">
                                  <span>{party.nome}</span>
                                  {party.documento && <span className="text-xs text-muted-foreground">{party.documento}</span>}
                                </div>
                              </CommandItem>
                            ))}
                          </CommandGroup>

                          <CommandSeparator />

                          <CommandGroup>
                            <CommandItem
                              onSelect={() => {
                                setPartyPopoverOpen(false);
                                setShowPartyModal(true);
                              }}
                              className="cursor-pointer text-primary font-medium"
                            >
                              <Plus className="mr-2 h-4 w-4" />
                              {formData.tipo === 'receita' ? 'Criar novo cliente' : 'Criar novo fornecedor'}
                            </CommandItem>
                          </CommandGroup>
                        </CommandList>
                      </Command>
                    }
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  {/* CATEGORIA */}
                  <div className="space-y-2">
                    <Label htmlFor="categoria">Categoria</Label>

                    <PopoverInline
                      open={catPopoverOpen}
                      onOpenChange={setCatPopoverOpen}
                      trigger={
                        <Button
                          type="button"
                          variant="outline"
                          role="combobox"
                          aria-expanded={catPopoverOpen}
                          className={cn("w-full justify-between bg-white", styles.border, !formData.categoria_id && "text-muted-foreground")}
                        >
                          {formData.categoria_id
                            ? categories.find((cat) => cat.id === formData.categoria_id)?.nome_conta
                            : "Selecione..."}
                          <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
                        </Button>
                      }
                      contentClassName="w-[340px] p-0"
                      content={
                        <Command onKeyDown={stopKeys}>
                          <CommandInput
                            id={catSearchId}
                            placeholder="Buscar categoria..."
                            value={catSearch}
                            onValueChange={setCatSearch}
                            onKeyDown={stopKeys}
                            onKeyDownCapture={stopKeys}
                          />
                          <CommandList>
                            <CommandEmpty>Nenhuma categoria encontrada.</CommandEmpty>

                            {categoriesByGroup.map(([groupName, cats]) => (
                              <CommandGroup key={groupName} heading={groupName} className="text-[11px] uppercase tracking-wide">
                                {cats.map((cat) => (
                                  <CommandItem
                                    key={cat.id}
                                    value={cat.nome_conta}
                                    onSelect={() => {
                                      handleChange('categoria_id', cat.id === formData.categoria_id ? "" : cat.id);
                                      setCatPopoverOpen(false);
                                    }}
                                    className="text-sm normal-case"
                                  >
                                    <Check
                                      className={cn(
                                        "mr-2 h-4 w-4",
                                        formData.categoria_id === cat.id ? "opacity-100" : "opacity-0"
                                      )}
                                    />
                                    {cat.nome_conta}
                                  </CommandItem>
                                ))}
                              </CommandGroup>
                            ))}

                            <CommandSeparator />

                            <CommandGroup>
                              <CommandItem
                                onSelect={() => {
                                  setCatPopoverOpen(false);
                                  setShowCatModal(true);
                                }}
                                className="cursor-pointer text-primary font-medium"
                              >
                                <Plus className="mr-2 h-4 w-4" /> Criar nova categoria
                              </CommandItem>
                            </CommandGroup>
                          </CommandList>
                        </Command>
                      }
                    />
                  </div>

                  {/* CONTA */}
                  <div className="space-y-2">
                    <Label htmlFor="conta">Conta</Label>

                    <PopoverInline
                      open={accPopoverOpen}
                      onOpenChange={setAccPopoverOpen}
                      trigger={
                        <Button
                          type="button"
                          variant="outline"
                          role="combobox"
                          aria-expanded={accPopoverOpen}
                          className={cn("w-full justify-between bg-white", styles.border, !formData.conta_id && "text-muted-foreground")}
                        >
                          {formData.conta_id
                            ? accounts.find((acc) => acc.id === formData.conta_id)?.nome_conta
                            : "Selecione..."}
                          <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
                        </Button>
                      }
                      contentClassName="w-[340px] p-0"
                      content={
                        <Command onKeyDown={stopKeys}>
                          <CommandInput
                            id={accSearchId}
                            placeholder="Buscar conta..."
                            value={accSearch}
                            onValueChange={setAccSearch}
                            onKeyDown={stopKeys}
                            onKeyDownCapture={stopKeys}
                          />
                          <CommandList>
                            <CommandEmpty>Nenhuma conta encontrada.</CommandEmpty>

                            {accountsByType.map(([tipo, list]) => (
                              <CommandGroup key={tipo} heading={accountTypeLabel(tipo)}>
                                {list.map((acc) => (
                                  <CommandItem
                                    key={acc.id}
                                    value={acc.nome_conta}
                                    onSelect={() => {
                                      handleChange('conta_id', acc.id === formData.conta_id ? "" : acc.id);
                                      setAccPopoverOpen(false);
                                    }}
                                  >
                                    <Check
                                      className={cn(
                                        "mr-2 h-4 w-4",
                                        formData.conta_id === acc.id ? "opacity-100" : "opacity-0"
                                      )}
                                    />
                                    {acc.nome_conta}
                                  </CommandItem>
                                ))}
                              </CommandGroup>
                            ))}

                            <CommandSeparator />

                            <CommandGroup>
                              <CommandItem
                                onSelect={() => {
                                  setAccPopoverOpen(false);
                                  setShowAccModal(true);
                                }}
                                className="cursor-pointer text-primary font-medium"
                              >
                                <Plus className="mr-2 h-4 w-4" /> Criar nova conta
                              </CommandItem>
                            </CommandGroup>
                          </CommandList>
                        </Command>
                      }
                    />
                  </div>
                </div>
              </>
            )}

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="data_competencia">Data de Competência</Label>
                <Input
                  id="data_competencia"
                  type="date"
                  required
                  value={formData.data_competencia}
                  onChange={(e) => handleChange('data_competencia', e.target.value)}
                  className="bg-white"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="vencimento">Data de Vencimento</Label>
                <Input
                  id="vencimento"
                  type="date"
                  value={formData.vencimento}
                  onChange={(e) => handleChange('vencimento', e.target.value)}
                  className="bg-white"
                />
              </div>
            </div>

            <div className="flex items-center space-x-2 pt-2">
              <Switch
                id="liquidado"
                checked={formData.liquidado}
                onCheckedChange={(checked) => handleChange('liquidado', checked)}
              />
              <Label htmlFor="liquidado" className="cursor-pointer">
                {formData.liquidado ? 'Lançamento Liquidado (Pago/Recebido)' : 'Lançamento em Aberto'}
              </Label>
            </div>

            {formData.liquidado && (
              <div className="space-y-2 animate-in fade-in duration-300">
                <Label htmlFor="data_liquidacao">Data da Liquidação</Label>
                <Input
                  id="data_liquidacao"
                  type="date"
                  value={formData.data_liquidacao || ''}
                  onChange={(e) => handleChange('data_liquidacao', e.target.value)}
                  className="bg-white"
                />
              </div>
            )}

            <div className="pt-2 border-t mt-4">
              <div className="flex items-center space-x-2 mb-4">
                <Switch
                  id="recurrence"
                  checked={formData.is_recurring}
                  onCheckedChange={(checked) => handleChange('is_recurring', checked)}
                  className="data-[state=checked]:bg-amber-500"
                />
                <Label htmlFor="recurrence" className="cursor-pointer font-medium text-amber-700 flex items-center gap-2">
                  <Repeat className="h-4 w-4" />
                  É uma transação recorrente?
                </Label>
              </div>

              {formData.is_recurring && (
                <div className="bg-amber-50 border border-amber-200 rounded-md p-4 space-y-4 animate-in slide-in-from-top-2 duration-300">
                  <div className="flex items-start gap-2 text-xs text-amber-800 bg-amber-100/50 p-2 rounded">
                    <Info className="h-4 w-4 flex-shrink-0 mt-0.5" />
                    <p>
                      Ao salvar, este lançamento se tornará um modelo. O sistema irá gerar automaticamente os lançamentos futuros com base na frequência escolhida.
                    </p>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="recurrence_frequency" className="text-amber-900">Frequência</Label>
                      <Select
                        value={formData.recurrence_frequency}
                        onValueChange={(val) => handleChange('recurrence_frequency', val)}
                      >
                        <SelectTrigger id="recurrence_frequency" className="bg-white border-amber-200">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="mensal">Mensal</SelectItem>
                          <SelectItem value="bimestral">Bimestral</SelectItem>
                          <SelectItem value="trimestral">Trimestral</SelectItem>
                          <SelectItem value="semestral">Semestral</SelectItem>
                          <SelectItem value="anual">Anual</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="recurrence_start_date" className="text-amber-900">Início da Recorrência</Label>
                      <Input
                        id="recurrence_start_date"
                        type="date"
                        required
                        className="bg-white border-amber-200"
                        value={formData.recurrence_start_date}
                        onChange={(e) => handleChange('recurrence_start_date', e.target.value)}
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="recurrence_end_date" className="text-amber-900">Data Final (Opcional)</Label>
                      <Input
                        id="recurrence_end_date"
                        type="date"
                        className="bg-white border-amber-200"
                        value={formData.recurrence_end_date}
                        onChange={(e) => handleChange('recurrence_end_date', e.target.value)}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="recurrence_installments" className="text-amber-900">Nº de Parcelas (Opcional)</Label>
                      <Input
                        id="recurrence_installments"
                        type="number"
                        min="1"
                        placeholder="Ex: 12"
                        className="bg-white border-amber-200"
                        value={formData.recurrence_installments}
                        onChange={(e) => handleChange('recurrence_installments', e.target.value)}
                      />
                    </div>
                  </div>
                </div>
              )}
            </div>

            <DialogFooter className="gap-2 sm:gap-0 mt-6">
              <Button type="button" variant="outline" onClick={onClose} disabled={loading}>
                Cancelar
              </Button>
              <Button type="submit" disabled={loading}>
                {loading ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Salvando...
                  </>
                ) : (
                  <>
                    <Save className="mr-2 h-4 w-4" />
                    {isEdit ? 'Salvar Alterações' : 'Criar Lançamento'}
                  </>
                )}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      <CreateCategoryDialog
        isOpen={showCatModal}
        onClose={() => setShowCatModal(false)}
        onSave={handleCreateCategory}
        loading={auxLoading}
      />
      <CreateAccountDialog
        isOpen={showAccModal}
        onClose={() => setShowAccModal(false)}
        onSave={handleCreateAccount}
        loading={auxLoading}
      />
      <CreatePartyDialog
        isOpen={showPartyModal}
        onClose={() => setShowPartyModal(false)}
        onSave={handleCreateParty}
        loading={auxLoading}
      />
    </>
  );
};

export default TransactionEditModal;