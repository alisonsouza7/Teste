import React from 'react';
import { Search, Filter, X } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { Card, CardContent } from '@/components/ui/card';

const TransactionFilters = ({
  filters,
  onFilterChange,
  onReset,
  categories = [],
  accounts = []
}) => {
  // Count active filters to show badge
  const activeFiltersCount = [
    filters.startDate,
    filters.endDate,
    filters.status !== 'all',
    filters.categoryId !== 'all',
    filters.accountId !== 'all',
    filters.type !== 'all'
  ].filter(Boolean).length;

  return (
    <Card className="mb-6 shadow-sm border-slate-200">
      <CardContent className="p-4 space-y-4">
        {/* Top Row: Search & Count */}
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div className="relative w-full md:max-w-sm">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Buscar por descrição..."
              value={filters.search}
              onChange={(e) => onFilterChange('search', e.target.value)}
              className="pl-9 bg-white whitespace-normal break-words"
            />
          </div>
          
          <div className="flex items-center gap-2">
            {activeFiltersCount > 0 && (
              <Badge variant="secondary" className="px-2 py-1">
                {activeFiltersCount} filtros ativos
              </Badge>
            )}
            <Button 
              variant="ghost" 
              size="sm" 
              onClick={onReset}
              disabled={activeFiltersCount === 0 && !filters.search}
              className="text-muted-foreground hover:text-destructive"
            >
              <X className="mr-2 h-4 w-4" />
              Limpar
            </Button>
          </div>
        </div>

        <Separator />

        {/* Filters Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-6 gap-4">
          
          {/* Date Start */}
          <div className="space-y-1.5">
            <Label className="text-xs text-muted-foreground">De</Label>
            <Input 
              type="date" 
              value={filters.startDate}
              onChange={(e) => onFilterChange('startDate', e.target.value)}
              className="bg-white whitespace-normal break-words"
            />
          </div>

          {/* Date End */}
          <div className="space-y-1.5">
            <Label className="text-xs text-muted-foreground">Até</Label>
            <Input 
              type="date" 
              value={filters.endDate}
              onChange={(e) => onFilterChange('endDate', e.target.value)}
              className="bg-white whitespace-normal break-words"
            />
          </div>

          {/* Type */}
          <div className="space-y-1.5">
            <Label className="text-xs text-muted-foreground">Tipo</Label>
            <Select 
              value={filters.type} 
              onValueChange={(v) => onFilterChange('type', v)}
            >
              <SelectTrigger className="bg-white whitespace-normal break-words h-auto min-h-[2.5rem] py-1">
                <SelectValue placeholder="Tipo" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todos</SelectItem>
                <SelectItem value="receita">Receita</SelectItem>
                <SelectItem value="despesa">Despesa</SelectItem>
                <SelectItem value="transferencia">Transferência</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Status */}
          <div className="space-y-1.5">
            <Label className="text-xs text-muted-foreground">Status</Label>
            <Select 
              value={filters.status} 
              onValueChange={(v) => onFilterChange('status', v)}
            >
              <SelectTrigger className="bg-white whitespace-normal break-words h-auto min-h-[2.5rem] py-1">
                <SelectValue placeholder="Status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todos</SelectItem>
                <SelectItem value="liquidado">Liquidado</SelectItem>
                <SelectItem value="aberto">Em Aberto</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Category */}
          <div className="space-y-1.5">
            <Label className="text-xs text-muted-foreground">Categoria</Label>
            <Select 
              value={filters.categoryId} 
              onValueChange={(v) => onFilterChange('categoryId', v)}
            >
              <SelectTrigger className="bg-white whitespace-normal break-words h-auto min-h-[2.5rem] py-1 text-left">
                <SelectValue placeholder="Categoria" />
              </SelectTrigger>
              <SelectContent className="max-h-[300px]">
                <SelectItem value="all">Todas</SelectItem>
                {categories.map(cat => (
                  <SelectItem key={cat.id} value={cat.id} className="whitespace-normal break-words">
                    {cat.nome_conta}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Account */}
          <div className="space-y-1.5">
            <Label className="text-xs text-muted-foreground">Conta</Label>
            <Select 
              value={filters.accountId} 
              onValueChange={(v) => onFilterChange('accountId', v)}
            >
              <SelectTrigger className="bg-white whitespace-normal break-words h-auto min-h-[2.5rem] py-1 text-left">
                <SelectValue placeholder="Conta" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todas</SelectItem>
                {accounts.map(acc => (
                  <SelectItem key={acc.id} value={acc.id} className="whitespace-normal break-words">
                    {acc.nome_conta}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default TransactionFilters;