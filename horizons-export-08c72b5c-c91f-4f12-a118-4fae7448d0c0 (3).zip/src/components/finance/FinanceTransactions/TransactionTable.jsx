
import React from 'react';
import { 
  ArrowUp, 
  ArrowDown, 
  ArrowUpDown, 
  Calendar, 
  Wallet,
  Tag,
  AlertCircle,
  Users,
  CheckCircle2
} from 'lucide-react';
import { format, parseISO } from 'date-fns';
import { ptBR } from 'date-fns/locale';

import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import { Skeleton } from '@/components/ui/skeleton';
import ActionMenu from '@/components/ui/ActionMenu';
import EmptyState from '@/components/ui/EmptyState';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { useFinanceTransactions } from '@/hooks/useFinanceTransactions';
import { cn, formatTransactionValue } from "@/lib/utils";

const TransactionTable = ({
  transactions = [],
  loading = false,
  sort = { field: 'data_competencia', direction: 'desc' },
  onSort,
  onEdit,
  onDelete
}) => {
  const { handlers } = useFinanceTransactions();
  const [liquidationDialog, setLiquidationDialog] = React.useState({ isOpen: false, transaction: null });
  const [isLiquidating, setIsLiquidating] = React.useState(false);

  // Helper to handle sort click
  const handleHeaderClick = (field) => {
    if (onSort) {
      onSort(field);
    }
  };

  // Helper to render sort icon
  const SortIcon = ({ field }) => {
    if (sort.field !== field) return <ArrowUpDown className="ml-2 h-4 w-4 text-muted-foreground/30 opacity-50" />;
    return sort.direction === 'asc' 
      ? <ArrowUp className="ml-2 h-4 w-4 text-primary" /> 
      : <ArrowDown className="ml-2 h-4 w-4 text-primary" />;
  };

  // Reusable Sortable Header
  const SortableHead = ({ field, label, className }) => (
    <TableHead 
      onClick={() => handleHeaderClick(field)}
      className={cn(
        "cursor-pointer hover:bg-muted/50 transition-colors select-none sticky top-0 bg-white z-10 shadow-sm whitespace-nowrap",
        className
      )}
    >
      <div className="flex items-center">
        {label}
        <SortIcon field={field} />
      </div>
    </TableHead>
  );

  const formatDateSafe = (dateStr) => {
    if (!dateStr) return '-';
    // If date is YYYY-MM-DD, append time to prevent timezone issues shifting the day
    const safeDateStr = dateStr.length === 10 ? `${dateStr}T12:00:00` : dateStr;
    try {
      return format(parseISO(safeDateStr), 'dd/MM/yyyy');
    } catch (e) {
      return dateStr;
    }
  };

  const openLiquidationDialog = (tx) => {
    setLiquidationDialog({ isOpen: true, transaction: tx });
  };

  const handleConfirmLiquidation = async () => {
    if (!liquidationDialog.transaction) return;
    setIsLiquidating(true);
    await handlers.liquidateTransaction(liquidationDialog.transaction.id);
    setIsLiquidating(false);
    setLiquidationDialog({ isOpen: false, transaction: null });
  };

  if (loading) {
    return (
      <div className="space-y-4">
         <Skeleton className="h-10 w-full mb-4 rounded-md" />
         <div className="space-y-2">
            {[1,2,3,4,5].map(i => <Skeleton key={i} className="h-16 w-full rounded-md" />)}
         </div>
      </div>
    );
  }

  if (transactions.length === 0) {
    return (
      <EmptyState 
        title="Nenhuma transação encontrada"
        description="Tente ajustar os filtros para encontrar o que procura."
        icon={AlertCircle}
        className="bg-white border rounded-md min-h-[400px]"
      />
    );
  }

  return (
    <>
      {/* Desktop View */}
      <div className="hidden md:block w-full overflow-hidden rounded-md border bg-white shadow-sm">
        <div className="overflow-x-auto w-full">
          <Table className="w-full min-w-[1000px]">
            <TableHeader>
              <TableRow className="bg-slate-50/50 hover:bg-slate-50/50">
                <SortableHead field="data_competencia" label="Competência" className="w-[120px]" />
                <SortableHead field="descricao" label="Descrição" className="min-w-[200px]" />
                <SortableHead field="party" label="Cliente/Fornecedor" className="min-w-[150px]" />
                <SortableHead field="categoria" label="Categoria" className="min-w-[150px]" />
                <SortableHead field="conta" label="Conta" className="min-w-[150px]" />
                <SortableHead field="valor" label={<div className="w-full text-right">Valor</div>} className="w-[120px]" />
                <SortableHead field="liquidado" label={<div className="w-full text-center">Status</div>} className="w-[120px]" />
                <TableHead className="w-[50px] sticky top-0 bg-white z-10 shadow-sm"></TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {transactions.map((tx) => (
                <TableRow key={tx.id} className="group hover:bg-slate-50/50 transition-colors">
                  <TableCell className="font-medium text-xs text-muted-foreground whitespace-nowrap align-top py-4">
                    {formatDateSafe(tx.data_competencia)}
                  </TableCell>
                  <TableCell className="align-top py-4 max-w-[250px]">
                    <div className="font-medium text-foreground truncate" title={tx.descricao}>
                      {tx.descricao}
                    </div>
                    {tx.criado_em && (
                       <div className="text-[10px] text-gray-400 font-light mt-0.5 truncate">
                          {format(parseISO(tx.criado_em), "dd/MM/yyyy HH:mm", { locale: ptBR })}
                       </div>
                    )}
                  </TableCell>
                  <TableCell className="align-top py-4 max-w-[200px]">
                     {tx.finance_parties ? (
                       <div className="flex flex-col">
                          <span className="text-sm text-foreground truncate" title={tx.finance_parties.nome}>
                            {tx.finance_parties.nome}
                          </span>
                          {tx.finance_parties.documento && (
                            <span className="text-xs text-muted-foreground truncate">
                              {tx.finance_parties.documento}
                            </span>
                          )}
                       </div>
                     ) : <span className="text-muted-foreground">-</span>}
                  </TableCell>
                  <TableCell className="align-top py-4 max-w-[180px]">
                    <div className="flex items-center gap-1.5" title={tx.finance_chart_of_accounts?.nome_conta}>
                      <span className="text-sm text-muted-foreground truncate">
                        {tx.finance_chart_of_accounts?.nome_conta || '-'}
                      </span>
                    </div>
                  </TableCell>
                  <TableCell className="align-top py-4 max-w-[180px]">
                    <div className="flex items-center gap-1.5" title={tx.finance_accounts?.nome_conta}>
                      <span className="text-sm text-muted-foreground truncate">
                        {tx.finance_accounts?.nome_conta || '-'}
                      </span>
                    </div>
                  </TableCell>
                  <TableCell className="text-right font-bold whitespace-nowrap align-top py-4">
                    <span className={tx.tipo === 'receita' ? "text-emerald-600" : (tx.tipo === 'despesa' ? "text-red-600" : "text-amber-700")}>
                      {formatTransactionValue(tx.valor)}
                    </span>
                  </TableCell>
                  <TableCell className="text-center align-top py-4">
                     <Badge 
                      variant="outline" 
                      className={cn(
                        "font-normal border-0 whitespace-nowrap",
                        tx.liquidado 
                          ? 'bg-emerald-50 text-emerald-700 hover:bg-emerald-100' 
                          : 'bg-amber-50 text-amber-700 hover:bg-amber-100'
                      )}
                    >
                      {tx.liquidado ? 'Liquidado' : 'Em Aberto'}
                    </Badge>
                  </TableCell>
                  <TableCell className="align-top py-4">
                    <ActionMenu 
                      onEdit={() => onEdit(tx)}
                      onDelete={() => onDelete(tx.id)}
                      align="end"
                      customActions={!tx.liquidado ? [{
                        label: 'Liquidar',
                        icon: CheckCircle2,
                        onClick: () => openLiquidationDialog(tx),
                        className: 'text-emerald-600 focus:text-emerald-700 focus:bg-emerald-50'
                      }] : []}
                    />
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      </div>

      {/* Mobile Card View */}
      <div className="md:hidden space-y-3">
        {transactions.map((tx) => (
          <Card key={tx.id} className="shadow-sm border-l-4 overflow-hidden" style={{ 
            borderLeftColor: tx.tipo === 'receita' ? '#059669' : (tx.tipo === 'despesa' ? '#dc2626' : '#b45309') 
          }}>
            <CardContent className="p-4">
              <div className="flex justify-between items-start gap-2 mb-2">
                <div className="flex-1 min-w-0">
                  <h4 className="font-semibold text-foreground text-sm leading-snug truncate">
                    {tx.descricao}
                  </h4>
                  <div className="flex items-center gap-2 text-xs text-muted-foreground mt-1">
                    <Calendar className="h-3 w-3 flex-shrink-0" />
                    {formatDateSafe(tx.data_competencia)}
                  </div>
                </div>
                <ActionMenu 
                   onEdit={() => onEdit(tx)}
                   onDelete={() => onDelete(tx.id)}
                   customActions={!tx.liquidado ? [{
                      label: 'Liquidar',
                      icon: CheckCircle2,
                      onClick: () => openLiquidationDialog(tx),
                      className: 'text-emerald-600'
                    }] : []}
                />
              </div>

              <div className="flex flex-col gap-2 mt-3 pt-3 border-t border-dashed">
                <div className="space-y-1.5">
                   {tx.finance_parties && (
                     <div className="flex items-center gap-2 text-xs text-foreground font-medium min-w-0">
                        <Users className="h-3 w-3 flex-shrink-0 text-muted-foreground" />
                        <span className="truncate">
                          {tx.finance_parties.nome}
                        </span>
                     </div>
                   )}
                   <div className="flex items-center gap-2 text-xs text-muted-foreground min-w-0">
                      <Tag className="h-3 w-3 flex-shrink-0" />
                      <span className="truncate">{tx.finance_chart_of_accounts?.nome_conta || 'Sem Categoria'}</span>
                   </div>
                   <div className="flex items-center gap-2 text-xs text-muted-foreground min-w-0">
                      <Wallet className="h-3 w-3 flex-shrink-0" />
                      <span className="truncate">{tx.finance_accounts?.nome_conta || 'Sem Conta'}</span>
                   </div>
                </div>
                
                <div className="flex justify-between items-end mt-2">
                   <Badge 
                      variant="outline" 
                      className={cn(
                        "text-[10px] px-2 py-0.5 h-auto",
                        tx.liquidado 
                          ? 'bg-emerald-50 text-emerald-700 border-emerald-100' 
                          : 'bg-amber-50 text-amber-700 border-amber-100'
                      )}
                    >
                      {tx.liquidado ? 'Liquidado' : 'Em Aberto'}
                    </Badge>
                   <div className={cn(
                     "font-bold text-lg",
                     tx.tipo === 'receita' ? "text-emerald-600" : (tx.tipo === 'despesa' ? "text-red-600" : "text-amber-700")
                   )}>
                      {formatTransactionValue(tx.valor)}
                   </div>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <Dialog open={liquidationDialog.isOpen} onOpenChange={(open) => !open && setLiquidationDialog({ isOpen: false, transaction: null })}>
        <DialogContent className="sm:max-w-[425px]">
          <DialogHeader>
            <DialogTitle>Confirmar Liquidação</DialogTitle>
            <DialogDescription>
              Deseja marcar "{liquidationDialog.transaction?.descricao}" como liquidada?
              A data será definida para hoje.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter className="flex-col sm:flex-row gap-2">
            <Button variant="outline" onClick={() => setLiquidationDialog({ isOpen: false, transaction: null })}>Cancelar</Button>
            <Button onClick={handleConfirmLiquidation} disabled={isLiquidating} className="bg-emerald-600 hover:bg-emerald-700">
              {isLiquidating ? 'Liquidando...' : 'Confirmar'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
};

export default TransactionTable;
