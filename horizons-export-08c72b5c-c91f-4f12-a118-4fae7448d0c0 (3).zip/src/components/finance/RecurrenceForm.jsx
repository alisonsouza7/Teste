import React from 'react';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { Card, CardContent } from '@/components/ui/card';
import { Repeat } from 'lucide-react';

/**
 * RecurrenceForm Component
 * 
 * Handles the configuration UI for creating recurring transactions.
 * It is embedded within the main transaction form.
 * 
 * Props:
 * - config: The current recurrence state object (enabled, type, frequency, etc.)
 * - onChange: Handler to update the parent state
 * - isEditing: Boolean to disable recurrence creation during edit mode (if not supported)
 */
const RecurrenceForm = ({ config, onChange, isEditing }) => {
    // Recurrence creation is typically only allowed during new transaction creation
    // to avoid complex logic of "converting" existing historical records.
    if (isEditing) return null; 

    const handleChange = (field, value) => {
        onChange({ ...config, [field]: value });
    };

    // If recurrence is not enabled, show only the toggle checkbox
    if (!config.enabled) {
        return (
            <div className="flex items-center space-x-2 pt-2">
                <Checkbox 
                    id="enable-recurrence" 
                    checked={config.enabled} 
                    onCheckedChange={(checked) => handleChange('enabled', checked)}
                />
                <Label htmlFor="enable-recurrence" className="text-sm font-medium leading-none cursor-pointer flex items-center gap-2">
                    <Repeat className="w-3 h-3 text-muted-foreground" />
                    Repetir este lançamento
                </Label>
            </div>
        );
    }

    // If enabled, show the full configuration panel
    return (
        <Card className="bg-slate-50 border-dashed border-slate-300 shadow-none mt-2">
            <CardContent className="p-4 space-y-4">
                <div className="flex justify-between items-center">
                    <div className="flex items-center space-x-2">
                        <Checkbox 
                            id="enable-recurrence-on" 
                            checked={config.enabled} 
                            onCheckedChange={(checked) => handleChange('enabled', checked)}
                        />
                        <Label htmlFor="enable-recurrence-on" className="font-semibold text-slate-700">Configuração de Recorrência</Label>
                    </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                    {/* Frequency Selection (Monthly, Weekly, etc.) */}
                    <div className="space-y-1">
                        <Label className="text-xs">Frequência</Label>
                        <Select 
                            value={config.recurrence_type} 
                            onValueChange={(v) => handleChange('recurrence_type', v)}
                        >
                            <SelectTrigger className="h-8 text-xs bg-white">
                                <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                                <SelectItem value="mensal">Mensal</SelectItem>
                                <SelectItem value="semanal">Semanal</SelectItem>
                                <SelectItem value="diario">Diário</SelectItem>
                                <SelectItem value="anual">Anual</SelectItem>
                            </SelectContent>
                        </Select>
                    </div>

                    {/* Interval Count (e.g., Every 2 months) */}
                    <div className="space-y-1">
                        <Label className="text-xs">Intervalo</Label>
                        <div className="flex items-center gap-2">
                            <span className="text-xs text-muted-foreground">A cada</span>
                            <Input 
                                type="number" 
                                min="1" 
                                className="h-8 w-16 text-xs bg-white"
                                value={config.interval_count}
                                onChange={(e) => handleChange('interval_count', e.target.value)}
                            />
                            <span className="text-xs text-muted-foreground">
                                {config.recurrence_type === 'mensal' ? 'meses' : 
                                 config.recurrence_type === 'semanal' ? 'semanas' :
                                 config.recurrence_type === 'anual' ? 'anos' : 'dias'}
                            </span>
                        </div>
                    </div>
                </div>

                {/* Optional End Date */}
                <div className="space-y-1">
                    <Label className="text-xs">Data Término (Opcional)</Label>
                    <Input 
                        type="date" 
                        className="h-8 text-xs bg-white"
                        value={config.end_date || ''}
                        onChange={(e) => handleChange('end_date', e.target.value)}
                    />
                    <p className="text-[10px] text-muted-foreground">Deixe em branco para repetir indefinidamente.</p>
                </div>
            </CardContent>
        </Card>
    );
};

export default RecurrenceForm;