
import React, { useState, useEffect } from 'react';
import { format, addMonths, subMonths, startOfMonth, endOfMonth, parseISO, isValid } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { ChevronLeft, ChevronRight, Calendar, X, Edit2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { cn } from '@/lib/utils';

const DateFilterCapsule = ({ dateRange, onDateRangeChange }) => {
  const [filterMode, setFilterMode] = useState('competencia'); // 'competencia' | 'personalizado'
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [tempRange, setTempRange] = useState({ startDate: '', endDate: '' });

  // Initialize internal state based on props if needed, but primarily rely on props
  // We determine mode based on whether the range matches a full month
  useEffect(() => {
    if (dateRange?.startDate && dateRange?.endDate) {
      const start = parseISO(dateRange.startDate);
      const end = parseISO(dateRange.endDate);
      
      if (isValid(start) && isValid(end)) {
        const isStartOfMonth = format(start, 'yyyy-MM-dd') === format(startOfMonth(start), 'yyyy-MM-dd');
        const isEndOfMonth = format(end, 'yyyy-MM-dd') === format(endOfMonth(start), 'yyyy-MM-dd');
        
        if (isStartOfMonth && isEndOfMonth) {
            setFilterMode('competencia');
        } else {
            setFilterMode('personalizado');
        }
      }
    }
  }, [dateRange]);

  const handlePrevMonth = () => {
    if (!dateRange.startDate) return;
    const currentStart = parseISO(dateRange.startDate);
    const newDate = subMonths(currentStart, 1);
    const newStart = startOfMonth(newDate);
    const newEnd = endOfMonth(newDate);
    
    onDateRangeChange({
      startDate: format(newStart, 'yyyy-MM-dd'),
      endDate: format(newEnd, 'yyyy-MM-dd')
    });
  };

  const handleNextMonth = () => {
    if (!dateRange.startDate) return;
    const currentStart = parseISO(dateRange.startDate);
    const newDate = addMonths(currentStart, 1);
    const newStart = startOfMonth(newDate);
    const newEnd = endOfMonth(newDate);
    
    onDateRangeChange({
      startDate: format(newStart, 'yyyy-MM-dd'),
      endDate: format(newEnd, 'yyyy-MM-dd')
    });
  };

  const openCustomModal = () => {
    setTempRange({
      startDate: dateRange.startDate || format(new Date(), 'yyyy-MM-dd'),
      endDate: dateRange.endDate || format(new Date(), 'yyyy-MM-dd')
    });
    setIsModalOpen(true);
  };

  const applyCustomRange = () => {
    onDateRangeChange(tempRange);
    setFilterMode('personalizado');
    setIsModalOpen(false);
  };

  const switchToCompetencia = () => {
    const today = new Date();
    onDateRangeChange({
      startDate: format(startOfMonth(today), 'yyyy-MM-dd'),
      endDate: format(endOfMonth(today), 'yyyy-MM-dd')
    });
    setFilterMode('competencia');
  };

  const formatDisplayDate = (isoDate) => {
      if (!isoDate) return '';
      const date = parseISO(isoDate);
      return isValid(date) ? format(date, 'dd/MM/yyyy') : '';
  };

  const currentMonthLabel = dateRange.startDate 
    ? format(parseISO(dateRange.startDate), 'MMMM yyyy', { locale: ptBR }) 
    : '';

  return (
    <>
      <div className="flex items-center">
        {filterMode === 'competencia' ? (
          <div className="flex items-center bg-gradient-to-b from-blue-50 to-blue-100 border border-blue-200 rounded-full p-1 shadow-sm transition-all hover:shadow-md">
            <Button 
              variant="ghost" 
              size="icon" 
              className="h-8 w-8 rounded-full hover:bg-white/50 text-blue-700"
              onClick={handlePrevMonth}
            >
              <ChevronLeft className="h-4 w-4" />
            </Button>
            
            <span className="px-4 text-sm font-semibold text-blue-800 capitalize min-w-[140px] text-center select-none">
              {currentMonthLabel}
            </span>

            <Button 
              variant="ghost" 
              size="icon" 
              className="h-8 w-8 rounded-full hover:bg-white/50 text-blue-700"
              onClick={handleNextMonth}
            >
              <ChevronRight className="h-4 w-4" />
            </Button>
            
            <div className="h-4 w-px bg-blue-300 mx-1" />
            
            <Button
              variant="ghost"
              size="sm"
              className="h-8 text-xs font-medium text-blue-700 hover:text-blue-900 hover:bg-white/50 rounded-full px-3"
              onClick={openCustomModal}
            >
              Personalizado
            </Button>
          </div>
        ) : (
          <div className="flex items-center bg-gradient-to-b from-purple-50 to-purple-100 border border-purple-200 rounded-full p-1 pl-4 shadow-sm transition-all hover:shadow-md group">
            <Calendar className="h-4 w-4 text-purple-600 mr-2" />
            <span className="text-sm font-semibold text-purple-800 mr-2 select-none">
              {formatDisplayDate(dateRange.startDate)} — {formatDisplayDate(dateRange.endDate)}
            </span>
            
            <Button
              variant="ghost"
              size="sm"
              className="h-8 text-xs font-medium text-purple-700 hover:text-purple-900 hover:bg-white/50 rounded-full px-3 ml-1"
              onClick={openCustomModal}
            >
              <Edit2 className="h-3 w-3 mr-1" /> Editar
            </Button>

            <Button 
              variant="ghost" 
              size="icon" 
              className="h-8 w-8 rounded-full hover:bg-white/50 text-purple-700 ml-1"
              onClick={switchToCompetencia}
            >
              <X className="h-4 w-4" />
            </Button>
          </div>
        )}
      </div>

      <Dialog open={isModalOpen} onOpenChange={setIsModalOpen}>
        <DialogContent className="sm:max-w-[425px]">
          <DialogHeader>
            <DialogTitle>Selecionar Período Personalizado</DialogTitle>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="start">Data Inicial</Label>
                <Input
                  id="start"
                  type="date"
                  value={tempRange.startDate}
                  onChange={(e) => setTempRange({ ...tempRange, startDate: e.target.value })}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="end">Data Final</Label>
                <Input
                  id="end"
                  type="date"
                  value={tempRange.endDate}
                  onChange={(e) => setTempRange({ ...tempRange, endDate: e.target.value })}
                />
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsModalOpen(false)}>Cancelar</Button>
            <Button onClick={applyCustomRange}>Aplicar Filtro</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
};

export default DateFilterCapsule;
