
import React from 'react';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useTaxRegimes } from '@/hooks/useTaxRegimes';
import { Skeleton } from '@/components/ui/skeleton';

const RegimeSelector = ({ value, onChange, disabled, className }) => {
  const { regimes, loading } = useTaxRegimes();

  if (loading) {
    return <Skeleton className="h-10 w-full" />;
  }

  const formatCurrency = (val) => {
    if (val === null) return 'Sem limite';
    return new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL', maximumFractionDigits: 0 }).format(val);
  };

  return (
    <Select value={value} onValueChange={onChange} disabled={disabled}>
      <SelectTrigger className={className}>
        <SelectValue placeholder="Selecione o Regime Tributário" />
      </SelectTrigger>
      <SelectContent>
        {regimes.map((regime) => (
          <SelectItem key={regime.id} value={regime.codigo}>
            <div className="flex flex-col items-start">
              <span className="font-medium">{regime.nome_exibicao}</span>
              <span className="text-xs text-muted-foreground">
                Limite: {formatCurrency(regime.limite_faturamento)}
              </span>
            </div>
          </SelectItem>
        ))}
      </SelectContent>
    </Select>
  );
};

export default RegimeSelector;
