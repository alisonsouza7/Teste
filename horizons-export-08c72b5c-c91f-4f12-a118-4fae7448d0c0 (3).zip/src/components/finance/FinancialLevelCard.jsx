
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { 
  CheckCircle2, 
  Crown, 
  ArrowUpCircle, 
  Info,
  CreditCard,
  Landmark,
  FileCheck,
  LayoutGrid
} from 'lucide-react';
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import { cn } from '@/lib/utils';
import { useFinanceLevel } from '@/hooks/useFinanceLevel';

const LEVEL_CONFIG = {
  'A': {
    color: 'emerald',
    gradient: 'from-emerald-500 to-green-600',
    bgLight: 'bg-emerald-50',
    borderLight: 'border-emerald-100',
    textDark: 'text-emerald-900',
    badge: 'bg-emerald-100 text-emerald-800 hover:bg-emerald-200',
    icon: LayoutGrid,
    label: 'Plano Básico',
    description: 'Gestão financeira essencial para quem está começando.',
    features: [
      { label: 'Conta Bancária Única', icon: Landmark },
      { label: 'Controle de Receitas e Despesas', icon: FileCheck },
      { label: 'Relatórios Básicos', icon: LayoutGrid },
    ]
  },
  'B': {
    color: 'blue',
    gradient: 'from-blue-500 to-indigo-600',
    bgLight: 'bg-blue-50',
    borderLight: 'border-blue-100',
    textDark: 'text-blue-900',
    badge: 'bg-blue-100 text-blue-800 hover:bg-blue-200',
    icon: ArrowUpCircle,
    label: 'Plano Intermediário',
    description: 'Recursos expandidos para empresas em crescimento.',
    features: [
      { label: 'Múltiplas Contas Bancárias', icon: Landmark },
      { label: 'Importação de OFX', icon: FileCheck },
      { label: 'Todos recursos do Plano A', icon: CheckCircle2 },
    ]
  },
  'C': {
    color: 'purple',
    gradient: 'from-violet-500 to-purple-600',
    bgLight: 'bg-purple-50',
    borderLight: 'border-purple-100',
    textDark: 'text-purple-900',
    badge: 'bg-purple-100 text-purple-800 hover:bg-purple-200',
    icon: Crown,
    label: 'Plano Avançado',
    description: 'Gestão completa com automação fiscal e financeira.',
    features: [
      { label: 'Emissão de NFS-e (Certificado A1)', icon: FileCheck },
      { label: 'Gestão de Cartões de Crédito', icon: CreditCard },
      { label: 'Conciliação Bancária', icon: Landmark },
      { label: 'Centros de Custo', icon: LayoutGrid },
    ]
  }
};

const FinancialLevelCard = ({ companyId }) => {
  const { level, loading } = useFinanceLevel(companyId);
  
  if (loading) return null;

  const currentConfig = LEVEL_CONFIG[level] || LEVEL_CONFIG['A'];
  const Icon = currentConfig.icon;

  return (
    <Card className={cn("overflow-hidden border shadow-md transition-all duration-300 hover:shadow-lg", currentConfig.borderLight)}>
      <div className={cn("h-2 w-full bg-gradient-to-r", currentConfig.gradient)} />
      
      <CardHeader className="pb-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className={cn("p-2 rounded-lg bg-gradient-to-br text-white shadow-sm", currentConfig.gradient)}>
              <Icon className="h-5 w-5" />
            </div>
            <div>
              <CardTitle className="text-lg font-bold flex items-center gap-2">
                {currentConfig.label}
                <Badge variant="secondary" className={cn("ml-2 font-semibold", currentConfig.badge)}>
                  Nível {level}
                </Badge>
              </CardTitle>
              <CardDescription className="mt-1">
                {currentConfig.description}
              </CardDescription>
            </div>
          </div>
        </div>
      </CardHeader>

      <CardContent>
        <div className={cn("rounded-lg p-4 grid gap-3 sm:grid-cols-2", currentConfig.bgLight)}>
          {currentConfig.features.map((feature, idx) => (
            <div key={idx} className="flex items-center gap-2.5">
              <div className={cn("p-1 rounded-full bg-white shadow-sm text-opacity-80", `text-${currentConfig.color}-600`)}>
                <feature.icon className="h-3.5 w-3.5" />
              </div>
              <span className={cn("text-sm font-medium", currentConfig.textDark)}>
                {feature.label}
              </span>
            </div>
          ))}
        </div>
      </CardContent>

      <CardFooter className="pt-0 flex justify-between items-center border-t bg-slate-50/50 p-4">
        <div className="flex items-center gap-2 text-xs text-muted-foreground">
          <CheckCircle2 className={cn("h-4 w-4", `text-${currentConfig.color}-500`)} />
          <span>Plano ativo atualmente</span>
        </div>

        <TooltipProvider>
          <Tooltip>
            <TooltipTrigger asChild>
              <span tabIndex={0}> {/* Span wrapper needed for disabled button tooltip */}
                <Button variant="outline" size="sm" disabled className="opacity-70">
                  Alterar Plano
                </Button>
              </span>
            </TooltipTrigger>
            <TooltipContent>
              <p className="flex items-center gap-2">
                <Info className="h-3 w-3" />
                Entre em contato com o suporte para alterar seu plano.
              </p>
            </TooltipContent>
          </Tooltip>
        </TooltipProvider>
      </CardFooter>
    </Card>
  );
};

export default FinancialLevelCard;
