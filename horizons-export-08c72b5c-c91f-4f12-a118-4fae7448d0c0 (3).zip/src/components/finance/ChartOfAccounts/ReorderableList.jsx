import React, { useState, useEffect } from 'react';
import { Reorder } from 'framer-motion';
import AccountCard from './AccountCard';

/**
 * ReorderableList Component
 * 
 * DESIGN DECISION:
 * - Utilizes Framer Motion's `Reorder.Group` and `Reorder.Item` for smooth and performant drag-and-drop.
 * - Manages its own internal `list` state for optimistic updates, providing immediate visual feedback to the user.
 * - The actual reorder logic (persisting to DB) is delegated to the `onReorder` prop in the parent component.
 */
const ReorderableList = ({ items, onReorder, onEdit, onDelete }) => {
  const [list, setList] = useState(items);

  useEffect(() => {
    // DESIGN: Update internal list state when parent `items` prop changes
    setList(items);
  }, [items]);

  const handleReorder = (newList) => {
    setList(newList); // Optimistic UI update
    
    // Prepare data for parent callback: send only id and new display_order
    const reorderedWithIndices = newList.map((item, index) => ({
      id: item.id,
      display_order: index + 1 // DESIGN: display_order is 1-based index
    }));
    
    // DESIGN: Delegate actual persistence to parent to keep this component focused on UI.
    // A debounce could be added here if frequent reorders cause too many API calls.
    onReorder(reorderedWithIndices); 
  };

  return (
    <Reorder.Group axis="y" values={list} onReorder={handleReorder}>
      {list.map((item) => (
        <Reorder.Item key={item.id} value={item} style={{ listStyle: 'none' }}>
           <AccountCard 
             account={item}
             onEdit={onEdit}
             onDelete={onDelete}
             // Framer Motion Reorder handles drag logic internally on the Item component
             // No need for separate dragHandleProps as Reorder.Item provides them to its children by default
           />
        </Reorder.Item>
      ))}
    </Reorder.Group>
  );
};

export default ReorderableList;