import React from 'react';
import { cn } from '@/lib/utils';
import { GripVertical, Edit2, Trash2 } from 'lucide-react';
import { Button } from '@/components/ui/button';

const AccountCard = ({
  account,
  onEdit,
  onDelete,
  dragHandleProps = {},
  isDragging = false,
  showAccountNumber = true,
  accentColor = '#cbd5e1',
}) => {
  const isInactive = account?.is_active === false;

  return (
    <div
      className={cn(
        'group flex items-center gap-3 p-3 bg-white border rounded-lg transition-all min-h-16',
        'hover:border-primary/30 hover:shadow-sm',
        isDragging && 'opacity-50 shadow-lg scale-[1.02] z-50',
        isInactive && 'opacity-60 bg-slate-50'
      )}
    >
      <div
        {...dragHandleProps}
        className="cursor-grab active:cursor-grabbing text-slate-300 hover:text-slate-500 p-1"
      >
        <GripVertical className="h-4 w-4" />
      </div>

      <div
        className="w-1.5 h-8 rounded-full shrink-0"
        style={{ backgroundColor: accentColor }}
      />

      <div
        className="w-3 h-3 rounded-full shrink-0"
        style={{ backgroundColor: account?.color || '#cbd5e1' }}
      />

      <div className="flex-1 min-w-0">
        <h4 className="text-sm font-medium truncate">
          {account?.nome_conta}

          {showAccountNumber && (
            <span className="ml-2 text-xs text-slate-500 font-normal">
              ({account?.account_number || '--'})
            </span>
          )}

          {isInactive && (
            <span className="ml-2 text-xs text-red-500 font-normal">
              (Inativo)
            </span>
          )}
        </h4>

        <p className="text-xs text-muted-foreground truncate">
          {account?.grupo || 'Sem grupo definido'}
        </p>
      </div>

      <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
        <Button size="icon" variant="ghost" className="h-7 w-7" onClick={() => onEdit(account)}>
          <Edit2 className="h-3.5 w-3.5 text-slate-500" />
        </Button>
        <Button size="icon" variant="ghost" className="h-7 w-7" onClick={() => onDelete(account.id)}>
          <Trash2 className="h-3.5 w-3.5 text-red-400 hover:text-red-600" />
        </Button>
      </div>
    </div>
  );
};

export default AccountCard;