import React from 'react';
import { cn } from '@/lib/utils';
import { Check } from 'lucide-react';

/**
 * ColorPicker Component
 * 
 * DESIGN DECISION:
 * - Provides a predefined palette for consistent branding and easier choice.
 * - Uses circular buttons for an aesthetic and compact display of color options.
 * - Displays a checkmark on the selected color for clear visual feedback.
 * - `hover:scale-110` provides micro-interaction for a more engaging experience.
 */
const PREDEFINED_COLORS = [
  { label: 'Navy', value: '#06407a' },
  { label: 'Blue', value: '#3b82f6' },
  { label: 'Sky', value: '#0ea5e9' },
  { label: 'Emerald', value: '#10b981' },
  { label: 'Green', value: '#22c55e' },
  { label: 'Yellow', value: '#fcd322' },
  { label: 'Amber', value: '#f59e0b' },
  { label: 'Orange', value: '#f97316' },
  { label: 'Red', value: '#ef4444' },
  { label: 'Purple', value: '#a855f7' },
  { label: 'Pink', value: '#ec4899' },
  { label: 'Slate', value: '#64748b' },
];

const ColorPicker = ({ value, onChange, className }) => {
  return (
    <div className={cn("flex flex-wrap gap-2", className)}>
      {PREDEFINED_COLORS.map((color) => (
        <button
          key={color.value}
          type="button"
          onClick={() => onChange(color.value)}
          className={cn(
            "w-8 h-8 rounded-full flex items-center justify-center transition-all hover:scale-110 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-ring border border-slate-200",
            value === color.value ? "ring-2 ring-offset-2 ring-slate-400 scale-110" : "" // DESIGN: Ring effect for selected color
          )}
          style={{ backgroundColor: color.value }}
          title={color.label}
        >
          {value === color.value && <Check className="w-4 h-4 text-white drop-shadow-md" />}
        </button>
      ))}
    </div>
  );
};

export default ColorPicker;