import React, { useState, useEffect } from 'react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { AlertCircle, CheckCircle2, Loader2, Save } from 'lucide-react';
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";

const ImportValidationDialog = ({
  isOpen,
  onClose,
  initialData = [],
  categories = [],
  accounts = [],
  parties = [],
  onImport
}) => {
  const [data, setData] = useState([]);
  const [importing, setImporting] = useState(false);

  useEffect(() => {
    if (isOpen) {
      // Initialize data with validation status
      const processed = initialData.map((row, index) => ({
        ...row,
        _id: index, // temporary id for react keys
        errors: validateRow(row)
      }));
      setData(processed);
    }
  }, [isOpen, initialData]);

  const validateRow = (row) => {
    const errors = [];
    if (!row.descricao) errors.push("Descrição é obrigatória");
    if (!row.valor || isNaN(Number(row.valor))) errors.push("Valor inválido");
    if (!row.tipo) errors.push("Tipo é obrigatório");
    if (!row.conta_nome) errors.push("Conta é obrigatória");
    // We allow category/party to be empty or new, so no strict validation failure unless critical logic
    return errors;
  };

  const handleChange = (id, field, value) => {
    setData(prev => prev.map(row => {
      if (row._id === id) {
        const updatedRow = { ...row, [field]: value };
        return { ...updatedRow, errors: validateRow(updatedRow) };
      }
      return row;
    }));
  };

  const handleImport = async () => {
    // Filter out rows with critical errors if you want strictness, or just try to import all valid ones
    const validRows = data.filter(r => r.errors.length === 0);
    if (validRows.length === 0) return;

    setImporting(true);
    await onImport(validRows);
    setImporting(false);
    onClose();
  };

  const totalRows = data.length;
  const validRowsCount = data.filter(r => r.errors.length === 0).length;
  const errorRowsCount = totalRows - validRowsCount;

  return (
    <Dialog open={isOpen} onOpenChange={open => !open && !importing && onClose()}>
      <DialogContent className="max-w-[95vw] h-[90vh] flex flex-col p-0 gap-0">
        <DialogHeader className="p-6 pb-2">
          <DialogTitle>Validar Importação</DialogTitle>
          <DialogDescription>
            Revise os dados abaixo antes de importar. Linhas com erro não serão importadas.
            Contas, Categorias e Parceiros inexistentes serão criados automaticamente.
          </DialogDescription>
        </DialogHeader>

        <div className="flex items-center gap-4 px-6 py-2 border-b bg-muted/20">
            <Badge variant="outline" className="bg-white">Total: {totalRows}</Badge>
            <Badge variant="outline" className="bg-emerald-50 text-emerald-700 border-emerald-200">
                <CheckCircle2 className="w-3 h-3 mr-1"/> Válidos: {validRowsCount}
            </Badge>
            {errorRowsCount > 0 && (
                <Badge variant="outline" className="bg-red-50 text-red-700 border-red-200">
                    <AlertCircle className="w-3 h-3 mr-1"/> Erros: {errorRowsCount}
                </Badge>
            )}
        </div>

        <div className="flex-1 overflow-auto p-0">
          <Table>
            <TableHeader className="sticky top-0 bg-white z-10 shadow-sm">
              <TableRow>
                <TableHead className="w-[120px]">Data</TableHead>
                <TableHead className="min-w-[200px]">Descrição</TableHead>
                <TableHead className="w-[180px]">Cliente/Fornecedor</TableHead>
                <TableHead className="w-[180px]">Categoria</TableHead>
                <TableHead className="w-[180px]">Conta</TableHead>
                <TableHead className="w-[120px]">Valor</TableHead>
                <TableHead className="w-[120px]">Tipo</TableHead>
                <TableHead className="w-[120px]">Status</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {data.map((row) => (
                <TableRow key={row._id} className={cn(row.errors.length > 0 && "bg-red-50 hover:bg-red-100/80")}>
                  <TableCell>
                    <Input 
                        type="date" 
                        value={row.data_competencia || ''} 
                        onChange={e => handleChange(row._id, 'data_competencia', e.target.value)}
                        className="h-8 w-full bg-transparent border-0 focus-visible:ring-1"
                    />
                  </TableCell>
                  <TableCell>
                    <Input 
                        value={row.descricao || ''} 
                        onChange={e => handleChange(row._id, 'descricao', e.target.value)}
                        className={cn("h-8 w-full bg-transparent border-0 focus-visible:ring-1", !row.descricao && "border-red-300")}
                        placeholder="Obrigatório"
                    />
                     {row.errors.includes("Descrição é obrigatória") && <span className="text-[10px] text-red-600 block">Obrigatório</span>}
                  </TableCell>
                  <TableCell>
                     {/* Using Input for Party to allow new creation easily, or could be a Creatable Select */}
                     <Input 
                        value={row.party_nome || ''}
                        onChange={e => handleChange(row._id, 'party_nome', e.target.value)}
                        className="h-8 w-full bg-transparent border-0 focus-visible:ring-1"
                        placeholder="Nome do parceiro"
                        list={`parties-${row._id}`}
                     />
                     <datalist id={`parties-${row._id}`}>
                        {parties.map(p => <option key={p.id} value={p.nome} />)}
                     </datalist>
                  </TableCell>
                  <TableCell>
                     <Input 
                        value={row.categoria_nome || ''}
                        onChange={e => handleChange(row._id, 'categoria_nome', e.target.value)}
                        className="h-8 w-full bg-transparent border-0 focus-visible:ring-1"
                        placeholder="Nome da categoria"
                        list={`categories-${row._id}`}
                     />
                     <datalist id={`categories-${row._id}`}>
                        {categories.map(c => <option key={c.id} value={c.nome_conta} />)}
                     </datalist>
                  </TableCell>
                  <TableCell>
                     <Input 
                        value={row.conta_nome || ''}
                        onChange={e => handleChange(row._id, 'conta_nome', e.target.value)}
                        className={cn("h-8 w-full bg-transparent border-0 focus-visible:ring-1", !row.conta_nome && "border-red-300")}
                        placeholder="Nome da conta"
                        list={`accounts-${row._id}`}
                     />
                     <datalist id={`accounts-${row._id}`}>
                        {accounts.map(a => <option key={a.id} value={a.nome_conta} />)}
                     </datalist>
                     {row.errors.includes("Conta é obrigatória") && <span className="text-[10px] text-red-600 block">Obrigatório</span>}
                  </TableCell>
                  <TableCell>
                    <Input 
                        type="number"
                        step="0.01"
                        value={row.valor || ''} 
                        onChange={e => handleChange(row._id, 'valor', e.target.value)}
                        className="h-8 w-full bg-transparent border-0 focus-visible:ring-1 text-right"
                    />
                  </TableCell>
                  <TableCell>
                    <Select value={row.tipo} onValueChange={v => handleChange(row._id, 'tipo', v)}>
                        <SelectTrigger className="h-8 border-0 bg-transparent">
                            <SelectValue placeholder="Tipo" />
                        </SelectTrigger>
                        <SelectContent>
                            <SelectItem value="receita">Receita</SelectItem>
                            <SelectItem value="despesa">Despesa</SelectItem>
                        </SelectContent>
                    </Select>
                  </TableCell>
                  <TableCell>
                    <Select 
                        value={row.status === 'liquidado' || row.liquidado ? 'liquidado' : 'aberto'} 
                        onValueChange={v => handleChange(row._id, 'status', v)}
                    >
                        <SelectTrigger className="h-8 border-0 bg-transparent">
                            <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                            <SelectItem value="liquidado">Liquidado</SelectItem>
                            <SelectItem value="aberto">Aberto</SelectItem>
                        </SelectContent>
                    </Select>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>

        <DialogFooter className="p-4 border-t bg-slate-50">
          <Button variant="outline" onClick={onClose} disabled={importing}>
            Cancelar
          </Button>
          <Button onClick={handleImport} disabled={importing || validRowsCount === 0}>
            {importing ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Save className="mr-2 h-4 w-4" />}
            Importar {validRowsCount} itens
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default ImportValidationDialog;