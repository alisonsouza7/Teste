
import React, { useState, useEffect } from 'react';
import { useFinanceTransactions } from '@/hooks/useFinanceTransactions';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { Button } from '@/components/ui/button';
import { AlertCircle, Clock, CalendarDays, ArrowRight } from 'lucide-react';
import { format, parseISO, isBefore, isAfter, startOfDay } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { Link } from 'react-router-dom';
import { formatTransactionValue } from '@/lib/utils';

const UpcomingPaymentsCard = () => {
  const { handlers } = useFinanceTransactions();
  const [payments, setPayments] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const loadData = async () => {
      setLoading(true);
      try {
        const data = await handlers.fetchUpcomingPayments();
        setPayments(data || []);
      } catch (error) {
        console.error("Failed to load upcoming payments", error);
      } finally {
        setLoading(false);
      }
    };
    loadData();
  }, [handlers]);

  const today = startOfDay(new Date());

  const overdue = payments.filter(p => isBefore(parseISO(p.vencimento), today));
  const upcoming = payments.filter(p => !isBefore(parseISO(p.vencimento), today));

  const totalDue = payments.reduce((acc, curr) => acc + (Number(curr.valor) || 0), 0);
  const overdueCount = overdue.length;
  const upcomingCount = upcoming.length;

  const displayList = payments.slice(0, 5);

  const formatDate = (dateStr) => format(parseISO(dateStr), 'dd/MM', { locale: ptBR });

  if (loading) {
    return <Skeleton className="w-full h-[300px] rounded-xl" />;
  }

  return (
    <Card className="shadow-sm border-border/60">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
            <div>
                <CardTitle className="text-lg flex items-center gap-2">
                    <CalendarDays className="w-5 h-5 text-primary"/> Próximos Pagamentos/Recebimentos
                </CardTitle>
                <CardDescription>Resumo de contas a vencer nos próximos 30 dias</CardDescription>
            </div>
            <div className="text-right">
                <span className="text-xs text-muted-foreground block">Total Previsto</span>
                <span className="text-xl font-bold tracking-tight text-foreground">{formatTransactionValue(totalDue)}</span>
            </div>
        </div>
      </CardHeader>
      <CardContent>
        <div className="flex gap-4 mb-4">
            <div className="flex items-center gap-2 bg-red-50 text-red-700 px-3 py-1.5 rounded-lg text-sm border border-red-100">
                <AlertCircle className="w-4 h-4" />
                <span className="font-semibold">{overdueCount}</span> Atrasados
            </div>
            <div className="flex items-center gap-2 bg-amber-50 text-amber-700 px-3 py-1.5 rounded-lg text-sm border border-amber-100">
                <Clock className="w-4 h-4" />
                <span className="font-semibold">{upcomingCount}</span> A vencer
            </div>
        </div>

        <div className="space-y-3">
            {displayList.length === 0 ? (
                <div className="text-center py-6 text-muted-foreground text-sm">
                    Nenhum pagamento pendente para este período.
                </div>
            ) : (
                displayList.map(item => {
                    const isOverdue = isBefore(parseISO(item.vencimento), today);
                    const itemDate = formatDate(item.vencimento);
                    
                    return (
                        <div key={item.id} className="flex items-center justify-between py-2 border-b last:border-0 border-dashed border-gray-100">
                            <div className="flex items-start gap-3 overflow-hidden">
                                <div className={`w-12 text-center text-xs font-bold py-1 rounded ${isOverdue ? 'bg-red-100 text-red-700' : 'bg-amber-100 text-amber-700'}`}>
                                    {itemDate}
                                </div>
                                <div className="min-w-0">
                                    <p className="text-sm font-medium truncate text-foreground">{item.descricao}</p>
                                    <p className="text-xs text-muted-foreground truncate">{item.finance_parties?.nome || 'Sem contato'}</p>
                                </div>
                            </div>
                            <div className={`text-sm font-bold whitespace-nowrap ${item.tipo === 'receita' ? 'text-emerald-600' : 'text-red-600'}`}>
                                {formatTransactionValue(item.valor)}
                            </div>
                        </div>
                    );
                })
            )}
        </div>
        
        {displayList.length > 0 && (
            <div className="mt-4 pt-2 border-t text-center">
                <Button variant="ghost" className="text-xs w-full h-8" asChild>
                    <Link to="/cliente/financeiro/lancamentos?status=aberto">
                        Ver todos pendentes <ArrowRight className="w-3 h-3 ml-1" />
                    </Link>
                </Button>
            </div>
        )}
      </CardContent>
    </Card>
  );
};

export default UpcomingPaymentsCard;
