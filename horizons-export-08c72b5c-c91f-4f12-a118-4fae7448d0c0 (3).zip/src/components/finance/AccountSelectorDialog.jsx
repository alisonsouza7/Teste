
import React, { useState, useEffect } from 'react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Check, PlusCircle, Search } from "lucide-react";
import { cn } from "@/lib/utils";
import { useFinanceTransactions } from '@/hooks/useFinanceTransactions';
import { Skeleton } from '@/components/ui/skeleton';

const AccountSelectorDialog = ({ open, onOpenChange, onSelectAccount, selectedAccountId }) => {
  const { accounts, loading: accountsLoading } = useFinanceTransactions();
  const [searchTerm, setSearchTerm] = useState('');
  const [filteredAccounts, setFilteredAccounts] = useState([]);

  useEffect(() => {
    if (accounts) {
      setFilteredAccounts(
        accounts.filter(account =>
          account.nome_conta.toLowerCase().includes(searchTerm.toLowerCase())
        )
      );
    }
  }, [accounts, searchTerm]);

  const handleSelect = (account) => {
    onSelectAccount(account);
    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[425px] p-0">
        <DialogHeader className="p-6 pb-4">
          <DialogTitle>Selecionar Conta</DialogTitle>
          <DialogDescription>
            Escolha uma conta para esta transação.
          </DialogDescription>
        </DialogHeader>
        <div className="px-6 py-4 border-t border-b">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Buscar conta..."
              className="pl-9"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
        </div>
        <ScrollArea className="h-[300px] px-6">
          {accountsLoading ? (
            <div className="space-y-2 py-2">
              {[1, 2, 3, 4, 5].map((i) => (
                <Skeleton key={i} className="h-10 w-full" />
              ))}
            </div>
          ) : filteredAccounts.length === 0 && searchTerm ? (
            <p className="text-center text-muted-foreground py-8">
              Nenhuma conta encontrada.
            </p>
          ) : (
            <div className="grid gap-2 py-2">
              {filteredAccounts.map((account) => (
                <Button
                  key={account.id}
                  variant="ghost"
                  className={cn(
                    "w-full justify-between px-3",
                    selectedAccountId === account.id && "bg-accent text-accent-foreground"
                  )}
                  onClick={() => handleSelect(account)}
                >
                  <span className="truncate">{account.nome_conta}</span>
                  {selectedAccountId === account.id && (
                    <Check className="ml-2 h-4 w-4 text-primary" />
                  )}
                </Button>
              ))}
            </div>
          )}
        </ScrollArea>
        <DialogFooter className="p-6 pt-4">
          <Button
            variant="outline"
            onClick={() => {
              // This is a placeholder. Real implementation would open a modal for creating a new account.
              console.log("Create new account functionality not implemented yet.");
              alert("🚧 This feature isn't implemented yet—but don't worry! You can request it in your next prompt! 🚀");
            }}
          >
            <PlusCircle className="mr-2 h-4 w-4" /> Nova Conta
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default AccountSelectorDialog;
