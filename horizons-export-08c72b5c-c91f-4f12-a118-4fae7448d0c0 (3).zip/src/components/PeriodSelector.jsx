import React, { useState, useEffect, useRef } from 'react';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { getPeriodDates } from '@/lib/periodHelpers';
import { cn } from '@/lib/utils';

const PeriodSelector = ({ onPeriodChange, className, initialType = 'monthly' }) => {
  const today = new Date();
  const [type, setType] = useState(initialType);
  const [year, setYear] = useState(today.getFullYear().toString());
  const [value, setValue] = useState(today.getMonth().toString()); // Month (0-11) or Quarter (1-4)
  
  // Ref to track previous values and prevent duplicate updates
  const prevValues = useRef({ type: null, startDate: null, endDate: null });

  // Generate year options (current +/- 5 years)
  const currentYear = today.getFullYear();
  const years = Array.from({ length: 11 }, (_, i) => (currentYear - 5 + i).toString());

  const months = [
    { value: '0', label: 'Janeiro' },
    { value: '1', label: 'Fevereiro' },
    { value: '2', label: 'Março' },
    { value: '3', label: 'Abril' },
    { value: '4', label: 'Maio' },
    { value: '5', label: 'Junho' },
    { value: '6', label: 'Julho' },
    { value: '7', label: 'Agosto' },
    { value: '8', label: 'Setembro' },
    { value: '9', label: 'Outubro' },
    { value: '10', label: 'Novembro' },
    { value: '11', label: 'Dezembro' },
  ];

  const quarters = [
    { value: '1', label: '1º Trimestre' },
    { value: '2', label: '2º Trimestre' },
    { value: '3', label: '3º Trimestre' },
    { value: '4', label: '4º Trimestre' },
  ];

  useEffect(() => {
    const { startDate, endDate } = getPeriodDates(type, year, value);
    
    // Only trigger change if values actually changed
    if (
      prevValues.current.type !== type ||
      prevValues.current.startDate !== startDate ||
      prevValues.current.endDate !== endDate
    ) {
      prevValues.current = { type, startDate, endDate };
      onPeriodChange({ type, startDate, endDate });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [type, year, value]);

  return (
    <div className={cn("flex flex-col sm:flex-row flex-wrap gap-2 items-start sm:items-center w-full sm:w-auto", className)}>
      {/* Period Type */}
      <Select value={type} onValueChange={(v) => {
        setType(v);
        // Reset value logic when switching types
        if (v === 'monthly') setValue(today.getMonth().toString());
        if (v === 'quarterly') setValue('1');
      }}>
        <SelectTrigger className="w-full sm:w-[140px]">
          <SelectValue placeholder="Período" />
        </SelectTrigger>
        <SelectContent>
          <SelectItem value="monthly">Mensal</SelectItem>
          <SelectItem value="quarterly">Trimestral</SelectItem>
          <SelectItem value="yearly">Anual</SelectItem>
          <SelectItem value="all">Todo o Período</SelectItem>
        </SelectContent>
      </Select>

      {/* Year Selector (visible for all except 'all') */}
      {type !== 'all' && (
        <div className="w-full sm:w-auto">
            <Select value={year} onValueChange={setYear}>
            <SelectTrigger className="w-full sm:w-[100px]">
                <SelectValue placeholder="Ano" />
            </SelectTrigger>
            <SelectContent>
                {years.map((y) => (
                <SelectItem key={y} value={y}>{y}</SelectItem>
                ))}
            </SelectContent>
            </Select>
        </div>
      )}

      {/* Month Selector */}
      {type === 'monthly' && (
        <div className="w-full sm:w-auto">
            <Select value={value} onValueChange={setValue}>
            <SelectTrigger className="w-full sm:w-[140px]">
                <SelectValue placeholder="Mês" />
            </SelectTrigger>
            <SelectContent>
                {months.map((m) => (
                <SelectItem key={m.value} value={m.value}>{m.label}</SelectItem>
                ))}
            </SelectContent>
            </Select>
        </div>
      )}

      {/* Quarter Selector */}
      {type === 'quarterly' && (
        <div className="w-full sm:w-auto">
            <Select value={value} onValueChange={setValue}>
            <SelectTrigger className="w-full sm:w-[140px]">
                <SelectValue placeholder="Trimestre" />
            </SelectTrigger>
            <SelectContent>
                {quarters.map((q) => (
                <SelectItem key={q.value} value={q.value}>{q.label}</SelectItem>
                ))}
            </SelectContent>
            </Select>
        </div>
      )}
    </div>
  );
};

export default PeriodSelector;