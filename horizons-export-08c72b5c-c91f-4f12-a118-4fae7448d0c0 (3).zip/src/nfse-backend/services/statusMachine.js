
/* global process, window */
import { createServiceRoleClient } from '../lib/supabaseServiceRole.js';

if (typeof window !== 'undefined') {
  throw new Error('Backend module StatusMachine loaded in browser');
}

const supabase = createServiceRoleClient();

const STATUS_TRANSITIONS = {
    'DRAFT': ['SIGNED', 'CANCELLED'],
    'SIGNED': ['TRANSMITTING', 'CANCELLED', 'ERROR'],
    'TRANSMITTING': ['AUTHORIZED', 'REJECTED', 'ERROR'],
    'AUTHORIZED': ['CANCELLED'],
    'REJECTED': ['DRAFT', 'SIGNED'],
    'ERROR': ['SIGNED', 'DRAFT'],
    'CANCELLED': []
};

export const isValidTransition = (fromStatus, toStatus) => {
    const allowed = STATUS_TRANSITIONS[fromStatus] || [];
    return allowed.includes(toStatus);
};

export const updateDpsStatus = async (dpsId, newStatus, details = {}) => {
    const { data: current } = await supabase
        .from('nfse_dps')
        .select('status') // Removed attempts if not in schema, assuming it exists based on prompt
        .eq('id', dpsId)
        .single();

    if (!current) throw new Error(`DPS ${dpsId} not found`);

    const updates = { status: newStatus, updated_at: new Date() };

    if (newStatus === 'AUTHORIZED') {
        updates.chave_acesso = details.chaveAcesso;
        updates.response_xml_path = details.xmlNfsePath;
    }

    if (details.xmlRequestPath) updates.request_xml_path = details.xmlRequestPath;
    if (details.xmlResponsePath) updates.response_xml_path = details.xmlResponsePath;

    await supabase.from('nfse_dps').update(updates).eq('id', dpsId);
    
    // Audit Log
    supabase.from('nfse_audit_logs').insert({
        company_id: details.company_id, // Need company_id
        message: `Status change to ${newStatus}`,
        level: 'INFO',
        context: { from: current.status, to: newStatus, ...details }
    }).then();
};

export default { isValidTransition, updateDpsStatus };
