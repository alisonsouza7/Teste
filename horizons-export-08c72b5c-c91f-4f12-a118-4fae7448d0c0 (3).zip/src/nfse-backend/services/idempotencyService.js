
/* global process, window */
import { createServiceRoleClient } from '../lib/supabaseServiceRole.js';

if (typeof window !== 'undefined') {
  throw new Error('Backend module IdempotencyService loaded in browser');
}

const supabase = createServiceRoleClient();

export const checkIdempotency = async (company_id, idempotencyKey, operation, payload) => {
    if (!idempotencyKey) {
        return { isNew: true, request: null };
    }

    const { data: existing } = await supabase
        .from('nfse_requests')
        .select('*')
        .eq('company_id', company_id)
        .eq('idempotency_key', idempotencyKey)
        .single();

    if (existing) {
        return { isNew: false, request: existing };
    }

    const { data: newReq, error: insertError } = await supabase
        .from('nfse_requests')
        .insert({
            company_id,
            idempotency_key: idempotencyKey,
            operation,
            request_payload: payload,
            status: 'PROCESSING',
            created_by: company_id // Assuming company_id for simplicity or context user
        })
        .select()
        .single();

    if (insertError) {
        if (insertError.code === '23505') {
             const { data: retryExisting } = await supabase
                .from('nfse_requests')
                .select('*')
                .eq('company_id', company_id)
                .eq('idempotency_key', idempotencyKey)
                .single();
             return { isNew: false, request: retryExisting };
        }
        throw new Error(`Failed to create idempotency record: ${insertError.message}`);
    }

    return { isNew: true, request: newReq };
};

export const updateRequestStatus = async (requestId, status, responseSummary, relatedDpsId = null) => {
    const updates = {
        status,
        updated_at: new Date()
    };
    // response_summary missing in some schemas, skipping if not present in your specific setup, 
    // but assuming it's part of jsonb 'payload_normalizado' or similar if needed. 
    // Here we assume a flexible column or existing payload update.

    await supabase.from('nfse_requests').update(updates).eq('id', requestId);
};

export default { checkIdempotency, updateRequestStatus };
