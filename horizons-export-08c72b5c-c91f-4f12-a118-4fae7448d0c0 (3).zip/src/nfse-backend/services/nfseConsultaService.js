
/* global process, window */
import { createServiceRoleClient } from '../lib/supabaseServiceRole.js';
import { checkDpsStatus, getNfseByAccessKey } from '../http/nfseHttpClient.js';
import { updateDpsStatus } from './statusMachine.js';
import { saveNfseXml, getXmlPreview } from './storageService.js';

if (typeof window !== 'undefined') {
  throw new Error('Backend module NfseConsultaService loaded in browser');
}

const supabase = createServiceRoleClient();

const wait = (ms) => new Promise(res => setTimeout(res, ms));

export const pollUntilAuthorized = async (company_id, dps_id, maxAttempts = 5) => {
    let attempts = 0;
    while (attempts < maxAttempts) {
        attempts++;
        try {
            const { status, data } = await checkDpsStatus(company_id, dps_id);
            if (status === 200) {
                return { status: 'AUTHORIZED', rawResponse: data };
            } else if (status === 202) {
                await wait(2000);
                continue;
            } else {
                return { status: 'ERROR', rawResponse: data };
            }
        } catch (e) {
            await wait(2000);
        }
    }
    throw new Error('Timeout waiting for authorization');
};

export const fetchNfseXml = async (company_id, chaveAcesso, dpsId) => {
    const { data: xml } = await getNfseByAccessKey(company_id, chaveAcesso);
    const path = await saveNfseXml(company_id, chaveAcesso, xml);
    const preview = await getXmlPreview(path);
    
    if (dpsId) {
        await updateDpsStatus(dpsId, 'AUTHORIZED', {
            company_id,
            chaveAcesso,
            xmlNfsePath: path
        });
    }

    return { xml, path, preview };
};

export const consultarNfsePorDps = async (company_id, dps_id) => {
    const result = await pollUntilAuthorized(company_id, dps_id);
    
    if (result.status === 'AUTHORIZED') {
        const chaveMock = `CHAVE_MOCK_${Date.now()}`; 
        const xmlResult = await fetchNfseXml(company_id, chaveMock, dps_id);
        
        return {
            status: 'AUTHORIZED',
            chaveAcesso: chaveMock,
            nfseXmlPath: xmlResult.path,
            preview: xmlResult.preview
        };
    }
    
    return { status: result.status };
};

export default { pollUntilAuthorized, fetchNfseXml, consultarNfsePorDps };
