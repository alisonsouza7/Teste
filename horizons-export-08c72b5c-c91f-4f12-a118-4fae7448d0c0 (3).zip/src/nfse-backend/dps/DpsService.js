

/* global process, window */
import { buildDpsXml } from './DpsBuilder.jsx';
import { validateXmlAgainstXsd } from './DpsValidator.js';
import { signXml } from '../xml/XmlSigner.js';
import { validateStructure } from '../xml/XmlVerifier.js';
import { validateServerEnv } from '../utils/env.server.js';

if (typeof window !== 'undefined') {
  throw new Error('Backend module DpsService loaded in browser');
}

export const createSignedDps = async ({ company_id, payload }) => {
  const env = validateServerEnv();

  const { xml: rawXml, referenceId, serie, nDPS } = await buildDpsXml(payload, company_id);

  const preValidation = validateXmlAgainstXsd(rawXml, env.nfseDpsXsdPath);
  if (!preValidation.ok) {
    throw new Error(`Pre-Sign Validation Failed: ${JSON.stringify(preValidation.errors)}`);
  }

  const { signedXml, thumbprint } = await signXml({
    company_id,
    xml: rawXml,
    referenceId
  });

  const structureValidation = validateStructure(signedXml, referenceId);
  if (!structureValidation.ok) {
    throw new Error(`Signature Structure Failed: ${structureValidation.errors.join(', ')}`);
  }

  const postValidation = validateXmlAgainstXsd(signedXml, env.nfseDpsXsdPath);
  if (!postValidation.ok) {
    throw new Error(`Post-Sign Validation Failed: ${JSON.stringify(postValidation.errors)}`);
  }

  return {
    referenceId,
    serie,
    nDPS,
    xsdValidation: { pre: preValidation, post: postValidation },
    signature: { ok: true, thumbprint },
    signedXml
  };
};

export default { createSignedDps };
