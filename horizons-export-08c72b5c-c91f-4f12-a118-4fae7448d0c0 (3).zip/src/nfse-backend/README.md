
# NFS-e Backend Module

## ⚠️ STRICTLY BACKEND ONLY ⚠️

This directory (`src/nfse-backend`) contains server-side logic, secret management, and cryptographic operations.

**IT MUST NEVER BE IMPORTED IN FRONTEND CODE.**

Doing so will break the build or expose sensitive credentials (private keys, service role keys) to the client browser.

### Deployment

These modules are designed to run in:
1.  **Supabase Edge Functions** (Recommended)
2.  External Node.js Server (e.g., Express, NestJS)

### Directory Structure

-   `utils/env.server.js`: Validates backend environment variables.
-   `lib/supabaseServiceRole.js`: Admin-privileged Supabase client.
-   `certificates/`: PFX handling and encryption.
-   `xml/`: XML Signing (xmldsig) and verification.
-   `dps/`: DPS construction, validation, and serialization.
-   `http/`: mTLS HTTP client for communicating with Sefin.

### Required Environment Variables

These variables must be set in the Backend environment (not `.env` for Vite):

-   `SUPABASE_URL`
-   `SUPABASE_SERVICE_ROLE_KEY`
-   `CERT_ENCRYPTION_KEY`
-   `NFSE_CERT_BUCKET`
