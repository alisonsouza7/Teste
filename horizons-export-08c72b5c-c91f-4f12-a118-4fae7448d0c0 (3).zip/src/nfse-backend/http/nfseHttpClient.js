
/* global process, window */
import https from 'https';
import axios from 'axios';
import CertificateManager from '../certificates/certificateManager.js';
import { validateServerEnv } from '../utils/env.server.js';

if (typeof window !== 'undefined') {
  throw new Error('Backend module NfseHttpClient loaded in browser');
}

export const createNfseHttpClient = async (company_id) => {
  const env = validateServerEnv();
  
  const certData = await CertificateManager.getActiveCertificate(company_id);
  if (!certData) throw new Error('No certificate found');
  
  const agent = new https.Agent({
    pfx: certData.pfxBuffer,
    passphrase: certData.password,
    rejectUnauthorized: false 
  });

  const client = axios.create({
      baseURL: env.nfseApiBase,
      httpsAgent: agent,
      timeout: 30000,
      headers: {
          'Content-Type': 'application/xml',
          'Accept': 'application/xml'
      }
  });

  return client;
};

const wait = (ms) => new Promise(res => setTimeout(res, ms));

export const sendWithRetry = async (client, method, url, data, maxRetries = 3) => {
    let attempt = 0;
    while (attempt < maxRetries) {
        try {
            const response = await client.request({ method, url, data });
            return response;
        } catch (error) {
            attempt++;
            const isTransient = 
                error.code === 'ECONNRESET' || 
                error.code === 'ETIMEDOUT' ||
                (error.response && error.response.status >= 502 && error.response.status <= 504);

            if (!isTransient || attempt >= maxRetries) {
                throw error;
            }
            const delay = Math.pow(2, attempt - 1) * 1000;
            console.warn(`[NfseClient] Transient error. Retrying in ${delay}ms...`);
            await wait(delay);
        }
    }
};

export const sendDpsToNfse = async (company_id, signedXml) => {
    const client = await createNfseHttpClient(company_id);
    return sendWithRetry(client, 'POST', '/nfse', signedXml);
};

export const checkDpsStatus = async (company_id, dpsId) => {
    const client = await createNfseHttpClient(company_id);
    return sendWithRetry(client, 'HEAD', `/dps/${dpsId}`);
};

export const getNfseByAccessKey = async (company_id, chaveAcesso) => {
    const client = await createNfseHttpClient(company_id);
    return sendWithRetry(client, 'GET', `/nfse/${chaveAcesso}`);
};

export default { createNfseHttpClient, sendWithRetry, sendDpsToNfse, checkDpsStatus, getNfseByAccessKey };
