
/* global process, window */
import { createServiceRoleClient } from '../lib/supabaseServiceRole.js';

if (typeof window !== 'undefined') {
  throw new Error('Backend module NfseWorker loaded in browser');
}

const supabase = createServiceRoleClient();

export const processQueue = async () => {
    // Placeholder worker logic
    console.log("Processing NFSe Queue...");
};

export default { processQueue };
