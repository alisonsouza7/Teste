
/* global process, window */
/**
 * Server-side Environment Configuration
 * 
 * BACKEND ONLY - SECRETS ALLOWED
 * This file MUST NOT be bundled in the browser.
 */

if (typeof window !== 'undefined') {
  throw new Error('SECURITY VIOLATION: env.server.js cannot be used in browser environment.');
}

export const validateServerEnv = () => {
  let env;
  try {
    env = process.env;
  } catch (e) {
    throw new Error('CRITICAL SERVER ERROR: Node.js process.env is not available.');
  }

  const required = [
    'SUPABASE_URL', 
    'SUPABASE_SERVICE_ROLE_KEY', 
    'CERT_ENCRYPTION_KEY'
  ];
  
  const missing = [];
  required.forEach(key => {
    if (!env[key]) {
      missing.push(key);
    }
  });

  if (missing.length > 0) {
    throw new Error(`[ServerEnv] Missing required environment variables: ${missing.join(', ')}`);
  }

  return {
    isValid: true,
    supabaseUrl: env.SUPABASE_URL,
    supabaseServiceRoleKey: env.SUPABASE_SERVICE_ROLE_KEY,
    certEncryptionKey: env.CERT_ENCRYPTION_KEY,
    
    // NFSe Config
    nfseEnv: env.NFSE_ENV || 'prodrestrita',
    nfseApiBase: env.NFSE_API_BASE || 'https://sefin.nfse.gov.br/api',
    nfseCertBucket: env.NFSE_CERT_BUCKET || 'nfse-certs',
    nfseDpsVersao: env.NFSE_DPS_VERSAO || '1.01',
    nfseDpsXsdPath: env.NFSE_DPS_XSD_PATH || '/app/xsd/DPS_v1.01.xsd',
    nfseXsdDir: env.NFSE_XSD_DIR || '/app/xsd'
  };
};

export default { validateServerEnv };
