
/* global process, window, Buffer */
import forge from 'node-forge';
import { Buffer } from 'buffer';
import { validateServerEnv } from '../utils/env.server.js';

if (typeof window !== 'undefined') {
  throw new Error('Backend module CryptoVault loaded in browser');
}

let cachedKeyBuffer = null;

export const getKey = () => {
  if (cachedKeyBuffer) return cachedKeyBuffer;
  const { certEncryptionKey } = validateServerEnv();
  
  if (/^[0-9a-fA-F]{64}$/.test(certEncryptionKey)) {
    cachedKeyBuffer = Buffer.from(certEncryptionKey, 'hex');
  } else {
    cachedKeyBuffer = Buffer.from(certEncryptionKey, 'base64');
  }
  return cachedKeyBuffer;
};

export const encrypt = (plainText) => {
  if (!plainText) throw new Error('Encryption Error: Empty input');
  const key = getKey();
  const iv = forge.random.getBytesSync(12);
  const cipher = forge.cipher.createCipher('AES-GCM', forge.util.createBuffer(key));
  cipher.start({ iv: forge.util.createBuffer(iv), tagLength: 128 });
  cipher.update(forge.util.createBuffer(plainText, 'utf8'));
  cipher.finish();
  const encrypted = cipher.output.getBytes();
  const tag = cipher.mode.tag.getBytes();
  return forge.util.encode64(iv + tag + encrypted);
};

export const decrypt = (payloadBase64) => {
  if (!payloadBase64) throw new Error('Decryption Error: Empty input');
  const key = getKey();
  const raw = forge.util.decode64(payloadBase64);
  const iv = raw.substring(0, 12);
  const tag = raw.substring(12, 28);
  const ciphertext = raw.substring(28);
  const decipher = forge.cipher.createDecipher('AES-GCM', forge.util.createBuffer(key));
  decipher.start({ iv: forge.util.createBuffer(iv), tagLength: 128, tag: forge.util.createBuffer(tag) });
  decipher.update(forge.util.createBuffer(ciphertext));
  if (!decipher.finish()) throw new Error('Integrity check failed');
  return decipher.output.toString('utf8');
};

export default { encrypt, decrypt, getKey };
