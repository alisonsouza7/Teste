
/* global process, window */
import { sendWithRetry, createNfseHttpClient } from '../../http/nfseHttpClient.js';

if (typeof window !== 'undefined') {
  throw new Error('Backend module NacionalAdnAdapter loaded in browser');
}

export default {
    async sendDps(company_id, signedXml, context) {
        const client = await createNfseHttpClient(company_id);
        client.defaults.baseURL = context.baseURL;
        return sendWithRetry(client, 'POST', '/nfse', signedXml);
    },

    async checkDps(company_id, dpsId, context) {
        const client = await createNfseHttpClient(company_id);
        client.defaults.baseURL = context.baseURL;
        return sendWithRetry(client, 'GET', `/dps/${dpsId}`);
    },

    async getNfse(company_id, chaveAcesso, context) {
        const client = await createNfseHttpClient(company_id);
        client.defaults.baseURL = context.baseURL;
        return sendWithRetry(client, 'GET', `/nfse/${chaveAcesso}`);
    }
};
