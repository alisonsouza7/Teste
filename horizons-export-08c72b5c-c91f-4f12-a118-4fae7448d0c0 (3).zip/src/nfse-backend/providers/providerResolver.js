
/* global process, window */
import { createServiceRoleClient } from '../lib/supabaseServiceRole.js';
import { validateServerEnv } from '../utils/env.server.js';

if (typeof window !== 'undefined') {
  throw new Error('Backend module ProviderResolver loaded in browser');
}

const supabase = createServiceRoleClient();

export const resolveProvider = async ({ company_id, cLocEmi }) => {
    const { data: companySettings } = await supabase
        .from('nfse_company_settings')
        .select('*')
        .eq('company_id', company_id)
        .single();
    
    const targetLoc = companySettings?.c_loc_emi || cLocEmi;
    if (!targetLoc) throw new Error('Location (cLocEmi) is required to resolve provider');

    const { data: config, error: configError } = await supabase
        .from('nfse_municipios_config')
        .select('*')
        .eq('codigo_ibge', targetLoc)
        .single();

    if (configError || !config) {
        throw new Error(`Municipality ${targetLoc} not supported yet.`);
    }

    const { data: caps } = await supabase
        .from('nfse_provider_capabilities')
        .select('*')
        .eq('provider_code', config.provider_code)
        .single();

    const serverEnv = validateServerEnv();
    const env = serverEnv.nfseEnv || 'homolog';

    const baseURL = (env === 'prod' || env === 'producao') 
        ? config.api_url_prod 
        : config.api_url_homolog;

    return {
        provider_code: config.provider_code,
        baseURL,
        municipioConfig: config,
        providerCaps: caps,
        companySettings
    };
};

export default { resolveProvider };
