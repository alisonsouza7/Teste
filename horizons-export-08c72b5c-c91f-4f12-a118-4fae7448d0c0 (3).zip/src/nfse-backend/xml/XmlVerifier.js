
/* global process, window */
import { DOMParser } from '@xmldom/xmldom';
import xpath from 'xpath';

if (typeof window !== 'undefined') {
  throw new Error('Backend module XmlVerifier loaded in browser');
}

export const validateStructure = (xml, referenceId) => {
    try {
        const doc = new DOMParser().parseFromString(xml, 'text/xml');
        const select = xpath.useNamespaces({ 
            ds: 'http://www.w3.org/2000/09/xmldsig#',
            nfse: 'http://www.sped.fazenda.gov.br/nfse' 
        });

        const signature = select('//ds:Signature', doc);
        if (!signature || signature.length === 0) {
            return { ok: false, errors: ['Signature element missing'] };
        }

        const ref = select(`//*[@Id='${referenceId}']`, doc);
        if (!ref || ref.length === 0) {
             return { ok: false, errors: [`Reference ID ${referenceId} not found in DOM`] };
        }

        return { ok: true };
    } catch (e) {
        return { ok: false, errors: [e.message] };
    }
};

export default { validateStructure };
