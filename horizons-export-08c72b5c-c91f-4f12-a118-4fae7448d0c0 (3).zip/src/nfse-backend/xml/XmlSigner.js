
/* global process, window, Buffer */
import { SignedXml } from 'xml-crypto';
import forge from 'node-forge';
import { Buffer } from 'buffer';
import CertificateManager from '../certificates/certificateManager.js';
import { validateServerEnv } from '../utils/env.server.js';

if (typeof window !== 'undefined') {
  throw new Error('Backend module XmlSigner loaded in browser');
}

export const signXml = async ({ company_id, xml, referenceId }) => {
  const env = validateServerEnv();

  // 1. Get Certificate
  const certData = await CertificateManager.getActiveCertificate(company_id);
  if (!certData) throw new Error(`No active certificate found for company ${company_id}`);
  
  const { pfxBuffer, password, meta } = certData;

  // 2. Extract Key/Cert
  const pfxDer = forge.util.createBuffer(Buffer.from(pfxBuffer).toString('binary'));
  const p12 = forge.pkcs12.pkcs12FromAsn1(forge.asn1.fromDer(pfxDer), false, password);
  
  const keyBag = p12.getBags({ bagType: forge.pki.oids.pkcs8ShroudedKeyBag })[forge.pki.oids.pkcs8ShroudedKeyBag]?.[0];
  const certBag = p12.getBags({ bagType: forge.pki.oids.certBag })[forge.pki.oids.certBag]?.[0];
  
  if (!keyBag || !certBag) throw new Error('Invalid PFX: Missing Key or Cert');

  const privateKeyPem = forge.pki.privateKeyToPem(keyBag.key);
  const certPem = forge.pki.certificateToPem(certBag.cert);
  
  // Clean PEM header/footer for XMLDSIG
  const certBase64 = certPem
    .replace('-----BEGIN CERTIFICATE-----', '')
    .replace('-----END CERTIFICATE-----', '')
    .replace(/\r/g, '')
    .replace(/\n/g, '');

  // 3. Configure SignedXml
  const sig = new SignedXml();
  
  sig.signatureAlgorithm = "http://www.w3.org/2001/04/xmldsig-more#rsa-sha256";
  sig.digestAlgorithm = "http://www.w3.org/2001/04/xmlenc#sha256";
  sig.canonicalizationAlgorithm = "http://www.w3.org/2001/10/xml-exc-c14n#";

  sig.addReference({
    xpath: `//*[@Id='${referenceId}' or @id='${referenceId}']`,
    transforms: [
      "http://www.w3.org/2000/09/xmldsig#enveloped-signature",
      "http://www.w3.org/2001/10/xml-exc-c14n#"
    ],
    digestAlgorithm: "http://www.w3.org/2001/04/xmlenc#sha256",
    uri: `#${referenceId}`
  });

  sig.signingKey = privateKeyPem;
  sig.keyInfoProvider = {
    getKeyInfo: () => `<ds:X509Data><ds:X509Certificate>${certBase64}</ds:X509Certificate></ds:X509Data>`
  };

  // 4. Compute Signature
  sig.computeSignature(xml, {
    location: { reference: "/*[local-name()='DPS']", action: 'append' }
  });

  return {
    signedXml: sig.getSignedXml(),
    thumbprint: meta.thumbprint
  };
};

export default { signXml };
