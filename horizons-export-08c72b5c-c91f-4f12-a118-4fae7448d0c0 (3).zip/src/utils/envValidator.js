
import { validateClientEnv } from './env.client';

/**
 * @deprecated Use src/utils/env.client.js instead
 */
export const validateEnv = validateClientEnv;

export default validateClientEnv;
