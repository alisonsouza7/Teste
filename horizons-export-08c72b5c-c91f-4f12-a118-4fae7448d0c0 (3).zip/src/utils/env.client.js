
/**
 * Client-side Environment Configuration
 * 
 * FRONTEND ONLY - NO SECRETS
 * This file is safe to bundle in the browser.
 */

export const validateClientEnv = () => {
  const env = import.meta.env || {};

  // Only validate non-sensitive frontend variables
  // VITE_SUPABASE_SERVICE_ROLE_KEY is strictly optional on client
  const required = ['VITE_SUPABASE_URL', 'VITE_SUPABASE_ANON_KEY'];
  const missing = [];

  required.forEach(key => {
    if (!env[key]) {
      missing.push(key);
    }
  });

  if (missing.length > 0) {
    console.warn(`⚠️ [ClientEnv] Missing required environment variables: ${missing.join(', ')}`);
  }

  return {
    isValid: missing.length === 0,
    missing,
    supabaseUrl: env.VITE_SUPABASE_URL,
    supabaseAnonKey: env.VITE_SUPABASE_ANON_KEY
  };
};

export default { validateClientEnv };
