
import React from "react";
import ReactDOM from "react-dom/client";
import App from "./App.jsx";
import "./index.css";
import { validateClientEnv } from "@/lib/env.client";

// Early validation of Client Environment
validateClientEnv();

// CRITICAL: Ensure no backend modules are imported here.
// src/lib/supabaseServiceRole.js is explicitly excluded.

ReactDOM.createRoot(document.getElementById("root")).render(
  <App />
);
