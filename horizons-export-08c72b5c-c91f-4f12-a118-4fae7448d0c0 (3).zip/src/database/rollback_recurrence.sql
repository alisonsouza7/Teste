-- Rollback Script for Recurring Transactions Feature
-- WARNING: This will delete all recurrence rules and remove the link from transactions.
-- Use this only if you need to completely revert the feature.

BEGIN;

-- 1. Drop foreign key from finance_transactions
-- This removes the constraint linking transactions to recurrence rules
ALTER TABLE public.finance_transactions 
DROP CONSTRAINT IF EXISTS finance_transactions_recurrence_id_fkey;

-- 2. Drop column from finance_transactions
-- This removes the recurrence_id column itself
ALTER TABLE public.finance_transactions 
DROP COLUMN IF EXISTS recurrence_id;

-- 3. Drop the recurrences table
-- This deletes all recurrence configurations and history of rules
DROP TABLE IF EXISTS public.finance_recurrences;

COMMIT;