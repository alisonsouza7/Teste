
import { useState, useEffect } from 'react';
import { supabase } from '@/lib/customSupabaseClient';
import { useCompany } from '@/contexts/CompanyContext';
import { useToast } from '@/components/ui/use-toast';

export const useProjects = () => {
  const [projects, setProjects] = useState([]);
  const [loading, setLoading] = useState(true);
  const { selectedCompany } = useCompany();
  const { toast } = useToast();

  useEffect(() => {
    if (!selectedCompany?.id) {
        setLoading(false);
        return;
    }

    const fetchProjects = async () => {
      setLoading(true);
      const { data, error } = await supabase
        .from('task_projects')
        .select('*')
        .eq('company_id', selectedCompany.id)
        .order('created_at', { ascending: false });

      if (error) {
        console.error('Error fetching projects:', error);
        toast({
          title: "Erro ao carregar projetos",
          description: error.message,
          variant: "destructive"
        });
      } else {
        setProjects(data || []);
      }
      setLoading(false);
    };

    fetchProjects();

    const subscription = supabase
      .channel(`projects:${selectedCompany.id}`)
      .on('postgres_changes', 
        { event: '*', schema: 'public', table: 'task_projects', filter: `company_id=eq.${selectedCompany.id}` }, 
        (payload) => {
          if (payload.eventType === 'INSERT') {
            setProjects(prev => [payload.new, ...prev]);
          } else if (payload.eventType === 'UPDATE') {
            setProjects(prev => prev.map(p => p.id === payload.new.id ? payload.new : p));
          } else if (payload.eventType === 'DELETE') {
            setProjects(prev => prev.filter(p => p.id !== payload.old.id));
          }
      })
      .subscribe();

    return () => {
      subscription.unsubscribe();
    };
  }, [selectedCompany?.id, toast]);

  const createProject = async (projectData) => {
    if (!selectedCompany?.id) return;
    const { data, error } = await supabase
      .from('task_projects')
      .insert([{ ...projectData, company_id: selectedCompany.id }])
      .select()
      .single();

    if (error) throw error;
    return data;
  };

  const updateProject = async (id, updates) => {
    const { data, error } = await supabase
      .from('task_projects')
      .update(updates)
      .eq('id', id)
      .select()
      .single();

    if (error) throw error;
    return data;
  };

  const deleteProject = async (id) => {
    const { error } = await supabase
      .from('task_projects')
      .delete()
      .eq('id', id);

    if (error) throw error;
  };

  return { projects, loading, createProject, updateProject, deleteProject };
};
