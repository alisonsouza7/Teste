
import { useState, useEffect } from 'react';
import { supabase } from '@/lib/customSupabaseClient';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { useToast } from '@/components/ui/use-toast';

export const usePomodoro = () => {
  const [sessions, setSessions] = useState([]);
  const [loading, setLoading] = useState(true);
  const { user } = useAuth();
  const { toast } = useToast();

  useEffect(() => {
    if (!user?.id) {
        setLoading(false);
        return;
    }

    const fetchSessions = async () => {
      setLoading(true);
      // Fetch today's sessions
      const today = new Date();
      today.setHours(0, 0, 0, 0);

      const { data, error } = await supabase
        .from('pomodoro_sessions')
        .select('*, task:tasks(title)')
        .eq('user_id', user.id)
        .gte('completed_at', today.toISOString())
        .order('completed_at', { ascending: false });

      if (error) {
        console.error('Error fetching pomodoro sessions:', error);
      } else {
        setSessions(data || []);
      }
      setLoading(false);
    };

    fetchSessions();
  }, [user?.id]);

  const saveSession = async ({ taskId, durationMinutes, notes }) => {
    if (!user?.id) return;

    const { data, error } = await supabase
      .from('pomodoro_sessions')
      .insert([{
        user_id: user.id,
        task_id: taskId,
        duration_minutes: durationMinutes,
        completed_at: new Date().toISOString(),
        notes
      }])
      .select()
      .single();

    if (error) {
        toast({ title: 'Erro ao salvar sessão', variant: 'destructive' });
        throw error;
    }

    // Refresh local state optimistically
    setSessions(prev => [data, ...prev]);
    return data;
  };

  const getTodayStats = () => {
      const totalSessions = sessions.length;
      const totalMinutes = sessions.reduce((acc, curr) => acc + (curr.duration_minutes || 0), 0);
      
      // Simple heuristic for "focus score" based on completed sessions vs goal (e.g. 8 per day)
      const focusScore = Math.min(100, Math.round((totalSessions / 8) * 100));

      return { totalSessions, totalMinutes, focusScore };
  };

  return { sessions, loading, saveSession, getTodayStats };
};
