
import { useState, useEffect } from 'react';
import { supabase } from '@/lib/customSupabaseClient';
import { useCompany } from '@/contexts/CompanyContext';

export const useTags = () => {
  const [tags, setTags] = useState([]);
  const [loading, setLoading] = useState(true);
  const { selectedCompany } = useCompany();

  useEffect(() => {
    if (!selectedCompany?.id) return;

    const fetchTags = async () => {
      const { data, error } = await supabase
        .from('task_tags')
        .select('*')
        .eq('company_id', selectedCompany.id)
        .order('name');
      
      if (!error) setTags(data || []);
      setLoading(false);
    };

    fetchTags();

    const sub = supabase.channel(`tags:${selectedCompany.id}`)
        .on('postgres_changes', { event: '*', schema: 'public', table: 'task_tags', filter: `company_id=eq.${selectedCompany.id}` }, (payload) => {
             if (payload.eventType === 'INSERT') setTags(prev => [...prev, payload.new].sort((a,b) => a.name.localeCompare(b.name)));
             if (payload.eventType === 'UPDATE') setTags(prev => prev.map(t => t.id === payload.new.id ? payload.new : t));
             if (payload.eventType === 'DELETE') setTags(prev => prev.filter(t => t.id !== payload.old.id));
        })
        .subscribe();

    return () => sub.unsubscribe();
  }, [selectedCompany?.id]);

  const createTag = async (name, color) => {
    if (!selectedCompany) return;
    const { data, error } = await supabase.from('task_tags').insert([{ company_id: selectedCompany.id, name, color }]).select().single();
    if (error) throw error;
    return data;
  };

  return { tags, loading, createTag };
};
