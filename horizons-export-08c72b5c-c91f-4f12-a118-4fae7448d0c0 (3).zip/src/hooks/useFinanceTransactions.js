
import { useState, useEffect, useCallback, useMemo } from 'react';
import { supabase } from '@/lib/customSupabaseClient';
import { useCompany } from '@/contexts/CompanyContext';
import { useToast } from '@/components/ui/use-toast';
import { addMonths, addYears, parseISO, format, isValid } from 'date-fns';

export const useFinanceTransactions = () => {
  // 1. Context Hooks
  const { selectedCompany } = useCompany();
  const { toast } = useToast();

  // 2. State Hooks
  const [transactions, setTransactions] = useState([]);
  const [categories, setCategories] = useState([]);
  const [accounts, setAccounts] = useState([]);
  const [parties, setParties] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [debouncedSearch, setDebouncedSearch] = useState('');

  const [filters, setFilters] = useState({
    startDate: '',
    endDate: '',
    status: 'all',
    categoryId: 'all',
    accountId: 'all',
    search: '',
    type: 'all'
  });

  const [sort, setSort] = useState({
    field: 'data_competencia',
    direction: 'desc'
  });

  // 3. Memoized Values
  const FILTER_KEY = useMemo(() => {
    if (!selectedCompany?.id) return null;
    return `finance-filters-${selectedCompany.id}`;
  }, [selectedCompany?.id]);

  // --- Helpers for Recurrence ---
  const mapFrequencyToDB = (freq) => {
    const map = {
      'mensal': 'monthly',
      'bimestral': 'bimonthly',
      'trimestral': 'quarterly',
      'semestral': 'semiannual',
      'anual': 'yearly'
    };
    return map[freq] || 'monthly';
  };

  const calculateNextExecution = (startDate, frequency) => {
    if (!startDate) return null;
    const date = typeof startDate === 'string' ? parseISO(startDate) : startDate;
    if (!isValid(date)) return null;

    switch (frequency) {
      case 'mensal': return format(addMonths(date, 1), 'yyyy-MM-dd');
      case 'bimestral': return format(addMonths(date, 2), 'yyyy-MM-dd');
      case 'trimestral': return format(addMonths(date, 3), 'yyyy-MM-dd');
      case 'semestral': return format(addMonths(date, 6), 'yyyy-MM-dd');
      case 'anual': return format(addYears(date, 1), 'yyyy-MM-dd');
      default: return format(addMonths(date, 1), 'yyyy-MM-dd');
    }
  };

  // 4. Callbacks & Auxiliary Creators
  const createCategory = useCallback(async (data) => {
    if (!selectedCompany?.id) return null;
    const payload = { ...data, company_id: selectedCompany.id };
    const { data: newCat, error } = await supabase.from('finance_chart_of_accounts').insert(payload).select().single();
    if (error) {
      toast({ variant: 'destructive', title: 'Erro ao criar categoria', description: error.message });
      throw error;
    }
    setCategories(prev => [...prev, newCat].sort((a,b) => a.nome_conta.localeCompare(b.nome_conta)));
    return newCat;
  }, [selectedCompany?.id, toast]);

  const createAccount = useCallback(async (data) => {
    if (!selectedCompany?.id) return null;
    const payload = { ...data, company_id: selectedCompany.id };
    const { data: newAcc, error } = await supabase.from('finance_accounts').insert(payload).select().single();
    if (error) {
      toast({ variant: 'destructive', title: 'Erro ao criar conta', description: error.message });
      throw error;
    }
    setAccounts(prev => [...prev, newAcc].sort((a,b) => a.nome_conta.localeCompare(b.nome_conta)));
    return newAcc;
  }, [selectedCompany?.id, toast]);

  const createParty = useCallback(async (data) => {
    if (!selectedCompany?.id) return null;
    const payload = { ...data, company_id: selectedCompany.id };
    const { data: newParty, error } = await supabase.from('finance_parties').insert(payload).select().single();
    if (error) {
      toast({ variant: 'destructive', title: 'Erro ao criar contato', description: error.message });
      throw error;
    }
    setParties(prev => [...prev, newParty].sort((a,b) => a.nome.localeCompare(b.nome)));
    return newParty;
  }, [selectedCompany?.id, toast]);


  const handleFilterChange = useCallback((key, value) => {
    setFilters(prev => ({ ...prev, [key]: value }));
  }, []);

  const handleResetFilters = useCallback(() => {
    setFilters({
      startDate: '',
      endDate: '',
      status: 'all',
      categoryId: 'all',
      accountId: 'all',
      search: '',
      type: 'all'
    });
    setDebouncedSearch('');
  }, []);

  const handleSortChange = useCallback((field) => {
    setSort(prev => ({
      field,
      direction: prev.field === field && prev.direction === 'desc' ? 'asc' : 'desc'
    }));
  }, []);

  const fetchTransactions = useCallback(async () => {
    if (!selectedCompany?.id) return;

    setLoading(true);
    setError(null);

    try {
      let query = supabase
        .from('finance_transactions')
        .select(`
          id,
          data_lancamento,
          data_competencia,
          descricao,
          valor,
          tipo,
          liquidado,
          data_liquidacao,
          vencimento,
          conta_id,
          categoria_id,
          party_id,
          transfer_group_id,
          recurrence_id,
          origem,
          criado_em,
          finance_accounts!inner(id, nome_conta, tipo, dia_fechamento, dia_vencimento),
          finance_chart_of_accounts(id, nome_conta, tipo),
          finance_parties(id, nome, documento, tipo)
        `)
        .eq('company_id', selectedCompany.id)
        .is('deleted_at', null);

      if (filters.startDate) query = query.gte('data_competencia', filters.startDate);
      if (filters.endDate) query = query.lte('data_competencia', filters.endDate);

      if (filters.status !== 'all') {
        query = query.eq('liquidado', filters.status === 'liquidado');
      }
      if (filters.categoryId !== 'all') query = query.eq('categoria_id', filters.categoryId);
      if (filters.accountId !== 'all') query = query.eq('conta_id', filters.accountId);
      if (filters.type !== 'all') query = query.eq('tipo', filters.type);

      if (debouncedSearch) query = query.ilike('descricao', `%${debouncedSearch}%`);

      const { data, error: fetchError } = await query;
      if (fetchError) throw fetchError;

      // Client-side sorting to handle joined fields, nulls, and consistent case-insensitivity
      const sortedData = [...(data || [])].sort((a, b) => {
        let valA, valB;

        // Map field to actual value
        switch(sort.field) {
          case 'data_competencia':
            valA = a.data_competencia;
            valB = b.data_competencia;
            break;
          case 'data_lancamento':
            valA = a.data_lancamento;
            valB = b.data_lancamento;
            break;
          case 'vencimento':
            valA = a.vencimento;
            valB = b.vencimento;
            break;
          case 'descricao':
            valA = a.descricao;
            valB = b.descricao;
            break;
          case 'valor':
            valA = Number(a.valor);
            valB = Number(b.valor);
            break;
          case 'liquidado':
            valA = a.liquidado ? 1 : 0;
            valB = b.liquidado ? 1 : 0;
            break;
          case 'party':
          case 'party_id':
            valA = a.finance_parties?.nome || '';
            valB = b.finance_parties?.nome || '';
            break;
          case 'categoria':
          case 'categoria_id':
            valA = a.finance_chart_of_accounts?.nome_conta || '';
            valB = b.finance_chart_of_accounts?.nome_conta || '';
            break;
          case 'conta':
          case 'conta_id':
            valA = a.finance_accounts?.nome_conta || '';
            valB = b.finance_accounts?.nome_conta || '';
            break;
          case 'origem':
            valA = a.origem || '';
            valB = b.origem || '';
            break;
          default:
            valA = a[sort.field];
            valB = b[sort.field];
        }

        // Handle null/undefined - push to bottom usually, or treat as empty string
        if (valA === null || valA === undefined) valA = '';
        if (valB === null || valB === undefined) valB = '';

        // Compare based on type
        let comparison = 0;
        if (typeof valA === 'number' && typeof valB === 'number') {
          comparison = valA - valB;
        } else if (typeof valA === 'string' && typeof valB === 'string') {
          comparison = valA.localeCompare(valB, 'pt-BR', { sensitivity: 'base' });
        } else if (typeof valA === 'boolean' && typeof valB === 'boolean') {
          comparison = (valA === valB) ? 0 : (valA ? 1 : -1);
        } else {
            // Fallback
            comparison = String(valA).localeCompare(String(valB));
        }

        return sort.direction === 'asc' ? comparison : -comparison;
      });

      setTransactions(sortedData);
    } catch (err) {
      console.error('Error fetching transactions:', err);
      setError(err);
      toast({
        variant: 'destructive',
        title: 'Erro ao buscar lançamentos',
        description: err?.message || 'Erro desconhecido'
      });
    } finally {
      setLoading(false);
    }
  }, [selectedCompany?.id, filters, debouncedSearch, sort, toast]);

  const liquidateTransaction = useCallback(async (transactionId) => {
    if (!transactionId) return { success: false, error: 'ID inválido' };

    try {
      const today = new Date().toISOString().split('T')[0];
      const { error } = await supabase
        .from('finance_transactions')
        .update({ liquidado: true, data_liquidacao: today })
        .eq('id', transactionId);

      if (error) throw error;

      toast({
        title: 'Sucesso',
        description: 'Transação liquidada com sucesso.',
        variant: 'default'
      });
      
      await fetchTransactions();
      return { success: true };
    } catch (err) {
      console.error('Error liquidating transaction:', err);
      toast({
        variant: 'destructive',
        title: 'Erro ao liquidar',
        description: err?.message || 'Erro desconhecido'
      });
      return { success: false, error: err };
    }
  }, [fetchTransactions, toast]);

  const fetchUpcomingPayments = useCallback(async () => {
    if (!selectedCompany?.id) return [];
    
    // Calculate date range: today to today + 30 days
    // But we also want overdue, so basically anything unliquidated with vencimento <= today + 30
    const next30Days = new Date();
    next30Days.setDate(next30Days.getDate() + 30);
    const dateLimit = next30Days.toISOString().split('T')[0];

    const { data, error } = await supabase
      .from('finance_transactions')
      .select('id, descricao, valor, vencimento, tipo, liquidado, finance_parties(nome)')
      .eq('company_id', selectedCompany.id)
      .eq('liquidado', false)
      .lte('vencimento', dateLimit)
      .is('deleted_at', null)
      .order('vencimento', { ascending: true });

    if (error) {
      console.error("Error fetching upcoming payments:", error);
      return [];
    }
    return data;
  }, [selectedCompany?.id]);

  const handleDeleteTransaction = useCallback(async (txOrId) => {
    try {
      const tx = typeof txOrId === 'object' ? txOrId : null;
      const id = typeof txOrId === 'string' ? txOrId : txOrId?.id;

      if (!id) throw new Error('ID inválido');

      const deleted_at = new Date().toISOString();

      if (tx?.tipo === 'transferencia' && tx?.transfer_group_id) {
        // Delete ALL transactions in this transfer group (both legs)
        const { error } = await supabase
          .from('finance_transactions')
          .update({ deleted_at })
          .eq('company_id', selectedCompany.id)
          .eq('transfer_group_id', tx.transfer_group_id);

        if (error) throw error;
      } else {
        const { error } = await supabase
          .from('finance_transactions')
          .update({ deleted_at })
          .eq('id', id);

        if (error) throw error;
      }

      toast({
        title: 'Sucesso',
        description: 'Lançamento removido com sucesso.'
      });

      await fetchTransactions();
    } catch (err) {
      console.error('Error deleting:', err);
      toast({
        variant: 'destructive',
        title: 'Erro ao excluir',
        description: err?.message || 'Erro desconhecido'
      });
    }
  }, [toast, fetchTransactions, selectedCompany?.id]);

  const updateTransaction = useCallback(async (id, updates) => {
    try {
      const { 
        is_recurring, 
        recurrence_frequency, 
        recurrence_start_date, 
        recurrence_end_date, 
        recurrence_installments,
        conta_origem_id,
        conta_destino_id,
        ...transactionUpdates 
      } = updates;

      const { data: currentTx } = await supabase
        .from('finance_transactions')
        .select('transfer_group_id, tipo, valor')
        .eq('id', id)
        .single();

      if (currentTx?.transfer_group_id) {
        const absVal = Math.abs(transactionUpdates.valor || currentTx.valor);
        
        const sharedUpdates = {
            data_competencia: transactionUpdates.data_competencia,
            vencimento: transactionUpdates.vencimento,
            descricao: transactionUpdates.descricao,
            liquidado: transactionUpdates.liquidado,
            data_liquidacao: transactionUpdates.data_liquidacao
        };
        
        await supabase
            .from('finance_transactions')
            .update(sharedUpdates)
            .eq('transfer_group_id', currentTx.transfer_group_id);

        const { data: legs } = await supabase
            .from('finance_transactions')
            .select('id, valor, conta_id')
            .eq('transfer_group_id', currentTx.transfer_group_id);

        if (legs && legs.length === 2) {
             const leg1 = legs[0];
             const leg2 = legs[1];
             
             const val1 = leg1.valor < 0 ? -absVal : absVal;
             const val2 = leg2.valor < 0 ? -absVal : absVal;

             let acc1 = leg1.conta_id;
             let acc2 = leg2.conta_id;

             if (conta_origem_id && conta_destino_id) {
                 if (leg1.valor < 0) { acc1 = conta_origem_id; } else { acc1 = conta_destino_id; }
                 if (leg2.valor < 0) { acc2 = conta_origem_id; } else { acc2 = conta_destino_id; }
             }

             await supabase.from('finance_transactions').update({ valor: val1, conta_id: acc1 }).eq('id', leg1.id);
             await supabase.from('finance_transactions').update({ valor: val2, conta_id: acc2 }).eq('id', leg2.id);
        }

      } else {
        const { error } = await supabase
          .from('finance_transactions')
          .update(transactionUpdates)
          .eq('id', id);

        if (error) throw error;
      }

      toast({
        title: 'Sucesso',
        description: 'Lançamento atualizado com sucesso.'
      });

      await fetchTransactions();
    } catch (err) {
      console.error('Error updating:', err);
      toast({
        variant: 'destructive',
        title: 'Erro ao atualizar',
        description: err?.message || 'Erro desconhecido'
      });
      throw err;
    }
  }, [toast, fetchTransactions, selectedCompany?.id]);

  const createTransaction = useCallback(async (payload) => {
    if (!selectedCompany?.id) throw new Error('Empresa não selecionada');

    try {
      const { 
        is_recurring, 
        recurrence_frequency, 
        recurrence_start_date, 
        recurrence_end_date, 
        recurrence_installments,
        conta_origem_id,
        conta_destino_id,
        ...transactionData 
      } = payload;

      const base = {
        company_id: selectedCompany.id,
        data_lancamento: transactionData.data_lancamento || new Date().toISOString().split('T')[0],
        data_competencia: transactionData.data_competencia || new Date().toISOString().split('T')[0],
        vencimento: transactionData.vencimento || transactionData.data_competencia || new Date().toISOString().split('T')[0],
        descricao: transactionData.descricao || '',
        liquidado: !!transactionData.liquidado,
        data_liquidacao: transactionData.liquidado ? (transactionData.data_liquidacao || transactionData.data_competencia) : null,
        origem: transactionData.origem || 'manual'
      };

      let createdTx = null;

      if (transactionData.tipo === 'transferencia') {
          const transferId = crypto.randomUUID();
          const absVal = Math.abs(Number(transactionData.valor));

          const sourceTx = {
             ...base,
             tipo: 'transferencia',
             valor: -absVal,
             conta_id: conta_origem_id,
             transfer_group_id: transferId
          };

          const destTx = {
             ...base,
             tipo: 'transferencia',
             valor: absVal,
             conta_id: conta_destino_id,
             transfer_group_id: transferId
          };

          const { data: txs, error } = await supabase.from('finance_transactions').insert([sourceTx, destTx]).select();
          if (error) throw error;
          createdTx = txs[0]; 

      } else {
          const normalTx = {
            ...base,
            tipo: transactionData.tipo || 'despesa',
            valor: transactionData.valor,
            conta_id: transactionData.conta_id,
            categoria_id: transactionData.categoria_id || null,
            party_id: transactionData.party_id || null,
          };

          const { data: tx, error } = await supabase
            .from('finance_transactions')
            .insert(normalTx)
            .select()
            .single();

          if (error) throw error;
          createdTx = tx;
      }

      if (is_recurring && createdTx) {
        const recurrenceType = mapFrequencyToDB(recurrence_frequency);
        const nextDate = calculateNextExecution(recurrence_start_date, recurrence_frequency);

        const { data: recData, error: recError } = await supabase.from('finance_recurrences').insert({
           company_id: selectedCompany.id,
           template_transaction_id: createdTx.id,
           recurrence_type: recurrenceType,
           interval_count: 1, 
           start_date: recurrence_start_date,
           end_date: recurrence_end_date || null,
           next_execution_date: nextDate,
           is_active: true,
           metadata: recurrence_installments ? { installments: recurrence_installments } : null
        }).select().single();

        if (recError) {
          console.error("Error creating recurrence:", recError);
          toast({ variant: 'warning', title: 'Atenção', description: 'Lançamento criado, mas falha ao configurar recorrência.' });
        } else {
           await supabase.from('finance_transactions')
             .update({ recurrence_id: recData.id })
             .eq('id', createdTx.id);
        }
      }

      toast({ title: 'Sucesso', description: 'Lançamento criado com sucesso.' });
      await fetchTransactions();
      return createdTx;
    } catch (err) {
      console.error('Error creating:', err);
      toast({
        variant: 'destructive',
        title: 'Erro ao criar',
        description: err?.message || 'Erro desconhecido'
      });
      throw err;
    }
  }, [selectedCompany?.id, toast, fetchTransactions]);

  const importTransactions = useCallback(async (importData) => {
    if (!selectedCompany?.id) return { successCount: 0, failedCount: 0, errors: [] };
    
    // Identify unique names from importData
    const newCategories = new Set();
    const newAccounts = new Set();
    const newParties = new Set();
    
    importData.forEach(row => {
      if (row.categoria_nome && !categories.some(c => c.nome_conta.toLowerCase() === row.categoria_nome.toLowerCase())) {
        newCategories.add(row.categoria_nome);
      }
      if (row.conta_nome && !accounts.some(a => a.nome_conta.toLowerCase() === row.conta_nome.toLowerCase())) {
        newAccounts.add(row.conta_nome);
      }
      if (row.party_nome && !parties.some(p => p.nome.toLowerCase() === row.party_nome.toLowerCase())) {
        newParties.add(row.party_nome);
      }
    });

    try {
      // Create missing Categories
      if (newCategories.size > 0) {
        const catsToCreate = Array.from(newCategories).map(name => ({
          company_id: selectedCompany.id,
          nome_conta: name,
          tipo: 'despesa', // Default to despesa if unknown, can be adjusted manually later
          grupo: 'Importados'
        }));
        const { error } = await supabase.from('finance_chart_of_accounts').insert(catsToCreate);
        if (error) throw new Error("Erro ao criar categorias: " + error.message);
      }

      // Create missing Accounts
      if (newAccounts.size > 0) {
        const accsToCreate = Array.from(newAccounts).map(name => ({
          company_id: selectedCompany.id,
          nome_conta: name,
          tipo: 'corrente',
          saldo_inicial: 0
        }));
        const { error } = await supabase.from('finance_accounts').insert(accsToCreate);
        if (error) throw new Error("Erro ao criar contas: " + error.message);
      }

      // Create missing Parties
      if (newParties.size > 0) {
        const partiesToCreate = Array.from(newParties).map(name => ({
          company_id: selectedCompany.id,
          nome: name,
          tipo: 'outro',
          documento: ''
        }));
        const { error } = await supabase.from('finance_parties').insert(partiesToCreate);
        if (error) throw new Error("Erro ao criar parceiros: " + error.message);
      }

      // Refetch all entities to get new IDs
      const [catsRes, accsRes, partyRes] = await Promise.all([
        supabase.from('finance_chart_of_accounts').select('id, nome_conta').eq('company_id', selectedCompany.id),
        supabase.from('finance_accounts').select('id, nome_conta').eq('company_id', selectedCompany.id),
        supabase.from('finance_parties').select('id, nome').eq('company_id', selectedCompany.id)
      ]);

      const allCats = catsRes.data || [];
      const allAccs = accsRes.data || [];
      const allParties = partyRes.data || [];

      // Map Transactions
      const transactionsToInsert = importData.map(row => {
        const catId = allCats.find(c => c.nome_conta.toLowerCase() === (row.categoria_nome || '').toLowerCase())?.id;
        const accId = allAccs.find(a => a.nome_conta.toLowerCase() === (row.conta_nome || '').toLowerCase())?.id;
        const partyId = allParties.find(p => p.nome.toLowerCase() === (row.party_nome || '').toLowerCase())?.id;

        // Skip if critical IDs missing (shouldn't happen if creation worked)
        if (!accId) return null; // Account is mandatory DB constraint usually

        return {
          company_id: selectedCompany.id,
          descricao: row.descricao || 'Importado sem descrição',
          valor: Math.abs(Number(row.valor) || 0),
          tipo: row.tipo || (Number(row.valor) < 0 ? 'despesa' : 'receita'),
          conta_id: accId,
          categoria_id: catId,
          party_id: partyId,
          liquidado: row.liquidado || row.status === 'liquidado',
          data_competencia: row.data_competencia || new Date().toISOString().split('T')[0],
          vencimento: row.vencimento || row.data_competencia || new Date().toISOString().split('T')[0],
          origem: 'importacao'
        };
      }).filter(Boolean);

      if (transactionsToInsert.length === 0) {
         return { successCount: 0, failedCount: importData.length, errors: ["Nenhuma transação válida para inserir."] };
      }

      const { error: insertError } = await supabase.from('finance_transactions').insert(transactionsToInsert);
      
      if (insertError) throw insertError;

      // Refresh data
      await fetchTransactions();

      return { successCount: transactionsToInsert.length, failedCount: importData.length - transactionsToInsert.length, errors: [] };

    } catch (err) {
      console.error("Import failed:", err);
      return { successCount: 0, failedCount: importData.length, errors: [err.message] };
    }
  }, [selectedCompany?.id, categories, accounts, parties, fetchTransactions]);

  // 5. Effects
  useEffect(() => {
    const timer = setTimeout(() => {
      setDebouncedSearch(filters.search || '');
    }, 300);
    return () => clearTimeout(timer);
  }, [filters.search]);

  useEffect(() => {
    if (!FILTER_KEY) return;
    const saved = localStorage.getItem(FILTER_KEY);
    if (!saved) return;
    try {
      const parsed = JSON.parse(saved);
      setFilters(prev => ({ ...prev, ...parsed }));
    } catch (err) {
      console.error('Failed to restore finance filters:', err);
    }
  }, [FILTER_KEY]);

  useEffect(() => {
    if (!FILTER_KEY) return;
    try {
      localStorage.setItem(FILTER_KEY, JSON.stringify(filters));
    } catch (err) {
      console.error('Failed to save finance filters:', err);
    }
  }, [FILTER_KEY, filters]);

  useEffect(() => {
    if (!selectedCompany?.id) return;

    const fetchAuxData = async () => {
      try {
        const [catsRes, accsRes, partyRes] = await Promise.all([
          supabase
            .from('finance_chart_of_accounts')
            .select('id, nome_conta, tipo, grupo')
            .eq('company_id', selectedCompany.id)
            .is('deleted_at', null)
            .order('nome_conta'),
          supabase
            .from('finance_accounts')
            .select('id, nome_conta, tipo, dia_fechamento, dia_vencimento')
            .eq('company_id', selectedCompany.id)
            .is('deleted_at', null)
            .order('nome_conta'),
          supabase
            .from('finance_parties')
            .select('id, nome, tipo, documento')
            .eq('company_id', selectedCompany.id)
            .is('deleted_at', null)
            .order('nome')
        ]);

        if (catsRes.error) throw catsRes.error;
        if (accsRes.error) throw accsRes.error;
        if (partyRes.error) throw partyRes.error;

        setCategories(catsRes.data || []);
        setAccounts(accsRes.data || []);
        setParties(partyRes.data || []);
      } catch (err) {
        console.error('Error fetching aux data:', err);
        toast({
          variant: 'destructive',
          title: 'Erro ao carregar dados',
          description: 'Não foi possível carregar categorias, contas e contatos.'
        });
      }
    };

    fetchAuxData();
  }, [selectedCompany?.id, toast]);

  useEffect(() => {
    fetchTransactions();
  }, [fetchTransactions]);

  // 6. Return
  const memoizedCategories = useMemo(() => categories, [categories]);
  const memoizedAccounts = useMemo(() => accounts, [accounts]);
  const memoizedParties = useMemo(() => parties, [parties]);

  return {
    transactions,
    categories: memoizedCategories,
    accounts: memoizedAccounts,
    parties: memoizedParties,
    loading,
    error,
    filters,
    sort,
    handlers: {
      onFilterChange: handleFilterChange,
      onResetFilters: handleResetFilters,
      onSortChange: handleSortChange,
      onDelete: handleDeleteTransaction,
      onUpdate: updateTransaction,
      onCreate: createTransaction,
      refresh: fetchTransactions,
      createCategory,
      createAccount,
      createParty,
      liquidateTransaction,
      fetchUpcomingPayments,
      importTransactions
    }
  };
};
