import { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/lib/customSupabaseClient';

export function useReportsData({ companyId, filters }) {
  // 1. State
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [transactions, setTransactions] = useState([]);

  // 2. Callbacks
  const fetchData = useCallback(async () => {
    if (!companyId) return;
    
    try {
      setLoading(true);
      setError(null);

      const dateField = filters.viewType === 'caixa' ? 'data_liquidacao' : 'data_competencia';
      
      let query = supabase
        .from('finance_transactions')
        .select(`
          *,
          categoria:finance_chart_of_accounts(nome_conta, grupo)
        `)
        .eq('company_id', companyId)
        .is('deleted_at', null);

      if (filters.startDate) query = query.gte(dateField, filters.startDate);
      if (filters.endDate) query = query.lte(dateField, filters.endDate);
      
      if (filters.viewType === 'caixa') {
        query = query.eq('liquidado', true);
      }

      const { data, error: err } = await query;

      if (err) throw err;
      setTransactions(data || []);
    } catch (e) {
      console.error("Error fetching report data:", e);
      setError(e);
    } finally {
      setLoading(false);
    }
  }, [companyId, filters.startDate, filters.endDate, filters.viewType]);

  // 3. Effects
  useEffect(() => {
    fetchData();
  }, [fetchData]);

  return {
    loading,
    error,
    transactions,
    meta: {},
    refetch: fetchData
  };
}