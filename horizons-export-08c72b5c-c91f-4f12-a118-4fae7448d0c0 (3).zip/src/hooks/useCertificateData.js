
import { useState, useCallback } from 'react';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { useToast } from '@/components/ui/use-toast';
import { 
  upload as uploadApi, 
  get as getMetadataApi, 
  deactivate as deactivateApi 
} from '@/nfse/api/certificados';
import PfxInspector from '@/nfse/certificates/pfxInspector';

export const useCertificateData = () => {
  const { user } = useAuth();
  const { toast } = useToast();
  
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const getCertificateData = useCallback(async (companyId) => {
    if (!companyId || !user) return;
    
    setLoading(true);
    setError(null);
    try {
      const response = await getMetadataApi({ 
        user, 
        userRole: user.app_metadata?.role, 
        companyId 
      });
      
      if (response.error) {
        // If it's just not found, we might not want to throw, but for now we handle it
        if (response.status !== 404) throw new Error(response.error);
        setData(null);
      } else {
        setData(response.data);
      }
    } catch (err) {
      console.error('Error fetching certificate:', err);
      setError(err);
    } finally {
      setLoading(false);
    }
  }, [user]);

  const testLocalCertificate = useCallback(async (file, password) => {
    setLoading(true);
    try {
      if (!file) throw new Error('Selecione um arquivo .pfx');
      if (!password) throw new Error('Digite a senha do certificado');

      const buffer = await file.arrayBuffer();
      
      // Use PfxInspector directly to validate
      const metadata = PfxInspector.inspectPfx(buffer, password);
      
      const now = new Date();
      const validTo = new Date(metadata.valid_to);
      
      if (validTo < now) {
        throw new Error(`Certificado expirado em ${validTo.toLocaleDateString()}`);
      }

      toast({
        title: 'Certificado Válido',
        description: `Válido até ${validTo.toLocaleDateString()}`,
      });

      return { success: true, metadata };
    } catch (err) {
      console.error('Certificate test error:', err);
      toast({
        variant: 'destructive',
        title: 'Certificado Inválido',
        description: err.message
      });
      return { success: false, error: err.message };
    } finally {
      setLoading(false);
    }
  }, [toast]);

  const uploadCertificate = useCallback(async (companyId, file, password) => {
    if (!companyId || !user) return;

    setLoading(true);
    try {
      const response = await uploadApi({
        user,
        userRole: user.app_metadata?.role,
        companyId,
        file,
        password
      });

      if (response.status === 200) {
        toast({
          title: 'Sucesso',
          description: 'Certificado instalado com sucesso!',
        });
        await getCertificateData(companyId);
        return true;
      } else {
        throw new Error(response.error || 'Falha ao instalar');
      }
    } catch (err) {
      console.error('Upload error:', err);
      toast({
        variant: 'destructive',
        title: 'Erro na Instalação',
        description: err.message || 'Falha ao instalar certificado.'
      });
      return false;
    } finally {
      setLoading(false);
    }
  }, [user, toast, getCertificateData]);

  const deactivateCertificate = useCallback(async (companyId) => {
    if (!companyId || !user) return;

    setLoading(true);
    try {
      const response = await deactivateApi({
        user,
        userRole: user.app_metadata?.role,
        companyId
      });

      if (response.status === 200) {
        toast({
          title: 'Desativado',
          description: 'Certificado removido com sucesso.',
        });
        
        setData(null); // Clear local data
        return true;
      } else {
        throw new Error(response.error);
      }
    } catch (err) {
      console.error('Deactivation error:', err);
      toast({
        variant: 'destructive',
        title: 'Erro',
        description: err.message
      });
      return false;
    } finally {
      setLoading(false);
    }
  }, [user, toast]);

  return {
    certificate: data,
    loading,
    error,
    getCertificateData,
    testLocalCertificate,
    uploadCertificate,
    deactivateCertificate
  };
};
