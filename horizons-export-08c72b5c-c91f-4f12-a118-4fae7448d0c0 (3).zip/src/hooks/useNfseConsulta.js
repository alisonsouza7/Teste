import { useState } from 'react';
import apiClient from '@/lib/apiClient';

export const useNfseConsulta = () => {
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState(null);
    const [result, setResult] = useState(null);

    const consultar = async (dps_id, company_id) => {
        setLoading(true);
        setError(null);
        setResult(null);
        try {
            const data = await apiClient.consultarNfse(dps_id, company_id);
            setResult(data);
            return data;
        } catch (err) {
            const msg = err.response?.data?.error || err.message || 'Erro desconhecido';
            setError(msg);
        } finally {
            setLoading(false);
        }
    };

    const obterStatus = async (dps_id, company_id) => {
        setLoading(true);
        setError(null);
        setResult(null);
        try {
            const data = await apiClient.obterStatusDps(dps_id, company_id);
            setResult(data);
            return data;
        } catch (err) {
            const msg = err.response?.data?.error || err.message || 'Erro desconhecido';
            setError(msg);
        } finally {
            setLoading(false);
        }
    };

    return {
        loading,
        error,
        result,
        consultar,
        obterStatus
    };
};

export default useNfseConsulta;