
import { useCallback } from 'react';
import { supabase } from '@/lib/customSupabaseClient';
import { useToast } from '@/components/ui/use-toast';
import { isPast, parseISO, subDays } from 'date-fns';

export const useTaskAutomations = () => {
  const { toast } = useToast();

  const completeTask = useCallback(async (taskId) => {
    try {
      const { data, error } = await supabase
        .from('tasks')
        .update({ 
          status: 'completed', 
          completed_at: new Date().toISOString() 
        })
        .eq('id', taskId)
        .select()
        .single();

      if (error) throw error;
      return data;
    } catch (error) {
      console.error('Automation Error (completeTask):', error);
      toast({ title: 'Erro ao completar tarefa', variant: 'destructive' });
      throw error;
    }
  }, [toast]);

  const getOverdueTasks = useCallback((tasks) => {
    const now = new Date();
    return tasks.filter(t => 
      t.due_date && 
      isPast(parseISO(t.due_date)) && 
      t.status !== 'completed'
    );
  }, []);

  const checkWIPLimit = useCallback((tasks, columnId, limit) => {
    if (!limit || limit <= 0) return true;
    const count = tasks.filter(t => t.column_id === columnId && t.status !== 'completed').length;
    return count < limit;
  }, []);

  const recalculatePareto = useCallback((tasks) => {
    // Scoring system: Priority (A=10, E=1) + Energy (High=5, Low=1)
    const getScore = (t) => {
      const pScore = { A: 10, B: 8, C: 5, D: 3, E: 1 }[t.priority_abcde] || 1;
      const eScore = { high: 5, medium: 3, low: 1 }[t.energy_level] || 3;
      return pScore + eScore;
    };

    const scoredTasks = tasks.map(t => ({ ...t, impact_score: getScore(t) }));
    scoredTasks.sort((a, b) => b.impact_score - a.impact_score);

    const cutoffIndex = Math.ceil(scoredTasks.length * 0.2);
    const top20 = scoredTasks.slice(0, cutoffIndex);
    const bottom80 = scoredTasks.slice(cutoffIndex);

    return { top20, bottom80, scoredTasks };
  }, []);

  const archiveOldTasks = useCallback(async (daysToKeep = 30) => {
    try {
      const cutoffDate = subDays(new Date(), daysToKeep).toISOString();
      
      // In a real scenario, we might move to a separate table. 
      // Here we'll just tag them or soft delete if supported, 
      // or for this example, just return the count of what WOULD be archived.
      const { count, error } = await supabase
        .from('tasks')
        .select('*', { count: 'exact', head: true })
        .eq('status', 'completed')
        .lt('completed_at', cutoffDate);

      if (error) throw error;
      
      toast({ title: `Automação: ${count} tarefas antigas identificadas para arquivamento.` });
      return count;
    } catch (error) {
      console.error('Automation Error (archiveOldTasks):', error);
      return 0;
    }
  }, [toast]);

  return {
    completeTask,
    getOverdueTasks,
    checkWIPLimit,
    recalculatePareto,
    archiveOldTasks
  };
};
