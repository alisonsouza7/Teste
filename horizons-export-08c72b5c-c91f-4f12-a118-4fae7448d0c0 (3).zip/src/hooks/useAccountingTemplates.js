
import { useState, useEffect } from 'react';
import { useCompany } from '@/contexts/CompanyContext';
import { supabase } from '@/lib/customSupabaseClient';
import { useToast } from '@/components/ui/use-toast';
import { addDays, addMonths, addYears, addQuarters } from 'date-fns';

export function useAccountingTemplates() {
  const { selectedCompany } = useCompany();
  const [templates, setTemplates] = useState([]);
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();

  useEffect(() => {
    if (selectedCompany?.id) {
      fetchTemplates();
    }
  }, [selectedCompany?.id]);

  const fetchTemplates = async () => {
    try {
      setLoading(true);
      const { data, error } = await supabase
        .from('accounting_task_templates')
        .select('*')
        .eq('owner_company_id', selectedCompany.id)
        .order('title');

      if (error) throw error;
      setTemplates(data || []);
    } catch (error) {
      console.error('Error fetching templates:', error);
      toast({
        title: 'Erro ao carregar modelos',
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  const createTemplate = async (templateData) => {
    try {
      const { data, error } = await supabase
        .from('accounting_task_templates')
        .insert([{ ...templateData, owner_company_id: selectedCompany.id }])
        .select()
        .single();

      if (error) throw error;
      setTemplates(prev => [...prev, data]);
      toast({ title: 'Modelo criado com sucesso!' });
      return data;
    } catch (error) {
      console.error('Error creating template:', error);
      toast({
        title: 'Erro ao criar modelo',
        description: error.message,
        variant: 'destructive',
      });
      throw error;
    }
  };

  const calculateNextOccurrence = (recurrenceType, recurrenceDay) => {
      const today = new Date();
      let nextDate = new Date(today.getFullYear(), today.getMonth(), recurrenceDay || 1);
      
      // If day passed in current month, start calculation from next month base
      if (nextDate < today) {
         nextDate = addMonths(nextDate, 1);
      }
      
      // Adjust based on type if needed (this logic can be more complex based on specific business rules)
      // For simplicity, we just return the next valid date based on recurrence_day relative to now
      return nextDate;
  };

  const createTaskFromTemplate = async (template, clientId) => {
    try {
      const dueDate = calculateNextOccurrence(template.recurrence_type, template.recurrence_day);
      
      const taskPayload = {
        title: template.title,
        description: template.description,
        client_id: clientId,
        template_id: template.id,
        category: template.category,
        priority: template.priority_level,
        status: 'pending',
        due_date: dueDate.toISOString(),
        legal_deadline: template.legal_deadline, // Assuming template stores offset or specific logic
        owner_company_id: selectedCompany.id
      };

      const { data, error } = await supabase
        .from('accounting_tasks')
        .insert([taskPayload])
        .select()
        .single();

      if (error) throw error;
      toast({ title: 'Tarefa gerada a partir do modelo!' });
      return data;

    } catch (error) {
      console.error('Error generating task from template:', error);
      toast({
        title: 'Erro ao gerar tarefa',
        description: error.message,
        variant: 'destructive',
      });
      throw error;
    }
  };

  return {
    templates,
    loading,
    fetchTemplates,
    createTemplate,
    createTaskFromTemplate
  };
}
