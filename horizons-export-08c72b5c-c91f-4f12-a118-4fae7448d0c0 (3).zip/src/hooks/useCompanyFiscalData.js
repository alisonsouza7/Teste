
import { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/lib/customSupabaseClient';
import { useCompany } from '@/contexts/CompanyContext';
import { useToast } from '@/components/ui/use-toast';

export const useCompanyFiscalData = () => {
  const { selectedCompany } = useCompany();
  const { toast } = useToast();
  
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const fetchData = useCallback(async () => {
    if (!selectedCompany?.id) return;
    
    setLoading(true);
    setError(null);
    
    try {
      // 1. Fetch Company details join with tax_regimes
      // Note: Foreign key allows us to select related data
      const { data: companyData, error: companyError } = await supabase
        .from('companies')
        .select(`
          regime_tributario, 
          tax_regimes (
            nome_exibicao,
            limite_faturamento
          )
        `)
        .eq('id', selectedCompany.id)
        .single();

      if (companyError) throw companyError;

      // 2. Fetch RBT12 metrics via RPC
      const { data: rbtData, error: rbtError } = await supabase
        .rpc('get_company_rbt12', { p_company_id: selectedCompany.id });

      if (rbtError) throw rbtError;
      
      const metrics = Array.isArray(rbtData) ? rbtData[0] : rbtData;
      
      // Fallback if tax_regimes join returns array or object depending on relationship cardinality
      // Since it's Many-to-One (Company -> Regime), it should be a single object, but Supabase sometimes returns array if not strictly defined as one-to-one in client types
      const regimeInfo = Array.isArray(companyData.tax_regimes) ? companyData.tax_regimes[0] : companyData.tax_regimes;

      setData({
        regime_tributario: companyData.regime_tributario,
        regime_label: regimeInfo?.nome_exibicao || 'Não Definido',
        limite_faturamento_anual: metrics?.limite_anual || regimeInfo?.limite_faturamento, // Prioritize RPC calculation or DB join
        faturamento_12_meses: metrics?.soma_ultimos_12_meses || 0,
        percentual_utilizado: metrics?.percentual_utilizado || 0
      });

    } catch (err) {
      console.error('Error fetching fiscal data:', err);
      setError(err);
    } finally {
      setLoading(false);
    }
  }, [selectedCompany?.id]);

  const updateRegime = useCallback(async (newRegime) => {
    if (!selectedCompany?.id) return;
    
    try {
      const { error } = await supabase
        .from('companies')
        .update({ regime_tributario: newRegime })
        .eq('id', selectedCompany.id);

      if (error) throw error;

      toast({
        title: 'Sucesso',
        description: 'Regime tributário atualizado.',
      });

      await fetchData();
      return true;
    } catch (err) {
      console.error('Error updating regime:', err);
      toast({
        variant: 'destructive',
        title: 'Erro ao atualizar',
        description: err.message || 'Falha ao atualizar regime tributário.'
      });
      return false;
    }
  }, [selectedCompany?.id, toast, fetchData]);

  useEffect(() => {
    if (selectedCompany?.id) {
      fetchData();

      const channel = supabase
        .channel(`fiscal-changes-${selectedCompany.id}`)
        .on(
          'postgres_changes',
          {
            event: 'UPDATE',
            schema: 'public',
            table: 'companies',
            filter: `id=eq.${selectedCompany.id}`
          },
          () => {
            fetchData();
          }
        )
        .subscribe();

      return () => {
        supabase.removeChannel(channel);
      };
    }
  }, [selectedCompany?.id, fetchData]);

  return {
    fiscalData: data,
    loading,
    error,
    refetch: fetchData,
    updateRegime
  };
};
