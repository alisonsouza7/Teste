
import { useState, useEffect } from 'react';
import { useCompany } from '@/contexts/CompanyContext';
import { supabase } from '@/lib/customSupabaseClient';
import { useToast } from '@/components/ui/use-toast';

export function useAccountingClients() {
  const { selectedCompany } = useCompany();
  const [clients, setClients] = useState([]);
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();

  useEffect(() => {
    if (!selectedCompany?.id) return;

    fetchClients();

    const subscription = supabase
      .channel('accounting_clients_changes')
      .on('postgres_changes', 
        { 
          event: '*', 
          schema: 'public', 
          table: 'accounting_clients',
          filter: `owner_company_id=eq.${selectedCompany.id}`
        }, 
        (payload) => {
          console.log('Accounting Client Change detected:', payload);
          if (payload.eventType === 'INSERT') {
            setClients(prev => [payload.new, ...prev]);
          } else if (payload.eventType === 'UPDATE') {
            setClients(prev => prev.map(client => client.id === payload.new.id ? payload.new : client));
          } else if (payload.eventType === 'DELETE') {
            setClients(prev => prev.filter(client => client.id !== payload.old.id));
          }
        }
      )
      .subscribe((status) => {
          if (status === 'SUBSCRIBED') {
              console.log('Subscribed to accounting_clients changes');
          } else {
              console.log('Subscription status:', status);
          }
      });

    return () => {
      subscription.unsubscribe();
    };
  }, [selectedCompany?.id]);

  const fetchClients = async () => {
    try {
      setLoading(true);
      if (!selectedCompany?.id) {
          console.warn('No company selected for fetching clients');
          return;
      }

      console.log('Fetching clients for company:', selectedCompany.id);

      const { data, error } = await supabase
        .from('accounting_clients')
        .select('*')
        .eq('owner_company_id', selectedCompany.id)
        .neq('status', 'archived') // Don't fetch archived by default unless requested
        .order('name');

      if (error) {
          console.error('Error fetching clients (Supabase):', error);
          throw error;
      }
      
      setClients(data || []);
      console.log('Clients fetched successfully:', data?.length);

    } catch (error) {
      console.error('Error fetching clients:', error);
      toast({
        title: 'Erro ao carregar clientes',
        description: error.message || "Verifique se você tem permissão.",
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  const createClient = async (clientData) => {
    try {
      if (!selectedCompany?.id) throw new Error("Nenhuma empresa selecionada");

      const payload = { ...clientData, owner_company_id: selectedCompany.id, status: 'active' };
      console.log('Creating client with payload:', payload);

      const { data, error } = await supabase
        .from('accounting_clients')
        .insert([payload])
        .select()
        .single();

      if (error) throw error;
      
      toast({ title: 'Cliente criado com sucesso!' });
      // Realtime should handle state update, but we can do optimistic update or manual update if needed
      // setClients(prev => [data, ...prev]); 
      return data;
    } catch (error) {
      console.error('Error creating client:', error);
      toast({
        title: 'Erro ao criar cliente',
        description: error.message,
        variant: 'destructive',
      });
      throw error;
    }
  };

  const updateClient = async (id, updates) => {
    try {
      console.log('Updating client:', id, updates);
      const { data, error } = await supabase
        .from('accounting_clients')
        .update(updates)
        .eq('id', id)
        .select()
        .single();

      if (error) throw error;
      toast({ title: 'Cliente atualizado com sucesso!' });
      return data;
    } catch (error) {
      console.error('Error updating client:', error);
      toast({
        title: 'Erro ao atualizar cliente',
        description: error.message,
        variant: 'destructive',
      });
      throw error;
    }
  };

  const deleteClient = async (id) => {
      // Soft delete (archive)
      return updateClient(id, { status: 'archived' });
  };

  return {
    clients,
    loading,
    fetchClients,
    createClient,
    updateClient,
    deleteClient // exposing deleteClient as requested (maps to archive)
  };
}
