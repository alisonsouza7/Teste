import { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/lib/customSupabaseClient';
import { generateNextOccurrences, updateRecurrenceStatus, deleteRecurrence } from '@/services/recurringTransactionsService';
import { useToast } from '@/components/ui/use-toast';

export const useRecurringTransactions = (companyId) => {
    // 1. Hooks
    const { toast } = useToast();

    // 2. State
    const [recurrences, setRecurrences] = useState([]);
    const [loading, setLoading] = useState(true);

    // 3. Callbacks
    const fetchRecurrences = useCallback(async () => {
        if (!companyId) return;
        setLoading(true);
        try {
            const { data, error } = await supabase
                .from('finance_recurrences')
                .select(`
                    *,
                    template:finance_transactions!finance_recurrences_template_transaction_id_fkey(descricao, valor)
                `)
                .eq('company_id', companyId)
                .order('created_at', { ascending: false });

            if (error) throw error;
            setRecurrences(data || []);
        } catch (error) {
            console.error('Error fetching recurrences:', error);
            toast({ variant: 'destructive', title: 'Erro', description: 'Falha ao carregar recorrências.' });
        } finally {
            setLoading(false);
        }
    }, [companyId, toast]);

    const checkAndRunAutomation = useCallback(async () => {
        if (!companyId) return;
        try {
            const result = await generateNextOccurrences(companyId);
            if (result.generated > 0) {
                toast({ 
                    title: 'Automação executada', 
                    description: `${result.generated} lançamentos recorrentes gerados.` 
                });
            }
        } catch (error) {
            console.error("Automation error", error);
        }
    }, [companyId, toast]);

    const toggleStatus = useCallback(async (id, currentStatus) => {
        try {
            await updateRecurrenceStatus(id, !currentStatus);
            setRecurrences(prev => prev.map(r => r.id === id ? { ...r, is_active: !currentStatus } : r));
            toast({ title: 'Status atualizado' });
        } catch (error) {
            toast({ variant: 'destructive', title: 'Erro ao atualizar status' });
        }
    }, [toast]);

    const remove = useCallback(async (id) => {
        try {
            await deleteRecurrence(id);
            setRecurrences(prev => prev.filter(r => r.id !== id));
            toast({ title: 'Recorrência excluída' });
        } catch (error) {
            toast({ variant: 'destructive', title: 'Erro ao excluir' });
        }
    }, [toast]);

    // 4. Effects
    useEffect(() => {
        fetchRecurrences();
    }, [fetchRecurrences]);

    return {
        recurrences,
        loading,
        refresh: fetchRecurrences,
        checkAndRunAutomation,
        toggleStatus,
        remove
    };
};