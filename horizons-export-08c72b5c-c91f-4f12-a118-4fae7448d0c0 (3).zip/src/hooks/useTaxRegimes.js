
import { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/lib/customSupabaseClient';

export const useTaxRegimes = () => {
  const [regimes, setRegimes] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const fetchRegimes = useCallback(async () => {
    try {
      setLoading(true);
      const { data, error } = await supabase
        .from('tax_regimes')
        .select('*')
        .eq('ativo', true)
        .order('limite_faturamento', { ascending: true, nullsFirst: false });

      if (error) throw error;
      setRegimes(data || []);
    } catch (err) {
      console.error('Error fetching tax regimes:', err);
      setError(err);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchRegimes();

    // Real-time subscription for updates to tax regimes
    const channel = supabase
      .channel('tax_regimes_changes')
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'tax_regimes' },
        () => fetchRegimes()
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [fetchRegimes]);

  const getRegimeByCode = useCallback((codigo) => {
    return regimes.find(r => r.codigo === codigo);
  }, [regimes]);

  const getLimitByCode = useCallback((codigo) => {
    const regime = regimes.find(r => r.codigo === codigo);
    return regime ? regime.limite_faturamento : null;
  }, [regimes]);

  return {
    regimes,
    loading,
    error,
    getRegimeByCode,
    getLimitByCode,
    refetch: fetchRegimes
  };
};
