import { useState, useEffect, useCallback, useMemo } from 'react';
import { supabase } from '@/lib/customSupabaseClient';
import { 
  calculateDREStructure, 
  validateDREQuality, 
  calculateMonthlyBreakdown 
} from '@/lib/dreCompute';
import { applyPeriodFilterToQuery } from '@/lib/periodHelpers';

export const useDREData = (companyId, dateRange, viewType) => {
  // 1. State
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [rawTransactions, setRawTransactions] = useState([]);
  const [categories, setCategories] = useState([]);

  // 2. Callbacks
  const getTransactionsForCategory = useCallback((categoryId) => {
    return rawTransactions.filter(tx => tx.categoria_id === categoryId);
  }, [rawTransactions]);

  // 3. Effects
  useEffect(() => {
    if (!companyId || !dateRange.startDate || !dateRange.endDate) return;

    const fetchData = async () => {
      setLoading(true);
      setError(null);
      try {
        const { data: cats, error: catError } = await supabase
          .from('finance_chart_of_accounts')
          .select('id, nome_conta, grupo, tipo, ordem')
          .eq('company_id', companyId)
          .is('deleted_at', null)
          .order('ordem');

        if (catError) throw catError;
        setCategories(cats || []);

        let query = supabase
          .from('finance_transactions')
          .select(`
            id, 
            valor, 
            tipo,
            liquidado, 
            data_competencia, 
            data_lancamento, 
            data_liquidacao,
            vencimento,
            descricao,
            categoria_id,
            conta_id,
            finance_accounts (nome_conta)
          `)
          .eq('company_id', companyId)
          .is('deleted_at', null);

        query = applyPeriodFilterToQuery(query, dateRange);
        
        const { data: txs, error: txError } = await query;
        if (txError) throw txError;
        setRawTransactions(txs || []);

      } catch (err) {
        console.error("DRE Fetch Error:", err);
        setError(err);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, [companyId, dateRange.startDate, dateRange.endDate]);

  // 4. Memos
  const dreData = useMemo(() => {
    if (loading || !rawTransactions.length) return null;
    return calculateDREStructure(rawTransactions, categories, viewType);
  }, [rawTransactions, categories, viewType, loading]);

  const monthlyData = useMemo(() => {
    if (loading || !rawTransactions.length) return null;
    return calculateMonthlyBreakdown(rawTransactions, categories, viewType);
  }, [rawTransactions, categories, viewType, loading]);

  const qualityReport = useMemo(() => {
    if (loading) return null;
    return validateDREQuality(rawTransactions, categories);
  }, [rawTransactions, categories, loading]);

  return {
    loading,
    error,
    dreData,
    monthlyData,
    qualityReport,
    categories,
    rawTransactions,
    getTransactionsForCategory
  };
};