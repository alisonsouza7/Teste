
import { useMemo } from 'react';
import { useAccountingTasks } from './useAccountingTasks';
import { startOfMonth, endOfMonth, isBefore, parseISO } from 'date-fns';

export function useAccountingMetrics() {
  const { tasks, loading } = useAccountingTasks(); // Fetches all tasks for the company

  const metrics = useMemo(() => {
    if (loading || !tasks.length) {
      return {
        totalTasks: 0,
        completedTasks: 0,
        overdueTasks: 0,
        onTimePercentage: 0,
        bottleneckClient: null,
        clientPerformance: []
      };
    }

    const now = new Date();
    const currentMonthStart = startOfMonth(now);
    const currentMonthEnd = endOfMonth(now);

    let total = 0;
    let completed = 0;
    let overdue = 0;
    let onTime = 0;
    
    // Client aggregation
    const clientStats = {};

    tasks.forEach(task => {
      // Initialize client stats
      if (!clientStats[task.client_id]) {
        clientStats[task.client_id] = {
            id: task.client_id,
            name: task.accounting_clients?.name || 'Unknown',
            total: 0,
            overdue: 0,
            completed: 0
        };
      }
      
      const stats = clientStats[task.client_id];
      stats.total++;
      total++;

      const dueDate = task.due_date ? parseISO(task.due_date) : null;
      const completedAt = task.completed_at ? parseISO(task.completed_at) : null;
      
      const isOverdue = dueDate && isBefore(dueDate, now) && task.status !== 'done';
      
      if (task.status === 'done') {
        completed++;
        stats.completed++;
        if (dueDate && completedAt && isBefore(completedAt, dueDate)) {
             onTime++;
        } else if (!dueDate) {
             onTime++; // No deadline = on time
        }
      }

      if (isOverdue) {
        overdue++;
        stats.overdue++;
      }
    });

    // Find bottleneck (Client with most overdue tasks)
    const clientsArray = Object.values(clientStats);
    const bottleneck = clientsArray.reduce((prev, current) => 
        (prev.overdue > current.overdue) ? prev : current, { overdue: -1, name: 'Nenhum' }
    );

    return {
      totalTasks: total,
      completedTasks: completed,
      overdueTasks: overdue,
      onTimePercentage: completed > 0 ? Math.round((onTime / completed) * 100) : 100,
      bottleneckClient: bottleneck.overdue > 0 ? bottleneck : null,
      clientPerformance: clientsArray
    };
  }, [tasks, loading]);

  return { metrics, loading };
}
