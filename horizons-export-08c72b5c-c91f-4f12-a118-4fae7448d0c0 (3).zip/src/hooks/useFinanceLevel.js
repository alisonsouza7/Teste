
import { useState, useEffect, useMemo, useCallback } from 'react';
import { supabase } from '@/lib/customSupabaseClient';

// Define the capabilities for each financial level
const LEVEL_PERMISSIONS = {
  'A': {
    canCreateMultipleAccounts: false,
    maxAccounts: 1,
    canUseCreditCards: false,
    canImportBank: false, // OFX import
    canConciliate: false,
    canManageCostCenters: false,
    label: 'Básico (Nível A)'
  },
  'B': {
    canCreateMultipleAccounts: true,
    maxAccounts: Infinity,
    canUseCreditCards: false,
    canImportBank: true,
    canConciliate: false,
    canManageCostCenters: false,
    label: 'Intermediário (Nível B)'
  },
  'C': {
    canCreateMultipleAccounts: true,
    maxAccounts: Infinity,
    canUseCreditCards: true,
    canImportBank: true,
    canConciliate: true,
    canManageCostCenters: true,
    label: 'Avançado (Nível C)'
  }
};

export const useFinanceLevel = (companyId) => {
  // Default to 'A' (most restrictive) for security
  const [level, setLevel] = useState('A');
  const [loading, setLoading] = useState(true);
  const [source, setSource] = useState('none'); // 'history', 'config', 'default'

  const fetchLevel = useCallback(async () => {
    let isMounted = true;
    if (!companyId) {
      if (isMounted) {
        setLevel('A');
        setLoading(false);
      }
      return;
    }

    setLoading(true);
    
    try {
      console.group(`[useFinanceLevel] Fetching for Company: ${companyId}`);
      
      // 1. Try History (finance_level_changes) - Priority 1
      const { data: historyData, error: historyError } = await supabase
        .from('finance_level_changes')
        .select('nivel_novo, mudado_em')
        .eq('company_id', companyId)
        .order('mudado_em', { ascending: false })
        .limit(1)
        .maybeSingle();

      if (historyError) {
        console.error('[useFinanceLevel] Error fetching history:', historyError);
      }

      if (historyData?.nivel_novo) {
        const normalizedLevel = historyData.nivel_novo.toUpperCase();
        console.log(`[useFinanceLevel] ✅ Found in HISTORY table.`);
        console.log(`[useFinanceLevel] Value: ${normalizedLevel}, Date: ${historyData.mudado_em}`);
        
        if (LEVEL_PERMISSIONS[normalizedLevel]) {
          setLevel(normalizedLevel);
          setSource('history');
          setLoading(false);
          console.groupEnd();
          return; // Exit early if found in history
        } else {
            console.warn(`[useFinanceLevel] Invalid level in history: ${normalizedLevel}`);
        }
      } else {
        console.log(`[useFinanceLevel] ⚠️ No history record found.`);
      }

      // 2. Fallback to Config (finance_config) - Priority 2
      console.log(`[useFinanceLevel] Attempting fallback to CONFIG table...`);
      const { data: configData, error: configError } = await supabase
        .from('finance_config')
        .select('nivel_financeiro')
        .eq('company_id', companyId)
        .maybeSingle();

      if (configError) {
        console.error('[useFinanceLevel] Error fetching config:', configError);
      }

      if (configData?.nivel_financeiro) {
        const normalizedLevel = configData.nivel_financeiro.toUpperCase();
        console.log(`[useFinanceLevel] ✅ Found in CONFIG table.`);
        console.log(`[useFinanceLevel] Value: ${normalizedLevel}`);

        if (LEVEL_PERMISSIONS[normalizedLevel]) {
          setLevel(normalizedLevel);
          setSource('config');
        } else {
          console.warn(`[useFinanceLevel] Invalid level in config: ${normalizedLevel}, defaulting to A`);
          setLevel('A');
          setSource('default');
        }
      } else {
        // 3. Fallback to Default - Priority 3
        console.log(`[useFinanceLevel] ⚠️ No config found. Falling back to DEFAULT 'A'.`);
        setLevel('A');
        setSource('default');
      }

    } catch (err) {
      console.error('[useFinanceLevel] Critical Exception:', err);
      setLevel('A');
      setSource('error-fallback');
    } finally {
      setLoading(false);
      console.groupEnd();
    }
  }, [companyId]);

  useEffect(() => {
    fetchLevel();

    if (!companyId) return;

    // Realtime subscription setup
    console.log(`[useFinanceLevel] Setting up Realtime Subscription for Company: ${companyId}`);
    
    const channel = supabase.channel(`finance_level_watcher_${companyId}`)
      .on(
        'postgres_changes',
        { 
          event: 'INSERT', 
          schema: 'public', 
          table: 'finance_level_changes',
          filter: `company_id=eq.${companyId}`
        },
        (payload) => {
          console.log('⚡ [useFinanceLevel] REALTIME: New record in finance_level_changes!', payload);
          fetchLevel();
        }
      )
      .on(
        'postgres_changes',
        { 
          event: '*', // Listen to Update/Insert
          schema: 'public', 
          table: 'finance_config',
          filter: `company_id=eq.${companyId}`
        },
        (payload) => {
          console.log('⚡ [useFinanceLevel] REALTIME: Update in finance_config!', payload);
          fetchLevel();
        }
      )
      .subscribe((status) => {
        if (status === 'SUBSCRIBED') {
           console.log(`[useFinanceLevel] ✅ Realtime Subscription Active: Watching finance_level_changes & finance_config`);
        }
      });

    return () => {
      console.log(`[useFinanceLevel] Cleaning up subscription for ${companyId}`);
      supabase.removeChannel(channel);
    };
  }, [companyId, fetchLevel]);

  const permissions = useMemo(() => {
    return LEVEL_PERMISSIONS[level] || LEVEL_PERMISSIONS['A'];
  }, [level]);

  return {
    level,
    source, // Export source for debugging/UI
    permissions,
    ...permissions,
    loading,
    isLevelA: level === 'A',
    isLevelB: level === 'B',
    isLevelC: level === 'C',
    refreshLevel: fetchLevel // Expose manual refresh if needed
  };
};
