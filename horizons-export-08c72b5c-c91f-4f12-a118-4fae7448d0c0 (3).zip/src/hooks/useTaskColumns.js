
import { useState, useEffect } from 'react';
import { supabase } from '@/lib/customSupabaseClient';
import { useToast } from '@/components/ui/use-toast';

export const useTaskColumns = (projectId) => {
  const [columns, setColumns] = useState([]);
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();

  useEffect(() => {
    if (!projectId) {
      setColumns([]);
      setLoading(false);
      return;
    }

    const fetchColumns = async () => {
      setLoading(true);
      const { data, error } = await supabase
        .from('task_columns')
        .select('*')
        .eq('project_id', projectId)
        .order('position', { ascending: true });

      if (error) {
        console.error('Error fetching columns:', error);
        toast({
          title: "Erro ao carregar colunas",
          description: error.message,
          variant: "destructive"
        });
      } else {
        setColumns(data || []);
      }
      setLoading(false);
    };

    fetchColumns();

    const subscription = supabase
      .channel(`columns:${projectId}`)
      .on('postgres_changes', 
        { event: '*', schema: 'public', table: 'task_columns', filter: `project_id=eq.${projectId}` }, 
        (payload) => {
           // Simple re-fetch strategy for columns to ensure order integrity on rapid updates
           fetchColumns();
      })
      .subscribe();

    return () => {
      subscription.unsubscribe();
    };
  }, [projectId, toast]);

  const createColumn = async (columnData) => {
    const { data, error } = await supabase
      .from('task_columns')
      .insert([columnData])
      .select()
      .single();
    if (error) throw error;
    return data;
  };

  const updateColumn = async (id, updates) => {
    const { data, error } = await supabase
      .from('task_columns')
      .update(updates)
      .eq('id', id)
      .select()
      .single();
    if (error) throw error;
    return data;
  };

  const deleteColumn = async (id) => {
    const { error } = await supabase
      .from('task_columns')
      .delete()
      .eq('id', id);
    if (error) throw error;
  };

  return { columns, loading, createColumn, updateColumn, deleteColumn, setColumns };
};
