
import { useState, useEffect } from 'react';
import { supabase } from '@/lib/customSupabaseClient';
import { useCompany } from '@/contexts/CompanyContext';
import { useToast } from '@/components/ui/use-toast';

export const useSmartGoals = () => {
  const [goals, setGoals] = useState([]);
  const [loading, setLoading] = useState(true);
  const { selectedCompany } = useCompany();
  const { toast } = useToast();

  useEffect(() => {
    if (!selectedCompany?.id) {
        setLoading(false);
        return;
    }

    const fetchGoals = async () => {
      setLoading(true);
      const { data, error } = await supabase
        .from('smart_goals')
        .select('*')
        .eq('company_id', selectedCompany.id)
        .order('created_at', { ascending: false });

      if (error) {
        console.error('Error fetching goals:', error);
        toast({ title: 'Erro ao carregar metas', description: error.message, variant: 'destructive' });
      } else {
        setGoals(data || []);
      }
      setLoading(false);
    };

    fetchGoals();

    const subscription = supabase
      .channel(`smart_goals:${selectedCompany.id}`)
      .on('postgres_changes', 
        { event: '*', schema: 'public', table: 'smart_goals', filter: `company_id=eq.${selectedCompany.id}` }, 
        (payload) => {
          if (payload.eventType === 'INSERT') {
            setGoals(prev => [payload.new, ...prev]);
          } else if (payload.eventType === 'UPDATE') {
            setGoals(prev => prev.map(g => g.id === payload.new.id ? payload.new : g));
          } else if (payload.eventType === 'DELETE') {
            setGoals(prev => prev.filter(g => g.id !== payload.old.id));
          }
      })
      .subscribe();

    return () => {
      subscription.unsubscribe();
    };
  }, [selectedCompany?.id, toast]);

  const createGoal = async (goalData) => {
    if (!selectedCompany?.id) return;
    const { data, error } = await supabase
      .from('smart_goals')
      .insert([{ ...goalData, company_id: selectedCompany.id }])
      .select()
      .single();

    if (error) throw error;
    return data;
  };

  const updateGoal = async (id, updates) => {
    const { data, error } = await supabase
      .from('smart_goals')
      .update(updates)
      .eq('id', id)
      .select()
      .single();

    if (error) throw error;
    return data;
  };

  const deleteGoal = async (id) => {
    const { error } = await supabase
      .from('smart_goals')
      .delete()
      .eq('id', id);

    if (error) throw error;
  };

  return { goals, loading, createGoal, updateGoal, deleteGoal };
};
