
import { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/lib/customSupabaseClient';
import { useToast } from '@/components/ui/use-toast';

export const useTasks = (projectId, filters = {}) => {
  const [tasks, setTasks] = useState([]);
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();

  const fetchTasks = useCallback(async () => {
    if (!projectId) {
        setTasks([]);
        setLoading(false);
        return;
    }
    
    setLoading(true);
    let query = supabase
      .from('tasks')
      .select('*, assignee:users(nome), tags:task_tags(*)')
      .eq('project_id', projectId)
      .order('position', { ascending: true });

    // Apply filters
    if (filters.status) query = query.eq('status', filters.status);
    if (filters.assigneeId) query = query.eq('assignee_id', filters.assigneeId);
    if (filters.priority) query = query.eq('priority_abcde', filters.priority);
    
    // Note: Search text filtering usually better done client side for small datasets or using dedicated search index
    
    const { data, error } = await query;

    if (error) {
      console.error('Error fetching tasks:', error);
      toast({ title: 'Erro', description: 'Não foi possível carregar as tarefas.', variant: 'destructive' });
    } else {
        // Client-side text search if needed
        let filteredData = data || [];
        if (filters.search) {
            const lowerSearch = filters.search.toLowerCase();
            filteredData = filteredData.filter(t => 
                t.title.toLowerCase().includes(lowerSearch) || 
                t.description?.toLowerCase().includes(lowerSearch)
            );
        }
        setTasks(filteredData);
    }
    setLoading(false);
  }, [projectId, JSON.stringify(filters), toast]);

  useEffect(() => {
    fetchTasks();
    
    if (!projectId) return;

    const subscription = supabase
      .channel(`tasks:${projectId}`)
      .on('postgres_changes', 
        { event: '*', schema: 'public', table: 'tasks', filter: `project_id=eq.${projectId}` }, 
        () => {
           fetchTasks();
        }
      )
      .subscribe();

    return () => {
      subscription.unsubscribe();
    };
  }, [fetchTasks, projectId]);

  const createTask = async (taskData) => {
    const { data, error } = await supabase
      .from('tasks')
      .insert([taskData])
      .select()
      .single();
    if (error) throw error;
    return data;
  };

  const updateTask = async (taskId, updates) => {
    // Optimistic update
    setTasks(prev => prev.map(t => t.id === taskId ? { ...t, ...updates } : t));
    
    const { data, error } = await supabase
      .from('tasks')
      .update(updates)
      .eq('id', taskId)
      .select()
      .single();

    if (error) {
        // Revert on error (could be improved with previous state)
        fetchTasks();
        throw error;
    }
    return data;
  };

  const deleteTask = async (taskId) => {
    setTasks(prev => prev.filter(t => t.id !== taskId));
    const { error } = await supabase.from('tasks').delete().eq('id', taskId);
    if (error) {
        fetchTasks();
        throw error;
    }
  };

  const reorderTasks = async (reorderedTasks) => {
      // Optimistic update
      setTasks(reorderedTasks);
      
      // Batch update positions
      // Note: Supabase doesn't support bulk update with different values easily in one query without RPC
      // For now, we'll update one by one or use a specific strategy. 
      // Ideally, use an RPC function for this. 
      // Simplified: Just update the moved task and its neighbors in a real app, 
      // but here we might just trigger individual updates for modified items.
      
      const updates = reorderedTasks.map((t, index) => ({
          id: t.id,
          position: index,
          column_id: t.column_id
      }));

      // In production, send only changed items
      for (const update of updates) {
           await supabase.from('tasks').update({ 
               position: update.position, 
               column_id: update.column_id 
           }).eq('id', update.id);
      }
  };

  return { tasks, loading, createTask, updateTask, deleteTask, reorderTasks, setTasks };
};
