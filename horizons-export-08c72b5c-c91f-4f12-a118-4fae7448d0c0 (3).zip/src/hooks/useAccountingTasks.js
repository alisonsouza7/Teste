
import { useState, useEffect } from 'react';
import { useCompany } from '@/contexts/CompanyContext';
import { supabase } from '@/lib/customSupabaseClient';
import { useToast } from '@/components/ui/use-toast';

export function useAccountingTasks(filters = {}) {
  const { selectedCompany } = useCompany();
  const [tasks, setTasks] = useState([]);
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();

  useEffect(() => {
    if (!selectedCompany?.id) return;
    
    fetchTasks();
    
    // Real-time subscription setup
    // Note: Complex filter subscriptions might require row level changes listening
    const subscription = supabase
      .channel('accounting_tasks_changes')
      .on('postgres_changes', 
        { 
          event: '*', 
          schema: 'public', 
          table: 'accounting_tasks' 
        }, 
        () => {
          // Re-fetch to apply complex filters correctly
          fetchTasks(); 
        }
      )
      .subscribe();

    return () => {
      subscription.unsubscribe();
    };
  }, [selectedCompany?.id, JSON.stringify(filters)]);

  const fetchTasks = async () => {
    try {
      setLoading(true);
      let query = supabase
        .from('accounting_tasks')
        .select(`
          *,
          accounting_clients!inner(name, owner_company_id)
        `)
        .eq('accounting_clients.owner_company_id', selectedCompany.id);

      // Apply Filters
      if (filters.clientId) {
        query = query.eq('client_id', filters.clientId);
      }
      if (filters.status) {
        query = query.eq('status', filters.status);
      }
      if (filters.priority) {
        query = query.eq('priority', filters.priority);
      }
      if (filters.startDate && filters.endDate) {
        query = query.gte('due_date', filters.startDate).lte('due_date', filters.endDate);
      }

      const { data, error } = await query.order('due_date', { ascending: true });

      if (error) throw error;
      setTasks(data || []);
    } catch (error) {
      console.error('Error fetching tasks:', error);
      toast({
        title: 'Erro ao carregar tarefas',
        description: error.message,
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  const createTask = async (taskData) => {
    try {
      const { data, error } = await supabase
        .from('accounting_tasks')
        .insert([taskData])
        .select()
        .single();

      if (error) throw error;
      toast({ title: 'Tarefa criada com sucesso!' });
      return data;
    } catch (error) {
      toast({
        title: 'Erro ao criar tarefa',
        description: error.message,
        variant: 'destructive',
      });
      throw error;
    }
  };

  const updateTask = async (id, updates) => {
    try {
      const { data, error } = await supabase
        .from('accounting_tasks')
        .update(updates)
        .eq('id', id)
        .select()
        .single();

      if (error) throw error;
      return data;
    } catch (error) {
      toast({
        title: 'Erro ao atualizar tarefa',
        description: error.message,
        variant: 'destructive',
      });
      throw error;
    }
  };

  const completeTask = async (id) => {
    return updateTask(id, { 
      status: 'done', 
      completed_at: new Date().toISOString() 
    });
  };

  const deleteTask = async (id) => {
    try {
      const { error } = await supabase
        .from('accounting_tasks')
        .delete()
        .eq('id', id);

      if (error) throw error;
      toast({ title: 'Tarefa removida' });
      setTasks(prev => prev.filter(t => t.id !== id));
    } catch (error) {
      toast({
        title: 'Erro ao remover tarefa',
        description: error.message,
        variant: 'destructive',
      });
    }
  };

  return {
    tasks,
    loading,
    createTask,
    updateTask,
    completeTask,
    deleteTask,
    fetchTasks
  };
}
