import { useState, useEffect, useCallback, useRef } from 'react';
import { supabase } from '@/lib/customSupabaseClient';
import { useToast } from '@/components/ui/use-toast';
import { generateAccountNumber } from '@/lib/accountNumbering';

const COLOR_PALETTES = {
  receita: ['#16a34a', '#22c55e', '#4ade80', '#15803d', '#10b981'],
  despesa: ['#dc2626', '#ef4444', '#f87171', '#b91c1c', '#f43f5e'],
  custo: ['#f59e0b', '#fbbf24', '#f97316', '#d97706', '#fb923c'],
  investimento: ['#2563eb', '#3b82f6', '#60a5fa', '#1d4ed8', '#0ea5e9'],
  ajustes: ['#64748b', '#6b7280', '#9ca3af', '#94a3b8', '#4b5563'],
};

const normalizeTipoKey = (tipo) => {
  const key = String(tipo || '').toLowerCase().trim();
  if (key === 'receita') return 'receita';
  if (key === 'despesa') return 'despesa';
  if (key === 'custo') return 'custo';
  if (key === 'investimento') return 'investimento';
  if (['ajustes', 'ajuste', 'transferencia', 'transferência', 'outros', 'other'].includes(key)) return 'ajustes';
  return 'ajustes';
};

const getNextColorForType = (tipo, existingAccounts) => {
  const key = normalizeTipoKey(tipo);
  const palette = COLOR_PALETTES[key] || COLOR_PALETTES.ajustes;

  const usedColors = (existingAccounts || [])
    .filter(a => normalizeTipoKey(a?.tipo) === key)
    .map(a => a?.color)
    .filter(Boolean);

  const startIndex =
    usedColors.length === 0
      ? Math.floor(Math.random() * palette.length)
      : usedColors.length;

  return palette[startIndex % palette.length];
};

// garante unicidade local independente de como generateAccountNumber funcione
const generateUniqueAccountNumber = (tipo, usedSet) => {
  // tenta várias vezes para evitar colisão
  for (let tries = 0; tries < 2000; tries++) {
    const candidate = generateAccountNumber(tipo, Array.from(usedSet));
    if (!usedSet.has(candidate)) {
      usedSet.add(candidate);
      return candidate;
    }
  }
  // se estourar, é porque generateAccountNumber está mal comportado
  // (sempre devolvendo o mesmo). Melhor explodir com erro explícito.
  throw new Error('Falha ao gerar código único (generateAccountNumber repetindo valores).');
};

export const useChartOfAccounts = (companyId) => {
  const { toast } = useToast();

  const [accounts, setAccounts] = useState([]);
  const [loading, setLoading] = useState(true);

  // trava contra clique duplo / reentrada
  const isAssigningRef = useRef(false);

  const fetchAccounts = useCallback(async () => {
    if (!companyId) return;

    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('finance_chart_of_accounts')
        .select('*')
        .eq('company_id', companyId)
        .is('deleted_at', null)
        .order('tipo', { ascending: true })
        .order('display_order', { ascending: true, nullsFirst: false })
        .order('nome_conta', { ascending: true });

      if (error) throw error;

      const sorted = (data || []).slice().sort((a, b) => {
        const ta = normalizeTipoKey(a?.tipo);
        const tb = normalizeTipoKey(b?.tipo);
        if (ta !== tb) return ta.localeCompare(tb, 'pt-BR');

        const da = a.display_order ?? 999999;
        const db = b.display_order ?? 999999;
        if (da !== db) return da - db;

        return String(a.nome_conta || '').localeCompare(String(b.nome_conta || ''), 'pt-BR');
      });

      setAccounts(sorted);
    } catch (err) {
      console.error('Error fetching accounts:', err);
      toast({
        title: 'Erro ao carregar categorias',
        description: err.message,
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  }, [companyId, toast]);

  const createAccount = useCallback(async (accountData) => {
    try {
      const existingNumbers = (accounts || []).map(a => a.account_number).filter(Boolean);
      const usedSet = new Set(existingNumbers);

      const accountNumber =
        accountData.account_number ||
        generateUniqueAccountNumber(accountData.tipo, usedSet);

      const nextColor =
        accountData.color ||
        getNextColorForType(accountData.tipo, accounts);

      const payload = {
        ...accountData,
        company_id: companyId,
        account_number: accountNumber,
        color: nextColor,
        is_active: accountData.is_active ?? true,
        display_order: accountData.display_order ?? 0,
      };

      const { data, error } = await supabase
        .from('finance_chart_of_accounts')
        .insert([payload])
        .select()
        .single();

      if (error) throw error;

      setAccounts(prev => [...prev, data]);
      toast({ title: 'Categoria criada com sucesso!' });
      return data;
    } catch (err) {
      toast({
        title: 'Erro ao criar',
        description: err.message,
        variant: 'destructive',
      });
      throw err;
    }
  }, [accounts, companyId, toast]);

  const updateAccount = useCallback(async (id, updates) => {
    try {
      const payload = {
        ...updates,
        is_active: updates?.is_active ?? true,
      };

      if (payload.tipo && (!payload.color || String(payload.color).trim() === '')) {
        payload.color = getNextColorForType(payload.tipo, accounts);
      }

      const { data, error } = await supabase
        .from('finance_chart_of_accounts')
        .update(payload)
        .eq('id', id)
        .select()
        .single();

      if (error) throw error;

      setAccounts(prev => prev.map(acc => (acc.id === id ? data : acc)));
      toast({ title: 'Categoria atualizada!' });
      return data;
    } catch (err) {
      toast({
        title: 'Erro ao atualizar',
        description: err.message,
        variant: 'destructive',
      });
      throw err;
    }
  }, [accounts, toast]);

  const deleteAccount = useCallback(async (id) => {
    try {
      const { error } = await supabase
        .from('finance_chart_of_accounts')
        .update({ deleted_at: new Date().toISOString() })
        .eq('id', id);

      if (error) throw error;

      setAccounts(prev => prev.filter(acc => acc.id !== id));
      toast({ title: 'Categoria removida' });
    } catch (err) {
      toast({
        title: 'Erro ao remover',
        description: err.message,
        variant: 'destructive',
      });
    }
  }, [toast]);

  const reorderAccounts = useCallback(async (sectionKey, reorderedItems) => {
    setAccounts(prev => {
      const next = prev.map(acc => {
        const found = reorderedItems.find(i => i.id === acc.id);
        return found ? { ...acc, display_order: found.display_order } : acc;
      });

      next.sort((a, b) => {
        const ta = normalizeTipoKey(a?.tipo);
        const tb = normalizeTipoKey(b?.tipo);
        if (ta !== tb) return ta.localeCompare(tb, 'pt-BR');

        const da = a.display_order ?? 999999;
        const db = b.display_order ?? 999999;
        if (da !== db) return da - db;

        return String(a.nome_conta || '').localeCompare(String(b.nome_conta || ''), 'pt-BR');
      });

      return next;
    });

    try {
      const results = await Promise.all(
        reorderedItems.map(item =>
          supabase
            .from('finance_chart_of_accounts')
            .update({ display_order: item.display_order })
            .eq('id', item.id)
        )
      );

      const firstErr = results.find(r => r?.error)?.error;
      if (firstErr) throw firstErr;
    } catch (err) {
      console.error('Reorder failed', err);
      fetchAccounts();
      toast({
        title: 'Erro ao salvar ordem',
        description: 'A reordenação não pôde ser persistida.',
        variant: 'destructive',
      });
    }
  }, [fetchAccounts, toast]);

  const assignMissingNumbers = useCallback(async () => {
    if (!companyId) return;

    if (isAssigningRef.current) {
      toast({
        title: 'Aguarde',
        description: 'Já estou gerando códigos neste momento.',
        variant: 'warning',
      });
      return;
    }

    isAssigningRef.current = true;

    try {
      // puxa do banco pra garantir visão atual (evita duplicar por estado desatualizado)
      const { data: fresh, error: freshErr } = await supabase
        .from('finance_chart_of_accounts')
        .select('*')
        .eq('company_id', companyId)
        .is('deleted_at', null);

      if (freshErr) throw freshErr;

      const snapshot = (fresh || []).slice();

      // usedSet por tipo => unicidade absoluta dentro de cada tipo
      const usedByTipo = new Map();
      for (const acc of snapshot) {
        const t = normalizeTipoKey(acc?.tipo);
        if (!usedByTipo.has(t)) usedByTipo.set(t, new Set());
        if (acc.account_number) usedByTipo.get(t).add(acc.account_number);
      }

      for (const acc of snapshot) {
        const updates = {};
        const tipoKey = normalizeTipoKey(acc?.tipo);

        // código
        if (!acc.account_number) {
          const usedSet = usedByTipo.get(tipoKey) || new Set();
          const nextNum = generateUniqueAccountNumber(tipoKey, usedSet);
          updates.account_number = nextNum;

          // mantém estado local coerente
          usedByTipo.set(tipoKey, usedSet);
        }

        // cor
        if (!acc.color) {
          // para sequência de cores, usamos o snapshot + "falsos" incrementos:
          // adicionamos um "acc virtual" com cor gerada na lista auxiliar
          const nextColor = getNextColorForType(tipoKey, snapshot);
          updates.color = nextColor;
          snapshot.push({ ...acc, color: nextColor });
        }

        // ativo
        if (acc.is_active === null || acc.is_active === undefined) {
          updates.is_active = true;
        }

        if (Object.keys(updates).length > 0) {
          const { error } = await supabase
            .from('finance_chart_of_accounts')
            .update(updates)
            .eq('id', acc.id);

          if (error) throw error;
        }
      }

      await fetchAccounts();
      toast({
        title: 'Plano de contas ajustado',
        description: 'Códigos, cores e status foram normalizados sem duplicação.',
      });
    } catch (err) {
      console.error('Assign missing error', err);
      toast({
        title: 'Erro ao ajustar plano de contas',
        description: err.message,
        variant: 'destructive',
      });
    } finally {
      isAssigningRef.current = false;
    }
  }, [companyId, fetchAccounts, toast]);

  useEffect(() => {
    fetchAccounts();
  }, [fetchAccounts]);

  return {
    accounts,
    loading,
    createAccount,
    updateAccount,
    deleteAccount,
    reorderAccounts,
    assignMissingNumbers,
    refresh: fetchAccounts,
  };
};