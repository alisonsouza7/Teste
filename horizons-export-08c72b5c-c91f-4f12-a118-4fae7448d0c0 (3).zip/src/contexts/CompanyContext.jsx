
import React, { createContext, useContext, useState, useEffect, useMemo, useCallback } from 'react';
import { supabase } from '@/lib/customSupabaseClient';
import { useAuth } from './SupabaseAuthContext';

const CompanyContext = createContext(undefined);

export const CompanyProvider = ({ children }) => {
  const { user, loading: authLoading } = useAuth();
  const [companies, setCompanies] = useState([]);
  const [selectedCompany, setSelectedCompany] = useState(null);
  const [loading, setLoading] = useState(true);

  const fetchCompanies = useCallback(async () => {
    if (!user?.id) {
      setCompanies([]);
      setSelectedCompany(null);
      setLoading(false);
      return;
    }

    setLoading(true);
    try {
      // Fixed query: Removed explicit references to columns that might not exist or are redundant with *
      // Added join to tax_regimes to get limite_faturamento correctly if needed
      const { data, error } = await supabase
        .from('user_company_roles')
        .select(`
          papel,
          companies (
            *,
            tax_regimes (
              nome_exibicao,
              limite_faturamento
            )
          )
        `)
        .eq('user_id', user.id);

      if (error) throw error;
      
      const companiesData = data.map(item => ({
        ...item.companies,
        papel: item.papel
      }));
      
      setCompanies(companiesData);
      
      // Try to keep the selected company if it's still in the list, otherwise select the first one
      if (companiesData.length > 0) {
        setSelectedCompany(prev => {
             if (prev && companiesData.find(c => c.id === prev.id)) {
                 const updated = companiesData.find(c => c.id === prev.id);
                 return updated; // Update with new fields
             }
             return companiesData[0];
        });
      } else {
        setSelectedCompany(null);
      }
      
    } catch (error) {
      console.error('Error fetching companies:', error);
      setCompanies([]);
      setSelectedCompany(null);
    } finally {
      setLoading(false);
    }
  }, [user?.id]);

  useEffect(() => {
    if (!authLoading && user?.id) {
      fetchCompanies();
    } else if (!authLoading && !user) {
        setCompanies([]);
        setSelectedCompany(null);
        setLoading(false);
    }
  }, [user?.id, authLoading, fetchCompanies]);

  const value = useMemo(() => ({
    companies,
    selectedCompany,
    setSelectedCompany,
    loading,
    refreshCompanies: fetchCompanies,
    isPF: selectedCompany?.tipo_cliente === 'pf',
    isPJ: selectedCompany?.tipo_cliente !== 'pf', // Default to PJ if null/undefined
  }), [companies, selectedCompany, loading, fetchCompanies]);

  return <CompanyContext.Provider value={value}>{children}</CompanyContext.Provider>;
};

export const useCompany = () => {
  const context = useContext(CompanyContext);
  if (context === undefined) {
    throw new Error('useCompany must be used within a CompanyProvider');
  }
  return context;
};
