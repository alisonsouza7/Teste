# Component Usage Guide

This document provides examples and guidelines for using the new Chart of Accounts-related UI components.

---

## 1. `AccountCard.jsx`

**Purpose:** Displays an individual financial account (category) within a list, including its number, name, color, and actions. It also integrates drag-and-drop handles.

**Props:**

*   `account` (Object): The account data object (must contain `id`, `account_number`, `nome_conta`, `grupo`, `color`, `is_active`).
*   `onEdit` (Function): Callback function when the edit button is clicked. Receives the `account` object.
*   `onDelete` (Function): Callback function when the delete button is clicked. Receives the `account.id`.
*   `dragHandleProps` (Object): Props to spread onto the drag handle element, typically from `Framer Motion`'s `useDragControls`.
*   `isDragging` (Boolean): A flag indicating if the card is currently being dragged. Used for visual feedback.

**Example Usage:**