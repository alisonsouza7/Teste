# Before vs After: DRE Fixes

## Example 1: Custom Categories Mapping

### BEFORE
**User Action:** Created a category group named "Custos Cloud (AWS/Azure)".
**Code Logic:** `if (group === 'Custos') ...`
**Result:**
*   The group "Custos Cloud" did not match the strict string check.
*   **Report:** Values appeared as "Outras Despesas" or were excluded entirely.
*   **Impact:** Margem Bruta (Gross Margin) was artificially high because costs were missing from the "Cost of Goods/Services" section.

### AFTER
**Code Logic:** `normalizeGroup` detects keyword "Custos".
**Result:**
*   "Custos Cloud" maps to `custos` ID.
*   **Report:** Appears under **(-) Custos (CMV/CSP)**.
*   **Impact:** Correct Gross Margin calculation.

---

## Example 2: Transfers Distortion

### BEFORE
**User Action:** Transferred R$ 50.000 from "Investments" to "Current Account".
**Code Logic:** Fetched `type != 'transferencia'` in some places, but `FinanceDRE.jsx` fetched all and relied on UI filtering that sometimes leaked.
**Result:**
*   Report showed R$ 50.000 as "Receita" or "Outras Entradas" depending on how the category was tagged.
*   **Impact:** Massive inflation of revenue figures.

### AFTER
**Code Logic:** `dreCompute.js`: `if (tx.tipo === 'transferencia') return;` at the very start of the loop.
**Result:**
*   Transaction is strictly ignored.
*   **Impact:** DRE reflects only true economic events, not cash movements.

---

## Example 3: Cash vs Competence Confusion

### BEFORE
**User Action:** Bill due in Jan (Competency), paid in Feb (Cash).
**Code Logic:** Filtered query by `data_competencia` for *both* views.
**Result:**
*   **View "Caixa" (Realized):** Showed the bill in Jan because it used `data_competencia` for filtering, even though it was paid in Feb.
*   **Impact:** Cash flow report did not match bank statement reality.

### AFTER
**Code Logic:** `useDREData.js` switches the filter column:
*   Realizado -> `data_liquidacao`
*   Projetado -> `data_competencia`
**Result:**
*   **View "Caixa":** Bill appears in Feb.
*   **Impact:** Accurate cash flow alignment.