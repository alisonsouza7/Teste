
# Integration Test Checklist: Task Management System

This document outlines the verification steps for the 8 views and new features integrated into the Task Management Dashboard.

## 1. Views Verification

### Kanban View
- [ ] **Drag & Drop**: Verify tasks can be moved between columns.
- [ ] **Optimistic Updates**: Ensure UI updates immediately before server confirmation.
- [ ] **Data Persistence**: Reload page to verify position/column changes persisted.
- [ ] **WIP Limits**: Verify indicators when column exceeds hypothetical limits (if configured).

### Waterfall View
- [ ] **Phases Rendering**: Confirm "Planejamento", "Execução", "Entrega" sections appear.
- [ ] **Expansion**: Verify accordion toggle works for each phase.
- [ ] **Blocking Logic**: Ensure "Execução" shows blocked state if "Planejamento" has incomplete tasks.
- [ ] **Progress Bars**: Check calculation logic (e.g., % of completed tasks within phase).

### ABCDE View
- [ ] **Sections**: Verify 5 distinct sections (A-E) are rendered with correct colors.
- [ ] **Filtering**: Ensure tasks with `priority_abcde` 'A' appear only in 'Crítico'.
- [ ] **Metrics**: Verify "Impacto" and "Urgência" counts update based on task volume.
- [ ] **Empty States**: Verify visual feedback when a priority section is empty.

### Pareto View (80/20)
- [ ] **Chart Rendering**: Confirm Combo Chart (Bar + Line) renders with `recharts`.
- [ ] **Top 20 Calculation**: Verify "Vital Few" list contains approx 20% of tasks with highest scores.
- [ ] **Impact Score**: Check if sorting logic (Priority + Energy) places 'A'/'High Energy' tasks at top.
- [ ] **KPI Cards**: Verify total count and impact % match the dataset.

### Mind Map View
- [ ] **Tree Structure**: Verify Project -> Status -> Task hierarchy.
- [ ] **Collapsible Nodes**: Click chevrons to expand/collapse branches.
- [ ] **Visuals**: Check color coding (Blue=Project, Purple=Status, Green=Task).
- [ ] **Actions**: Verify Edit button works on task nodes.

### List View
- [ ] **Grouping**: Verify grouping selector (Status/Priority/Context) works.
- [ ] **Sorting**: Test sorting by Due Date and Priority.
- [ ] **Completion**: Toggle checkbox and verify task moves to 'completed' state/style.

### Calendar View
- [ ] **Grid Rendering**: Verify correct days/dates for current month.
- [ ] **Task Placement**: Tasks with `due_date` appear on correct cells.
- [ ] **Navigation**: Test Prev/Next month and "Today" buttons.
- [ ] **Interaction**: Clicking a date selects it in side panel.

### Metrics View
- [ ] **Charts**: Verify all 4 charts render (Pie, Bar, Line).
- [ ] **Data Accuracy**: Cross-reference "Total Tasks" card with actual task count.
- [ ] **Responsive**: Check layout on mobile vs desktop.

## 2. Feature Verification

### Floating Action Button (FAB)
- [ ] **Expansion**: Click (+) button, verify menu opens with animation.
- [ ] **Items**: Check all 5 options (Task, Goal, Project, Tag, Event) appear.
- [ ] **Callbacks**: Verify clicking "Nova Tarefa" opens the modal.

### Advanced Filters
- [ ] **Panel Toggle**: Verify "Filtros Avançados" expands/collapses panel.
- [ ] **Filtering Logic**:
    - [ ] Status filter (e.g., only 'todo').
    - [ ] Priority filter (e.g., only 'A').
    - [ ] Text search (title/description).
    - [ ] Overdue checkbox (shows only past due tasks).
- [ ] **Badge**: Verify active filter count badge updates correctly.
- [ ] **Clear**: Verify "Limpar Filtros" resets all fields.

### Automation Hook (`useTaskAutomations`)
- [ ] **Overdue Calculation**: Verify logic correctly identifies past dates.
- [ ] **Pareto Logic**: Verify sorting mechanism prioritizes A/B + High Energy.

## 3. Edge Cases & Error Handling
- [ ] **No Tasks**: Verify all views handle empty task lists gracefully (Empty States).
- [ ] **Network Error**: Simulate offline mode/error and check Toast notifications.
- [ ] **Missing Fields**: Tasks without `priority` or `due_date` should default safely (e.g., 'C' priority, no date on calendar).

## 4. Permissions (RLS)
- [ ] **Company Isolation**: Verify user only sees tasks for `selectedCompany`.
- [ ] **Role Access**: Verify restricted actions (if implemented) for non-admin users.
