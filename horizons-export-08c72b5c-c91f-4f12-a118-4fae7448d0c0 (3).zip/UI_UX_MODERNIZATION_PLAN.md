# UI/UX Modernization Plan: The "Navy & Gold" Horizon

## 1. Executive Summary & Analysis
**Current State:** The application currently uses a standard "slate/gray" dashboard aesthetic typical of default shadcn/ui installations. While functional, it lacks brand identity and visual hierarchy. The mobile experience relies heavily on horizontal scrolling for tables, and the layout is utilitarian.

**Target State:** A professional, authoritative, yet energetic financial interface using a **Deep Navy (Trust/Stability)** and **Bright Yellow (Energy/Growth)** palette. The design will emphasize data readability, clear actions, and mobile-first ergonomics.

---

## 2. Design System & Tokens
We will shift the global CSS variables to the new palette.

### Color Palette Strategy
*   **Primary (Navy):** Used for navigation, active states, primary buttons, and headers.
*   **Secondary (Yellow):** Used for high-priority actions (CTAs), highlights, and "Premium" indicators.
*   **Background (White/Gray):** Clean white content areas on very light cool-gray backgrounds to create depth.

### CSS Variables (`src/index.css`)