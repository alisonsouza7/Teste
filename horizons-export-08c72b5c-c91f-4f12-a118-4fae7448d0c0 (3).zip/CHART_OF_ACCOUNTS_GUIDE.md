# Chart of Accounts Enhancement Guide

This document provides a comprehensive overview of the recent enhancements to the Chart of Accounts system, focusing on new features, design principles, and how to utilize them effectively.

---

## 1. Overview of Changes

The Chart of Accounts (Plano de Contas) has undergone a significant modernization to provide users with better organization, clarity, and control over their financial categories. Key enhancements include:

*   **Hierarchical Account Numbering:** Each category now has a unique, structured `account_number` that helps classify it within specific financial types (Receita, Custo, Despesa, Outros).
*   **Custom Reordering:** Categories within each type can now be reordered using a drag-and-drop interface, allowing users to define their preferred display sequence.
*   **Color Coding:** Assign visual `color` tags to categories for quick identification and improved visual grouping in reports and lists.
*   **Activation Status:** Categories can be set as `is_active` (active) or inactive, providing a soft-delete mechanism to manage historical data without permanent deletion.
*   **Enhanced Management UI:** A redesigned interface consolidates creation, editing, and reordering functionalities, making category management more intuitive.
*   **Improved Export:** Export functionalities now include the new account number and active status for better data integration with external systems.

---

## 2. Account Numbering System

The new account numbering system follows a predefined hierarchical structure to provide logical grouping and easy identification of account types.

*   **1000 - 1999**: **Receitas (Revenues)**
    *   Examples: Vendas de Produtos, Serviços Prestados, Juros Recebidos.
*   **2000 - 2999**: **Custos (Costs)**
    *   Examples: Custo da Mercadoria Vendida (CMV), Custo do Serviço Prestado (CSP), Matéria-Prima.
*   **3000 - 3999**: **Despesas (Expenses)**
    *   Examples: Aluguel, Salários, Despesas de Marketing, Impostos.
*   **4000 - 4999**: **Outras (Other)**
    *   Used for categories that don't fit neatly into the above, such as Investimentos, Transferências, etc.

**Auto-Generation:** When creating a new account, the system automatically suggests the next available `account_number` within its `tipo` (type). Users can manually override this, but it must adhere to the type's range.

---

## 3. Color Palette

A predefined color palette is available for assigning visual tags to each category. This helps in quickly distinguishing categories, especially in visual reports or lists.

**Predefined Colors (Hex Values):**

*   **Navy**: `#06407a`
*   **Blue**: `#3b82f6`
*   **Sky**: `#0ea5e9`
*   **Emerald**: `#10b981`
*   **Green**: `#22c55e`
*   **Yellow**: `#fcd322`
*   **Amber**: `#f59e0b`
*   **Orange**: `#f97316`
*   **Red**: `#ef4444`
*   **Purple**: `#a855f7`
*   **Pink**: `#ec4899`
*   **Slate**: `#64748b` (Default)

The selected color is displayed as a small circle next to the account name and in the edit modal.

---

## 4. Reordering Mechanism

Categories within each `tipo` (Receita, Custo, Despesa, Investimento) can be reordered using a simple drag-and-drop interface.

*   **Drag Handles:** Each account card has a `GripVertical` icon on the left. Click and hold this icon to drag the card.
*   **Optimistic Updates:** The UI updates immediately upon dragging, providing instant visual feedback. The changes are then asynchronously saved to the database.
*   **Scope:** Reordering is specific to each type. You cannot drag a "Receita" category into the "Despesa" section.

---

## 5. Edit/Create/Delete Flows

### Create New Category
1.  Click the "Nova Categoria" button at the top of the page, or the `+` button within a specific section card.
2.  The `AccountEditModal` will open.
3.  **Tipo (Type):** Select the financial type (Receita, Despesa, Custo, Investimento). This selection determines the suggested `account_number` range. This field is read-only after creation.
4.  **Número (Number):** The system auto-generates a unique number. You can override it, but it must be unique within your company and adhere to the selected `tipo`'s range. This field is read-only after creation.
5.  **Nome da Conta:** Enter a descriptive name for the category.
6.  **Grupo DRE (Optional):** Assign a group for DRE reporting.
7.  **Cor da Etiqueta:** Select a color using the color picker.
8.  Click "Salvar" to create the category.

### Edit Existing Category
1.  Hover over an account card to reveal the action buttons (`Edit2` and `Trash2` icons).
2.  Click the `Edit2` (pencil) icon.
3.  The `AccountEditModal` will open, pre-filled with the account's current data.
4.  You can update the `nome_conta`, `grupo`, `color`, and toggle its `is_active` status.
5.  **`account_number` and `tipo` are read-only** to maintain data integrity and prevent numbering conflicts.
6.  Click "Salvar" to apply changes.

### Delete Category (Soft Delete)
1.  Hover over an account card and click the `Trash2` (trash can) icon.
2.  Alternatively, open the `AccountEditModal` for an existing account and toggle the `is_active` switch to `off`.
3.  The system performs a "soft delete" by setting the `is_active` flag to `false`. This keeps historical transaction data intact while removing the category from active lists.
4.  Currently, there is no UI to view or reactivate inactive accounts, but the mechanism is in place for future enhancements.

---

## 6. Export Format

The export functionality for Chart of Accounts and Transactions has been enhanced to include the new `account_number` and `is_active` status.

### Chart of Accounts Export
*   **File Format:** CSV
*   **Encoding:** UTF-8 (BOM for Excel compatibility)
*   **Columns:**
    *   `Código`: `account_number`
    *   `Nome`: `nome_conta`
    *   `Tipo`: `tipo`
    *   `Grupo DRE`: `grupo`
    *   `Status`: `is_active` (displayed as "Ativo" or "Inativo")
    *   `Cor`: `color` (hex value)

### Transactions Export
*   **File Format:** CSV
*   **Encoding:** UTF-8 (BOM for Excel compatibility)
*   **New Column:**
    *   `Código Conta`: Includes the `account_number` of the associated category.
    *   All other existing transaction fields (`data_competencia`, `descricao`, `valor`, `status`, etc.) remain.

This enhanced export provides a more complete dataset for external analysis and reporting.