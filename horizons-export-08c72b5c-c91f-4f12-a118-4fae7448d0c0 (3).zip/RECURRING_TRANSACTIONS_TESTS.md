# Test Plan: Recurring Transactions

## 1. Unit Tests (Logic Verification)

### Date Calculation
*   **Input:** Start `2024-01-31`, Freq `Monthly`, Interval `1`.
*   **Expected:** `2024-02-29` (Leap year handling).
*   **Input:** Start `2024-01-15`, Freq `Weekly`, Interval `2`.
*   **Expected:** `2024-01-29`.

### Deduplication Logic
*   **Scenario:** Run `generateNextOccurrences` twice consecutively.
*   **Expectation:**
    *   Run 1: Inserts 1 transaction, updates `next_execution_date`.
    *   Run 2: Inserts 0 transactions, makes no changes (or just updates date if stale).

## 2. Integration Tests (Generation)

### `createRecurrence`
*   Verify it throws error if `template_transaction_id` is missing.
*   Verify it defaults `interval_count` to 1 if missing.

### `generateNextOccurrences`
*   Verify it correctly copies `descricao`, `valor`, `categoria_id`, `conta_id` from template.
*   Verify it sets `liquidado = false` (future occurrences should be pending).
*   Verify it appends "(Automático)" or similar marker to description (if implemented).

## 3. Manual Test Scenarios

### Scenario A: Create Simple Monthly Recurrence
1.  Open "Nova Despesa".
2.  Fill: "Aluguel", R$ 2000, Date: Today.
3.  Toggle "Repetir", Select "Mensal", Interval "1".
4.  Save.
5.  **Check:**
    *   Transaction appears in list.
    *   DB: `finance_recurrences` has 1 row linked to this transaction.
    *   DB: `next_execution_date` is Today + 1 Month.

### Scenario B: Automation Trigger
1.  Manually update a recurrence rule in DB: set `next_execution_date` to **Yesterday**.
2.  Refresh the `FinanceTransactions` page (triggers `useRecurringTransactions` hook).
3.  **Check:**
    *   New transaction appears for "Yesterday".
    *   Recurrence rule `next_execution_date` advances to next month.

### Scenario C: Pausing
1.  (Via DB or Future UI) Set `is_active = false` on a recurrence.
2.  Set `next_execution_date` to Yesterday.
3.  Refresh page.
4.  **Check:** No new transaction is generated.

### Scenario D: End Date
1.  Create recurrence with `end_date` = Next Month.
2.  Wait/Simulate 2 months passing.
3.  **Check:** Automation stops generating after the end date.

### Scenario E: Edit Template
1.  Edit the original transaction (e.g., change value).
2.  Wait for next recurrence.
3.  **Check:** Does the new transaction use the *new* value or the *original* snapshot? (System design: usually uses current state of template transaction).