# Account Numbering System Specification

This document details the technical specifications and rules governing the `account_number` field in the `finance_chart_of_accounts` table.

---

## 1. Numbering Rules (Ranges)

The system enforces distinct numerical ranges for different types of financial accounts, aiding in logical organization and automated classification.

| Account Type (`tipo` field) | Number Range | Description |
| :-------------------------- | :----------- | :---------- |
| `receita` (Revenue)         | 1000 - 1999  | Accounts representing income and earnings. |
| `custo` (Cost)              | 2000 - 2999  | Accounts related to the direct cost of goods sold or services provided. |
| `despesa` (Expense)         | 3000 - 3999  | Accounts for operational, administrative, and selling expenses. |
| `investimento` (Investment) | 4000 - 4999  | Accounts for assets purchased for future income or appreciation. |
| `other` (Fallback)          | 4000 - 4999  | Used if a `tipo` doesn't explicitly match a defined range or for general classification. |

**Key Constraint**: An `account_number` must fall within the range dictated by its `tipo`.

---

## 2. Examples

Here are concrete examples of how `account_number` would be assigned for various `tipo`s:

*   **Receita:**
    *   `1000`: Vendas de Produtos
    *   `1001`: Serviços de Consultoria
    *   `1002`: Juros Recebidos
*   **Custo:**
    *   `2000`: Custo da Mercadoria Vendida (CMV)
    *   `2001`: Matéria-Prima Utilizada
    *   `2002`: Custos de Produção Diretos
*   **Despesa:**
    *   `3000`: Aluguel
    *   `3001`: Salários e Encargos
    *   `3002`: Despesas de Marketing e Publicidade
    *   `3003`: Energia Elétrica
*   **Investimento (or Other):**
    *   `4000`: Aquisição de Ativos Fixos
    *   `4001`: Participações Societárias

---

## 3. Auto-Increment Logic (`generateAccountNumber` function)

The `generateAccountNumber` function (located in `src/lib/accountNumbering.js`) is responsible for providing the next available `account_number` within a given `tipo`'s range.

**Algorithm:**

1.  **Determine Range:** Based on the `tipo`, identify the `start` and `end` numerical bounds (e.g., `receita` uses 1000-1999).
2.  **Collect Used Numbers:** Retrieve all existing `account_number`s for the current `company_id` that fall within the determined range and are associated with the same `tipo`.
3.  **Sort Used Numbers:** Sort the collected numbers in ascending order.
4.  **Find First Gap:** Iterate from the `start` of the range.
    *   If the current `start` number is not present in the `usedNumbers` array, then `start` is the next available number.
    *   If a number is found, increment `start` and continue.
5.  **Handle No Gaps:** If the iteration completes and no gap is found (meaning all numbers from `start` to the highest used number are taken), the next available number is `highest_used_number + 1`.
6.  **Range Overflow:** If `highest_used_number + 1` exceeds the `end` of the range, it indicates the range is full. For simplicity, the function will currently return the `end` of the range (this scenario is highly unlikely for a typical Chart of Accounts).

**Example:**
If `tipo` is `despesa` (range 3000-3999) and existing numbers are `[3000, 3001, 3003, 3004]`:
`generateAccountNumber('despesa', existingNumbers)` would return `"3002"`.
If existing numbers are `[3000, 3001, 3002, 3003]`:
`generateAccountNumber('despesa', existingNumbers)` would return `"3004"`.

---

## 4. Validation Rules (`validateAccountNumber` function)

The `validateAccountNumber` function (located in `src/lib/accountNumbering.js`) ensures that any manually entered or auto-generated `account_number` conforms to the established rules.

**Rules Applied:**

1.  **Numerical Check:** The input `number` must be a valid integer.
2.  **Type Range Adherence:** The `number` must fall inclusively within the `start` and `end` range defined for the given `tipo`.

**Example:**
*   `validateAccountNumber('1005', 'receita')`: `true`
*   `validateAccountNumber('2000', 'receita')`: `false` (2000 is for `custo`)
*   `validateAccountNumber('abc', 'despesa')`: `false`
*   `validateAccountNumber('3000', 'despesa')`: `true`
*   `validateAccountNumber('3000', 'custo')`: `false` (3000 is for `despesa`)

These rules ensure the integrity and consistency of the account numbering system across the application.