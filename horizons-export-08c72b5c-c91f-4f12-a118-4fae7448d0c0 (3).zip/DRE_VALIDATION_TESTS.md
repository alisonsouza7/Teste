# DRE Validation Test Scenarios

## Test Case 1: The "Simple Month"
**Setup:**
*   1 Receita (Venda) of R$ 10.000 (Liquidado).
*   1 Despesa (Aluguel) of R$ 2.000 (Liquidado).
*   Date Range: Current Month.
*   View: Realizado.

**Expected Result:**
*   **Receita Operacional Bruta:** R$ 10.000.
*   **Despesas Fixas:** R$ 2.000.
*   **Resultado do Exercício:** R$ 8.000.
*   **AV% Aluguel:** 20%.

---

## Test Case 2: Unlinked Transactions (Quality Check)
**Setup:**
*   Create a transaction of R$ 500, type 'despesa', but **do not select a category** (or force null in DB).
*   Refresh DRE.

**Expected Result:**
*   **Quality Panel:** Appears at top. Message: "1 lançamentos sem categoria vinculada".
*   **DRE Table:** The R$ 500 might appear under "Outras" or "Unmapped" depending on fallback logic, but the warning is mandatory.

---

## Test Case 3: Transfer Exclusion
**Setup:**
*   Create a transfer of R$ 5.000 from Bank A to Bank B.
*   Refresh DRE.

**Expected Result:**
*   **Total Revenue/Expense:** Should NOT change.
*   **Drill Down:** Should NOT find this transaction in any expense group.

---

## Test Case 4: Realizado vs Projetado
**Setup:**
*   Tx A: R$ 1.000 (Receita), Date: Today, **Liquidado: YES**.
*   Tx B: R$ 2.000 (Receita), Date: Today, **Liquidado: NO**.

**Expected Result:**
*   **View "Realizado":** Revenue = R$ 1.000.
*   **View "Projetado":** Revenue = R$ 2.000.
*   **View "Ambos":** Revenue = R$ 3.000.

---

## Test Case 5: Annual View with Monthly Columns
**Setup:**
*   Tx Jan: R$ 100.
*   Tx Feb: R$ 200.
*   Filter: Jan 1st to Feb 28th.
*   Mode: Monthly View.

**Expected Result:**
*   **Column Jan:** R$ 100.
*   **Column Feb:** R$ 200.
*   **Total Column:** R$ 300.
*   **Row "Receita":** Shows individual values per month.

---

## Test Case 6: Drill-Down Accuracy
**Setup:**
*   DRE shows "Material de Escritório": R$ 150.
*   Click the row.

**Expected Result:**
*   Modal opens.
*   List shows exactly the transactions summing to R$ 150.
*   Summing manually the rows in modal matches the DRE line.