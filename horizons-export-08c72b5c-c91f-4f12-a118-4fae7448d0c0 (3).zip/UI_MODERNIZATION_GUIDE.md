# UI/UX Modernization Guide: The "Navy & Gold" Horizon

## 1. Design System Overview
This modernization shifts the application from a generic utility dashboard to a professional, high-trust financial interface. The design language relies on a strong "Navy & Gold" palette, utilizing whitespace and subtle gradients to create depth and hierarchy.

### Color Palette Strategy
*   **Primary (Navy - `hsl(220 90% 25%)`)**: Used for high-level navigation, primary actions, and headers. Represents stability, trust, and authority.
*   **Secondary (Yellow - `hsl(45 96% 56%)`)**: Used for accenting, highlighting call-to-actions, and drawing attention to positive trends. Represents energy and growth.
*   **Backgrounds**: We moved away from pure gray (`slate-100`) to a cooler, lighter tone (`hsl(210 40% 98%)`) to reduce eye strain and modernize the feel.
*   **Surfaces**: Cards are strictly white with subtle borders and shadows to pop against the cool background.

### Design Tokens (CSS Variables)
Defined in `src/index.css`:
*   `--primary`: Deep Navy (#06407a)
*   `--secondary`: Bright Yellow (#fcd322)
*   `--radius`: `0.75rem` (12px) - Softer, friendlier corners than the previous 4px/8px default.
*   `--shadow-card`: Soft shadow for depth without clutter.
*   `--shadow-elevated`: Stronger shadow for hover states and modals.

---

## 2. Component Library
We have introduced "Compound Components" to standardize page layouts and reduce code repetition.

### `PageHeader`
**Purpose:** Standardizes the top section of every page.
**Features:**
*   Automatic breadcrumb rendering.
*   Subtle top gradient border for brand consistency.
*   Responsive layout (stacks on mobile, row on desktop).
**Usage:**