# Chart of Accounts Enhancement Implementation Plan

This document outlines the comprehensive strategy to modernize the Chart of Accounts system, introducing hierarchical numbering, custom ordering, color coding, and enhanced management capabilities.

## 1. Database Schema Evolution

### Target Table: `finance_chart_of_accounts`

We need to extend the existing table to support the new features.

#### New Columns
| Column Name | Type | Constraints | Description |
| :--- | :--- | :--- | :--- |
| `account_code` | `text` | `UNIQUE(company_id, account_code)` | Hierarchical code (e.g., "1.01", "2.05"). Replaces `account_number` concept for flexibility. |
| `display_order` | `integer` | `DEFAULT 0` | Controls visual sequence within its parent/type group. |
| `color` | `text` | `DEFAULT '#cbd5e1'` | Hex code for UI badges/tags. |
| `is_active` | `boolean` | `DEFAULT true` | Soft delete mechanism for historical data integrity. |
| `parent_id` | `uuid` | `FK to self` | *Existing*, but critical for hierarchy logic. |

#### Migration SQL (Draft)