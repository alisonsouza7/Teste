# Implementation Checklist: Recurring Transactions

## 1. Database Migration
- [x] **Table Creation:** `finance_recurrences` table created with correct UUID types.
- [x] **Foreign Keys:** Linked `company_id` and `template_transaction_id` correctly.
- [x] **Back-link:** Added `recurrence_id` column to `finance_transactions` table.
- [x] **Indexes:** Added composite indexes for performance (`idx_finance_recurrences_company_active_next`).
- [x] **RLS Policies:** Implemented Row Level Security for SELECT, INSERT, UPDATE, DELETE based on `company_id`.

## 2. Service Function Deployment
- [x] **Date Logic:** Verified `calculateNextDate` handles month rollovers correctly (e.g., Jan 31 -> Feb 28).
- [x] **Creation Logic:** `createRecurrence` captures the template transaction ID.
- [x] **Generation Logic:** `generateNextOccurrences` queries only active rules where `next_execution_date <= today`.
- [x] **Deduplication:** Confirmed `maybeSingle()` check prevents duplicate inserts for the same period.
- [x] **State Update:** Confirmed `next_execution_date` advances only after successful insertion.

## 3. Component Integration Verification
- [x] **Form UI:** `RecurrenceForm.jsx` integrated into `FinanceTransactions.jsx`.
- [x] **Conditional Rendering:** Recurrence fields only appear when toggle is checked.
- [x] **Save Flow:** Transaction is saved first, then Recurrence rule is created using the new ID.
- [x] **Feedback:** Toast notifications confirm "Recorrência Configurada".

## 4. UI Testing Scenarios
- [ ] **Toggle Interaction:** Clicking "Repetir" reveals form immediately.
- [ ] **Validation:** Ensure "Intervalo" cannot be less than 1.
- [ ] **Date Selection:** Ensure "Data Término" allows clearing (for indefinite).
- [ ] **Responsiveness:** Form looks good on mobile devices.

## 5. Edge Cases Testing
- [ ] **Leap Years:** Test Feb 29th recurrences (should map to Feb 28 or Mar 1 in non-leap years).
- [ ] **End Dates:** Verify recursion stops exactly after `end_date`.
- [ ] **Deleted Template:** Ensure system handles cases where the original transaction was deleted (should pause recurrence).
- [ ] **Permissions:** Verify a "Client" user cannot see recurrences of another company.