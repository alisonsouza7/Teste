# DRE Implementation & Verification Checklist

## 1. Database & Schema Verification
- [ ] **Foreign Keys:** Confirm `finance_transactions.categoria_id` correctly points to `finance_chart_of_accounts.id`.
- [ ] **Group Names:** Query distinct `grupo` values from `finance_chart_of_accounts` to ensure the Normalization Logic covers all current variations.
- [ ] **Indexes:** Verify index on `finance_transactions(company_id, deleted_at, data_competencia)` for fast filtering.

## 2. Code Integration
- [ ] **Hook Implementation:** `useDREData.js` should return `dreData`, `monthlyData`, and `qualityReport` without errors.
- [ ] **Compute Logic:** Verify `calculateDREStructure` correctly sums values (Revenue positive, Expenses negative/positive depending on display logic).
- [ ] **Sign Logic:** Ensure "Deduções" decreases the Net Revenue and "Custos" decreases the Gross Profit.

## 3. Component Rendering
- [ ] **Standard View:**
    - [ ] Hierarchy renders correctly (Groups -> Accounts).
    - [ ] Totals (bold rows) match the sum of children.
    - [ ] Percentages (AV%) are calculated against Net Revenue.
- [ ] **Monthly View:**
    - [ ] Columns appear for all months in range.
    - [ ] Horizontal totals match the Standard View totals.
- [ ] **Drill Down:**
    - [ ] Modal opens on click.
    - [ ] Transactions listed match the total value of the row.

## 4. Data Accuracy Tests
- [ ] **Realizado vs Projetado:**
    - [ ] Filter "Realizado": Should only sum `liquidado = true`.
    - [ ] Filter "Projetado": Should only sum `liquidado = false`.
    - [ ] Filter "Ambos": Sum of all.
- [ ] **Zero Values:** Toggle "Mostrar contas zeradas" should reveal/hide rows correctly.
- [ ] **Transfers:** Create a Transfer transaction and ensure it **DOES NOT** appear in the DRE.

## 5. Edge Cases
- [ ] **Empty Period:** Select a date range with no transactions. DRE should render empty state/zeros, not crash.
- [ ] **Deleted Categories:** Transactions linked to a soft-deleted category should still appear (mapped via ID), or flag as "Unmapped" if the join fails completely.
- [ ] **Cross-Year Filter:** Select Dec 2023 to Jan 2024. Monthly view should show both columns.

## 6. Performance
- [ ] **Bulk Data:** Load 1,000+ transactions. Render time should be under 1s.
- [ ] **Drill Down:** Opening drill down should be instant (filtered in memory).