# DRE Restructuring & Implementation Plan

## 1. Diagnostic Analysis

### Database Relationships & Foreign Keys
*   **Path:** `finance_transactions.categoria_id` → `finance_chart_of_accounts.id`
*   **Critical Dependency:** The DRE structure relies entirely on the `grupo` and `tipo` text columns in the `finance_chart_of_accounts` table.
*   **Current Weakness:** The link is "loose" regarding aggregation. There is no `dre_section_id`. The system relies on string matching (e.g., `grupo === 'Despesas Fixas'`). If a user renames a group to "Despesas Fixas ADM", the current mapping logic might fail or categorize it as "Outras".

### Current Grouping Logic (`FinanceDRE.jsx`)
*   **Mechanism:** Client-side aggregation.
*   **Flow:** 
    1. Fetches *all* transactions for the period.
    2. Fetches *all* categories.
    3. Iterates transactions → Sums into `totalsByCategory`.
    4. Iterates categories → Maps `grupo` string to hardcoded DRE Sections.
*   **Exclusions:** 
    *   **Implicit:** Transactions with `tipo = 'transferencia'` are technically fetched but usually fail the `mapGroup` function (returning `null`), effectively excluding them from the view.
    *   **Explicit:** `deleted_at` is filtered in the query.
*   **Realizado vs. Projetado:**
    *   Separation is done via the `liquidado` boolean flag on each transaction.
    *   `liquidado = true` → Realizado.
    *   `liquidado = false` → Projetado.

### Identified Bugs & Issues
1.  **Date Filter Mismatch:** The current query filters by `data_competencia` (via `applyPeriodFilterToQuery`). However, a true "Realizado" (Cash) view should conceptually filter by `data_liquidacao`. Mixing these can cause confusion (e.g., a bill due in Jan but paid in Feb shows in Jan's Realized DRE, which is "Competency Realized", not "Cash Flow").
2.  **Unmapped Categories:** If a user creates a custom Category Group that isn't in the hardcoded `mapGroup` switch case, those values disappear from the report or fall into a generic bucket without warning.
3.  **Performance:** Fetching raw transactions (SELECT *) becomes heavy as data grows. Aggregation should ideally happen closer to the database or be memoized.

---

## 2. Proposed Restructuring (The Fix)

### Core Philosophy
Move away from "Hardcoded UI Logic" to a "Computed Service" approach. We will introduce a centralized `dreCompute.js` utility that handles the messy mapping logic, ensuring consistency between the table, charts, and exports.

### A. New Utility: `src/lib/dreCompute.js`
This file will contain pure functions to process data:
*   `computeDRE(transactions, categories)`: Returns a structured DRE object.
*   `normalizeDREGroup(dbGroup)`: A fuzzy matcher that maps database strings like "Custos de Produção" to the canonical "Custos" section.
*   **Validation:** It will flag "Orphaned Transactions" (transactions with categories that don't match any known DRE section).

### B. Grouping Logic Update
Instead of an exact match, we will use a "Tiered Fallback" system:
1.  **Exact Match:** `grupo` === 'Receita Operacional'
2.  **Keyword Match:** `grupo` contains 'Receita' → 'Receita Operacional'
3.  **Type Fallback:** `tipo` === 'receita' → 'Outras Receitas'
4.  **Catch-all:** Everything else → 'Outras Despesas' (Flagged as warning).

---

## 3. Implementation Steps

### Step 1: Create Compute Utility (`dreCompute.js`)
*   **Action:** Extract aggregation logic from `FinanceDRE.jsx`.
*   **Feature:** Implement `deduplicateAndSum` to handle multiple transactions.
*   **Feature:** Implement `getOrphanedTransactions` to return a list of items that didn't fit cleanly into sections.

### Step 2: Create Data Hooks (`useDREData.js`)
*   **Action:** Create a custom hook that fetches transactions and categories.
*   **Optimization:** Implement `useMemo` to prevent re-calculation on every render.
*   **Query Update:** Ensure we select `categoria(nome_conta, grupo, tipo)` in the join to avoid N+1 issues.

### Step 3: Refactor `FinanceDRE.jsx`
*   Replace internal `useEffect` logic with `useDREData`.
*   Pass the computed DRE object to components instead of raw states.

### Step 4: Implement New Components
*   **`DRETable.jsx`**: A dumb component that just renders the rows.
*   **`DREQualityPanel.jsx`**: An alert box that appears ONLY if `orphanedTransactions.length > 0`, warning the user that some values might be missing from the report due to bad categorization.
*   **`DREDrillDown.jsx`**: A modal triggered by clicking a DRE row. It shows the raw transactions composing that number.

---

## 4. File Structure Changes