# Export Format Specification

This document details the standardized export formats for Chart of Accounts (Plano de Contas) and Financial Transactions, incorporating new fields and ensuring compatibility for external data analysis.

---

## 1. General Export Principles

*   **Format:** CSV (Comma Separated Values)
*   **Encoding:** UTF-8 with BOM (Byte Order Mark) to ensure proper display of special characters (e.g., accents, cedillas) in spreadsheet software like Microsoft Excel.
*   **Delimiters:** Comma (`,`) for fields, Newline (`\n` or `\r\n`) for rows.
*   **Quoting:** Fields containing commas, newlines, or double quotes will be enclosed in double quotes. Any double quotes within a quoted field will be escaped by a preceding double quote (e.g., `"Value with ""quotes"" "`).

---

## 2. Chart of Accounts Export (`CATEGORIES` Schema)

This export provides a comprehensive list of all defined financial categories for a company, including their new attributes.

**File Name Convention:** `Plano_de_Contas_YYYY-MM-DD.csv`

**Columns and Data Mapping:**

| Header (CSV)   | Internal Field Name (`finance_chart_of_accounts` column) | Description                                                | Example Value                      |
| :------------- | :------------------------------------------------------- | :--------------------------------------------------------- | :--------------------------------- |
| `Código`       | `account_number`                                         | Unique numerical identifier for the account.               | `1001`                             |
| `Nome`         | `nome_conta`                                             | The display name of the account.                           | `Vendas de Produtos`               |
| `Tipo`         | `tipo`                                                   | The general type of the account (e.g., `receita`, `despesa`). | `receita`                          |
| `Grupo DRE`    | `grupo`                                                  | An optional grouping for DRE reporting.                    | `Receita Operacional Bruta`        |
| `Status`       | `is_active` (derived)                                    | Indicates if the account is active or inactive.            | `Ativo` / `Inativo`                |
| `Cor`          | `color`                                                  | The hexadecimal color code assigned to the account.        | `#10b981` (Emerald Green)          |

---

## 3. Financial Transactions Export (`TRANSACTIONS` Schema)

This export provides a detailed record of all financial transactions, now enriched with the `account_number` of the associated category.

**File Name Convention:** `Exportacao_transactions_YYYY-MM-DD.csv`

**Columns and Data Mapping (including new fields):**

| Header (CSV)         | Internal Field Name (`finance_transactions` or joined) | Description                                                 | Example Value             |
| :------------------- | :----------------------------------------------------- | :---------------------------------------------------------- | :------------------------ |
| `Data Competência`   | `data_competencia`                                     | Date the transaction belongs to (YYYY-MM-DD).               | `2026-01-01`              |
| `Data Vencimento`    | `vencimento`                                           | Due date of the transaction (YYYY-MM-DD).                   | `2026-01-10`              |
| `Descrição`          | `descricao`                                            | Short description of the transaction.                       | `Compra de material de escritório` |
| `Valor`              | `valor`                                                | Amount of the transaction.                                  | `150.75`                  |
| `Tipo`               | `tipo`                                                 | Type of transaction (e.g., `receita`, `despesa`).           | `despesa`                 |
| `Conta`              | `finance_accounts.nome_conta`                          | Name of the financial account involved.                     | `Conta Corrente PJ`       |
| **`Código Conta`**   | `finance_chart_of_accounts.account_number`             | **NEW:** Numerical code of the associated category.         | `3005`                    |
| `Categoria`          | `finance_chart_of_accounts.nome_conta`                 | Name of the associated category.                            | `Material de Escritório`  |
| `Cliente/Fornecedor` | `finance_parties.nome`                                 | Name of the associated client/supplier/party.               | `Papelaria ABC Ltda`      |
| `Status`             | `liquidado` (derived)                                  | Status of the transaction (e.g., `Liquidado`, `Aberto`).    | `Liquidado`               |
| `Data Liquidação`    | `data_liquidacao`                                      | Date the transaction was settled (YYYY-MM-DD).              | `2026-01-05`              |
| `Conta Origem`       | `finance_accounts_origin.nome_conta` (for transfers)   | Name of the origin account for transfers.                   | `Caixa`                   |
| `Conta Destino`      | `finance_accounts_destination.nome_conta` (for transfers) | Name of the destination account for transfers.              | `Poupança Empresarial`    |

This detailed format ensures that all relevant data points are available for external analysis, reporting, and integration.