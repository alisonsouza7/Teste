# DRE Restructuring Guide

## 1. Overview of Changes
The DRE (Demonstração do Resultado do Exercício) module has been completely restructured to ensure financial accuracy, improve performance, and provide deeper analytical capabilities.

### Key Improvements:
*   **Computation Logic:** Moved from scattered frontend logic to a centralized `dreCompute.js` utility.
*   **Fuzzy Matching:** Implemented a robust mapping system that links categories to DRE sections even if group names vary slightly (e.g., "Custos" vs "CMV/Custos").
*   **Quality Control:** Added a dedicated panel to warn users about data inconsistencies (e.g., transactions without categories).
*   **Interactive Drill-Down:** Users can now click on any line item to see the raw transactions composing that number.
*   **Monthly Breakdown:** Added a pivot table view to analyze trends over the year.

---

## 2. How the Vínculo (Linking) Was Fixed
Previously, the DRE relied on exact string matches between the database `grupo` column and hardcoded UI switches. If a user created a group called "Despesas Administrativas" instead of "Despesas Fixas", it would disappear or fall into "Outros".

**The New Solution:**
We introduced a **Normalization Layer** in `src/lib/dreCompute.js`: